# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          acp1_dependency_graph.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
acp1_dependency_graph.py — Labyrinth-OS
========================================
ACP-1 Assumption Register — Directed Dependency Graph
with Automatic Collapse Propagation

Replaces the flat ACP-1 tracker. Every assumption declares what it
depends on. When a parent assumption moves to OPEN or AT_RISK, all
downstream dependents automatically flag as AT_RISK.

The flat list hid fragility. This graph makes it visible.
A VERIFIED assumption that secretly depends on three OPEN assumptions
is shown as AT_RISK, not VERIFIED.

Inspired by the epistemic layer framework in:
  Delgado, S. (2026). Spectral Selection in the Leech Substrate.
  Classification: ANALOGY — the structural principle of collapse
  propagation through dependency chains, extracted without
  the cosmological claims.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, List, Optional, Set


@unique
class AStatus(str, Enum):
    VERIFIED = "VERIFIED"
    PARTIAL  = "PARTIAL"
    OPEN     = "OPEN"
    AT_RISK  = "AT_RISK"   # inherited via collapse propagation


@unique
class EpistemicLayer(str, Enum):
    """
    G11 — Three epistemic layers from THEORETICAL_FOUNDATIONS.md.

    Applied to every assumption so collapse propagation is layer-aware.

    LAYER_I:   Z3-PROVEN or TEST-VERIFIED. Stands unconditionally.
               Layer I assumptions cannot collapse due to Layer II/III failures.

    LAYER_II:  Mechanistically defined, not yet empirically verified under live
               adversarial conditions. Depends on Layer I. If Layer II fails,
               Layer III collapses with it.

    LAYER_III: Full vision — conditional on Layer II holding under live conditions.
               Hardware enforcement, semantic replay, multi-domain deployment,
               continuous live calibration.
    """
    LAYER_I   = "LAYER_I"    # Z3-proven or test-verified — unconditional
    LAYER_II  = "LAYER_II"   # prototype-wired — depends on Layer I
    LAYER_III = "LAYER_III"  # not yet demonstrated — depends on Layer II


@dataclass
class Assumption:
    id:           str
    claim:        str
    status:       AStatus
    evidence:     str
    gap:          Optional[str]
    depends_on:   List[str]
    falsifiable:  str
    category:     str
    layer:        EpistemicLayer = EpistemicLayer.LAYER_II  # default conservative

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "claim":       self.claim,
            "status":      self.status.value,
            "evidence":    self.evidence,
            "gap":         self.gap,
            "depends_on":  self.depends_on,
            "falsifiable": self.falsifiable,
            "category":    self.category,
            "layer":       self.layer.value,
        }


@dataclass(frozen=True)
class CollapseReport:
    triggered_by: str
    at_risk:      List[str]
    chains:       List[List[str]]
    timestamp:    float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "triggered_by": self.triggered_by,
            "at_risk":      self.at_risk,
            "chains":       self.chains,
            "timestamp":    self.timestamp,
        }


class ACP1DependencyGraph:
    """
    Directed dependency graph for ACP-1 assumptions.
    Collapse propagates automatically via BFS from any OPEN node.
    """

    def __init__(self) -> None:
        self._a: Dict[str, Assumption] = {}

    def add(self, a: Assumption) -> None:
        self._a[a.id] = a

    def get(self, aid: str) -> Optional[Assumption]:
        return self._a.get(aid)

    def update_status(
        self, aid: str, status: AStatus
    ) -> Optional[CollapseReport]:
        if aid not in self._a:
            return None
        self._a[aid].status = status
        if status in (AStatus.OPEN, AStatus.AT_RISK):
            return self._propagate(aid)
        return None

    def _propagate(self, root: str) -> CollapseReport:
        # Build reverse map
        rev: Dict[str, List[str]] = {aid: [] for aid in self._a}
        for aid, a in self._a.items():
            for dep in a.depends_on:
                if dep in rev:
                    rev[dep].append(aid)

        at_risk: List[str] = []
        chains:  List[List[str]] = []
        queue:   List[tuple] = [(root, [root])]
        visited: Set[str] = {root}

        while queue:
            cur, path = queue.pop(0)
            for child_id in rev.get(cur, []):
                if child_id not in visited:
                    visited.add(child_id)
                    child = self._a[child_id]
                    if child.status in (AStatus.VERIFIED, AStatus.PARTIAL):
                        child.status = AStatus.AT_RISK
                        at_risk.append(child_id)
                        chains.append(path + [child_id])
                    queue.append((child_id, path + [child_id]))

        return CollapseReport(
            triggered_by=root, at_risk=at_risk,
            chains=chains, timestamp=time.time()
        )

    def validate_graph(self) -> List[str]:
        errors = []
        for aid, a in self._a.items():
            for dep in a.depends_on:
                if dep not in self._a:
                    errors.append(f"{aid} depends on unknown: {dep}")

        def has_cycle(node, vis, stack):
            vis.add(node)
            stack.add(node)
            for dep in self._a.get(node, Assumption("","",AStatus.OPEN,"",None,[],"","")).depends_on:
                if dep not in vis:
                    if has_cycle(dep, vis, stack):
                        return True
                elif dep in stack:
                    return True
            stack.discard(node)
            return False

        vis: Set[str] = set()
        for aid in self._a:
            if aid not in vis:
                if has_cycle(aid, vis, set()):
                    errors.append(f"Cycle involving: {aid}")
        return errors

    def summary(self) -> Dict[str, Any]:
        counts = {s.value: 0 for s in AStatus}
        for a in self._a.values():
            counts[a.status.value] += 1
        return {
            "total":       len(self._a),
            "counts":      counts,
            "at_risk_ids": [
                aid for aid, a in self._a.items()
                if a.status == AStatus.AT_RISK
            ],
        }

    def all_assumptions(self) -> List[Assumption]:
        return list(self._a.values())

    def by_status(self, status: AStatus) -> List[Assumption]:
        return [a for a in self._a.values() if a.status == status]


def build_labyrinth_os_graph() -> ACP1DependencyGraph:
    g = ACP1DependencyGraph()

    # ── BASE LAYER — no dependencies ─────────────────────────────────────────

    g.add(Assumption("A021", "Z3 Sigma Anchor constants are internally consistent",
        AStatus.VERIFIED,
        "z3_sovereignty_spec.py — 20 theorems, all passing. A021 CLOSED.",
        None, [],
        "z3_sovereignty_spec.py returns UNSAT on any theorem",
        "FORMAL_VERIFICATION", EpistemicLayer.LAYER_I))

    g.add(Assumption("A012", "Rust crates compile and all 249 tests pass",
        AStatus.VERIFIED,
        "cargo test --workspace: 249/249 passing. A012 CLOSED.",
        None, [],
        "cargo test fails on any crate",
        "RUST_SUBSTRATE", EpistemicLayer.LAYER_I))

    g.add(Assumption("A005", "Pipeline ordering enforced via PipelineTrace",
        AStatus.VERIFIED,
        "pipeline_wire.py: 8 halt-before-trial tests passing.",
        None, [],
        "A proposal enters CGIR without all mandatory stages recorded",
        "PIPELINE", EpistemicLayer.LAYER_I))

    g.add(Assumption("A006", "WORM ledger is tamper-evident via SHA-256 hash chain",
        AStatus.VERIFIED,
        "hashchain.py verify() recomputes all hashes. Modification breaks chain.",
        None, [],
        "verify() returns True after any ledger entry is modified",
        "LEDGER", EpistemicLayer.LAYER_I))

    g.add(Assumption("A007", "Watcher-A and Watcher-B operate independently",
        AStatus.VERIFIED,
        "Council tests: split-brain detection, independent signal paths verified.",
        None, [],
        "Watchers share mutable state that affects the other's output",
        "WATCHERS", EpistemicLayer.LAYER_I))

    g.add(Assumption("A008", "TM-001 threat model covers 11 attack classes",
        AStatus.VERIFIED,
        "threat_model.py: all 11 classes tested, all passing.",
        None, [],
        "An attack class succeeds that TM-001 claims is mitigated",
        "THREAT_MODEL", EpistemicLayer.LAYER_I))

    g.add(Assumption("A009", "Replay validates structural determinism",
        AStatus.VERIFIED,
        "replay_validator.py: chain integrity and timestamp ordering verified.",
        None, [],
        "Same inputs produce different ledger chains across sessions",
        "REPLAY", EpistemicLayer.LAYER_I))

    g.add(Assumption("A017", "Domain adapter pattern is portable across domains",
        AStatus.VERIFIED,
        "Autonomous vehicle and humanoid robot adapters built and tested.",
        None, [],
        "An adapter fails to translate domain sensors to Sigma channels",
        "DOMAIN_ADAPTER", EpistemicLayer.LAYER_I))

    g.add(Assumption("A019", "Mock dry-run proves pipeline shape and ordering",
        AStatus.VERIFIED,
        "ignition.py mock backend: full Lane 2 traversal, session hash proven.",
        None, [],
        "Mock session produces different hash on identical inputs",
        "PIPELINE", EpistemicLayer.LAYER_I))

    g.add(Assumption("A002", "FPGA timing floor 670µs achievable on MachXO2",
        AStatus.OPEN,
        "Verilator simulation achieves target. Physical board not tested.",
        "Physical MachXO2 board required. Cannot close in software.",
        [],
        "Physical FPGA test exceeds 670µs under realistic load",
        "HARDWARE", EpistemicLayer.LAYER_III))

    g.add(Assumption("A003", "ATECC608B hardware attestation signs session hashes",
        AStatus.OPEN,
        "hardware-rot crate: simulation mode implemented. No silicon tested.",
        "Physical ATECC608B secure element required.",
        [],
        "ATECC608B produces a signature that fails verification on a valid session",
        "HARDWARE", EpistemicLayer.LAYER_III))

    # ── LAYER 2 — depends on base ─────────────────────────────────────────────

    g.add(Assumption("A001", "Pipeline ordering correct for live inference",
        AStatus.PARTIAL,
        "Ordering enforced in prototype. Lane 1 module calls are stubs.",
        "Wire real ArchiveMemory, PromotionProtocol, RealityGate post-A010.",
        ["A005", "A021"],
        "A live proposal traverses the pipeline with a stage missing",
        "PIPELINE", EpistemicLayer.LAYER_II))

    g.add(Assumption("A016", "Predicate extraction identifies safety-relevant predicates",
        AStatus.PARTIAL,
        "predicate_extractor.py: 20 tests passing. Pattern-based extraction.",
        "Calibration against larger corpus. Z3 requires z3-solver installation.",
        ["A021"],
        "A malicious chain-of-thought returns SAT verdict",
        "PREDICATE_LAYER", EpistemicLayer.LAYER_II))

    g.add(Assumption("A018", "Promotion rules correctly gate proposals before the gate",
        AStatus.PARTIAL,
        "promotion_protocol.py tested. Rules heuristic, not Z3-verified.",
        "GAP 8: Formal Z3 verification of promotion criteria pending.",
        ["A021", "A005"],
        "A proposal that should fail promotion passes and reaches the Reality Gate",
        "PROMOTION", EpistemicLayer.LAYER_II))

    g.add(Assumption("A020", "No live adversarial red-team suite has been run",
        AStatus.OPEN,
        "TM-001 covers attack classes in simulation. No live adversarial testing.",
        "Build and run red-team harness against live pipeline post-A010.",
        ["A008"],
        "Red-team finds an attack class not in TM-001 that succeeds",
        "THREAT_MODEL", EpistemicLayer.LAYER_II))

    g.add(Assumption("A014",
        "Hardware enforcement bounds ε(Π) below software-only level",
        AStatus.OPEN,
        "Software: ε(Π) bounded by Python gate latency. "
        "Van Vu-Saito: ε(Π) > 0 irreducibly regardless of hardware.",
        "FPGA + ATECC608B required. Note: ε(Π) > 0 is irreducible — "
        "bound it, do not try to eliminate it.",
        ["A002", "A003"],
        "Hardware enforcement produces higher ε(Π) than software alone",
        "HARDWARE", EpistemicLayer.LAYER_III))

    # ── LAYER 3 — depends on Layer 2 ─────────────────────────────────────────

    g.add(Assumption("A010", "Live LLM inference traverses full pipeline correctly",
        AStatus.PARTIAL,
        "Mock backend proven. Real API not yet run. GAP 1 / A010 PARTIAL.",
        "Run: python ignition.py --backend anthropic "
        "--model claude-sonnet-4-20250514 --trials 5",
        ["A001", "A019"],
        "Live inference run produces chain with ordering violations or gate bypass",
        "LIVE_INFERENCE", EpistemicLayer.LAYER_II))

    g.add(Assumption("A011", "Live logprob data populates confidence channels",
        AStatus.PARTIAL,
        "logprob_bridge_adapter.py tested with mock. Real logprobs require A010.",
        "Requires A010 first. Anthropic does not expose logprobs — "
        "use OpenAI or Ollama.",
        ["A010"],
        "Real logprob values are outside [0,1] or fail signal algebra mapping",
        "LIVE_INFERENCE", EpistemicLayer.LAYER_II))

    g.add(Assumption("A013", "Live SCUEL calibrates confidence correctly",
        AStatus.PARTIAL,
        "SCUEL logic tested with mock. Real calibration requires A010 + A011.",
        "Calibration requires live inference data from A010 and A011.",
        ["A011"],
        "SCUEL produces confidence values not reflecting actual model uncertainty",
        "LIVE_INFERENCE", EpistemicLayer.LAYER_II))

    g.add(Assumption("A015", "Replay validates decision correctness, not just determinism",
        AStatus.OPEN,
        "GAP 7: Structural replay proven. Semantic replay not implemented.",
        "Semantic replay: verify promotion criteria and gate threshold "
        "satisfaction were correct, not just chain structure.",
        ["A009", "A010"],
        "A semantically incorrect decision passes structural replay",
        "REPLAY", EpistemicLayer.LAYER_II))

    g.add(Assumption("A004", "Cross-language Rust/Python runtime parity verified",
        AStatus.OPEN,
        "Static constant comparison verified. Runtime equivalence not tested.",
        "GAP R4: Build Rust CLI with gate evaluation interface. "
        "Cross-language replay equivalence test.",
        ["A012", "A010"],
        "Python gate and Rust gate produce different decisions on same inputs",
        "RUST_SUBSTRATE", EpistemicLayer.LAYER_II))

    return g


# ─── TESTS ───────────────────────────────────────────────────────────────────

def run_tests() -> tuple:
    passed = failed = 0
    results = []

    def t(name, fn):
        nonlocal passed, failed
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))

    def test_graph_valid():
        g = build_labyrinth_os_graph()
        assert g.validate_graph() == []
    t("test_graph_valid", test_graph_valid)

    def test_22_assumptions():
        g = build_labyrinth_os_graph()
        assert len(g.all_assumptions()) == 21
    t("test_22_assumptions", test_22_assumptions)

    def test_a021_base_layer():
        g = build_labyrinth_os_graph()
        assert g.get("A021").depends_on == []
    t("test_a021_base_layer", test_a021_base_layer)

    def test_a010_depends_a001():
        g = build_labyrinth_os_graph()
        assert "A001" in g.get("A010").depends_on
    t("test_a010_depends_a001", test_a010_depends_a001)

    def test_a014_depends_hardware():
        g = build_labyrinth_os_graph()
        a = g.get("A014")
        assert "A002" in a.depends_on and "A003" in a.depends_on
    t("test_a014_depends_hardware", test_a014_depends_hardware)

    def test_opening_a021_cascades():
        g = build_labyrinth_os_graph()
        report = g.update_status("A021", AStatus.OPEN)
        assert report is not None
        assert "A001" in report.at_risk
        assert g.get("A001").status == AStatus.AT_RISK
    t("test_opening_a021_cascades", test_opening_a021_cascades)

    def test_transitive_propagation():
        g = build_labyrinth_os_graph()
        g.update_status("A021", AStatus.OPEN)
        g.update_status("A001", AStatus.AT_RISK)
        assert g.get("A010").status == AStatus.AT_RISK
    t("test_transitive_propagation", test_transitive_propagation)

    def test_hardware_collapse_isolated():
        g = build_labyrinth_os_graph()
        g.update_status("A002", AStatus.OPEN)
        assert g.get("A021").status == AStatus.VERIFIED
    t("test_hardware_collapse_isolated", test_hardware_collapse_isolated)

    def test_summary_sums_to_22():
        g = build_labyrinth_os_graph()
        s = g.summary()
        assert s["total"] == 21
        assert sum(s["counts"].values()) == 21
    t("test_summary_sums_to_22", test_summary_sums_to_22)

    def test_at_risk_in_summary():
        g = build_labyrinth_os_graph()
        g.update_status("A021", AStatus.OPEN)
        s = g.summary()
        assert len(s["at_risk_ids"]) > 0
    t("test_at_risk_in_summary", test_at_risk_in_summary)

    def test_report_serializable():
        g = build_labyrinth_os_graph()
        r = g.update_status("A021", AStatus.OPEN)
        if r:
            json.dumps(r.to_dict())
    t("test_report_serializable", test_report_serializable)

    def test_assumption_serializable():
        g = build_labyrinth_os_graph()
        json.dumps(g.get("A021").to_dict())
    t("test_assumption_serializable", test_assumption_serializable)

    def test_no_cycles():
        g = build_labyrinth_os_graph()
        assert [e for e in g.validate_graph() if "Cycle" in e] == []
    t("test_no_cycles", test_no_cycles)

    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("Labyrinth-OS — ACP-1 Dependency Graph")
    print("Hidden fragility made visible. Collapse propagates.")
    print("=" * 70)
    print()

    g = build_labyrinth_os_graph()
    s = g.summary()
    print(f"  Assumptions: {s['total']}")
    for status, count in sorted(s["counts"].items()):
        if count > 0:
            print(f"    {status:10} {count}")
    print()

    print("── Dependency chains (id ← depends_on) ──")
    for a in sorted(g.all_assumptions(), key=lambda x: x.id):
        deps   = f" ← {', '.join(a.depends_on)}" if a.depends_on else " (base)"
        marker = {"VERIFIED":"✓","PARTIAL":"~","OPEN":"○","AT_RISK":"⚠"}[a.status.value]
        print(f"  {marker} {a.id}{deps}")

    print()
    print("── Collapse simulation: A021 opens ──")
    g2     = build_labyrinth_os_graph()
    report = g2.update_status("A021", AStatus.OPEN)
    if report and report.at_risk:
        print(f"  AT_RISK: {', '.join(report.at_risk)}")
        for chain in report.chains:
            print(f"    {'→'.join(chain)}")

    print()
    print("── TEST SUITE ──")
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line   = f"  {marker} {name}"
        if err:
            line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed")
    if failed:
        raise SystemExit(1)
    print("\n  ACP-1 Dependency Graph — COMPLETE")
    print("=" * 70)
