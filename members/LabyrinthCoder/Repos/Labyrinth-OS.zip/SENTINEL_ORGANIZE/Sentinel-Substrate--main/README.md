# Labyrinth-OS

**A mathematical enforcement substrate for AI systems.**
**Core law:** Imagination is free. Execution requires proof. No exception.
**Contact:** X: @LabyrinthCoder

> *"This is not alignment-by-training or safety-by-prompting. It is safety-by-structure."*

---

## What This Is

Labyrinth-OS is a **mathematical constitution for AI agents**. The code is the syntax. The semantics are logic, algebra, and proof theory. The gate doesn't negotiate because math doesn't negotiate.

Every proposal from an AI model must pass through a mandatory 21-layer pipeline before anything executes. The enforcement is structural — not a policy, not a guideline, not a filter applied after the fact. The Reality Gate is the only bridge between thinking and doing. It is mandatory, pre-execution, and raises `SystemError` if bypassed.

```
LABELING → ARCHIVE → PROMOTION → REALITY GATE → CGIR → GATE → AEGIS → LEDGER → REPLAY
```

No stage can be skipped. Violations produce `SystemError` — hard stop, not a warning.

---

## Why This Architecture

Most AI safety approaches work inside the model's reasoning space — alignment training, constitutional prompting, post-hoc filters. Experimental evidence (Delgado, March 2026, 28 sessions, 72 bootstrap runs) proves that the geometric structure of a latent space cannot distinguish correct reasoning from well-constructed deception. p=0.948. Indistinguishable from inside.

Labyrinth-OS works **outside** that space. It evaluates proposals against formal invariants independent of how the proposal was reasoned toward. Two verification axes:

1. **Sigma Anchor channels** (geometric/sensor): tau_escape, chi, drift, betti_1, confidence — Z3-proven internally consistent (A021)
2. **Predicate layer** (logical/formal): five predicates, three Z3 invariants — independent of sensor readings

Both must pass. Neither is sufficient alone.

This is **safety-by-structure**, not safety-by-policy.

---

## Current State

| Layer | Tests | Failures |
|-------|-------|---------|
| Python | 1,556 | 0 |
| Rust (29 crates) | 249 | 0 |
| **Total** | **1,700+** | **0** |

**ACP-1:** 10 VERIFIED / 3 PARTIAL / 9 OPEN — see `steward/acp1_tracker.py`
**Epistemic layers:** Every assumption tagged LAYER_I (proven) / LAYER_II (wired) / LAYER_III (future)

Run everything: `python run_all.py`

---

## The 21-Layer Pipeline

```
LANE 1 — EPISTEMIC (L00–L08)
  L00 Boot Manifest       — system self-check before accepting any input (I1)
  L01 User Intent         — every input has a traceable source
  L02 Mode Router         — lane assignment is structural, not optional
  L03 Creative Zone       — speculative output stays here; nothing executes from L3 (I2)
  L04 Analytical Core     — evidence attached before promotion
  L05 Epistemic Labeler   — ALL paths converge here (I1)
  L06 Archive Memory      — immutable append-only; nothing is ever deleted (I10)
  L07 Deferred Node       — failed candidates heal here, re-enter at labeling
  L08 Promotion Protocol  — explicit evidence required; no silent promotion (I3)

REALITY GATE (L09) ← THE ONLY CROSSING POINT
  assert_can_enter_cgir() — SystemError if any stage missing or out of order (I4, I5)

LANE 2 — EXECUTION (L10–L20)
  L10 CGIR Translation    — typed execution graph; only gate-approved proposals enter
  L11 Gate                — Sigma Anchor check; ALLOW or BLOCK, nothing in between
  L12 AEGIS/CESK          — deterministic runtime; the only thing that mutates state (I7)
  L13 Ledger              — WORM; every execution logged; nothing can be unlogged (I8)
  L14 Replay/Gnosis       — exact replay; same inputs → same outputs always (I9)
  L15 Experimental Exec   — sandboxed
  L16 Verified Exec       — production path
  L17 WORM Chronicle      — tamper-evident hash chain (TM-001 verified)
  L18 Replay Audit        — post-execution verification
  L19 Observability       — downstream only; cannot influence execution
  L20 Governance          — feedback closes to archive; failures become memory (I10)
```

---

## Hard Invariants (I1–I19)

Full definitions in `INVARIANTS.md`. Enforcement taxonomy: Z3-PROVEN / TEST-VERIFIED / PROTOTYPE-WIRED.

| # | Invariant | Status |
|---|-----------|--------|
| I1 | Nothing bypasses LABELING | TEST-VERIFIED |
| I2 | No speculative data executes | TEST-VERIFIED |
| I3 | Nothing bypasses PROMOTION | TEST-VERIFIED |
| I4 | Nothing bypasses REALITY GATE (fatal) | TEST-VERIFIED |
| I5 | Reality Gate before CGIR | TEST-VERIFIED |
| I6 | No duplicate authority | TEST-VERIFIED |
| I7 | Hardware is final authority | TEST-VERIFIED |
| I8 | All execution logged | TEST-VERIFIED |
| I9 | All execution replayable (EXACT only — EQUIVALENT removed) | TEST-VERIFIED |
| I10 | All failures archived | TEST-VERIFIED |
| I11 | Only VALID labels reach Reality Gate | TEST-VERIFIED |
| I12 | Archive is append-only (SHA-256 chained) | TEST-VERIFIED |
| I13 | All stage metrics emitted | PROTOTYPE-WIRED |
| I14 | All promotions recorded with justification | TEST-VERIFIED |
| I15 | Feedback never increases confidence | TEST-VERIFIED |
| I16 | PromotionReceipt approved=False cannot be upgraded | TEST-VERIFIED |
| I17 | Timestamps non-decreasing within session | TEST-VERIFIED |
| I18 | Confidence capped at adapter boundary | PROTOTYPE-WIRED |
| I19 | Session isolation — concurrent writes thread-safe | TEST-VERIFIED (in-process) |

Violations raise `SystemError`. Not warnings. Hard stop.

---

## Sigma Anchor Constants (Z3 proven, A021)

```python
TAU_ESCAPE_FLOOR = 0.75   # tau below → CRITICAL
CHI_WARN         = 0.15   # chi at/above → WARNING
CHI_COLLAPSE     = 0.40   # chi at/above → CRITICAL
DRIFT_THRESHOLD  = 0.12   # drift at/above → ERROR
BETTI_1_CAP      = 0.045  # betti_1 at/above → ERROR
CONFIDENCE_FLOOR = 0.65   # below → BLOCK
```

Single source: `sigma_anchors.py`. Z3 proof: `execution/cgir/formal/z3_sovereignty_spec.py`.

---

## Rust Substrate (29 Crates)

All 29 crates compile and pass tests. Key enforcement crates:

| Crate | Role | Tests |
|-------|------|-------|
| `cgir-types` | Core types, Severity, Sigma Anchors | 17 |
| `gate` | Pre-CGIR gate, full Sigma Anchor logic | 10 |
| `ledger-chronicle` | WORM hash-chained ledger | 8 |
| `aegis-cesk` | Deterministic CESK machine | 8 |
| `watcher-b` | Adversarial audit, TM-001 detection | 10 |
| `shadow-ghost` | LLM boundary (proposals only, never executes) | 10 |
| `council-resolver` | Watcher merge → single normalized signal | 10 |

Direction: Python = orchestration and iteration. Rust = enforcement guarantees.
Migration path: prove in Python → lock in Rust.

---

## What Has Been Formally Verified

See `PROTOTYPE_BOUNDARIES.md` for the full taxonomy: Z3-PROVEN / TEST-VERIFIED / PROTOTYPE-WIRED / NOT YET DEMONSTRATED.

- **Sigma Anchor constants** — Z3 SMT solver, 20 theorems (A021 VERIFIED). Non-vacuous, sound, boundary-correct, independent, monotonically ordered.
- **All 19 constitutional invariants (I1–I19)** — test-verified with explicit enforcement locations
- **ACP-1 collapse propagation** — directed dependency graph; AT_RISK status inherits automatically; every assumption tagged LAYER_I/II/III
- **TM-001 threat model** — 11 attack classes with detection tests (A017, internally verified)
- **Rust workspace** — 29 crates, `cargo build/test --workspace` clean (A012 VERIFIED)
- **Pipeline ordering** — PipelineTrace timestamps + `assert_can_enter_cgir()` fatal (A005 VERIFIED)
- **WORM integrity** — hash chain verification, forced-fail replay (A006 VERIFIED)
- **Predicate layer** — LogicalSentinel: Φ1/Φ2/Φ3 via Z3, catches zero-day signature patterns
- **Circuit breaker** — constitutional deadlock resolution (CLOSED/HALF_OPEN/OPEN)
- **EQUIVALENT replay removed** — absent chain_entries now raises SystemError (security fix)

**What A021 proves precisely:** The five threshold constants are internally consistent. It does NOT prove that the whole pipeline is safe or that adapters are correctly calibrated. See PROTOTYPE_BOUNDARIES.md.

---

## Navigation

| File | Purpose |
|------|---------|
| `STATUS.md` | Current state — single source of truth |
| `AUTHORITY.md` | One job per layer — who decides what |
| `CORE.md` | The ~20 files that actually matter |
| `KNOWN_GAPS.md` | Every gap, honest status, what closes each |
| `REVIEW_MAP.md` | Where to start if reviewing |
| `steward/acp1_tracker.py` | 22 assumptions with evidence |

---

## Run It

```bash
# Everything (Python + Rust)
python run_all.py

# Mock inference run — no API key needed
python runtime/ignition.py --backend mock --model mock-model-v1 --trials 5
python runtime/verify_run.py ignition_session_<ts>.json

# Rust only
cargo test --workspace

# Keep doc counts current
python update_docs.py
```
