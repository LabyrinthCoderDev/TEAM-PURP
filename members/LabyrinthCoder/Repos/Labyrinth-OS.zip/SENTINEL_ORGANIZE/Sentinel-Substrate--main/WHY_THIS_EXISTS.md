# Labyrinth-OS — Component Rationale Index
## Why Each Major Component Exists
## Ω Cipher · June 2026

> GPT external review (June 2026): "The next level is being able to answer
> 'Why does this component exist?' in under 30 seconds. Not because humans
> forget. Because six months from now you will have forgotten why some of
> it exists too."
>
> This file is the answer. One paragraph per component, max.

---

## Core Gate Components

**sigma_anchors.py**
Single source of truth for six constants that define where the gate opens
and closes: tau_escape_floor (0.75), chi_warn (0.15), chi_collapse (0.40),
drift_threshold (0.12), betti_1_cap (0.045), confidence_floor (0.65). Plus
three sensor gate constants and contract version. Exists so no module ever
hardcodes these values — every gate decision traces back to one file.

**gate_function.py**
The pure decision boundary. Given a label, confidence, and promotion status,
it produces a YES or NO with a deterministic hash. Exists because the gate
must be provably deterministic — the same inputs always produce the same
output. No side effects. No randomness. The gate is the only crossing from
Lane 1 reasoning to Lane 2 execution (Invariant I1).

**gate_proof.py / GateProofIssuer**
Attaches a cryptographic proof to every gate decision. Exists because a
gate decision that cannot be audited later is not a gate — it is a promise.
The proof includes a SHA-256 hash of all inputs plus a Z3 verification
receipt. Maturity label `independent_review_receipted` for Z3-proven proofs.

**bounded_sensor_gate.py**
Rate-limits, bound-limits, and staleness-checks raw sensor data before it
reaches the PhysicsSentinel or the gate. Exists because a sensor reading
that jumps 40% in 50ms is not a legitimate reading — it is a spike or an
attack. The gate cannot see this if the spike has already entered the
pipeline. Defense in depth: block contaminated readings before they arrive.

**merkle_permit_set.py**
Commits 12 permitted action types to a Merkle tree. Any action type not in
the tree is structurally excluded before the gate evaluates it. Exists
because the gate evaluates whether a specific proposal is safe, but does
not know whether that type of proposal was ever supposed to exist. The
permit set closes that gap. Not a replacement for the gate — a layer before it.

---

## Ledger and Audit Components

**cgir_ledger.py / LedgerEntry**
Append-only WORM ledger for every gate crossing. Exists because you cannot
audit what was not recorded. Every entry carries contract_version (schema
evolution), retention policy (EPHEMERAL/SESSION/DURABLE/PERMANENT), and a
SHA-256 hash chain linking each entry to the previous one. Tamper-evidence
without Z3.

**retention_policy.py**
Maps event types to how long they should be kept. Exists because not
everything should be permanently retained. Hypothesis test runs are
EPHEMERAL. Session traces are SESSION. Gate decisions are DURABLE. Z3
sovereignty proofs and first live inference events are PERMANENT. As the
system runs longer, this distinction matters for storage and query cost.

**hashchain.py**
Links ledger entries into a tamper-evident chain via SHA-256. Exists
because a ledger that can be silently modified is not a ledger. Modifying
any entry breaks verify() for all subsequent entries. This is not Z3
verification — it is tamper-evidence. They address different threat models.

**chronicle_query.py**
SQLite-backed queryable interface to the ledger. Exists because the WORM
ledger is append-only and unstructured — querying it directly at scale
would be unworkable. Chronicle allows filtering by retention level, event
type, label, and time range. The retention index makes PERMANENT record
queries fast.

**replay_gnosis.py**
Exact chain replay and audit. Exists because the ability to replay a
session and verify that every decision was valid at the time it was made
is what separates a ledger from a log. The chain is not just a record —
it is a proof that the system behaved consistently.

---

## Learning and Evolution Components

**trial_reflection.py**
Produces named lessons from every trial — TAU_NEAR_FLOOR,
CHI_ELEVATED, BETTI_PLACEHOLDER, JOULE_OVERRUN, etc. Exists because
`cue_pattern_miner.py` mines aggregate failure patterns across many trials,
but does not produce transferable lessons from individual trials. After A010,
the first live inference will produce unexpected results. TrialReflection
is how you capture what those results teach, in a form the next session can
read.

**cue_pattern_miner.py**
Mines conditions that preceded BLOCK decisions in the ledger. Exists because
individual trial reflections show what happened once; the pattern miner shows
what conditions reliably precede failures. Both are needed — individual
lessons and aggregate patterns feed the learning loop from different angles.

**continuous_learning_loop.py**
Session-to-session learning infrastructure. Exists because without it,
every ignition session starts from scratch. The loop records per-trial
feedback, generates TrialReflections, and surfaces lessons at the start of
the next session. It is the mechanism that makes the system learn rather
than just execute.

**promotion_rules.py / PromotionDecision**
Controls when a label graduates from SPECULATIVE to TRUTH. Exists because
the gate needs something to promote — a raw confidence score is not enough.
Promotion requires consecutive runs above threshold, evidence accumulation,
and formal Z3 verification (PR1-PR8). The maturity label on every
PromotionDecision records how trustworthy the promotion evidence is.

---

## Input and Observation Components

**logprob_bridge_adapter.py**
Translates raw model output (logprobs, confidence signals) into normalized
sigma anchor readings. Exists because the gate evaluates tau, chi, drift,
betti, confidence — not raw text. The bridge is the translation layer
between what the model produces and what the gate can evaluate. When A010
runs, this module is the first point where IC-1 and IC-2 controls would be
applied.

**api_adapter.py**
Provider-agnostic LLM inference interface. OpenAI, Anthropic, Grok, Ollama,
any OpenAI-compatible endpoint. Exists because A010 should work regardless
of which provider is available. The adapter normalizes provider differences.
extract_from_json() and extract_response_value() handle defensive response
parsing — returning None on any unexpected structure rather than crashing.

**physics_sentinel.py**
First-pass hardware safety check before the constitutional pipeline. Exists
because some conditions (sensor density > 7.0) should produce an immediate
stop regardless of what the gate decides. Hardware-level safety is separate
from epistemic safety. The sentinel answers: "Is this physically safe to
evaluate?" The gate answers: "Is this epistemically sound?"

---

## Infrastructure Components

**execution_loop.toml** (config/)
Machine-readable 21-stage pipeline contract. Exists because the pipeline
stages should be readable without reading ignition.py. Any future agent
reads this file and knows what stages exist, in what order, and what the
invariants are. The loop contract is portable; the execution engine
implements it. They are not the same thing.

**LABYRINTH_CONTRACT_VERSION = "1.0.0"** (sigma_anchors.py)
Schema version on every persisted record. Exists because when the schema
changes, there must be a way to know which records were written under the
old schema. One field per dataclass, zero logic change, queryable in
chronicle_query.py immediately.

**check_consistency.py** (scripts/)
Three-way drift detector: live test output vs SYSTEM_REPORT.json vs most
recent journal. Exists because GPT's external review showed that the
documentation can say one thing while the exported artifact contains
another. This script makes that divergence impossible to miss. Run it
before every packaging session.

---

## What Does NOT Exist Yet (and Why)

**tally_reflections()** — Needs A010 live data to calibrate which lessons
matter across multiple real trials. The structure is designed; the function
is deferred.

**Soterion headers on 208 Python files** — Per-file ownership and review
metadata. Designed, prototype started (sigma_anchors.py has it). Needs a
dedicated session to apply to all 208 remaining files.

**Input Constitution** — IC-1 model identity, IC-2 input provenance, IC-3
training provenance. The deepest upstream gap. IC-1/IC-2 partial at A010,
full at A014+. IC-3 is a long-horizon boundary.

---

*Ω Cipher · June 2026*
*GPT external review recommendation — implemented*
*"Why does this component exist?" answered for every major module*
