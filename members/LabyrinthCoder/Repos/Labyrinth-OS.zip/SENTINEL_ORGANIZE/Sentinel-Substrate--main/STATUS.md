# STATUS — Labyrinth-OS

**This is the source of truth. All other docs defer here.**
Last updated: May 2026

**Dependency rule:** Layer III collapses if Layer II fails. Layer II depends on Layer I. Layer I stands unconditionally. See `THEORETICAL_FOUNDATIONS.md`.

Labyrinth-OS is a **mathematical enforcement substrate** for AI systems.
1,556 Python tests pass (plus 249 Rust = 1,700+ total). 10 of 22 architectural assumptions
verified by concrete evidence and tests. A021 is the only Z3-proven claim. All others are TEST-VERIFIED or PROTOTYPE-WIRED.
See `PROTOTYPE_BOUNDARIES.md` for the complete taxonomy. See `PROJECT_CONTEXT.md` for the full picture.

---

## Current Test Counts

| Layer | Passed | Failed |
|-------|--------|--------|
| Python | 1,482+ | 0 |
| Rust | 249 | 0 |
| **Total** | **1,700+** | **0** |

Run: `python run_all.py` — runs both layers, prints totals.

---

## ACP-1 Assumptions (22 total)

**VERIFIED (10):** A001, A005, A006, A007, A008, A009, A012, A017, A019, A021

**PARTIAL (3):**
- A010 — first real inference run (needs API key)
- A011 — real logprob data (needs live OpenAI/Ollama)
- A013 — SCUEL live classification (needs 100+ real inference events)

**OPEN (9):** A002, A003, A004, A014, A015, A016, A018, A020, A022
All genuinely blocked on hardware (FPGA, ATECC608B) or live system.

See `steward/acp1_tracker.py` for full evidence per assumption.

---

## What Works

- Full pipeline wired: LABELING → ARCHIVE → PROMOTION → REALITY GATE → CGIR → GATE → AEGIS → LEDGER → REPLAY → OBSERVABILITY → GOVERNANCE → FEEDBACK → ARCHIVE
- `assert_can_enter_cgir()` fatal — SystemError if any stage missing
- PipelineTrace timestamps all stages, proves ordering
- WORM ledger: append-only, hash-chained, tamper-evident
- Exact replay: same inputs produce same outputs
- Sigma Anchor constants Z3-proven (A021)
- All 10 TM-001 attack classes have detection tests (A017)
- 29 Rust crates compile and test clean (A012)
- Classification enforcement: FAILED/ARCHIVED/DEPRECATED are blocked
- `update_docs.py` — one command keeps all doc counts current

## What Does Not Work Yet

- **ignition.py uses mock stages** (GAP 1 — PARTIAL): `_archive_ignition`, `_promote_ignition`, `_reality_gate_admission` are local stubs. They do not call real `ArchiveMemory`, `PromotionProtocol.evaluate()`, or `RealityGate.check()`. A proposal that would be rejected by real Lane 1 can still pass ignition. Ordering enforcement is real. Module calls are stubs.
- **No real inference run** (A010 PARTIAL): mock dry-run proves pipeline shape, not live behavior
- **No live logprob data** (A011 PARTIAL): confidence values are estimated, not from real token distributions
- **Hardware enforcement** (A002/A003/A014 OPEN): FPGA + ATECC608B not owned

---

## Known Gaps

| Gap | Status |
|-----|--------|
| GAP 1 — ignition mock stages | PARTIAL — ordering real, module calls stubbed |
| GAP 2 — Rust compile | CLOSED — A012 VERIFIED |
| GAP 3 — Lane 1 empty | CLOSED — L00-L04 implemented |
| GAP 4 — Feedback→Archive | CLOSED — FeedbackRecord written |
| GAP 5 — PipelineTrace on live | READY — wired, not yet on live inference |
| GAP 6 — Physical hardware | HARDWARE — FPGA required |

---

## Next Milestone

A010 is the only meaningful next step in code.

```bash
export ANTHROPIC_API_KEY=your_key
python runtime/ignition.py --backend anthropic --model claude-sonnet-4-20250514 --trials 5
python runtime/verify_run.py ignition_session_<ts>.json
python runtime/a010_monitor.py ignition_session_<ts>.json
```

After A010: A011 (live logprobs) → A013 (live SCUEL) → multi-sentinel → distributed.

---

## What This Is

Side project. Anonymous. Spare time. No funding. No team.
See `PROJECT_CONTEXT.md` for full framing.
