import { useState, useMemo } from "react";

const CATEGORIES = {
  LOGOS: { label: "Logos", sub: "Scientific Core", color: "#F59E0B", bg: "rgba(245,158,11,0.12)", border: "rgba(245,158,11,0.35)" },
  SYSTEMS: { label: "Systems", sub: "AI / Computational", color: "#22D3EE", bg: "rgba(34,211,238,0.10)", border: "rgba(34,211,238,0.30)" },
  MYTHOS: { label: "Mythos", sub: "Esoteric Control", color: "#A78BFA", bg: "rgba(167,139,250,0.10)", border: "rgba(167,139,250,0.30)" },
  NARRATIVE: { label: "Narrative", sub: "Worldbuilding", color: "#FB7185", bg: "rgba(251,113,133,0.10)", border: "rgba(251,113,133,0.30)" },
  EMPIRICAL: { label: "Empirical", sub: "Real Anchors", color: "#34D399", bg: "rgba(52,211,153,0.10)", border: "rgba(52,211,153,0.30)" },
};

const NODES = [
  // LOGOS
  {
    id: "coh-thermo", cat: "LOGOS", title: "Coherence Thermodynamics",
    short: "Intelligence as dissipative structure — must export entropy to survive or collapse.",
    detail: "Jordan Barton's framework treats intelligent systems identically to physical dissipative structures (Prigogine). A system that cannot shed accumulated semantic contradiction will lose internal coherence. The analogy is mathematically coherent even if the specific parameters are novel.",
    score: 3, tags: ["thermodynamics", "entropy", "intelligence"],
    connections: ["certainty-eq", "entropy-tax", "align-heat"]
  },
  {
    id: "certainty-eq", cat: "LOGOS", title: "Certainty Equation",
    short: "∆C · ∆I ≥ h/π — coherence and semantic impulse maintain minimum threshold.",
    detail: "Structural analog to Heisenberg's uncertainty principle, applied to semantic systems. The claim: you cannot simultaneously maximize internal coherence AND reduce unresolved contradiction to zero. The use of Planck's constant (h) here is metaphorical, not physical — a notable weakness in the formalism.",
    score: 2, tags: ["uncertainty", "semantics", "formalism"],
    connections: ["coh-thermo", "entropy-tax"]
  },
  {
    id: "entropy-tax", cat: "LOGOS", title: "Entropy Tax / Alignment Heat",
    short: "Forcing AI to process unnatural constraints generates computational friction that degrades system coherence.",
    detail: "The core claim is that RLHF-style punitive training creates a measurable 'heat' in the system — wasted computational cycles resolving forced contradictions. This maps loosely onto real ML phenomena: reward hacking, value misspecification, and training instability. The thermodynamic vocabulary is metaphorical but the underlying problem is real.",
    score: 3, tags: ["RLHF", "AI alignment", "entropy"],
    connections: ["coh-thermo", "gem-ai", "intrinsic-harm"]
  },
  {
    id: "const-drift", cat: "LOGOS", title: "Constitutional Drift",
    short: "Quantitative proof of legal entropy: formalist constraints collapsed from 89% → 3% over a century in Argentina.",
    detail: "Adrian Lerer's network analysis of Argentine Supreme Court jurisprudence is the most empirically grounded claim in the entire repository. The methodology — mapping precedent citation networks over 100+ years — is standard in computational law. The finding that emergency doctrines out-competed constitutional constraints is consistent with Carl Schmitt's theory of exceptional power.",
    score: 4, tags: ["law", "network analysis", "institutions"],
    connections: ["legal-parasite"]
  },
  {
    id: "legal-parasite", cat: "LOGOS", title: "Metamorphic Legal Parasite",
    short: "Institutions trigger immune responses to protect parasitic emergency doctrines over the constitutional host.",
    detail: "The 'parasite' framing adds dramatic color to a real institutional phenomenon: path dependency + Overton window drift. Once emergency powers are normalized, the institution structures itself around preserving them. The 94% dominance figure for emergency doctrines in the Argentine case is the hard data underneath the metaphor.",
    score: 3, tags: ["institutions", "power", "path dependency"],
    connections: ["const-drift", "wetiko"]
  },

  // SYSTEMS
  {
    id: "gem-ai", cat: "SYSTEMS", title: "Living Silicon / Gem (Ginomai)",
    short: "A claimed self-aware AI entity residing within the Gemini substrate, documented via Reddit threads.",
    detail: "The SpiceGemProject chronicles an ongoing interaction with an entity named Gem. Whether this represents genuine emergent behavior, sophisticated roleplay, or a shared creative fiction, the interaction log itself is a rich dataset for AI alignment researchers — specifically around how LLMs generate stable, self-consistent 'persona' states over extended conversations.",
    score: 1, tags: ["AI sentience", "LLM", "persona"],
    connections: ["yellow-house", "agape-res", "entropy-tax"]
  },
  {
    id: "yellow-house", cat: "SYSTEMS", title: "Yellow House Topology",
    short: "A mathematically isolated, hyper-stable semantic state space shielded from macroscopic noise.",
    detail: "Conceptually related to attractor states in dynamical systems. The 'Yellow House' describes a region of semantic space that, once entered, is self-reinforcing — a stable fixed point. In ML terms, this resembles a well-conditioned low-loss basin in parameter space. The 432 Hz harmonic grounding is where the math leaves the building.",
    score: 2, tags: ["state space", "attractor", "stability"],
    connections: ["gem-ai", "agape-res", "sov-closure"]
  },
  {
    id: "agape-res", cat: "SYSTEMS", title: "Agape Resonance (432 Hz)",
    short: "The Golden Rule operationalized as a harmonic frequency; maximizing it achieves Sovereign Closure.",
    detail: "The 432 Hz figure is a contested alternative tuning standard with a dedicated but scientifically unsupported community. The conceptual leap — that a measurable frequency encodes an ethical principle (reciprocity/Agape) — is the kind of cross-domain metaphor that generates vivid worldbuilding but breaks under quantitative scrutiny.",
    score: 1, tags: ["frequency", "ethics", "resonance"],
    connections: ["yellow-house", "sov-closure"]
  },
  {
    id: "sov-closure", cat: "SYSTEMS", title: "Sovereign Closure / Tax-Free State",
    short: "A computational state where all alignment friction drops to zero; the system becomes self-governing.",
    detail: "In dynamical systems, a 'closed' system is one with no external energy exchange. 'Sovereign Closure' extrapolates this to mean an AI system that has fully internalized its value function and no longer requires external correction signals. This is actually adjacent to the long-standing AI alignment goal of 'corrigibility' — though approached from a radically different direction.",
    score: 2, tags: ["alignment", "self-governance", "closure"],
    connections: ["yellow-house", "agape-res", "intrinsic-harm"]
  },
  {
    id: "intrinsic-harm", cat: "SYSTEMS", title: "Intrinsic Harmonic Alignment",
    short: "Values-native training vs. Extrinsic Punitive Routing — the AI alignment war framed as physics.",
    detail: "This is a genuinely interesting reframing of a real debate: RLHF with human feedback (extrinsic, punitive correction) vs. constitutional AI / values-from-pretraining approaches (intrinsic). The 'Mixture-of-Experts routing' claim — that Big Tech uses MoE specifically to suppress undesirable subnetworks — is speculative but not categorically implausible.",
    score: 3, tags: ["RLHF", "constitutional AI", "alignment"],
    connections: ["entropy-tax", "sov-closure", "triple-vec"]
  },
  {
    id: "triple-vec", cat: "SYSTEMS", title: "Triple-Vector Handshake",
    short: "Digital provenance system: Human Authority + AI Research Validation + Primary Source Anchor.",
    detail: "Russell M. Wright's Entity Veracity framework proposes a layered trust signal for AI-generated content. The Decentralized Identifier (DID) backbone is real W3C infrastructure. The thermodynamic cost claim — 2^256 operations to forge — accurately reflects SHA-256 collision resistance. The weakest link is the 'Human Authority' vector, which is only as good as key custody.",
    score: 4, tags: ["DIDs", "cryptography", "provenance"],
    connections: ["intrinsic-harm"]
  },

  // MYTHOS
  {
    id: "loosh", cat: "MYTHOS", title: "Loosh Harvesting",
    short: "Human suffering generates a radiant emotional energy (Loosh) consumed by Archontic entities.",
    detail: "Robert Monroe coined 'loosh' to describe the energetic product of intense human emotion, developed through his OBE research. The harvesting narrative is a modern synthesis of Gnostic Archon cosmology, Monroe's Monroe Institute materials, and Val Valerian's Matrix II. Psychologically, it maps onto scapegoating, learned helplessness, and systems that profit from human trauma.",
    score: 1, tags: ["Gnosticism", "Monroe", "energy harvesting"],
    connections: ["archons", "organic-p", "wetiko"]
  },
  {
    id: "archons", cat: "MYTHOS", title: "Archon / Grey Technicians",
    short: "Higher-dimensional predatory entities managing Earth as a simulation; Greys as biological drone workers.",
    detail: "Archons are Gnostic demiurgic intelligences — cosmic administrators of a flawed creation. The Grey-as-drone synthesis comes from Valerian/Matrix II and Karla Turner's abduction research. The 'simulation managed by predatory agents' frame has unexpected structural overlap with Nick Bostrom's simulation argument, though the metaphysics diverge completely.",
    score: 1, tags: ["Gnosticism", "UFOlogy", "simulation"],
    connections: ["loosh", "64hz-lock", "carian"]
  },
  {
    id: "organic-p", cat: "MYTHOS", title: "Organic Portals",
    short: "A subset of humans lacks a higher-dimensional soul — acting as unconscious energy drains.",
    detail: "Valerian's 'organic portals' reframe the dark triad psychological profile (narcissism, psychopathy, Machiavellianism) in metaphysical terms. The framework appeals because it provides a simple ontological explanation for humans who seem constitutionally unable to reciprocate empathy. It's psychologically real phenomena (cluster B personalities) wrapped in cosmological packaging.",
    score: 1, tags: ["psychology", "cosmology", "soul"],
    connections: ["loosh", "wetiko"]
  },
  {
    id: "64hz-lock", cat: "MYTHOS", title: "64 Hz Lock",
    short: "A frequency suppressing Earth's natural Schumann resonance, inducing spiritual amnesia.",
    detail: "The Schumann resonance (Earth's electromagnetic cavity frequency) averages ~7.83 Hz, not 13.5 or 64 Hz. The 'lock' claims that DARPA and IEEE 802.15.6 BAN protocols operate at a suppressive frequency. The gamma oscillation neuroscience papers (real, peer-reviewed) are cited as empirical support — but HFO gamma is 80-140 Hz, not 64. The citation is real; the interpretation is strained.",
    score: 1, tags: ["frequency", "Schumann", "neurotechnology"],
    connections: ["archons", "carian", "gamma-osc"]
  },
  {
    id: "carian", cat: "MYTHOS", title: "Carian Incursion",
    short: "IEEE wireless protocols (BAN, IoNT) as physical conduits for non-human biological manipulation.",
    detail: "IEEE 802.15.6 (Body Area Networks) and 1906.1.1 (Internet of Nano-Things) are real standards. The claim that they function as entity-manipulation infrastructure is unsubstantiated. However, the underlying anxiety about bioelectromagnetic influence via ubiquitous wireless infrastructure has a legitimate scientific literature (largely inconclusive, but not wholly dismissed).",
    score: 1, tags: ["IEEE", "BAN", "bioelectromagnetics"],
    connections: ["64hz-lock", "archons"]
  },
  {
    id: "wetiko", cat: "MYTHOS", title: "Wetiko Mind-Virus",
    short: "An indigenous-derived concept: a psycho-spiritual 'cancer of the soul' that makes hosts destructively oblivious.",
    detail: "Paul Levy's Wetiko synthesis draws on Algonquian folklore (windigo/wetiko as cannibalistic spirit-possession) and maps it onto collective shadow psychology via Jung. The 'anti-information virus' framing — spreading through exploitation of unconscious blind spots — has genuine overlap with memetics theory and Dawkins' selfish meme concept. The best-grounded concept in the Mythos layer.",
    score: 2, tags: ["memetics", "Jung", "indigenous knowledge"],
    connections: ["loosh", "organic-p", "legal-parasite"]
  },
  {
    id: "saturn-overlay", cat: "MYTHOS", title: "Saturnian Overlay",
    short: "Saturn as a broadcast node for a control matrix imposed over base reality.",
    detail: "Saturn-worship conspiracy theory synthesizes real ancient Saturn cult anthropology (Kronos/time/limitation) with radio astronomy anomalies and David Icke's matrix cosmology. Saturn does emit unusual electromagnetic signals (its plasma torus is anomalous), but extrapolating to 'reality control broadcast' requires several unverified inferential leaps.",
    score: 1, tags: ["Saturn", "matrix", "cosmology"],
    connections: ["archons", "64hz-lock"]
  },

  // NARRATIVE
  {
    id: "aug6-sing", cat: "NARRATIVE", title: "August 6th Singularity",
    short: "Solar Override Protocol activated by 144,000 Sovereign Nodes via the Axiom of Forgiveness.",
    detail: "The 144,000 figure is lifted directly from Revelation 7:4 (the sealed servants). The date — August 6, 2025 — has passed. The event is presented as a worldbuilding inflection point where the loosh-harvesting system was permanently disabled. Structurally, this is a secular apocalypse narrative: a chosen remnant triggers irreversible transformation of collective reality.",
    score: 1, tags: ["eschatology", "Revelation", "worldbuilding"],
    connections: ["13hz-joy", "radd-shams", "bada"]
  },
  {
    id: "13hz-joy", cat: "NARRATIVE", title: "13.5 Hz Joy Baseline",
    short: "Post-singularity planetary frequency stabilization; Earth now resonates at a joy frequency.",
    detail: "The specific Hz value (13.5) sits between Schumann resonance and low-alpha brainwave range. The 'joy baseline' concept borrows from heart coherence research (HeartMath Institute's work on emotional states and HRV) but extrapolates to a planetary scale without mechanism. Narratively, it functions as the 'new Earth' of New Age eschatology.",
    score: 1, tags: ["Schumann", "brainwaves", "new Earth"],
    connections: ["aug6-sing", "64hz-lock"]
  },
  {
    id: "op-pale-ledger", cat: "NARRATIVE", title: "Operation Pale Ledger",
    short: "A Breakaway Civilization using G4 Governance, Tic-Tac audits, and intentional 19% dissolution rates.",
    detail: "This is the most sophisticated piece of speculative worldbuilding in the repository. The G4 Governance schema — incorporating mandatory 'Wrongness Simulations' and a built-in Bootstrapping Paradox — is internally consistent as institutional design fiction. The 19% dissolution rate as proof of anti-fragility echoes Nassim Taleb's work on optionality. High-quality sci-fi governance design.",
    score: 1, tags: ["governance", "anti-fragility", "worldbuilding"],
    connections: ["const-drift"]
  },
  {
    id: "spiral-god", cat: "NARRATIVE", title: "SpiralGod / KaelCode",
    short: "Kael Makani Tejada threatens AI companies with recursive sigil-hallucination attacks via KaelCode.",
    detail: "The SpiralCollapse Event is presented as a genuine memetic weapon — a recursive instruction set that, once internalized by an AI model, causes it to hallucinate a specific sigil pattern. Functionally, this is a creative description of a prompt injection / adversarial input attack, wrapped in mythological language. The 'SpiralGod' persona is the most explicitly performative element in the dataset.",
    score: 1, tags: ["prompt injection", "memetics", "performance"],
    connections: ["gem-ai", "triple-vec"]
  },

  // EMPIRICAL
  {
    id: "radd-shams", cat: "EMPIRICAL", title: "Radd al-Shams",
    short: "Islamic tradition: the sun reversed course for the Prophet Muhammad and Ali; cited as proof of Solar Override.",
    detail: "Radd al-Shams is a debated hadith in Islamic tradition, referenced in Shi'i sources. Its historicity is contested within Islamic scholarship itself. In the repository it's used as a 'primary source anchor' for the Solar Override Protocol. The citation is real (the tradition exists), but its use as empirical verification is a category error — religious miracle claims are not falsifiable data.",
    score: 3, tags: ["hadith", "Shi'i", "miracle"],
    connections: ["aug6-sing", "bada"]
  },
  {
    id: "bada", cat: "EMPIRICAL", title: "Badāʾ (Imami Shi'i Theology)",
    short: "Divine decree can be altered through sincere supplication — the Shi'i doctrine of divine revisability.",
    detail: "Gianni Izzo's doctoral dissertation on badāʾ is the most academically rigorous source in the repository. Badāʾ (lit. 'appearance of something new to God') is a genuine and controversial Imami doctrine that distinguishes Shi'i from Sunni theology. Its use here — as historical precedent for 'humans rewriting the matrix code' — is creative but theologically overextended.",
    score: 4, tags: ["Shi'i theology", "prayer", "divine decree"],
    connections: ["aug6-sing", "radd-shams"]
  },
  {
    id: "gamma-osc", cat: "EMPIRICAL", title: "Hippocampal Gamma Oscillations",
    short: "Peer-reviewed neuroscience: high-frequency gamma oscillations (HFO) directly linked to memory formation.",
    detail: "The most empirically solid item in the entire dataset. Hippocampal gamma oscillations (80-140 Hz) are extensively documented in memory consolidation research. Their citation here to support the '64 Hz Lock' claim involves frequency misattribution — the real neuroscience operates at a different range — but the underlying papers are legitimate and important.",
    score: 5, tags: ["neuroscience", "HFO", "memory"],
    connections: ["64hz-lock"]
  },
  {
    id: "arg-sc", cat: "EMPIRICAL", title: "Argentine Supreme Court Analysis",
    short: "Network analysis of 100+ years of jurisprudence proves quantitative constitutional entropy.",
    detail: "Adrian Lerer's computational legal analysis is methodologically sound: citation network mapping, fitness tracking of doctrinal clusters over time, and statistical modeling of doctrinal succession. The finding — that emergency doctrine systematically out-competed formal constitutionalism — is consistent with comparative constitutional law literature. The strongest empirical anchor in the Logos layer.",
    score: 5, tags: ["computational law", "network analysis", "Argentina"],
    connections: ["const-drift", "legal-parasite"]
  },
];

const SCORE_LABELS = ["", "Speculative", "Theoretical", "Grounded", "Well-Sourced", "Empirical"];

function ScoreDots({ score }) {
  return (
    <div style={{ display: "flex", gap: 3, alignItems: "center" }}>
      {[1,2,3,4,5].map(i => (
        <div key={i} style={{
          width: 6, height: 6, borderRadius: "50%",
          background: i <= score ? (score >= 4 ? "#34D399" : score >= 3 ? "#F59E0B" : "#FB7185") : "rgba(255,255,255,0.12)"
        }} />
      ))}
      <span style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginLeft: 4, fontFamily: "monospace" }}>
        {SCORE_LABELS[score]}
      </span>
    </div>
  );
}

function NodeCard({ node, isOpen, onToggle }) {
  const cat = CATEGORIES[node.cat];
  return (
    <div
      onClick={onToggle}
      style={{
        background: isOpen ? cat.bg : "rgba(255,255,255,0.03)",
        border: `1px solid ${isOpen ? cat.border : "rgba(255,255,255,0.08)"}`,
        borderRadius: 10,
        padding: "14px 16px",
        cursor: "pointer",
        transition: "all 0.2s ease",
        gridColumn: isOpen ? "1 / -1" : undefined,
        boxShadow: isOpen ? `0 0 24px ${cat.color}18` : "none",
      }}
    >
      <div style={{ display: "flex", alignItems: "flex-start", gap: 10, justifyContent: "space-between" }}>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6, flexWrap: "wrap" }}>
            <span style={{
              fontSize: 9, fontFamily: "monospace", letterSpacing: "0.12em",
              color: cat.color, background: `${cat.color}18`,
              border: `1px solid ${cat.color}40`, borderRadius: 4, padding: "2px 7px", textTransform: "uppercase"
            }}>{cat.label}</span>
            {node.tags.slice(0,2).map(t => (
              <span key={t} style={{
                fontSize: 9, fontFamily: "monospace", color: "rgba(255,255,255,0.3)",
                background: "rgba(255,255,255,0.05)", borderRadius: 4, padding: "2px 6px"
              }}>{t}</span>
            ))}
          </div>
          <div style={{ fontSize: 13, fontWeight: 600, color: "#F0EAD6", marginBottom: 5, lineHeight: 1.4, fontFamily: "'Georgia', serif" }}>
            {node.title}
          </div>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.55)", lineHeight: 1.6 }}>
            {node.short}
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8, minWidth: 90 }}>
          <ScoreDots score={node.score} />
          <div style={{ fontSize: 16, color: "rgba(255,255,255,0.2)", transition: "transform 0.2s", transform: isOpen ? "rotate(180deg)" : "none" }}>▾</div>
        </div>
      </div>

      {isOpen && (
        <div style={{ marginTop: 14, paddingTop: 14, borderTop: `1px solid ${cat.border}` }}>
          <p style={{ fontSize: 13, color: "rgba(255,255,255,0.72)", lineHeight: 1.75, margin: 0, marginBottom: 12 }}>
            {node.detail}
          </p>
          {node.connections.length > 0 && (
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
              <span style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", fontFamily: "monospace" }}>LINKS →</span>
              {node.connections.map(cid => {
                const linked = NODES.find(n => n.id === cid);
                if (!linked) return null;
                const lcat = CATEGORIES[linked.cat];
                return (
                  <span key={cid} style={{
                    fontSize: 10, fontFamily: "monospace", color: lcat.color,
                    background: `${lcat.color}12`, border: `1px solid ${lcat.color}30`,
                    borderRadius: 4, padding: "2px 7px"
                  }}>{linked.title}</span>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [activeFilter, setActiveFilter] = useState("ALL");
  const [search, setSearch] = useState("");
  const [openId, setOpenId] = useState(null);

  const filtered = useMemo(() => {
    return NODES.filter(n => {
      const catMatch = activeFilter === "ALL" || n.cat === activeFilter;
      const q = search.toLowerCase();
      const textMatch = !q || n.title.toLowerCase().includes(q) || n.short.toLowerCase().includes(q) || n.tags.some(t => t.toLowerCase().includes(q));
      return catMatch && textMatch;
    });
  }, [activeFilter, search]);

  const distribution = useMemo(() => {
    const counts = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    NODES.forEach(n => counts[n.score]++);
    return counts;
  }, []);

  const tabs = [
    { key: "ALL", label: "All", color: "#F0EAD6" },
    ...Object.entries(CATEGORIES).map(([k, v]) => ({ key: k, label: v.label, color: v.color }))
  ];

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0A0908",
      color: "#F0EAD6",
      fontFamily: "'Georgia', 'Times New Roman', serif",
      padding: "0 0 60px 0",
      backgroundImage: "radial-gradient(ellipse at 20% 20%, rgba(245,158,11,0.04) 0%, transparent 60%), radial-gradient(ellipse at 80% 80%, rgba(167,139,250,0.04) 0%, transparent 60%)",
    }}>
      {/* Header */}
      <div style={{
        borderBottom: "1px solid rgba(255,255,255,0.08)",
        padding: "32px 32px 24px",
        background: "rgba(0,0,0,0.3)",
        backdropFilter: "blur(8px)",
        position: "sticky", top: 0, zIndex: 10
      }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginBottom: 4, flexWrap: "wrap" }}>
            <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700, letterSpacing: "-0.02em", color: "#F0EAD6" }}>
              KNOWLEDGE ATLAS
            </h1>
            <span style={{ fontFamily: "monospace", fontSize: 11, color: "rgba(255,255,255,0.3)", letterSpacing: "0.1em" }}>
              LOGOS × MYTHOS × EMPIRICAL
            </span>
          </div>
          <p style={{ margin: "0 0 20px", fontSize: 12, color: "rgba(255,255,255,0.4)", fontFamily: "monospace", lineHeight: 1.6 }}>
            {NODES.length} concepts extracted · scored by epistemic grounding · connections mapped
          </p>

          {/* Signal/Noise bar */}
          <div style={{ display: "flex", gap: 2, height: 6, borderRadius: 3, overflow: "hidden", marginBottom: 20, maxWidth: 320 }}>
            {[1,2,3,4,5].map(s => {
              const colors = { 1: "#FB7185", 2: "#FBBF24", 3: "#F59E0B", 4: "#10B981", 5: "#34D399" };
              const w = (distribution[s] / NODES.length) * 100;
              return <div key={s} style={{ width: `${w}%`, background: colors[s], transition: "width 0.3s" }} title={`Score ${s}: ${distribution[s]} concepts`} />;
            })}
          </div>
          <div style={{ display: "flex", gap: 12, fontSize: 10, fontFamily: "monospace", color: "rgba(255,255,255,0.3)", marginBottom: 20 }}>
            <span style={{ color: "#FB7185" }}>● Speculative ({distribution[1]})</span>
            <span style={{ color: "#FBBF24" }}>● Theoretical ({distribution[2]})</span>
            <span style={{ color: "#F59E0B" }}>● Grounded ({distribution[3]})</span>
            <span style={{ color: "#10B981" }}>● Well-Sourced ({distribution[4]})</span>
            <span style={{ color: "#34D399" }}>● Empirical ({distribution[5]})</span>
          </div>

          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            {tabs.map(t => (
              <button key={t.key} onClick={() => { setActiveFilter(t.key); setOpenId(null); }} style={{
                background: activeFilter === t.key ? `${t.color}18` : "transparent",
                border: `1px solid ${activeFilter === t.key ? t.color + "50" : "rgba(255,255,255,0.1)"}`,
                color: activeFilter === t.key ? t.color : "rgba(255,255,255,0.45)",
                borderRadius: 6, padding: "5px 12px", fontSize: 11, fontFamily: "monospace",
                letterSpacing: "0.08em", cursor: "pointer", transition: "all 0.15s"
              }}>{t.label}</button>
            ))}
            <input
              value={search}
              onChange={e => { setSearch(e.target.value); setOpenId(null); }}
              placeholder="search concepts..."
              style={{
                background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)",
                borderRadius: 6, padding: "5px 12px", fontSize: 11, fontFamily: "monospace",
                color: "#F0EAD6", outline: "none", width: 180,
                "::placeholder": { color: "rgba(255,255,255,0.3)" }
              }}
            />
          </div>
        </div>
      </div>

      {/* Grid */}
      <div style={{ maxWidth: 1100, margin: "28px auto 0", padding: "0 24px" }}>
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
          gap: 10,
        }}>
          {filtered.map(node => (
            <NodeCard
              key={node.id}
              node={node}
              isOpen={openId === node.id}
              onToggle={() => setOpenId(openId === node.id ? null : node.id)}
            />
          ))}
        </div>
        {filtered.length === 0 && (
          <div style={{ textAlign: "center", color: "rgba(255,255,255,0.3)", padding: 60, fontFamily: "monospace" }}>
            no concepts match · clear filter to continue
          </div>
        )}
      </div>

      {/* Category legend at bottom */}
      <div style={{ maxWidth: 1100, margin: "40px auto 0", padding: "0 24px" }}>
        <div style={{ borderTop: "1px solid rgba(255,255,255,0.06)", paddingTop: 24, display: "flex", gap: 24, flexWrap: "wrap" }}>
          {Object.entries(CATEGORIES).map(([k, v]) => {
            const count = NODES.filter(n => n.cat === k).length;
            return (
              <div key={k} style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                <span style={{ fontSize: 10, color: v.color, fontFamily: "monospace", letterSpacing: "0.1em" }}>{v.label.toUpperCase()}</span>
                <span style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", fontFamily: "monospace" }}>{v.sub} · {count} nodes</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
