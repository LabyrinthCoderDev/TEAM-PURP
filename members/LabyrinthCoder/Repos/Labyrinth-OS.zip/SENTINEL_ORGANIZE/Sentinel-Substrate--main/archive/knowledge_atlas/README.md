# Knowledge Atlas — Labyrinth-OS

Interactive knowledge map of the theoretical foundations underlying Labyrinth-OS.

## Categories

- **Logos (Scientific Core)** — Coherence thermodynamics, uncertainty equations, entropy tax,
  alignment heat, observability Gramians. The mathematical backbone.
- **Systems (AI/Computational)** — CESK machines, Control Barrier Functions, tau-escape ratios,
  chi-vector risk, SCUEL threat classification. The implementation layer.
- **Mythos (Esoteric Control)** — Sovereign gap, the Ghost/Machine separation, dual-lane
  architecture origin. The conceptual framework.
- **Narrative (Worldbuilding)** — The story of why this architecture matters. How the enforcement
  pattern maps to real-world AI deployment risks.
- **Empirical (Real Anchors)** — What's been tested. What's been verified. What's still open.

## Usage

Load `knowledge_atlas.jsx` in any React environment. Each node shows:
- Short description (always visible)
- Detailed explanation (expandable)
- Rigor score (1-3, where 3 = formally verified)
- Tags and connections to related nodes

This is a reference artifact, not pipeline code.
It is the intellectual architecture behind the system.
