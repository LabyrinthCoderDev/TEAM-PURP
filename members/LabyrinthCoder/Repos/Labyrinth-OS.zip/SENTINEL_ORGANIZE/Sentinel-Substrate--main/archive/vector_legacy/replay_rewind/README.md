# Replay / Rewind — VECTOR Legacy

**Source:** VECTOR (archived reference)  
**Status:** PROMOTE_TO_LABYRINTH (pattern), NEEDS_REWRITE (implementation)

---

## What VECTOR Proves

VECTOR implements session rewind as in-memory checkpoints per conversation turn.
The state captured per checkpoint includes:
- `coherenceData[]` — full array of per-turn scores, Kalman state, variance, flags
- `kalmanState: {x, P}` — current filter state
- `smoothedVar` — current GARCH variance
- `messages[]` — conversation history
- `driftCount`, `calmStreak`, `harnessMode`

The rewind operation restores all of the above to the selected turn checkpoint,
effectively replaying the session to that point.

**What this proves:** The core data needed for deterministic replay is well-defined.
The state vector is finite and enumerable.

---

## What Is Missing

| Gap | Labyrinth-OS Requirement |
|-----|-----------------------|
| In-memory only | Must be backed by `ledger-chronicle` |
| No cryptographic hash | Each checkpoint must include a SHA-256 hash of the state vector |
| No post-rewind invariant check | After rewind, all invariants (I1–I10) must be re-validated |
| No tamper-evidence | Hash chain must cover the full checkpoint sequence |
| Non-deterministic SDE | SDE simulation not included in checkpoint — not needed if Labyrinth-OS uses deterministic algebra |
| Sensor state not captured | Sensor readings at rewind point must be included in checkpoint |

---

## Labyrinth-OS Mapping

| VECTOR concept | Labyrinth-OS module |
|----------------|-----------------|
| Session checkpoint | `crates/replay-gnosis` `SystemCheckpoint` |
| Rewind operation | `crates/replay-gnosis` `replay_to_checkpoint()` |
| Checkpoint hash | SHA-256 over canonical state serialisation |
| Ledger backing | `crates/ledger-chronicle` |
| Post-rewind validation | `crates/cgir-validator` re-runs all invariant checks |

---

## Promotion Requirements

1. Define `SystemCheckpoint` in `crates/replay-gnosis` with all VECTOR state fields plus:
   - `checkpoint_hash: String` — SHA-256 of canonical JSON state
   - `parent_hash: Option<String>` — chain to prior checkpoint
   - `logical_time: u64` — bound to Labyrinth-OS logical clock
   - `council_result_hash: String` — hash of last CouncilResult at this checkpoint
2. Store every checkpoint in `ledger-chronicle` before advancing to next turn
3. `replay_to_checkpoint(id)` must:
   a. Load checkpoint from ledger
   b. Verify hash chain integrity
   c. Re-run all invariant checks
   d. Return `Err(ReplayError)` if any invariant fails
4. Determinism test: `replay(checkpoint) == original_execution_state`
5. **Do NOT include SDE simulation state** — Labyrinth-OS replay uses deterministic algebra only

---

## Files to Reference

- `components/VECTOR.jsx` — search for `rewind` state and `setRewindIdx` for checkpoint logic
- `sdk/engine.ts` — `CoherenceDataPoint` interface for the per-turn state shape
