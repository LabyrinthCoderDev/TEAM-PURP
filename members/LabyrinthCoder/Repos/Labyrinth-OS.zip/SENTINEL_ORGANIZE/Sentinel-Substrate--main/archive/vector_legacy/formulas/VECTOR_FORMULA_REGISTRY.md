# VECTOR Formula Registry

**Source:** VECTOR (archived reference)  
**Commit scanned:** 5ac87e993336cbe39d3b2e9e85e17a1c2e4fa7bf  
**Scanned:** 2026-04-24  
**Language:** TypeScript (sdk/*.ts) + JavaScript (VECTOR.jsx)

Canonical reference for every formula, constant, and algorithm extracted
from the VECTOR prototype.

> **Promote rule:** A formula may only enter Labyrinth-OS core if it is:
> deterministic, testable, documented, replay-compatible, and mapped to a
> current invariant or module.

---

## Constants

### κ — Damping Constant (Hudson Constant)

| Field | Value |
|-------|-------|
| **Source** | `sdk/constants.ts` |
| **Value** | `0.444` (Hudson-Perry empirical) or `0.500` (standard) |
| **Derived** | `DAMPING = 1/(1+κ) = 0.6925` |
| **Used in** | SDE damping, Kalman λ, drift law, pipe injection γ |
| **Labyrinth-OS mapping** | `crates/signal-algebra` / `crates/cgir-temporal` |
| **Status** | WORKS — empirically validated across VECTOR sessions |
| **Notes** | 0.444 is VECTOR-specific. RESONANCE_ANCHOR=623.81 Hz is explicitly UNVALIDATED. Use 0.444 only after validating for Labyrinth-OS signal domain. |

### ε — Coherence Floor (Ghost Tax)

| Field | Value |
|-------|-------|
| **Source** | `sdk/constants.ts` → `EPSILON = 0.05` |
| **Value** | `0.05` — ~5% irreducible inefficiency floor |
| **Used in** | Drift Law cap_eff, coherence score floor anchor |
| **Labyrinth-OS mapping** | `crates/signal-algebra` |
| **Status** | EXPERIMENTAL — cross-domain convergence observed (fMRI Lamm 2011) but not proven causal |
| **Notes** | FRAMEWORK.md: "ε = 0.05 is the anchor, not a free parameter." Do not modify without empirical justification. |

### GARCH Defaults

| Parameter | Value | Role |
|-----------|-------|------|
| `GARCH_OMEGA` | 0.02 | Baseline variance |
| `GARCH_ALPHA` | 0.15 | Weight on last squared error |
| `GARCH_BETA` | 0.80 | Weight on previous variance estimate |
| Stationarity | α+β=0.95 < 1 ✓ | Stationary by default |

Per-preset overrides: CIRCUIT has α=0.09, β=0.88 (α+β=0.97 — near boundary).

### Variance Thresholds (DEFAULT preset)

| State | σ² threshold | Meaning |
|-------|-------------|---------|
| CALM | < 0.080 | Stable, coherent |
| NOMINAL | 0.080–0.120 | Normal operating range |
| CAUTION | > 0.120 | Rising variance |
| DECOHERENCE | > 0.200 | High variance, max correction |

### Kalman Constants

| Parameter | Value | Role |
|-----------|-------|------|
| `KALMAN_R` | 0.015 | Observation noise variance |
| `KALMAN_SIGMA_P` | 0.06 | Process noise std dev |
| `λ` | `1/(1+κ) = 0.6925` | Damping factor |

---

## Core Formulas

### 1. GARCH(1,1) Variance

**Source:** `sdk/drift.ts :: updateSmoothedVariance()`

```
σ²_t = ω_g + α_g · ε²_{t-1} + β_g · σ²_{t-1}

Early-turn blend:
  weight = min(t/10, 1)
  σ²_t   = weight × GARCH + (1 − weight) × rolling_window_variance

Stationarity condition: α_g + β_g < 1
```

| Field | Value |
|-------|-------|
| **Inputs** | `history: number[]`, `prev: number\|null`, `cfg?: PresetConfig` |
| **Output** | `smoothedVar: number` (variance estimate) |
| **Purpose** | Track volatility clustering — single unusual turn doesn't trigger escalation; sustained elevation does |
| **Source location** | `sdk/drift.ts:updateSmoothedVariance()` |
| **Maps to Labyrinth-OS** | Yes |
| **Labyrinth-OS destination** | `crates/signal-algebra/src/lib.rs` |
| **Status** | WORKS — reference: Engle 1982 |

---

### 2. Drift Law Floor

**Source:** `sdk/drift.ts :: driftLawFloor() / driftLawCapEff()`

```
cap_eff = ε / (1 + γ_h)
τ       = max(0.0225 / ε, 1)

ΔS = cap_eff × (1 − exp(−n^α_s / τ))
   + |β_C × sin(γ_h × n × 0.01)| × 0.05

Constants: α_s = 1.8, β_C = 0.2, ε = 0.05
Harness modes: γ_h ∈ {0.05, 50, 5000, 10000}
```

| Field | Value |
|-------|-------|
| **Inputs** | `n: number` (turn), `gamma_h: number` (harness mode), `epsilon?: number` |
| **Output** | `deltaS: number` — systematic drift floor |
| **Purpose** | Model the irreducible floor of drift accumulation over turns |
| **Source location** | `sdk/drift.ts:driftLawFloor()` |
| **Maps to Labyrinth-OS** | Yes (temporal validity, I5) |
| **Labyrinth-OS destination** | `crates/cgir-temporal/src/lib.rs` |
| **Status** | PARTIAL — empirical formula, cross-domain unvalidated |

---

### 3. Coherence Score

**Source:** `sdk/coherence.ts :: computeCoherence()`

```
C_raw = w_tfidf × TF-IDF(new, recent)
      + w_jsd   × (1 − JSD(new, recent))
      + w_len   × exp(−|newLen − avgLen| / avgLen × 2)
      + w_struct × exp(−|newSC − avgSC| / avgSC × 1.5)
      + w_persist × (top-15-term overlap rate)
      × repPenalty(overlap > 0.65 → penalty = 0.65, else 1.0)

Default weights: tfidf=0.25, jsd=0.25, len=0.25, struct=0.15, persist=0.10

Exponential Bayesian blending (V1.7.0):
  α(t) = 1 − exp(−t / τ),  τ = 5
  prior = 0.75
  C = α(t) × C_raw + (1 − α(t)) × 0.75

Output: clamp(C, 0.30, 0.99)
```

| Field | Value |
|-------|-------|
| **Inputs** | `newContent: string`, `history: Message[]`, `weights?: CoherenceWeights` |
| **Output** | `score: number ∈ [0.30, 0.99]` |
| **Purpose** | Per-turn quality/coherence metric measuring vocabulary and structural consistency |
| **Source location** | `sdk/coherence.ts:computeCoherence()` |
| **Maps to Labyrinth-OS** | Yes — signal confidence synthesis |
| **Labyrinth-OS destination** | `crates/signal-algebra/src/lib.rs` |
| **Status** | WORKS — EDM parallel validated (Kim et al. Science Advances April 2026) |
| **Notes** | TF-IDF only in SDK. Semantic embeddings (all-MiniLM-L6-v2) available in Vercel deployment only. |

---

### 4. TF-IDF Cosine Similarity

**Source:** `sdk/coherence.ts :: tfidfSimilarity()`

```
IDF(term) = log((N+1) / (df+1)) + 1  [N=2 for 2-document comparison]

df=2 (shared):  IDF ≈ 1.000  — shared terms contribute
df=1 (unique):  IDF ≈ 1.405  — unique terms weighted higher

tfidf_a[term] = tf_a[term] × IDF(term)
tfidf_b[term] = tf_b[term] × IDF(term)

cosine = dot(tfidf_a, tfidf_b) / (|tfidf_a| × |tfidf_b|)
output = clamp(cosine, 0, 1)
```

| Field | Value |
|-------|-------|
| **Inputs** | `tokensA: string[]`, `tokensB: string[]` |
| **Output** | `similarity: number ∈ [0, 1]` |
| **Source location** | `sdk/coherence.ts:tfidfSimilarity()` |
| **Maps to Labyrinth-OS** | Yes |
| **Labyrinth-OS destination** | `crates/signal-algebra/src/lib.rs` |
| **Status** | WORKS (V1.7 fix — old formula always returned 0 for shared terms) |

---

### 5. Jensen-Shannon Divergence

**Source:** `sdk/coherence.ts :: jensenShannonDivergence()`

```
M[t] = (P[t] + Q[t]) / 2

KL(P||M) = Σ_t P[t] × log(P[t] / M[t])  (where P[t] > 0)
KL(Q||M) = Σ_t Q[t] × log(Q[t] / M[t])  (where Q[t] > 0)

JSD(P, Q) = clamp((KL(P||M) + KL(Q||M)) / (2 × ln(2)), 0, 1)

Properties: JSD = 0 ↔ identical distributions
            JSD = 1 ↔ maximally different distributions
            Symmetric: JSD(P,Q) = JSD(Q,P)
```

| Field | Value |
|-------|-------|
| **Inputs** | `tokensA: string[]`, `tokensB: string[]` |
| **Output** | `jsd: number ∈ [0, 1]` |
| **Purpose** | Symmetric semantic divergence between two text distributions |
| **Source location** | `sdk/coherence.ts:jensenShannonDivergence()` |
| **Maps to Labyrinth-OS** | Yes — highest priority port |
| **Labyrinth-OS destination** | `crates/signal-algebra/src/lib.rs` |
| **Status** | WORKS — reference: Chuang et al. 2024 (Anthropic/Berkeley DoLa) |

---

### 6. Exponential Bayesian Blending

**Source:** `sdk/coherence.ts :: computeCoherence()` (V1.7.0)

```
α(t) = 1 − exp(−t / τ),  τ = 5

C_blended = α(t) × C_raw + (1 − α(t)) × prior
prior = 0.75

At t=0:  α=0,    C_blended = 0.75 (pure prior)
At t=5:  α=0.63, C_blended ≈ 0.63×C_raw + 0.37×0.75
At t=∞:  α→1,   C_blended → C_raw
```

| Field | Value |
|-------|-------|
| **Purpose** | Smooth continuous transition from prior-dominated (early) to signal-dominated (late) scoring. Replaces hard linear ramp from V1.0–1.6. |
| **Source location** | `sdk/coherence.ts:computeCoherence()` |
| **Maps to Labyrinth-OS** | Yes — confidence synthesis early-session handling |
| **Labyrinth-OS destination** | `crates/signal-algebra/src/lib.rs` |
| **Status** | WORKS (reference: ChatGPT Labyrinth-OS Q1 resolution, April 16 2026) |

---

### 7. Kalman Filter (Linear)

**Source:** `sdk/sde.ts :: kalmanStep()`

```
λ = 1/(1+κ)
a(t) = λ × (α + β_p×sin(ωt) − δ×σ²(t))
F = 1 + a(t)              [process model]
Q = (σ_p × λ)²            [process noise]

x_p = F × x̂_{t-1}        [predict]
P_p = F² × P_{t-1} + Q

K = P_p / (P_p + R)       [Kalman gain]
x̂_t = x_p + K × (obs − x_p)   [update]
P_t = (1 − K) × P_p

Defaults: R=0.015, σ_p=0.06, λ=0.6925
```

| Field | Value |
|-------|-------|
| **Inputs** | `state: {x, P}`, `obs: number`, `t: number`, `params: SDEParams` |
| **Output** | `state: {x, P}` — updated Kalman state |
| **Purpose** | Smooth noisy per-turn coherence scores into reliable state estimate |
| **Source location** | `sdk/sde.ts:kalmanStep()` |
| **Maps to Labyrinth-OS** | Yes |
| **Labyrinth-OS destination** | `crates/signal-algebra/src/lib.rs` |
| **Status** | WORKS — standard algorithm |
| **Notes** | Watch Kalman line, not raw score. Sustained downward trend in x̂ is the signal. |

---

### 8. SDE — Ornstein-Uhlenbeck + Periodic Forcing

**Source:** `sdk/sde.ts :: simulateSDE()`

```
dε(t) = a(t) ε(t) dt + b dW_t + J dN(λ)

a(t) = (α + β_p sin(ωt) − δ σ²(t)) / (1+κ)
b    = σ / (1+κ)

GARCH-in-Mean coupling: high σ² pushes a(t) toward mean reversion

Jump-diffusion: J dN(λ), jumpProb = 1 − exp(−λ·dt)

Defaults: α=−0.25, β_p=0.18, ω=2π/12, σ=0.10, κ=0.444
Stable iff: a_max = (α + β_p) / (1+κ) < 0  → (−0.25+0.18)/1.444 = −0.048 < 0 ✓
```

| Field | Value |
|-------|-------|
| **Purpose** | Monte Carlo simulation of coherence trajectory dynamics |
| **Source location** | `sdk/sde.ts:simulateSDE()` |
| **Maps to Labyrinth-OS** | No — ARCHIVE_ONLY |
| **Status** | WORKS for simulation, NOT DETERMINISTIC (stochastic) |
| **Notes** | Mathematical backbone of VECTOR. Archive as reference. Labyrinth-OS uses deterministic algebra, not simulation. |

---

### 9. Lyapunov Stability Bound

**Source:** `sdk/sde.ts :: computeLyapunovBound()`

```
a_max = (α + β_p − δ·σ²) / (1+κ)   [worst-case drift coefficient]
a_min = (α − β_p − δ·σ²) / (1+κ)

stable  iff a_max < 0
margin = −a_max  (positive = stable, larger = more margin)

At VECTOR defaults (δ=0.30, σ²=0):
  a_max = (−0.25 + 0.18) / 1.444 = −0.048  → stable, margin=0.048
```

| Field | Value |
|-------|-------|
| **Inputs** | `params: SDEParams`, `smoothedVar: number` |
| **Output** | `{stable: bool, a_max, a_min, margin}` |
| **Purpose** | Live stability guarantee of SDE parameters — reject unstable configs at Gate |
| **Source location** | `sdk/sde.ts:computeLyapunovBound()` |
| **Maps to Labyrinth-OS** | Yes — cgir-validator invariant check |
| **Labyrinth-OS destination** | `crates/cgir-validator/src/lib.rs` |
| **Status** | WORKS — reference: Lyapunov 1892; Gardiner 1985 |

---

### 10. ΔC Causal Delta (Forward Delta)

**Source:** `sdk/causal.ts :: propagateForwardDeltas()`

```
ΔC_k(origin) = C_{origin+k} − C_{origin}    for k = 1..5

Policy arm:   origins where injection fired
Baseline arm: origins with no injection in [i+1 .. i+MAX_LAG]
              (disjoint windows prevent contamination)

Recovery: P(C_{t+k} > 0.60 for some k ≤ 3 | C_t < 0.50)

Constants:
  DRIFT_THRESHOLD    = 0.50
  RECOVERY_THRESHOLD = 0.60
  RECOVERY_WINDOW    = 3
  MAX_LAG            = 5
  BIN_EDGES          = 0.50 (low/mid), 0.75 (mid/high)
```

| Field | Value |
|-------|-------|
| **Inputs** | `priors: ShadowEntry[]`, `currentScore: number` |
| **Output** | Updated priors with `forwardDeltas[k]` and `recovered` fields |
| **Purpose** | Trajectory-based counterfactual measurement of correction injection effectiveness |
| **Source location** | `sdk/causal.ts:propagateForwardDeltas()` |
| **Maps to Labyrinth-OS** | Yes — replay-gnosis causal analysis |
| **Labyrinth-OS destination** | `crates/replay-gnosis/src/lib.rs` |
| **Status** | PARTIAL — Phase B (N≥100 sessions) not yet complete |
| **Notes** | Pre-requisite for any causal claim about correction effectiveness. Reference: ROADMAP.md #1. |

---

### 11. Pipe Injection u_drift(t)

**Source:** `sdk/engine.ts :: buildPipeInjection()` (compressed format)

```
Compressed format:
  [V|t{turn}|v={σ²}|st={STATE}|kx={x̂}|kp={P}|cl={calmStreak}|dr={driftCount}|md={MODE}|h={H}|b={B}]->{DIRECTIVE}.[/V]

States: NOM / CAU / DEC / CLM
Modes:  AUD (γ_h=0.05) / MOD (γ_h=50) / DPC (γ_h=5000) / XTR (γ_h=10000)

Directives:
  DEC → "REALIGN. One sentence. No questions."
  CAU → "CONSOLIDATE. Increase term persistence."
  CLM (≥3) → "STABLE. Maintain density. Max one question."
  NOM → "DIRECT. No unrequested content. Max one question."

Mute injection (word limit):
  wordLimit = round(muteMaxTokens × 0.75)    [corrected from cap/8]

Drift gate injection:
  σ² > varCaution  → "Hard limit: {wordLimit} words or fewer"
  σ² > varDecoherence → severity = CRITICAL
```

| Field | Value |
|-------|-------|
| **Purpose** | u_drift(t) — bounded corrective forcing injected into system prompt |
| **Source location** | `sdk/engine.ts:buildPipeInjection()` |
| **Maps to Labyrinth-OS** | NEEDS_REWRITE — route as PlannerProposal through Gate |
| **Labyrinth-OS destination** | `crates/planner/src/lib.rs` |
| **Status** | WORKS in VECTOR. BROKEN as Labyrinth-OS architecture: bypasses Gate. |
| **Notes** | Compressed format is clever. 60–70% fewer tokens than verbose format. Preserve the encoding scheme as reference. |

---

### 12. AutoTune — Context Detection + Feedback Learning

**Source:** `sdk/autotune.ts :: computeAutoTuneParams()`

```
Context types: code | creative | analytical | conversational | chaotic

Pattern matching:
  current message weight = 3×
  last 4 history messages = 1× each

Confidence blend:
  if confidence < 0.6:
    params = confidence/0.6 × profile_params + (1 − confidence/0.6) × conversational_params

EMA feedback learning (≥3 samples in bucket):
  wt = min((sampleCount/20) × 0.5, 0.5)
  adjustment = (pos_params[k] − neutral[k]) − (neg_params[k] − neutral[k])
  params[k] += adjustment × wt

Profiles:
  code:           temp=0.15, top_p=0.80, freq_pen=0.20
  creative:       temp=1.15, top_p=0.95, freq_pen=0.50
  analytical:     temp=0.40, top_p=0.88, freq_pen=0.20
  conversational: temp=0.75, top_p=0.90, freq_pen=0.10
  chaotic:        temp=1.70, top_p=0.99, freq_pen=0.80
```

| Field | Value |
|-------|-------|
| **Purpose** | Adaptive sampling parameter selection based on message context + user feedback |
| **Source location** | `sdk/autotune.ts:computeAutoTuneParams()` |
| **Maps to Labyrinth-OS** | REVISIT_LATER — pattern maps to offline-evolution |
| **Labyrinth-OS destination** | `crates/offline-evolution/src/lib.rs` |
| **Status** | WORKS for LLM API tuning. UNVALIDATED beyond that domain. |

---

### 13. Failure Probability Formulas

**Source:** `sdk/reliability.ts`

```
Murphy's infinity:
  P(fail in n) = 1 − (1−p)^n

Min-n for target failure rate:
  n = ⌈ log(1−q) / log(1−p) ⌉

Series system:
  P(any fail) = 1 − Π_i (1 − p_i)

Laplace-smoothed rate estimate:
  rate = (k+1) / (n+2)    [flat Bayesian prior]

Law of Total Probability:
  P(A) = Σ_i P(A|B_i) × P(B_i)
```

| Field | Value |
|-------|-------|
| **Purpose** | Standard reliability engineering formulas for failure probability analysis |
| **Source location** | `sdk/reliability.ts` |
| **Maps to Labyrinth-OS** | Yes — cgir-validator reliability analysis |
| **Labyrinth-OS destination** | `crates/cgir-validator/src/lib.rs` |
| **Status** | WORKS — reference: Feller 1968 |
| **Notes** | Do NOT port `sodsLawScore` or `entropyDriftNarrative` — satirical/narrative only. |

---

### 14. Shannon Response Entropy (χ proxy)

**Source:** `sdk/signals.ts :: computeResponseEntropy()`

```
H = −Σ_w p(w) × log2(p(w))    [Shannon entropy over token frequencies]

Thresholds:
  H < 0.8 AND len > 10 → repetitive/low-information signal (H-signal 4)
  H > 3.5 AND high vocab growth → possible confabulation
```

| Field | Value |
|-------|-------|
| **Inputs** | `tokens: string[]` |
| **Output** | `entropy: number` |
| **Purpose** | χ stability proxy — low entropy = repetitive content |
| **Source location** | `sdk/signals.ts:computeResponseEntropy()` |
| **Maps to Labyrinth-OS** | Yes — vector-sensors chi_stability |
| **Labyrinth-OS destination** | `crates/vector-sensors/src/lib.rs` |
| **Status** | WORKS |

---

### 15. Bhattacharyya-style Contextual Overlap

**Source:** `sdk/signals.ts :: computeContextualOverlap()`  
*(formerly computeMutualInformation — renamed V1.8.1)*

```
For each term t:
  freqJoint[t] = √(p_A[t] × p_B[t])    [geometric mean of marginals]

H_A = Shannon entropy of p_A
H_B = Shannon entropy of p_B
H_Joint = Shannon entropy of normalized freqJoint

overlap = clamp((H_A + H_B − H_Joint) / min(H_A, H_B), 0, 1)
```

| Field | Value |
|-------|-------|
| **Purpose** | Context-dependence proxy. Low = response statistically disconnected from context. |
| **Source location** | `sdk/signals.ts:computeContextualOverlap()` |
| **Maps to Labyrinth-OS** | Yes — vector-sensors contextual_overlap field |
| **Labyrinth-OS destination** | `crates/vector-sensors/src/lib.rs` |
| **Status** | NEEDS_TEST_HARNESS |
| **Notes** | NOT Shannon MI. Proper MI requires joint distribution via k-NN (Kraskov et al. 2004). V2 TODO in VECTOR code. Do NOT call it mutual_information in Labyrinth-OS. |

---

### 16. StableDRL Clipping

**Source:** `sdk/drift.ts :: stabledrlClipScore() / stabledrlNormalizeVar()`

```
Score clipping:
  ratio = rawScore / prevScore
  if ratio > 3.0:  clipped = prevScore × 3.0
  if ratio < 1/3:  clipped = prevScore / 3.0
  output = clamp(clipped, 0.30, 0.99)

Variance normalization:
  clippedSum = Σ min(score, 0.85) over last 8 turns
  normFactor = max(clippedSum / window, 0.50)
  normalizedVar = smoothedVar / normFactor
```

| Field | Value |
|-------|-------|
| **Purpose** | Prevent over-correction feedback loops by unconditional ratio clipping |
| **Source location** | `sdk/drift.ts:stabledrlClipScore()` |
| **Maps to Labyrinth-OS** | Yes — Gate THROTTLE / FALLBACK |
| **Labyrinth-OS destination** | `crates/gate/src/lib.rs` |
| **Status** | WORKS — reference: Li et al. 2026 StableDRL |

---

### 17. PID Controller on Variance

**Source:** `sdk/drift.ts :: computePIDCorrection()`

```
error = current_var − TARGET   [TARGET = 0.080]

P = KP × error                 [KP = 1.20]
I = clamp(KI × mean(error over last 8), −1.0, 1.0)  [KI = 0.08]
D = KD × (current − prev_var)  [KD = 0.40]

output = clamp(1.0 + P + I + D, 0, 3.0)

output > 2.0 → over-correction risk → harness should escalate
```

| Field | Value |
|-------|-------|
| **Purpose** | Proportional-Integral-Derivative control on variance — corrective force magnitude |
| **Source location** | `sdk/drift.ts:computePIDCorrection()` |
| **Maps to Labyrinth-OS** | REVISIT_LATER — Planner proposal weighting |
| **Labyrinth-OS destination** | `crates/planner/src/lib.rs` |
| **Status** | WORKS — reference: Åström & Hägglund 1995 |

---

### 18. Realized Volatility

**Source:** `sdk/drift.ts :: computeRealizedVolatility()`

```
RV_t = (1/n) Σ_{i=1}^{n} (score_i − score_{i-1})²   [window n=8]
```

| Field | Value |
|-------|-------|
| **Purpose** | Fast-reacting variance complement to GARCH. Detects sudden spikes. |
| **Source location** | `sdk/drift.ts:computeRealizedVolatility()` |
| **Maps to Labyrinth-OS** | Yes — signal-algebra |
| **Status** | WORKS — reference: Andersen & Bollerslev 1998 |

---

### 19. Lyapunov Stability Check

Already documented above (formula #9).

---

### 20. EWMA Trend

**Source:** `sdk/signals.ts :: computeEWMATrend()`

```
ewma_0 = score_0
ewma_t = α × score_t + (1−α) × ewma_{t-1}   [α=0.3 default]
trend  = ewma_t − score_{t-1}
momentum = trend_t − trend_{t-1}
```

| Field | Value |
|-------|-------|
| **Purpose** | Smooth coherence trend with momentum for direction detection |
| **Source location** | `sdk/signals.ts:computeEWMATrend()` |
| **Maps to Labyrinth-OS** | Yes — signal-algebra |
| **Status** | WORKS |

---

## VECTOR → Labyrinth-OS Module Mapping

| VECTOR Component | Source File | Labyrinth-OS Module | Notes |
|-----------------|-------------|-----------------|-------|
| GARCH(1,1) | `sdk/drift.ts` | `crates/signal-algebra` | Port to Rust, per-preset params |
| Coherence formula | `sdk/coherence.ts` | `crates/signal-algebra` | Highest priority |
| TF-IDF similarity | `sdk/coherence.ts` | `crates/signal-algebra` | Fix IDF formula already in VECTOR |
| JSD | `sdk/coherence.ts` | `crates/signal-algebra` | Proven by Chuang et al. 2024 |
| Drift Law | `sdk/drift.ts` | `crates/cgir-temporal` | Validate ε=0.05 first |
| Kalman filter | `sdk/sde.ts` | `crates/signal-algebra` | Configurable R, sigma_p |
| Lyapunov bound | `sdk/sde.ts` | `crates/cgir-validator` | Gate rejects unstable params |
| ΔC causal delta | `sdk/causal.ts` | `crates/replay-gnosis` | Phase B validation required |
| Shannon entropy (χ) | `sdk/signals.ts` | `crates/vector-sensors` | chi_stability field |
| Vocab growth rate | `sdk/signals.ts` | `crates/vector-sensors` | Bounded history window needed |
| Bhattacharyya overlap | `sdk/signals.ts` | `crates/vector-sensors` | NOT MI — rename carefully |
| Fisher information | `sdk/signals.ts` | `crates/signal-algebra` | Needs test harness |
| EWMA trend | `sdk/signals.ts` | `crates/signal-algebra` | Standard — promote directly |
| Realized volatility | `sdk/drift.ts` | `crates/signal-algebra` | Standard — promote directly |
| StableDRL clipping | `sdk/drift.ts` | `crates/gate` | Safety property |
| Failure prob formulas | `sdk/reliability.ts` | `crates/cgir-validator` | Normal tier only |
| Mann-Whitney + BH FDR | `sdk/stats.ts` | `tests/` | Validation test infrastructure |
| H-signals | `sdk/signals.ts` | `crates/watcher-a` | Signal 3 needs V2 rewrite |
| B-signals | `sdk/signals.ts` | `crates/watcher-b` | Regex → Rust regex crate |
| AutoTune | `sdk/autotune.ts` | `crates/offline-evolution` | EMA learning pattern |
| Pipe injection | `sdk/engine.ts` | `crates/planner` | MUST route through Gate |
| PID controller | `sdk/drift.ts` | `crates/planner` | Re-tune for Labyrinth-OS domain |
| Session rewind | `components/VECTOR.jsx` | `crates/replay-gnosis` | Needs ledger backing + hash |
| SDE simulation | `sdk/sde.ts` | ARCHIVE_ONLY | Math reference only |
| Dashboard | `components/VECTOR.jsx` | NONE | Build fresh from ledger-chronicle |
| JSONL storage | `sdk/storage.ts` | ARCHIVE_ONLY | Schema reference only |
| Industry presets | `sdk/constants.ts` | `crates/signal-algebra` | Validate for Labyrinth-OS domain |
| RESONANCE_ANCHOR=623.81 | `sdk/constants.ts` | ARCHIVE_ONLY | Explicitly UNVALIDATED |
| Berry Phase | `sdk/signals.ts` | experiments/ | Needs theoretical justification |
| SHE Torque | `sdk/signals.ts` | experiments/ | Needs hardware co-validation |
| Zero-Drift Lock | `sdk/drift.ts` | experiments/ | Anchor unvalidated |
| Sod's Law | `sdk/reliability.ts` | DO NOT PROMOTE | Satirical formula |
