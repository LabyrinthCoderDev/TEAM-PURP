# Drift Metrics — VECTOR Legacy

**Source:** VECTOR (archived reference)  
**Primary files:** `sdk/drift.ts`, `sdk/signals.ts`, `sdk/sde.ts`

---

## Drift Metrics Inventory

### GARCH(1,1) — `sdk/drift.ts :: updateSmoothedVariance()`
**Category:** PROMOTE_TO_LABYRINTH  
**Formula:** `σ²_t = ω + α·ε²_{t-1} + β·σ²_{t-1}`  
**Key property:** Volatility clustering — sustained elevation matters more than single spikes  
**Stationarity:** `α + β < 1` required (DEFAULT: 0.15 + 0.80 = 0.95 ✓)  
**Labyrinth-OS destination:** `crates/signal-algebra`

### Drift Law — `sdk/drift.ts :: driftLawFloor()`
**Category:** PROMOTE_TO_LABYRINTH (after validation)  
**Formula:** `ΔS = (ε/(1+γ_h)) × (1 − exp(−n^1.8 / τ)) + |0.2 × sin(γ_h×n×0.01)| × 0.05`  
**Purpose:** Irreducible drift floor — prevents false "all clear" as turns accumulate  
**Labyrinth-OS destination:** `crates/cgir-temporal`

### Realized Volatility — `sdk/drift.ts :: computeRealizedVolatility()`
**Category:** PROMOTE_TO_LABYRINTH  
**Formula:** `RV = (1/n) Σ (score_i − score_{i-1})²`  
**Purpose:** Fast-reacting complement to GARCH — detects sudden spikes  
**Labyrinth-OS destination:** `crates/signal-algebra`

### PID Controller — `sdk/drift.ts :: computePIDCorrection()`
**Category:** REVISIT_LATER  
**Formula:** `output = clamp(1.0 + KP×error + KI×integral + KD×derivative, 0, 3.0)`  
**KP=1.20, KI=0.08, KD=0.40, TARGET=0.080**  
**Labyrinth-OS destination:** `crates/planner` (advisory weight only, through Gate)

### StableDRL Clipping — `sdk/drift.ts :: stabledrlClipScore()`
**Category:** PROMOTE_TO_LABYRINTH  
**Formula:** Ratio clipping: `if ratio > 3.0: clipped = prev × 3.0`  
**Purpose:** Prevents correction injection from amplifying variance (feedback loop)  
**Labyrinth-OS destination:** `crates/gate`

### Fisher Information — `sdk/signals.ts :: computeFisherInformation()`
**Category:** NEEDS_TEST_HARNESS  
**Formula:** `FI = velocity² / variance` (velocity = recent score changes)  
**Purpose:** Sudden character-change detection  
**Labyrinth-OS destination:** `crates/signal-algebra`

### EWMA Trend — `sdk/signals.ts :: computeEWMATrend()`
**Category:** PROMOTE_TO_LABYRINTH  
**Formula:** `ewma = α × score + (1−α) × ewma_prev`, `α=0.3 default`  
**Purpose:** Smooth trend with momentum  
**Labyrinth-OS destination:** `crates/signal-algebra`

### Shannon Entropy (χ) — `sdk/signals.ts :: computeResponseEntropy()`
**Category:** PROMOTE_TO_LABYRINTH  
**Formula:** `H = −Σ p(w) × log2(p(w))`  
**Threshold:** H < 0.8 → repetitive content  
**Labyrinth-OS destination:** `crates/vector-sensors` (chi_stability field)

### Vocabulary Growth Rate — `sdk/signals.ts :: computeVocabGrowthRate()`
**Category:** PROMOTE_TO_LABYRINTH  
**Formula:** `novel_tokens / total_tokens` vs prior session  
**Threshold:** > 70% under elevated variance → H-signal 5  
**Labyrinth-OS destination:** `crates/vector-sensors`

### Lyapunov Stability Bound — `sdk/sde.ts :: computeLyapunovBound()`
**Category:** PROMOTE_TO_LABYRINTH  
**Formula:** `stable iff a_max = (α + β_p − δ·σ²)/(1+κ) < 0`  
**Purpose:** Reject unstable SDE parameterisations at Gate  
**Labyrinth-OS destination:** `crates/cgir-validator`

### Berry Phase — `sdk/signals.ts :: computeBerryPhase()`
**Category:** EXPERIMENTAL  
**Formula:** `crossings/total × π`  
**Status:** Needs theoretical justification. Archive in `experiments/`. Do not promote.

### SHE Torque — `sdk/signals.ts :: computeSHETorque()`
**Category:** EXPERIMENTAL  
**Formula:** `θ_SH × σ² × sign(Kalman x̂)`, `θ_SH=0.20`  
**Status:** Hardware co-validation not done. Archive in `experiments/`. Do not promote.

### Zero-Drift Lock — `sdk/drift.ts :: applyZeroDriftLock()`
**Category:** EXPERIMENTAL  
**Status:** RESONANCE_ANCHOR=623.81 explicitly UNVALIDATED in VECTOR README.  
Archive in `experiments/`. Do not promote until validated.

---

## Threshold Reference

### DEFAULT Preset

| State | σ² | Action |
|-------|-----|--------|
| CALM | < 0.080 | STABLE directive if calm ≥ 3 turns |
| NOMINAL | 0.080–0.120 | DIRECT directive |
| CAUTION | > 0.120 | CONSOLIDATE directive |
| DECOHERENCE | > 0.200 | REALIGN directive, max correction |

### CIRCUIT Preset (tightest — most applicable to Labyrinth-OS)

| State | σ² |
|-------|-----|
| CALM | < 0.050 |
| NOMINAL | 0.050–0.080 |
| CAUTION | > 0.080 |
| DECOHERENCE | > 0.140 |

### Drift Escalation Turns (DEFAULT)

| Level | Turns |
|-------|-------|
| Moderate escalation | 3 drift events |
| Deep escalation | 5 drift events |
| Extreme escalation | 8 drift events |

---

## Labyrinth-OS Integration Notes

- GARCH and Kalman state must be included in `SystemCheckpoint` for replay
- All drift thresholds must be configurable (not hardcoded) in Labyrinth-OS
- The CIRCUIT preset thresholds are the closest to Labyrinth-OS's tightest invariants
- Validate all threshold values for Labyrinth-OS signal domain before adopting
