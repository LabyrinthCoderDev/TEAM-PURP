# VECTOR Migration Report

**Source:** VECTOR (archived reference)  
**Commit scanned:** 5ac87e993336cbe39d3b2e9e85e17a1c2e4fa7bf  
**Target project:** Labyrinth-OS / CGIR / Labyrinth-OS  
**Scanned:** 2026-04-24  
**Status:** ACTIVE — do not delete VECTOR repo until Labyrinth-OS Rust ports are complete

---

## A. Summary

VECTOR is a **JavaScript/TypeScript Next.js dashboard application** for real-time
LLM coherence and drift monitoring. It is a research prototype (V2.0.0), not a
production system. It is explicitly self-described as "an observability engine with
a soft heuristic controller" — not a provably safe control system.

**Architecture:**
- `VECTOR.jsx` (455KB) — monolithic React dashboard, deployable as Claude artifact
- `sdk/*.ts` (13 TypeScript modules) — standalone math library
- `tools/*.py` — Python offline analysis tools
- `evals/VECTOR_EVALS.md` — 15-check release checklist

**What VECTOR does:**  
Every LLM output is scored (TF-IDF + JSD coherence formula). The score feeds a
GARCH(1,1) variance model and a Kalman filter. When variance exceeds thresholds,
signal detectors fire (H-signals and B-signals). Corrective directives are
injected into the next system prompt as compressed text (`u_drift(t)`). Causal
deltas (ΔC for k=1..5 turns) measure whether corrections actually worked.

**What VECTOR is NOT:**
- Not deterministic (stochastic SDE simulation)
- Not replay-verified (no cryptographic checkpoints)
- Not gate-governed (corrections bypass any approval process)
- Not validated beyond LLM conversation sessions (per its own README)
- Not production-ready in the Labyrinth-OS sense

---

## B. What VECTOR Already Proved

The following results are confirmed by VECTOR's own validation status and
independent third-party evidence:

| Claim | Evidence |
|-------|---------|
| GARCH(1,1) tracks volatility clustering across turns | Engle 1982; standard quant finance result |
| Kalman filter smooths noisy per-turn scores | Standard algorithm; well-proven |
| JSD is the correct tool for sparse-vocab semantic drift | Chuang et al. 2024 (DoLa, Anthropic/Berkeley) |
| 45° angular gate for drift detection is independent parallel | Kim et al. Science Advances April 2026 — same math independently derived |
| Exponential Bayesian blending α(t)=1−exp(−t/τ) beats linear ramp | V1.7.0 internal validation (ChatGPT Labyrinth-OS Q1 2026) |
| Sycophancy as systematic RLHF behavior | Sharma et al. ICLR 2024 (Anthropic) |
| StableDRL unconditional clipping prevents feedback loop amplification | Li et al. 2026 |
| Heston Full Truncation Euler eliminates absorption bias | Lord et al. 2010 |
| CIR Feller condition 2κθ ≥ σ² ensures non-negative variance | Standard result |
| Lyapunov stability: OU process stable iff a_max < 0 | Lyapunov 1892; Gardiner 1985 |
| B-signal (sycophancy) behavioral proxy patterns | Sharma et al. ICLR 2024 |
| Laplace-smoothed rate (k+1)/(n+2) safer than k/n for small n | Standard Bayesian; Feller 1968 |

**What VECTOR has NOT yet proved (per its own README):**
- C-score correlation with human judgment (target r > 0.6)
- H-signal false positive rate (need 100 labeled examples, AUC > 0.80)
- RESONANCE_ANCHOR = 623.81 Hz physical grounding
- Cross-domain applicability beyond LLM conversations
- Langevin/MTJ empirical co-validation with actual spintronic hardware

---

## C. What Should Be Archived Only

| Component | Reason |
|-----------|--------|
| `VECTOR.jsx` (full dashboard) | 455KB monolith; UI-coupled; not modular |
| `sdk/storage.ts` (localStorage) | Browser-only; no tamper-evidence; schema diverges from ledger-chronicle |
| `sdk/sde.ts :: simulateSDE()` | Non-deterministic (stochastic); archive as mathematical reference |
| `sdk/drift.ts :: applyZeroDriftLock()` | RESONANCE_ANCHOR=623.81 explicitly UNVALIDATED |
| `sdk/signals.ts :: computeBerryPhase()` | Zero-crossing count is a crude proxy; no theoretical justification provided |
| `sdk/signals.ts :: computeSHETorque()` | Hardware co-validation not done; θ_SH=0.20 is placeholder |
| `sdk/reliability.ts :: sodsLawScore()` | Satirical formula (Wiseman 2004) — explicitly NOT a reliability metric |
| `sdk/reliability.ts :: entropyDriftNarrative()` | Narrative metaphor — not a physical claim |
| `sdk/engine.ts :: pruneContext()` | Context management; inapplicable to Labyrinth-OS execution model |
| `sdk/engine.ts :: computeSessionHealth()` | Heuristic 0–100 score; not formally validated; Phase B incomplete |
| Industry preset tuning for non-CIRCUIT presets | Tuned on LLM sessions; unknown transfer to Labyrinth-OS domain |

---

## D. What Should Be Promoted

Candidates for Labyrinth-OS promotion (in priority order):

1. **JSD + TF-IDF Coherence Scoring** (`sdk/coherence.ts`) — highest confidence;  
   proven by independent parallel (Kim et al. 2026) and Anthropic citation (Chuang 2024)

2. **GARCH(1,1) Variance** (`sdk/drift.ts`) — standard quantitative finance;  
   needs per-preset params + stationarity guard

3. **Kalman Filter** (`sdk/sde.ts`) — standard algorithm; needs configurable params

4. **StableDRL Clipping** (`sdk/drift.ts`) — critical safety property for Gate;  
   maps to THROTTLE/FALLBACK logic

5. **Shannon Entropy / Vocab Growth Rate** (`sdk/signals.ts`) — clean, deterministic;  
   maps to `vector-sensors` χ stability sensing

6. **Lyapunov Stability Bound** (`sdk/sde.ts`) — deterministic invariant check;  
   maps to `cgir-validator`

7. **Failure Probability Formulas** (`sdk/reliability.ts`, normal tier only) —  
   standard reliability engineering; directly applicable

8. **EWMA Trend + Realized Volatility** (`sdk/signals.ts`, `sdk/drift.ts`) —  
   standard algorithms; clean promote

9. **H-signals + B-signals** (`sdk/signals.ts`) — maps to Watcher-A and Watcher-B;  
   Signal 3 (contradiction) must be rewritten; validate AUC before production

10. **ΔC Causal Delta** (`sdk/causal.ts`) — conceptually excellent; Phase B required before promotion

11. **Mann-Whitney U + BH FDR** (`sdk/stats.ts`) — for Labyrinth-OS test harness infrastructure

12. **Session Rewind pattern** (`components/VECTOR.jsx`) — map to replay-gnosis  
    with ledger backing + cryptographic hashing

13. **CIRCUIT preset constants** — validate thresholds for Labyrinth-OS signal domain first

---

## E. What Should Be Rewritten Cleanly

| Component | Problem | Rewrite Target |
|-----------|---------|---------------|
| Pipe injection `buildPipeInjection()` | Directly injects into system prompt, bypasses Gate | `PlannerProposal` struct routed through Council→Gate→AEGIS |
| Self-contradiction check (H-signal 3) | VECTOR itself flags as superseded proxy; negation-density heuristic | Embedding-based claim-level similarity (V2 TODO in VECTOR code) |
| RAG retrieval `ragRetrieve()` | In-memory, TF-IDF only, no ledger backing | `crates/world-model` with `ledger-chronicle` as backing store |
| AutoTune context detection | English regex patterns; not validated beyond LLM APIs | Embedding-based context classification in `crates/offline-evolution` |
| `computeContextualOverlap()` | Not MI — Bhattacharyya-style geometric mean | V2 requires k-NN MI estimation (Kraskov et al. 2004) |
| Mute injection word limit | Was `cap/8` (gave 15 words); fixed to `cap×0.75` | Already fixed in VECTOR V1.8. Use `round(cap × 0.75)` formula. |

---

## F. What Maps to Labyrinth-OS Modules

```
VECTOR                              → Labyrinth-OS
────────────────────────────────────────────────────────
sdk/coherence.ts (TF-IDF, JSD, C)  → crates/signal-algebra (confidence synthesis)
sdk/drift.ts (GARCH, StableDRL)     → crates/signal-algebra (variance tracking)
sdk/drift.ts (Drift Law)            → crates/cgir-temporal (temporal validity, I5)
sdk/sde.ts (Kalman, EKF)            → crates/signal-algebra (state estimation)
sdk/sde.ts (Lyapunov)               → crates/cgir-validator (invariant enforcement)
sdk/signals.ts (H-signals)          → crates/watcher-a (internal consistency audit)
sdk/signals.ts (B-signals)          → crates/watcher-b (adversarial audit)
sdk/signals.ts (entropy, χ)         → crates/vector-sensors (sensing field chi_stability)
sdk/signals.ts (vocab growth)       → crates/vector-sensors (sensing)
sdk/signals.ts (Fisher Info)        → crates/signal-algebra (rate-of-change detection)
sdk/signals.ts (EWMA)               → crates/signal-algebra (smoothing)
sdk/drift.ts (Realized Vol)         → crates/signal-algebra (fast variance complement)
sdk/causal.ts (ΔC)                  → crates/replay-gnosis (intervention analysis)
sdk/engine.ts (pipe injection)      → crates/planner (as PlannerProposal ONLY)
sdk/engine.ts (RAG)                 → crates/world-model (with ledger backing)
sdk/reliability.ts (normal tier)    → crates/cgir-validator (reliability analysis)
sdk/stats.ts (Mann-Whitney, BH)     → tests/ (validation infrastructure)
sdk/autotune.ts                     → crates/offline-evolution (adaptive learning)
sdk/storage.ts                      → ARCHIVE_ONLY (ledger-chronicle is the Labyrinth-OS analog)
components/VECTOR.jsx (rewind)      → crates/replay-gnosis (replay + hash verification)
evals/VECTOR_EVALS.md               → tests/ (port applicable evals to automated CI)
tools/meta_loop.py                  → crates/offline-evolution (meta-loop pattern)
RESONANCE_ANCHOR=623.81             → ARCHIVE_ONLY (unvalidated)
SDE simulation                      → ARCHIVE_ONLY (math reference only)
Berry Phase, SHE Torque             → experiments/ (unvalidated)
Dashboard UI                        → NONE (build fresh from ledger-chronicle)
```

---

## G. Missing Tests

The following are identified as missing or incomplete in VECTOR, and must be
created for Labyrinth-OS before promotion:

| Component | Missing Test |
|-----------|-------------|
| GARCH(1,1) | Same history → same σ² (I8 determinism) |
| GARCH(1,1) | Stationarity guard: assert α+β < 1 |
| JSD | JSD(P,P) = 0 exactly; JSD(P,Q) = JSD(Q,P) symmetry; JSD ∈ [0,1] |
| TF-IDF | Identical texts → ~1.0; disjoint texts → 0.0 |
| Coherence | Same inputs → same score (I8) |
| Kalman | K ∈ [0,1] always; P decreases over stable observations |
| Lyapunov | Known stable params → stable=true; positive α → unstable |
| ΔC | Forward deltas correct for known sequences |
| StableDRL | Output ∈ [0.30, 0.99] always |
| Entropy | Constant text → H=0; uniform dist → H=log2(n) |
| Failure prob | probFailureN(0,n) = 0; probFailureN(1,n) = 1 for n>0 |
| H-signal 3 | Needs validation before promotion (AUC > 0.80 on 100 examples) |
| CouncilResolver | determinism_hash: same_id+different_logical_time → different hash |
| CouncilResolver | determinism_hash: same_id+different_valid_for → different hash |
| CouncilResolver | determinism_hash: same_id+different_watcher_graph_hash → different hash |

---

## H. Replay / Determinism Implications

**VECTOR's replay story (partial):**
- VECTOR.jsx has session rewind (in-memory checkpoints, per-turn)
- No cryptographic verification of checkpoints
- No ledger-backed audit trail
- GARCH and Kalman are deterministic given same history → replayable in principle
- SDE simulation is non-deterministic (stochastic) — NOT replayable unless seeded
- Pipe injection text is logged but effect on model is not captured

**Labyrinth-OS replay requirements for promoted components:**
- Every promoted formula must be deterministic: same inputs → same output
- Kalman and GARCH must include their full state in SystemStep replay traces
- ΔC analysis must read from ledger-chronicle (not live session state)
- Any correction proposal (planner output) must be logged before execution
- Hash chain from ledger-chronicle must cover all promoted formula outputs
- Seed-42 LCG RNG in VECTOR SDE is NOT cryptographically suitable — do not reuse

**CouncilResolver replay inclusion:**  
`council_resolver.py` v2 is structured for SystemStep replay inclusion:
- `determinism_hash` includes `signal_id`, `logical_time`, `severity`, `confidence`,
  `escalation_code` (not human string), `valid_for`, `watcher_a_hash`, `watcher_b_hash`
- Replay proof: same watcher graph → same hash
- Strict divergence tests now included (see strict test functions in `council_resolver.py`)

---

## I. Risks if Blindly Merged

The following risks would occur if VECTOR code were merged into Labyrinth-OS without review:

| Risk | Source | Impact |
|------|--------|--------|
| Gate bypass | Pipe injection directly modifies system prompt | Correction applied without Council/Gate approval — violates Labyrinth-OS invariants |
| Non-determinism | SDE simulation stochastic | Replay traces diverge — I9 violated |
| Unvalidated constants | RESONANCE_ANCHOR=623.81 | Physical anchor claim unsupported — could mislead downstream validation |
| Browser-only storage | localStorage in `sdk/storage.ts` | Session data not persisted in ledger-chronicle — breaks audit trail |
| Phase B incomplete | ΔC causal delta, H-signals | Causal claims premature — promoting as proven evidence would be dishonest |
| English-only regex | B-signals, AutoTune | Silent failure on non-English content |
| Memory leak risk | Unbounded vocabulary set in vocab growth rate | O(turns × vocab_size) memory growth |
| Over-correction amplification | Missing StableDRL in some paths | Without clipping, pipe injection can amplify variance instead of reducing it |
| No tamper evidence | No hash chain on VECTOR session data | Cannot distinguish authentic from tampered session replays |
| H-signal 3 false positives | Negation-density heuristic (superseded in V2) | Incorrect self-contradiction flags — unvalidated |

---

## J. Recommended Next Migration Steps

**Immediate (Sprint 1):**
1. Port `sdk/coherence.ts` (TF-IDF + JSD + coherence formula) to `crates/signal-algebra`
2. Port `sdk/drift.ts` (GARCH, StableDRL, Realized Volatility) to `crates/signal-algebra`
3. Port Kalman filter from `sdk/sde.ts` to `crates/signal-algebra`
4. Add determinism tests (I8) for all three above
5. Port Lyapunov bound to `crates/cgir-validator`

**Short-term (Sprint 2):**
6. Port Shannon entropy + vocab growth rate to `crates/vector-sensors`
7. Port Fisher Information + EWMA to `crates/signal-algebra`
8. Port failure probability formulas (normal tier) to `crates/cgir-validator`
9. Port Mann-Whitney U + BH FDR to `tests/` infrastructure
10. Port H-signals (except signal 3) to `crates/watcher-a`
11. Port B-signals to `crates/watcher-b` (using Rust regex crate)

**Medium-term (Sprint 3):**
12. Design `PlannerProposal` struct in `crates/planner` — map pipe injection concept
13. Design session-rewind checkpoint format in `crates/replay-gnosis` with SHA-256 hashing
14. Adapt `tools/meta_loop.py` pattern to `crates/offline-evolution`
15. Complete Phase B validation (N≥100 labeled sessions) before promoting ΔC and H-signals
16. Implement SensorWatcher (A011) so sensor severity routes as WatcherReport → Council

**Do not do (blocked):**
- Do NOT import SDE simulation code — ARCHIVE_ONLY
- Do NOT import RESONANCE_ANCHOR=623.81 — UNVALIDATED
- Do NOT import `sodsLawScore` or `entropyDriftNarrative` — satirical/narrative only
- Do NOT port pipe injection as direct text injection — must be PlannerProposal through Gate
- Do NOT promote H-signal 3 (self-contradiction) until embedding-based V2 is implemented
- Do NOT use VECTOR's ΔC as proven evidence until Phase B AUC > 0.80

---

*Archive principle: VECTOR is immune memory. Labyrinth-OS core stays deterministic,
canonical, replayable, and governed. Archive everything. Promote nothing blindly.*

*© 2026 VECTOR (archived reference)*  
*Migration analysis by Labyrinth-OS / Labyrinth-OS project*
