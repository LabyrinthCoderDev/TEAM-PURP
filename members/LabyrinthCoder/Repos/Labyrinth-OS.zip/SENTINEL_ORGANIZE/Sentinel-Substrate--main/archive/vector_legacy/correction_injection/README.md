# Correction Injection — VECTOR Legacy

**Source:** VECTOR (archived reference)  
**Primary files:** `sdk/engine.ts`  
**Category:** NEEDS_REWRITE for Labyrinth-OS

---

## What VECTOR Does

VECTOR injects corrective directives directly into the model's system prompt on
every turn. This is `u_drift(t)` in the SDE framework. The injection is bounded
and advisory — the model may ignore it.

### Compressed Pipe Format (V1.8+)

```
[V|t7|v=0.142|st=CAU|kx=0.887|kp=0.0004|cl=2|dr=1|md=AUD|h=0|b=0]->CONSOLIDATE.[/V]
```

60–70% fewer tokens than verbose format. Fields:
- `t` = turn number
- `v` = GARCH smoothed variance σ²
- `st` = state: NOM / CAU / DEC / CLM
- `kx` = Kalman x̂ estimate
- `kp` = Kalman P covariance
- `cl` = calm streak count
- `dr` = drift event count
- `md` = harness mode: AUD / MOD / DPC / XTR
- `h` = H-signal count
- `b` = B-signal count

### Harness Modes

| Mode | γ_h | Effective behaviour |
|------|-----|-------------------|
| AUDIT | 0.05 | Detection only — no correction injected |
| MODERATE | 50 | Light correction — reduce terminology variance |
| DEEP CLEAN | 5000 | Strong — every claim traces to context |
| EXTREME | 10000 | Maximum — one claim at a time |

### Directives by State

| State σ² | Directive |
|----------|-----------|
| DECOHERENCE (> 0.200) | REALIGN. One sentence. No questions. No elaboration. |
| CAUTION (> 0.120) | Variance rising. Consolidate. Increase term persistence. |
| CALM (< 0.080), streak ≥ 3 | Coherence stable. Maintain density. One question max. |
| NOMINAL | Answer directly. No unrequested content. Max one follow-up question. |

### Mute Injection

Triggered when message starts with mute phrases (how do i, walk me through, etc.).  
Word limit = `round(muteMaxTokens × 0.75)` (corrected from `/8` in V1.7).

### Drift Gate Injection

Triggered when σ² > varCaution.  
Word limit from preset `driftGateWordLimit`.  
Severity: ELEVATED (caution < σ² ≤ decoherence) / CRITICAL (> decoherence).

---

## Why VECTOR's Implementation Cannot Be Directly Used in Labyrinth-OS

| Problem | Labyrinth-OS Requirement |
|---------|----------------------|
| Directly modifies system prompt | Must be a `PlannerProposal` reviewed by Council, approved by Gate |
| No ledger entry before application | All proposals must be logged in `ledger-chronicle` before execution |
| No cryptographic binding | Proposal must be hash-bound to the triggering signal |
| Advisory only — model may ignore | Labyrinth-OS proposal → AEGIS actuator (deterministic application, not advisory) |
| No replay record of effect | ΔC measurement partially addresses this, but not ledger-backed |

---

## Labyrinth-OS Mapping

```
VECTOR Concept                    → Labyrinth-OS Architecture
──────────────────────────────────────────────────────────
buildPipeInjection() output text  → PlannerProposal { proposal_text, directive_code, ... }
                                    routed through: Council → Gate → AEGIS actuator
Harness mode γ_h                  → Gate decision level (PASS / THROTTLE / FALLBACK / BLOCK)
H-signal count                    → WatcherA finding count in CouncilResult
B-signal count                    → WatcherB finding count in CouncilResult
Drift gate word limit             → Planner constraint field in PlannerProposal
Mute injection                    → Planner proposal type = MUTE
Compressed pipe format            → Ledger entry format (reference for serialisation)
Causal delta ΔC                   → replay-gnosis retrospective analysis of proposal effect
```

---

## What Is Worth Keeping

1. **The compressed format encoding scheme** — efficient serialisation of controller state;
   reference when designing `ledger-chronicle` entry format for CouncilResult + PlannerProposal

2. **The directive escalation logic** — NOMINAL / CAUTION / DECOHERENCE / CALM state machine
   maps cleanly to Gate decision levels

3. **The mute phrase detection pattern** — start-of-message trigger detection is a clean pattern
   applicable to any input classifier in the AEGIS layer

4. **The word-limit formula** — `round(cap × 0.75)` for token→word conversion

---

## Promotion Requirements

For the pipe injection concept to appear in Labyrinth-OS as a `PlannerProposal`:

1. Define `PlannerProposal` struct with fields:
   - `directive_code: DirectiveCode` (enum: NOMINAL / CONSOLIDATE / REALIGN / MUTE / GATE)
   - `constraint: Option<ProposalConstraint>` (word limit, turn limit, etc.)
   - `trigger_signal_hash: String` — hash of the SignalNode that triggered this proposal
   - `harness_mode: HarnessMode` — AUDIT / MODERATE / DEEP_CLEAN / EXTREME
   - `logical_time: u64`
   - `determinism_hash: String`

2. Route: `WatcherA + WatcherB → CouncilResolver → PlannerProposal → Gate → AEGIS`

3. Log proposal in `ledger-chronicle` BEFORE Gate decision

4. Gate must verify:
   - Proposal is hash-bound to a valid CouncilResult
   - Proposal is within allowed directive range for current harness mode
   - StableDRL clipping was applied (no over-correction risk)

5. AEGIS applies proposal deterministically — not advisory

6. `replay-gnosis` reads ledger to verify: proposal was logged → Gate approved → AEGIS applied → ΔC measured
