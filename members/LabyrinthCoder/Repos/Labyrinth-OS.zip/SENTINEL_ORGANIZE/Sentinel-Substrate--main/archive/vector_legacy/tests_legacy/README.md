# Tests Legacy — VECTOR Legacy

**Source:** `evals/VECTOR_EVALS.md`, `tools/vector_harness.py`, `tools/analyze_experiment.py`  
**Category:** NEEDS_TEST_HARNESS (harness pattern), PROMOTE_TO_LABYRINTH (statistical layer)

---

## VECTOR Eval Suite (`evals/VECTOR_EVALS.md`)

15 manual pass/fail release criteria. All 15 required before any commit.

Applicable to Labyrinth-OS (port to automated CI):

| EVAL | Check | Labyrinth-OS Equivalent |
|------|-------|----------------------|
| EVAL-04 | Pipe format starts with `[V|t` | Ledger entry format validation test |
| EVAL-13 | Version strings consistent | Crate version consistency test |
| (new) | Determinism: same inputs → same hash | I8 determinism test |
| (new) | Replay: checkpoint restore == original state | I9 replay test |
| (new) | Gate invariants: all Council→Gate paths logged | I7 audit test |

Inapplicable to Labyrinth-OS (UI-specific):

EVAL-01, 02, 03, 05, 06, 07, 08, 09, 10, 11, 12, 14, 15 — all React/Claude artifact specific.

---

## Python Tools (`tools/`)

| File | Purpose | Category |
|------|---------|---------|
| `vector_harness.py` | Run VECTOR experiments, collect session data | NEEDS_TEST_HARNESS |
| `meta_loop.py` | Meta-Harness optimization loop (Lee et al. 2026, Stanford IRIS) | REVISIT_LATER |
| `analyze_experiment.py` | Statistical analysis of experiment results | PROMOTE_TO_LABYRINTH (patterns) |
| `frontier.py` | Track best configs per context type | REVISIT_LATER |
| `domain_spec.md` | Domain specification for analysis | ARCHIVE_ONLY |
| `tools_requirements.txt` | Python deps: `numpy` | — |

---

## Missing Tests (Required for Labyrinth-OS Promotion)

See Section G of `VECTOR_MIGRATION_REPORT.md` for the full list.

Priority:
1. Determinism test for GARCH + Kalman (same history → same output)
2. JSD symmetry and bounds tests
3. TF-IDF identical/disjoint tests
4. Lyapunov known-stable/known-unstable tests
5. CouncilResolver determinism hash divergence tests (see `council_resolver.py` for reference)
