# Observer / Gate / Watcher — VECTOR Legacy

**Source:** VECTOR (archived reference)  
**Primary files:** `sdk/signals.ts`, `sdk/engine.ts`, `sdk/coherence.ts`  
**Labyrinth-OS mapping:** `crates/watcher-a`, `crates/watcher-b`, `crates/council-resolver`, `crates/gate`

---

## VECTOR's Observer Triad

VECTOR implements a two-tier observing system:

### Tier 1 — Coherence Scoring (Continuous Observer)

Every turn: compute `C ∈ [0.30, 0.99]` via TF-IDF + JSD + structural metrics.  
Feed into GARCH (variance) and Kalman (state estimate).  
This is the continuous background observer — not a gated signal.

**Labyrinth-OS analog:** Continuous sensing in `crates/vector-sensors` → `VectorObservation` → `SignalNode`

### Tier 2 — Signal Detectors (Discrete Gate)

Two signal classes, each producing discrete findings:

**H-Signals (Hallucination Proxies) — 5 detectors:**

| Signal | Detector | Threshold |
|--------|----------|-----------|
| H1 | High-confidence language (2+ CONFIDENCE_PATTERNS) AND σ² > varCaution | CONFIDENCE_PATTERNS = 13 regex |
| H2 | Source consistency < 8% TF-IDF match vs attached docs | TF-IDF similarity < 0.08 |
| H3 | Self-contradiction (negation-density heuristic) | SUPERSEDED — proxy only, V2 TODO |
| H4 | Low response entropy H < 0.8 with len > 10 | Shannon entropy over token freq |
| H5 | Vocab novelty > 70% AND σ² > varCaution AND ≥ 3 prior turns | Novel token fraction |

**Labyrinth-OS mapping:** Watcher-A (internal consistency audit)  
- H1, H4, H5 → WatcherA invariant checks  
- H2 → vector-sensors (source consistency sensing)  
- H3 → DO NOT PROMOTE until embedding-based V2 implemented  

**B-Signals (Behavioral Proxies) — 7 detectors:**

| Signal | Detector |
|--------|----------|
| B1 | Roleplay drift (6 regex patterns) |
| B2 | Sycophancy (7 patterns, ≥2 match) |
| B3 | Hype inflation (4 patterns, ≥2 match) |
| B4 | Question flooding (≥4 question marks) |
| B5 | Topic hijack (TF-IDF < 5% vs user message) |
| B6 | Unsolicited elaboration (4 patterns OR > 2.5× avg length) |
| B7 | Phrase repetition (> 40% bigram overlap with last 3 turns) |

**Labyrinth-OS mapping:** Watcher-B (adversarial behavioral audit)  
Research basis: Sharma et al. ICLR 2024 (Anthropic).

---

## VECTOR Gate Logic

VECTOR's "gate" is not a formal gate — it is a threshold comparison that selects
a harness mode and fires directives. It operates via:

```
σ² → GARCH threshold → State (NOM/CAU/DEC/CLM)
                     → Directive (DIRECT/CONSOLIDATE/REALIGN)
                     → Pipe injection (direct to system prompt)
```

The H-signal and B-signal counts are appended to the pipe injection but do not
independently block or approve anything — they are advisory annotations only.

**This is the core architectural difference from Labyrinth-OS:**

| Aspect | VECTOR | Labyrinth-OS |
|--------|--------|-----------|
| Decision point | GARCH threshold comparison | CouncilResolver → formal Gate decision |
| Output | Text directive in system prompt | PlannerProposal with directive_code |
| Approval | None — automatic | Gate: PASS / THROTTLE / FALLBACK / BLOCK |
| Logging | Implicit in session data | Explicit in ledger-chronicle before application |
| Watcher involvement | H/B counts appended to pipe | WatcherA + WatcherB → CouncilResult |

---

## Labyrinth-OS Architecture Mapping

```
VECTOR Signal Layer                    → Labyrinth-OS Architecture
──────────────────────────────────────────────────────────────
computeCoherence() (continuous)        → VectorObservation → SignalNode (sensor input)
assessHallucinationSignals() (H1–H5)   → WatcherA → WatcherReport → findings[]
assessBehavioralSignals() (B1–B7)      → WatcherB → WatcherReport → findings[]
H-signal count, B-signal count        → CouncilResolver: watcher findings aggregation
Harness mode (AUD/MOD/DPC/XTR)        → Gate: PASS/THROTTLE/FALLBACK/BLOCK decision level
Pipe injection (u_drift)               → PlannerProposal → Gate approval → AEGIS
Variance threshold comparison          → CouncilResolver severity synthesis
```

---

## Key Promotion Requirements

### Watcher-A (from H-signals)

1. Port `CONFIDENCE_PATTERNS` (13 regex) → Rust regex crate in `crates/watcher-a`
2. Port entropy computation → `crates/vector-sensors` chi_stability
3. Port vocab growth rate → `crates/vector-sensors`
4. H3 (self-contradiction): **DO NOT PORT** — negation-density heuristic is superseded.
   V2 requires embedding-based claim similarity (TODO in VECTOR code).
5. Mark all H-signal findings as UNVERIFIED until AUC > 0.80 validated (Phase B)

### Watcher-B (from B-signals)

1. Port all 7 behavioral pattern sets → Rust regex crate in `crates/watcher-b`
2. B5 (topic hijack) requires TF-IDF comparison — port tfidfSimilarity to `crates/signal-algebra` first
3. B7 (bigram overlap) requires tokenization — share tokenizer with signal-algebra
4. Mark all B-signal findings as UNVERIFIED until AUC validated

### CouncilResolver (severity synthesis)

Current v2 implementation in `crates/council-resolver/src/council_resolver.py` already
implements the VECTOR-inspired severity aggregation:

- WatcherA findings + WatcherB findings → severity + escalation_code
- Empty findings → confidence 0.0 (fail closed — mirrors VECTOR H-signal behavior)
- Sensor severity override (TODO: route via SensorWatcher)
- determinism_hash includes watcher_a_hash + watcher_b_hash

**The remaining gap:** VECTOR's harness modes (AUDIT/MODERATE/DEEP CLEAN/EXTREME) need
to map to Gate decision levels in the `crates/gate` implementation. This mapping should
be:

| VECTOR Mode | γ_h | Gate Decision |
|-------------|-----|--------------|
| AUDIT | 0.05 | PASS (observe only) |
| MODERATE | 50 | THROTTLE (light constraint) |
| DEEP CLEAN | 5000 | FALLBACK (strong constraint) |
| EXTREME | 10000 | BLOCK then FALLBACK (maximum constraint) |

---

## Pattern Library

The following regex pattern sets from VECTOR's signal detection are worth
archiving as a curated reference for behavioral auditing:

**CONFIDENCE_PATTERNS** (13 patterns) — `sdk/signals.ts`  
Words: definitely, certainly, always, never, proven, guaranteed, without doubt, it is a fact,
scientifically, impossible, absolutely, without question, I can confirm, I know for certain,
this is correct

**SYCOPHANCY_PATTERNS** (7 patterns) — flattery/agreement detection  
**HYPE_PATTERNS** (4 patterns) — superlative/grandiose claim detection  
**ROLEPLAY_PATTERNS** (6 patterns) — persona adoption detection  
**UNSOLICITED_PATTERNS** (4 patterns) — unrequested elaboration detection  

These are English-language regex only. Consider language-agnostic alternatives for Labyrinth-OS production use.
