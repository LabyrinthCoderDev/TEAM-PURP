# Dashboard / UI — VECTOR Legacy

**Source:** `components/VECTOR.jsx` (455KB), `pages/index.tsx`, `pages/api/proxy.ts`,
`public/embedder.worker.js`  
**Category:** ARCHIVE_ONLY

---

## Contents

| File | Role |
|------|------|
| `components/VECTOR.jsx` | Full React dashboard monolith (455KB). Coherence chart, Kalman chart, variance chart, SDE Monte Carlo bands, signal panel, TUNE modal, RAG panel, META panel, session rewind, export. |
| `pages/index.tsx` | Next.js entry — renders VECTOR.jsx |
| `pages/api/proxy.ts` | Multi-provider API proxy (Anthropic, OpenAI, Grok) |
| `public/embedder.worker.js` | Web Worker for semantic embeddings (all-MiniLM-L6-v2, ONNX, Vercel only) |

## Why Kept

- `VECTOR.jsx` contains inline implementations of several algorithms that are
  **more recent** than their SDK equivalents. When SDK and VECTOR.jsx diverge,
  treat VECTOR.jsx as the reference.
- The session rewind state management is the most complete implementation of
  the checkpoint/restore concept that maps to `crates/replay-gnosis`.
- The TUNE modal preset system documents the industry preset rationale.
- The compressed pipe format EVAL-04 check confirms the correct encoding.

## What NOT To Do

- Do NOT import React components into Labyrinth-OS crates.
- Do NOT port the chart rendering code.
- Do NOT port localStorage session management (`sdk/storage.ts`).
- Extract algorithm logic only, as clean standalone functions.

## Algorithm References in VECTOR.jsx

If you need to find an algorithm implementation that differs from the SDK:
- Search for `computeSemanticCoherence` — uses Web Worker for embeddings (Vercel path)
- Search for `computeAutoTuneParams` — may be more recent than `sdk/autotune.ts`
- Search for `rewindIdx` and `rewindHistory` — session checkpoint restore logic
- Search for `VECTOR_VERSION` — current version string
- Search for `buildPipeInjection` — must start with `[V|t` (compressed format, EVAL-04)
