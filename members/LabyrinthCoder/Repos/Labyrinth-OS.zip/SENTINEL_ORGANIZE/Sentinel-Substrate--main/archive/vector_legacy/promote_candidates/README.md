# Promote Candidates — Ready for Labyrinth-OS Promotion Review

These VECTOR-origin artifacts have been reviewed and are candidates
for formal promotion into the Labyrinth-OS execution substrate.

Each must still pass:
  LABELING → ARCHIVE → PROMOTION_PROTOCOL → REALITY_GATE

before entering any execution path.

---

## READY FOR PROMOTION

### Kuramoto R (PhaseSyncMonitor)
**Origin:** VECTOR L2.9
**Status:** WORKS — A006 CLOSED (90.7% chatter reduction)
**Labyrinth-OS target:** epistemic/vector/tau_baseline_generator.py
**Evidence:** PhaseSyncMonitor tests passing in Labyrinth-OS (A006 verified)
**Note:** Already partially ported. Full port needs Rust crate.

### GARCH(1,1) Variance Model
**Origin:** VECTOR sdk/garch.ts
**Status:** WORKS in VECTOR — UNVERIFIED in Labyrinth-OS
**Labyrinth-OS target:** epistemic/signal-aggregation/ (drift component)
**Blocker:** No Python port yet. TypeScript → Python rewrite needed.
**Test required:** Synthetic variance series, compare output to VECTOR reference.

### Kalman Filter State Estimation
**Origin:** VECTOR sdk/kalman.ts
**Status:** WORKS in VECTOR — UNVERIFIED in Labyrinth-OS
**Labyrinth-OS target:** epistemic/signal-aggregation/ (alongside GARCH)
**Blocker:** No Python port yet.

### TF-IDF + JSD Coherence Formula
**Origin:** VECTOR sdk/coherence.ts
**Status:** WORKS in VECTOR — confirmed in A009 (coherence_estimator.py 72/72)
**Labyrinth-OS target:** Already ported (coherence_estimator.py)
**Evidence:** A009 CLOSED

### Landauer Bit-Erasure Budget
**Origin:** VECTOR physics extensions
**Status:** WORKS — A019 CLOSED (E_BIT = kT ln2 = 2.9667e-21 J at 310K)
**Labyrinth-OS target:** Already in Labyrinth-OS
**Note:** Use 310K (biological), not 293K (room temp).

---

## NOT READY — NEEDS REWRITE

### SDE Simulation (OU + Heston + Vasicek)
**Origin:** VECTOR physics extension
**Status:** EXPERIMENTAL — stochastic, not deterministic
**Labyrinth-OS rule violation:** Labyrinth-OS requires deterministic execution.
  Stochastic simulation cannot enter Lane 2 without deterministic wrapper.
**Path:** Deterministic approximation needed. Park in deferred_exploration.

### Correction Injection (u_drift(t))
**Origin:** VECTOR correction_injection/
**Status:** ARCHIVE_ONLY — bypasses approval in VECTOR
**Labyrinth-OS rule violation:** Corrections cannot bypass labeling/promotion/gate.
**Path:** Must be reframed as a candidate that enters at LABELING.
  The correction itself is a proposal, not a direct execution.

---

## ARCHIVE_ONLY — NOT PROMOTABLE

### Dashboard / UI (VECTOR.jsx)
**Origin:** VECTOR.jsx (455KB React component)
**Status:** ARCHIVE_ONLY
**Reason:** UI code has no place in deterministic execution substrate.
  Useful as a reference for observability visualization design only.

### RESONANCE_ANCHOR = 623.81 Hz
**Origin:** VECTOR physics extension
**Status:** BROKEN / UNVERIFIED — physical grounding not established
**Labyrinth-OS rule:** Cannot promote ungrounded constants.
