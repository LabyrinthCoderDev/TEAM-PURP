# Experiments — Speculative / Unverified

These are documented speculative ideas that have not been tested.
They live here per Hard Invariant I10: nothing is deleted.
They may re-enter the pipeline via DeferredExplorationNode.

## Open Experiments

### ARC-AGI-2 Coherence Profiling (A016)
**Hypothesis:** Labyrinth-OS pipeline produces meaningful D_KL and ΔH on ARC-AGI-2 tasks.
**Status:** UNVERIFIED
**Path:** arc_agi2_ignition.py → live Ollama → Chronicle telemetry
**Falsifiable test:** Chronicle contains sealed telemetry JSON after run.

### Cross-Domain Applicability
**Hypothesis:** VECTOR formulas work beyond LLM conversation sessions.
**Status:** EXPERIMENTAL — VECTOR's own README explicitly disclaims this.
**Path:** Run against code completion, image description, structured data tasks.
**Risk:** Formulas may be tuned specifically for conversation entropy patterns.

### fractal_parameter_solver.py Multi-Model Validity (A015)
**Hypothesis:** Parameters valid for GPT-4o, Claude, Qwen, Llama simultaneously.
**Status:** UNVERIFIED
**Path:** Run ignition against all four providers, compare parameter stability.

### ATECC608B Hardware Attestation (A003)
**Hypothesis:** ATECC608B can replace MockGuardianSlot without interface change.
**Status:** UNVERIFIED
**Path:** I2C provisioning → sign guardian decision → verify chain
**Risk:** Signing latency may exceed FPGA timing budget.
