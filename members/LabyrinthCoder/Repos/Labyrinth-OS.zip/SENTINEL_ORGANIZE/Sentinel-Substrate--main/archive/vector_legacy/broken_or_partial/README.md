# Broken or Partial — Known Issues

## BROKEN (kept for reference — do not use)

### VECTOR Correction Bypass
**What:** u_drift(t) injected directly into next system prompt without gate.
**Why broken for Labyrinth-OS:** Bypasses labeling, promotion, reality gate.
**Lesson:** All corrections are proposals. All proposals go through Lane 1.

### RESONANCE_ANCHOR = 623.81 Hz
**What:** Claimed physical frequency anchor for coherence tuning.
**Why broken:** Physical grounding never established. Arbitrary constant.
**Lesson:** Constants need proof of physical or mathematical necessity.

## PARTIAL (partially working — gap documented)

### H-Signal Detection (AUC claim)
**What:** H-signals claimed AUC > 0.80 for hallucination detection.
**Status:** PARTIAL — AUC not confirmed beyond VECTOR's own test set.
**Gap:** No cross-domain validation. Correlation with human judgment unknown.
**Labyrinth-OS path:** Needs blind benchmark on ≥2 distinct model families (A004).

### Chronicle Tamper Evidence (A017)
**What:** WORM chain tamper detection via SHA-256.
**Status:** PARTIAL — 8/10 TM-001 attack classes tested.
**Gap:** CLASS-9 (TIME_ORDER_MANIP) and CLASS-10 (PARTIAL_WRITE) need stress.
**Path:** Run threat_model.py extended suite once archive/deferred healing loop active.
