# VECTOR Legacy Archive

This directory is the **canonical archive** of all components extracted
from the VECTOR prototype system during the migration to Labyrinth-OS / CGIR.

---

## What Is VECTOR?

**Source:** VECTOR (archived reference)  
**Language:** TypeScript / JavaScript / Python  
**Framework:** Next.js + React  
**Version scanned:** V2.0.0 (commit 5ac87e9)  
**Authors:** David Hudson & David Perry, Hudson & Perry Research (2026)

VECTOR (Volatility Engine: Correction, Tracking, Output, Response) is a
**real-time LLM coherence and drift monitoring dashboard** that proved
the following concepts:

- **Drift sensing:** GARCH(1,1) variance, Kalman state estimation, JSD + TF-IDF coherence scoring
- **Entropy / χ metrics:** Shannon response entropy, vocabulary growth rate, Bhattacharyya overlap
- **ΔC causal delta:** Forward-delta measurement of correction injection effectiveness (k=1..5 lags)
- **Observer / signal detection:** H-signals (hallucination proxies), B-signals (behavioral proxies)
- **Correction injection:** u_drift(t) compressed pipe format, harness modes AUDIT/MODERATE/DEEP CLEAN/EXTREME
- **Rewind / replay:** In-memory per-turn session checkpoints (pattern for replay-gnosis)
- **Statistical validation:** Mann-Whitney U, Fisher's exact test, Benjamini-Hochberg FDR correction
- **JSONL logging and export:** Session data export patterns (schema reference for ledger-chronicle)
- **Dashboard:** Full React UI with coherence chart, Kalman chart, SDE Monte Carlo bands
- **Physics extensions:** SDE OU + periodic forcing, CIR, Heston, Vasicek, SABR, Lévy noise, Berry Phase, SHE Torque

VECTOR is **not** Labyrinth-OS. It is the **immune memory** — the evidence
base whose tested patterns, formulas, and invariants are being distilled into
the current clean architecture.

**What VECTOR proved (validated):** GARCH, Kalman, TF-IDF+JSD, StableDRL clipping,
exponential Bayesian blending, B-signal behavioral detection (Sharma et al. ICLR 2024),
EDM 45° angular gate parallel (Kim et al. Science Advances April 2026).

**What VECTOR has NOT proved:** C-score vs human judgment correlation,
H-signal AUC > 0.80, RESONANCE_ANCHOR=623.81 Hz physical grounding,
cross-domain applicability beyond LLM conversations (per VECTOR README).

---

## How To Use This Archive

1. **Do not import VECTOR code directly into Labyrinth-OS crates.**
2. Consult [`manifest.json`](manifest.json) for the status of every artifact.
3. Consult [`formulas/VECTOR_FORMULA_REGISTRY.md`](formulas/VECTOR_FORMULA_REGISTRY.md)
   for all extracted formulas and their Labyrinth-OS mapping.
4. Consult [`VECTOR_MIGRATION_REPORT.md`](VECTOR_MIGRATION_REPORT.md) for
   the full migration analysis and recommended next steps.
5. Any artifact marked `PROMOTE_TO_LABYRINTH` must pass the promotion gate:
   - deterministic
   - testable
   - documented
   - replay-compatible
   - mapped to a current invariant or module
   - placed behind the proper Council / Gate / Guardian boundary

---

## Directory Layout

| Directory | Contents |
|-----------|----------|
| `formulas/` | Extracted formulas and constants — clean reference |
| `replay_rewind/` | Replay, rewind, and rollback logic |
| `drift_metrics/` | Drift, entropy, τ, χ, ΔC metrics |
| `correction_injection/` | Correction injection patterns |
| `observer_gate_watcher/` | Observer, gate, watcher triad |
| `dashboards_ui/` | Dashboard and UI code (not promotable to core) |
| `tests_legacy/` | Legacy test helpers and harnesses |
| `broken_or_partial/` | Known-broken or partially working code |
| `experiments/` | Experimental or unverified code |
| `promote_candidates/` | Artifacts ready for Labyrinth-OS promotion review |

---

## Status Labels

| Label | Meaning |
|-------|---------|
| `WORKS` | Verified working in VECTOR context |
| `PARTIAL` | Works in some cases but incomplete |
| `BROKEN` | Known to be broken — kept for reference |
| `EXPERIMENTAL` | Speculative; not verified |
| `FALSIFIABLE` | Testable hypothesis with clear pass/fail criteria |
| `UNVERIFIED` | Not yet tested |
| `REVISIT_LATER` | Potentially useful but not ready |
| `ARCHIVE_ONLY` | Kept for provenance; not promotable |
| `PROMOTE_TO_LABYRINTH` | Ready for promotion review |
| `NEEDS_TEST_HARNESS` | Logic is sound but has no test coverage |
| `NEEDS_REWRITE` | Idea is valid but implementation must be rewritten |

---

## Provenance Principle

> Archive everything. Promote nothing blindly.
> The old VECTOR system is immune memory.
> Labyrinth-OS core stays deterministic, canonical, replayable, and governed.
