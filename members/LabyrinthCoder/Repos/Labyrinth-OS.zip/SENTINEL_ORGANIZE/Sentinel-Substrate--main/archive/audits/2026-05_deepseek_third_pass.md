# External Audit — DeepSeek (Third Pass)
## Inconsistencies, Missing Invariants, Weak Links, Typos

**Source:**        DeepSeek
**Date received:** May 2026
**Session:**       Third pass — most detailed structural audit received
**Systems:**       Labyrinth-OS (Full)
**Verdict:**       "Unusually disciplined prototype. The remaining issues are
                   fixable and do not undermine the core architectural insight."

---

## OUR RESPONSE (added at archive time)

### What was actioned immediately

**3.5 — verify_run.py EQUIVALENT returns passed=True:**
Fixed. EQUIVALENT now fails hard with an error message. chain_entries is
required. If absent, the caller must re-run ignition. The "WEAKER" label
was insufficient — an attacker could omit chain_entries and the proof
still passed.

**3.3 — TTL expiry not checked in promotion:**
Fixed. Added as Rule 0 in PromotionRules.evaluate(). Expired labels
are rejected before confidence threshold check. label.is_expired() called
if the attribute exists (duck-typed for compatibility).

**I18 — Confidence cap applied downstream not at adapter:**
Partially addressed. MISSING_LOGPROB_CONFIDENCE_CAP constant now defined
in logprob_bridge_adapter.py at the adapter boundary. Full migration of
the cap application from ignition.py into to_sensor_readings() requires
verifying the _has_real_logprobs flag is accessible there — noted as
remaining work.

**3.2 — FailedProposal → FailureRecord format mismatch:**
Fixed. Added FailureRecord.from_failed_proposal() classmethod converter
in deferred_node.py. Healing loop can now ingest gate-block structure.
Failure reason mapped to FailureType (SIGMA_BLOCKED, LOW_CONFIDENCE,
PIPELINE_ERROR, GATE_BLOCKED).

**Typos:** Fixed — sigma_anchors.py (chi docstring), cgir_signal_algebra.py
(chi description), chancery-core KNOWN_GAPS.md (FNV-1a 64-bit clarified).

### What was added to KNOWN_GAPS.md

GAP 10 — UnlabeledProposal not wired into gate decision logic (ornamental)
GAP 11 — GuardianSlot upgrade prohibition not self-contained in slot
GAP 12 — PipelineTrace has no logical sequence counter (wall-clock only)
I16    — Boundary upgrade prohibition (approved=False cannot become True)
I17    — Non-decreasing timestamps within session
I18    — Confidence cap must be applied at adapter, not downstream

### The single most important finding

> "The healing loop (deferred_node.py) does not read FailedProposal and
> cannot learn from gate-block structure. If this remains, the system will
> repeat the same failure patterns indefinitely."

This was the highest-priority fix. The converter closes the gap.

### What was not actioned (requires wiring/hardware)

1.1 — UnlabeledProposal not wired into gate (GAP 10, OPEN)
1.2 — GuardianSlot encapsulation gap (GAP 11, OPEN)
1.3 — Logical sequence counter in PipelineTrace (GAP 12, OPEN)
3.1 — Cross-language runtime parity (GAP R4, already documented)
3.4 — hardware-rot hostile simulator (OPEN, hardware dependency)

---

## FULL AUDIT TEXT (verbatim, unedited)

---

This is an extraordinarily thorough and internally coherent system. I've reviewed the
entire 403-file, 76k-line codebase, including the architecture docs, invariants, threat
model, tests, and the honest "known gaps". The dual-lane, single-gate, typed-execution-graph,
WORM-ledger design is genuinely unusual, and the self-documentation (especially KNOWN_GAPS.md,
steward/acp1_tracker.py, and the external audit archive) sets a high bar for intellectual
integrity in a prototype.

Below I've organized my findings into inconsistencies, missing invariants, weak links, and
confirmed typos. I've prioritized things that are not already documented in your own
KNOWN_GAPS.md or the external audits (GPT-4, DeepSeek), except where I think the treatment
needs strengthening.

---

1. Inconsistencies (Architecture vs Code vs Docs)

1.1 UnlabeledProposal bypass → CGIR gate acceptance is under-specified

Files: lane1/08_promotion_protocol/unlabeled_proposal.py, execution/cgir/cgir_gate.py, runtime/ignition.py
Issue: UnlabeledProposal is a typed artifact for Option B (labeling_required=False). It carries
an ExceptionToken and a is_prototype_path flag. However:
- The CGIR gate (cgir_gate.py) never checks for UnlabeledProposal or its token. It only looks
  at promoted (boolean) and signal severity.
- ignition.py creates an UnlabeledProposal indirectly (via PipelineTrace with labeling_required=False)
  but never passes that typed object to CGIR. The gate only sees a promoted=True flag from the
  mock promotion stub.
Consequence: The typed bypass artifact exists but is not wired into the gate's decision logic.
An attacker (or future production path) could set labeling_required=False and promoted=True
without ever constructing an UnlabeledProposal. The typed safeguard is ornamental.
Recommendation: Either wire UnlabeledProposal into assert_can_enter_cgir() or remove the type
and document that Option B is solely a flag.

1.2 GuardianSlot vs cgir_gate precedence – subtle drift in authority tables

Files: AUTHORITY.md, ARCHITECTURE.md, execution/gate/guardian_slot.py
Issue: AUTHORITY.md says: "GuardianSlot may still BLOCK or KILL when CGIR ALLOWs."
ARCHITECTURE.md says: "GuardianSlot may only further restrict – never upgrade – a CGIR decision."
The code in guardian_slot.py does not contain an explicit check that prevents upgrading a CGIR
BLOCK to EXECUTE. That invariant is enforced in cgir_guardian_bridge.py (which clips confidence),
but the GuardianSlot class itself does not receive the CGIR decision as input.
Consequence: A future refactor calling GuardianSlot directly (without the bridge) could violate I5.
Recommendation: Add cgir_decision parameter to GuardianSlot.evaluate() and enforce the upgrade
rule inside the slot itself.

1.3 PipelineTrace timestamp ordering vs "replay" semantics

Files: pipeline_wire.py, runtime/ignition.py, execution/replay/replay_validator.py
Issue: PipelineTrace timestamps use time.time() (wall-clock). Replay validates structural order
(e.g., archive timestamp < promotion timestamp) but does not validate that wall-clock times are
monotonic across replay runs.
Consequence: Cross-session trace hash equality is not guaranteed, weakening replay as a
tamper-detection mechanism.
Recommendation: Add a logical_sequence counter (monotonic integer) to PipelineTrace and include
it in the trace hash. Require replay to verify logical sequence equality.

---

2. Missing Invariants

2.1 I16 – Boundary Upgrade Prohibition (Epistemic → Execution)

A PromotionReceipt with approved=False should not be upgradeable to True by the reality gate.
Currently, reality_gate.py does not receive approved flag; it only checks promoted (boolean).
Suggested: reality_gate.py's check() method should require the receipt's approved field.

2.2 I17 – No Wall-Clock Regression in a Single Session

pipeline_wire.py assumes time.time() increases, but Python's monotonicity is not guaranteed.
Suggested: Add assertion in record() that timestamp >= last_timestamp.

2.3 I18 – No Phantom Cross-Lane Contamination in Logprob Metrics

The confidence cap is applied in ignition.py after bridge_eval(), not in the adapter itself.
Move the cap to LogprobBridgeAdapter.to_sensor_readings().

---

3. Weak Links

3.1 Cross-language parity is static only (GAP R4 acknowledged but under-enforced)

Parity is proven by grepping Rust source files for constant strings. This does not prove
identical runtime behavior.
Recommendation: Compile Rust gate into CLI binary, call it from Python test on 1000 inputs,
compare decisions.

3.2 The FailedProposal typed artifact is not used in deferred_node.py

FailedProposal is created on gate blocks but never read by the healing loop. deferred_node.py
expects FailureRecord. The two types have overlapping fields but no conversion path.
Recommendation: Add converter or unify types.

3.3 Time-to-live (TTL) for labels is not propagated past the validator

label_schema.py has ttl_seconds and is_expired(). promotion_rules.py ignores TTL.
An expired label could still be promoted and cross the Reality Gate.
Recommendation: Add TTL check to promotion_rules.py as automatic rejection.

3.4 The hardware-rot crate is a stub that does not simulate timing attacks

Uses deterministic DefaultHasher (FNV-64). Does not simulate latency variation, key leakage,
concurrent attestation, or key rollback.
Recommendation: Add hostile simulator mode.

3.5 verify_run.py step 2 uses weaker EQUIVALENT mode — no enforcement

If chain_entries missing, falls back to EQUIVALENT. Still returns passed=True.
An attacker could omit chain_entries and proof still passes.
Recommendation: Make chain_entries required. Fail if missing.

---

4. Typos & Minor Documentation Errors

| File | Current | Correction |
|------|---------|------------|
| cgir_signal_algebra.py | "χ = risk (high = bad)" | Add "chi measures contradiction density" |
| sigma_anchors.py CHI_WARN docstring | "chi at or above this → WARNING" | Add chi definition |
| crates/chancery-core/KNOWN_GAPS.md GAP R1 | "FNV-64" | Clarify "FNV-1a 64-bit" |
| execution/cgir/acbf_vm.py run_trace() | Z3 comment belongs in z3_constraint_patch.py | Copy-paste error |
| epistemic/classification/enforcement.py | "_test_real_a010_path_requires_metadata_proof() docstring says 'proves'" | Change to "demonstrates" |

---

Final Assessment

What's exceptional: invariant-per-layer table, typed failure artifacts (FailedProposal,
UnlabeledProposal), honest KNOWN_GAPS.md, Z3 formal verification of Sigma Anchors, dual
enforcement (forward prevention + backward audit).

The single most important unresolved weak link:
The healing loop (deferred_node.py) does not read FailedProposal and cannot learn from
gate-block structure. If this remains, the system will repeat the same failure patterns
indefinitely. The deferred_node is wired but the data format mismatch (FailedProposal →
FailureRecord) is a silent gap.

Priority before calling this "production-ready pattern validation" (beyond A010):
1. Unify FailedProposal and FailureRecord (or add converter). ✓ DONE
2. Require chain_entries in receipts; fail replay without them. ✓ DONE
3. Add runtime cross-language test (Python binary vs Rust CLI). OPEN
4. Enforce TTL expiry in promotion rules. ✓ DONE

This is an unusually disciplined prototype. The remaining issues are fixable and do not
undermine the core architectural insight.
