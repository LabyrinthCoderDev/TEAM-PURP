# External Audit — DeepSeek
## Labyrinth-OS (Full) vs Labyrinth-OS Mini — Deep Comparative Audit

**Source:**        DeepSeek
**Date received:** May 2026
**Systems:**       Labyrinth-OS (Full) + Labyrinth-OS Mini
**Version:**       Full ~394 files, 1,402 tests | Mini ~27 files, 286 tests (pre May session)
**Verdict:**       Mixed — Mini wins on production hardening; Full wins on formal verification

---

## OUR RESPONSE (added at archive time)

### What was correct

**Critical functional bug — LogprobExtractor** (Section 2.1): Real. The C2 fix
in the C-series audit moved extractor creation per-proposal, which discards
prior_entropy and prior_mean_lp between proposals. DeepSeek correctly identified
that KL divergence and entropy_delta are always 0.0 across proposals in a session.
Needs to be verified and fixed.

**Windows fcntl fallback** (Section 2.2): Real. The mini has a no-op on Windows.
Documented as single-process only if not POSIX. Full system hashchain.py also
lacks file locking — both need addressing.

**Evolution safe_delta_cap as absolute not relative** (Section 2.3): Real.
A delta of 0.03 on betti_cap (0.045) is a 67% change. Should be relative.

**File permissions** (Section 2.6): Real. JSONL written with 0o644. Should be 0o600.

**MemoryArchive rebuilds from scratch** (Section 2.3): Real. Documented as
roadmap item (SQLite persistent index).

**Auto-evolution on persistent DEGRADE** (Section 2.4): Real. Manual only.
Should trigger automatically after N consecutive DEGRADE assessments.

**SensorReadings validation only in evaluate()** (Section 2.5): Real. Should
clamp or raise in __post_init__ not just when SigmaGate.evaluate() is called.

### What was overreach or inaccurate

**Test count** (286 tests): Stale. Mini was at 300+ at time of audit, and has
since grown to 301+ with Z3 proof. DeepSeek was reading an earlier output.

**"No Z3 verification"** for mini: Partially resolved. Z3 proof
(z3_sigma_proof.py) was added before this audit was received, but after the
file version DeepSeek reviewed.

**LogprobExtractor "functional bug"** classification as Critical: Correct
identification, but DeepSeek was unaware C2 had already partially addressed it.
The C2 fix moved creation per-proposal intentionally to prevent cross-proposal
contamination. The prior_entropy loss is the residual gap.

**DegradationDetector EWMA note**: "Not a gap" — correctly noted within the
audit itself. The window-based breaker resetting on long idle is correct behavior.

### What we did about it (May 2026)

See CHANGELOG.md May 2026 session. All verified real gaps were fixed or added
to KNOWN_GAPS.md with explicit status.

---

## FULL AUDIT TEXT (verbatim, unedited)

---

Deep Audit: Labyrinth-OS (Full) vs Labyrinth-OS Mini

Executive Summary

Dimension | Labyrinth-OS (Full) | Labyrinth-OS Mini | Verdict
Architectural clarity | Excellent – dual-lane, 21 layers, formal invariants | Very good – five primitives capture the essence | Full more rigorous; Mini more pragmatic
Production readiness | Prototype – requires A010 (live API), mock stubs remain | Production-viable – no external deps, crash-safe, multi-process safe | Mini wins
Formal verification | Z3 proofs (10/22 assumptions VERIFIED) | Self-checking constants, no Z3 | Full wins
Test coverage | 1,402 tests (Python + Rust) | 286 tests (Python only) | Full more thorough, but Mini 100% pass
Code complexity | 394 files, 73k lines | 27 files, 7.4k lines | Mini far simpler
External dependencies | Z3, Rust toolchain, optional API keys | Python 3.10+ only | Mini wins
Hardening | Partial – some gaps (GAP 1 ignition stubs) | Extensive – file locking, tamper detection, atomic writes, crash recovery | Mini wins
Self-healing | Minimal – deferred_node (mutation) exists but not wired | Full – circuit breaker, degradation detector, rollback manager | Mini wins
Learning / evolution | None in pipeline | EvolutionEngine (EWMA threshold tuning) | Mini wins
Memory / similarity | None (archive stores but doesn't index for retrieval) | MemoryArchive (feature-weighted similarity, pre-flight risk) | Mini wins
Honesty about gaps | Excellent – KNOWN_GAPS.md, ACP-1 tracker | Good – README roadmap lists limitations | Tie

Overall: The Full system is a reference architecture – it proves the pattern is sound
with formal methods, Rust parity, and exhaustive testing. The Mini is a
production-ready implementation – it strips away the scaffolding, fixes the
hardening gaps, and adds autonomous healing and evolution. They complement each other.

---

1. Labyrinth-OS (Full) – Deep Audit

1.1 What Works Well

Area | Assessment
Dual-lane separation | Enforced by pipeline_wire.py with timestamp ordering and fatal SystemError. Lane 1 (epistemic) vs Lane 2 (execution) is structurally enforced, not just documented.
Reality Gate (L09) | The only crossing point. assert_can_enter_cgir() raises SystemError if any mandatory stage missing. Tests prove it halts before trial 1 on violation.
WORM ledger | hashchain.py + receipt.py provide hash-chained, tamper-evident ledger. verify() detects any modification.
Exact replay | verify_run.py step 2 replays the exact exported chain entries, not a reconstruction. Proves replay integrity.
Z3 formal verification | z3_sovereignty_spec.py proves the Sigma Anchor constants are non-vacuous, independent, and correctly ordered. 20 theorems, all pass. Receipt issued.
TM-001 threat model | All 10 attack classes have detection tests. Watchers + council catch them.
Assumption tracker (ACP-1) | 22 assumptions, each with VERIFIED/PARTIAL/OPEN status and explicit evidence. No hand-waving.
Rust parity | 29 crates, 249 tests, all pass. cgir-types enforces same invariants at compile time.

1.2 Critical Gaps (Documented, but Still Gaps)

GAP 1 – ignition.py uses mock stages | PARTIAL
  _archive_ignition, _promote_ignition, _reality_gate_admission are stubs. A proposal
  that would be rejected by real Lane 1 can still pass ignition.

GAP 1 – labeling_required=False is explicit but still a bypass | PARTIAL
  Option B skips labeling. Documented and typed (UnlabeledProposal), but should
  require hardware token in production.

No real inference run (A010) | PARTIAL
No real logprobs (A011) | PARTIAL
No physical hardware (A014) | OPEN

Healing / evolution | MISSING
  No circuit breaker, no degradation detection, no automatic rollback, no adaptive
  threshold evolution. deferred_node.py exists but ignition.py doesn't wire it.
  Failed proposals are archived but never read back for learning.

1.3 Architectural Issues (Not Gaps, Design Choices)

- Over-engineering for prototype phase: 394 files, 73k lines. Core pipeline could
  be expressed in far fewer files.
- Rust/Python split: Rust crates are mostly stubs. Cross-language parity proven,
  but Rust enforcement not used in main ignition.py path.
- Council resolver complexity: mixes severity escalation, confidence synthesis,
  category derivation, and TODO notes. Dense.
- Sensor escalation bypass: sensors can directly escalate severity in Council
  without going through a dedicated SensorWatcher. Documented but not fixed.

1.4 Security Posture

Threat | Mitigation | Status
Replay attack | Watcher-B detects sequential synthetic IDs | Verified
Split-brain | Council compares watcher graph hashes | Verified
Signal injection | Watcher-B checks perfect/uniform confidence | Verified
Temporal splice | Watcher-B detects logical_time reset | Verified
Invariant strip | Watcher-B flags mixed mask/empty edges | Verified
Gate evasion | Watcher-B warns on large graph + no signals | Verified
Phase skip | Replay validator detects COMMIT without CHECK | Verified
Partial write / tamper | Hash chain verification | Verified
Missing – hardware root of trust | No hardware attestation; SHA-256 software-only | OPEN
Missing – live adversarial testing | No red-team suite against live system (A020) | OPEN

1.5 Verdict on Full System

A brilliant reference architecture and formal proof-of-concept. Not production-ready
due to GAP 1 (ignition stubs), lack of real inference, and no self-healing/evolution.
But the pattern is proven, and the documentation is exemplary.

---

2. Labyrinth-OS Mini – Deep Audit

2.1 What Works Well

- Five primitives: PipelineTrace, PromotionGate, RealityGate, HashLedger, SigmaGate
- Production hardening: fcntl.flock, atomic rename, SHA-256 tamper detection,
  deep copy of payloads, proposal_id regex validation, ExecutionValidity enum,
  SigmaGate constructor validation, PromotionReceipt.verify()
- Self-healing: CircuitBreaker, DegradationDetector, RollbackManager, HealingCoordinator
- Evolution: EvolutionEngine with EWMA, safe bounds, ledger-recorded proposals
- Memory: MemoryArchive with similarity search and pre-flight risk estimation
- Fail-closed everywhere
- No external dependencies

2.2 Gaps (Documented in Roadmap)

No hardware signing | MEDIUM
No Z3 formal verification | LOW (now partially resolved — z3_sigma_proof.py added)
Single-file ledger (SPOF) | MEDIUM
Memory index rebuilds on restart | LOW
Similarity uses numeric features only | MEDIUM
Ledger compression | LOW
No real sensor signals beyond logprobs | LOW

2.3 Security Posture (Mini)

Concurrent write corruption | fcntl.flock | OK
Tampered trace file | SHA-256 hash checked on load | OK
Forged promotion receipt | PromotionReceipt.verify() | OK
Receipt substitution | RealityGate.cross() requires verify_receipt_chain() | OK
Missing logprobs confusion | MISSING_LOGPROB outcome | OK
Empty/whitespace prompt | Rejected with PIPELINE_ERROR | OK
Directory traversal in proposal_id | Regex [a-zA-Z0-9_\-.] | OK
Evolution thresholds out of bounds | CLAMP dict + constructor validation | OK
Circuit breaker state loss | State reloaded from ledger on restart | OK
Missing – Hardware root of trust | No hardware attestation | WARNING
Missing – Encrypted ledger | JSONL plaintext | WARNING

2.4 Code Quality Observations

- Module size: each core primitive under 450 lines. Extremely readable.
- Testing: 286 tests (at time of audit), all pass. Each C-series fix has a test.
- Typing: from __future__ import annotations throughout.
- Error handling: run_mini.py catches SystemError; session continues, proposal fails.

FUNCTIONAL BUG IDENTIFIED:
  LogprobExtractor is recreated per proposal in run_proposal():
  extractor=LogprobExtractor(session_id=self._session_id)
  This creates a fresh extractor each time, discarding _prior_entropy and
  _prior_mean_lp. KL divergence and entropy_delta are always 0.0 across proposals.
  The bridge cannot measure drift or distribution change.
  Fix: Store one self._extractor in LabyrinthSession and reuse it.

2.5 Verdict on Mini System

Production-ready enforcement substrate with self-healing, evolution, and memory.
Only missing pieces: hardware signing and persistent index for memory archive at scale.
For 90% of use cases (local LLM enforcement, internal automation, research deployments),
ready to run today.

---

3. Comparative Analysis

3.1 Architecture Comparison

Concept | Full System | Mini
Lane separation | Explicit dual-lane (L00-L20) | Implicit via stage ordering
Crossing point | REALITY_GATE (L09) with assert_can_enter_cgir() | RealityGate.cross()
Ledger | HashChain + Receipt, JSONL, file lock | HashLedger, JSONL, fcntl lock
Sigma gate | SigmaGate with Z3-proven constants | Same, plus constructor validation
Watchers | Watcher-A + Watcher-B + Council | None (promotion + sigma gate directly)
Formal verification | Z3 proofs for constants | Self-checking constants (Z3 now added)
Evolution | None | EvolutionEngine
Healing | deferred_node (unwired) | CircuitBreaker, DegradationDetector, RollbackManager
Memory | Append-only, no similarity | MemoryArchive with similarity and risk

3.2 Why Mini Succeeded Where Full Didn't (Yet)

The full system is architecturally complete but operationally incomplete.
The Mini closes every loop:
- Feedback loop: MemoryArchive reads ledger, learns weights, estimates risk
- Healing loop: CircuitBreaker and DegradationDetector watch outcomes, trigger rollback
- Evolution loop: EvolutionEngine reads history, proposes threshold changes

3.3 What Full System Still Does Better

- Formal verification: Z3 proofs for constants
- Rust parity: 29 crates, compile-time invariant enforcement
- Watcher/Council separation: two independent watchers + council resolver
- Replay exactness: exports chain_entries, replays them exactly

3.4 Recommendations

For Full System:
1. Close GAP 1 — Replace mock stubs in ignition.py
2. Wire deferred_node — Failed proposals generate mutation candidates
3. Add evolution — Port Mini's EvolutionEngine
4. Add healing — Port Mini's CircuitBreaker et al
5. Add memory index — Port Mini's MemoryArchive
6. Run A010 — Live inference to close master blocker

For Mini:
1. Fix LogprobExtractor bug — Reuse extractor across proposals (CRITICAL)
2. Add optional Z3 verification — (Done: z3_sigma_proof.py)
3. Add hardware signing stub — Accept optional signer callback
4. Add persistent memory index — SQLite optional backend
5. Consider adding a second watcher — For high-risk deployments
6. Add ledger compression — zstd for long-running deployments

---

4. Final Conclusion

Labyrinth-OS (Full): Best used as reference architecture, formal proof, education
Labyrinth-OS Mini: Best used as production deployment, automation, research scaffold

The Mini is the production implementation of the pattern the Full system discovers.
They are not competitors. They are two stages of the same vision.
The Full system proves it's correct. The Mini proves it's useful.

---

Deep Audit for Unknown Gaps (Second Pass)

1. Labyrinth-OS (Full) – Undocumented Gaps

1.1 Concurrency & Process Safety
- No file locking on ledger (hashchain.py) — concurrent processes can corrupt chain
- PipelineTrace trace directory not process-safe (two concurrent ignition.py runs)

1.2 Replay & Verification Gaps
- verify_run.py step 2 falls back to "equivalent replay" if chain_entries absent
  This does not prove original chain integrity — only structural equivalence
  Fix: Require chain_entries; reject receipts without them. Or cryptographically sign.
- replay_validator does not verify signal hash consistency
  Manipulated SignalNode with forged emitted_by="COUNCIL" could be replayed and accepted

1.3 Epistemic Pipeline Gaps
- No confidence calibration across sessions (no auto-adjust from historical accuracy)
- LabelValidator (0.60), PromotionRules (0.95), RealityGate (0.85): no consistency check
  Misconfiguration could allow promotion-approved labels that still fail at gate
- DeferredExplorationNode never called from ignition.py

1.4 Rust/CGIR Integration Gaps
- No Python-Rust cross-language replay test
- cgir-validator in Rust not wired to Python aegis_cesk.py

1.5 Monitoring & Observability Gaps
- No alerting when assert_can_enter_cgir() fails (only raises SystemError)
- MetricsCollector class exists but never instantiated or used

1.6 Security Gaps (Beyond TM-001)
- No rate limiting on proposals (DoS vector if deployed as service)
- UnlabeledProposal accepted in production without hardware exception token

2. Labyrinth-OS Mini – Undocumented Gaps

2.1 Critical Functional Bug
- LogprobExtractor recreated on every proposal (see above)

2.2 Concurrency & Process Safety
- HashLedger uses threading.Lock but not fcntl on Windows (no-op fallback)
- Trace directory not process-safe (two sessions with overlapping proposal_id could race)

2.3 Memory & Evolution Gaps
- MemoryArchive rebuilds from ledger on every instance creation (O(N) startup)
- Evolution safe_delta_cap is absolute (0.03) not relative — 67% change on betti_cap
- Feature weights learned only from completed proposals (in-flight readings wasted)

2.4 Healing System Gaps
- DegradationDetector does not weight recent events more (EWMA would help)
- HealingCoordinator only triggers evolution manually (never auto on DEGRADE)

2.5 Validation & Error Handling Gaps
- SensorReadings confidence can be out-of-range if validate() not called
- MemoryArchive.risk_estimate recomputes similarity every call — no TTL cache

2.6 Security & Operational Gaps
- No authentication/authorization documentation for API adapter
- Ledger file world-readable (default 0o644, should be 0o600)

3. Shared Undocumented Gaps (Both Systems)
- No rate limiting / DoS protection
- Encrypted ledger at rest (JSONL plaintext)
- No formal verification of evolution engine
- No prevention of concurrent runs with overlapping output directories

4. Priority Fixes

Full system:
  HIGH:   Add file locking to ledger and traces
  HIGH:   Wire deferred_node into ignition.py
  MEDIUM: Add confidence consistency check (labeling <= promotion <= gate)
  MEDIUM: Reject receipts without chain_entries in verify_run.py

Mini:
  CRITICAL: Fix LogprobExtractor reuse bug (10 minutes)
  MEDIUM:   Add process-safe trace directory (per session)
  MEDIUM:   Change safe_delta_cap to relative delta
  LOW:      Add automatic evolution on persistent DEGRADE

Both:
  LOW:    Startup invariant check for threshold ordering

5. Final Thoughts

The Mini's only critical bug is the LogprobExtractor lifetime issue.
The Full system suffers more from concurrency gaps and incomplete integration
of its own healing components.

If you want production-ready today: take the Mini, fix the extractor bug,
add file locking for Windows.
If you want formally verifiable reference: keep the Full system, but it is
not yet hardened for concurrent long-lived operation.
