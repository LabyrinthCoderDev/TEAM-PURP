# External References Archive

Work studied, referenced, or adapted for Labyrinth-OS that is NOT Labyrinth-OS-original.

Every entry must include:
  - Source / author if known
  - What was studied
  - What (if anything) was adapted into Labyrinth-OS
  - Attribution status

Labyrinth-OS-original work lives in the main repo.
VECTOR (the prototype system) lives in archive/vector_legacy/.
This directory is for everything else.

---

## Contents

### quicksilver_v3/
**Source:** External upload for audit 2026-04-26
**Author:** Unknown / not attributed in source
**What it is:** Classical physics simulation — JOX Tower + Atomic Cascade
**What Labyrinth-OS took:** RTZ floor pattern (already independent in Labyrinth-OS as TAU_ESCAPE_FLOOR)
**Attribution:** Not Labyrinth-OS work. Studied for pattern comparison only.

### quantum_tubulin/
**Source:** External description + QuTiP simulation 2026-04-26
**Author:** Unknown / not attributed
**What it is:** Quantum mechanical extension of Quicksilver — tubulin dimer as qubit
**What Labyrinth-OS took:** Physical interpretation of TAU_ESCAPE_FLOOR as coherence floor
**Attribution:** Not Labyrinth-OS work. Quantum mechanics is sound. Physical premise (Penrose-Hameroff) is contested science.

---

## reactive_research_tools/

Two independent projects that demonstrate architectural pattern convergence
with Labyrinth-OS. Neither is Labyrinth-OS code.

**effective_boolean_filter/** — Deterministic boolean argument evaluation pipeline.
Its `trace_gate.py` independently implements PipelineTrace / PromotionGate /
RealityGate with stage ordering enforcement and hash provenance — identical
structure to Labyrinth-OS, built for a different domain (logical argument
evaluation). Potential future integration into PromotionProtocol.

**xi_jensen_pipeline/** — Numerical mathematics research tool (Riemann Xi function,
Jensen polynomial approach). Two-layer pattern: fast candidate scan + certified
deepcheck, never conflating exploratory vs certified results. Maps to planned
Labyrinth-OS multi-sentinel architecture.

Full assessment: `reactive_research_tools/ASSESSMENT.md`
Roadmap entry: `../../ROADMAP.md` (Effective Boolean Filter Integration section)
