# Quantum Tubulin Dimer Simulation — Audit Record

**Received:** 2026-04-26
**Source:** External description + QuTiP simulation result
**Author:** Not attributed in source
**Status:** EXPERIMENTAL
**Attribution:** Not Labyrinth-OS work. Referenced for physical interpretation only.

---

## What This Is

A QuTiP (Quantum Toolbox in Python) simulation of a tubulin dimer
modeled as a two-level quantum system (qubit: |0⟩ ground, |1⟩ excited).

The same RTZ floor and SSB (Mexican-hat) force from Quicksilver v3
are applied quantum-mechanically to rescue coherence from decoherence collapse.

Dephasing rate used: γ = 0.08 — same value throughout the tower simulations.

---

## What the Simulation Shows

**With rescue active (full JOX Tower):**
- Coherence (off-diagonal density matrix element ρ₀₁) rescued
- Stabilizes above RTZ floor
- Does not collapse to zero

**Without rescue (control case):**
- Rapid exponential collapse to near-zero coherence
- Exactly as standard Lindblad decoherence predicts

The math is correct quantum mechanics (Lindblad master equation).

---

## Component Classification

| Component | Status | Notes |
|-----------|--------|-------|
| Lindblad master equation | WORKS | Standard QM — textbook correct |
| γ = 0.08 dephasing rate | EXPERIMENTAL | Same as tower — consistent, not derived |
| RTZ floor on coherence | EXPERIMENTAL | Maps to TAU_ESCAPE_FLOOR physically |
| SSB Mexican-hat rescue term | EXPERIMENTAL | Same shape as classical SSB force |
| Tubulin as quantum two-level system | UNVERIFIED | Penrose-Hameroff hypothesis — contested |
| Biological temperature coherence | UNVERIFIED | Warm quantum coherence is disputed |

---

## Why This Matters for Labyrinth-OS

### Physical Interpretation of TAU_ESCAPE_FLOOR

TAU_ESCAPE_FLOOR = 0.75 in Labyrinth-OS measures observability —
how much system state is still readable by sensors.

This simulation suggests a physical substrate interpretation:
- τ-escape maps to quantum coherence (ρ₀₁ in density matrix)
- TAU_ESCAPE_FLOOR = the minimum coherence before the system
  enters the collapse basin and cannot self-rescue
- When τ < 0.75, the system is below the RTZ rescue floor

This is a physical interpretation, not a derivation.
The mapping is conceptually clean but not empirically proven.

### SSB Force as Coherence Rescue

The Mexican-hat potential `0.15 * rho * (1 - rho²)` in the quantum
version does the same job as in Labyrinth-OS's DeferredNode:
- Pushes coherence away from zero (unstable equilibrium)
- Into the stable non-zero basin (ρ ≈ 1)
- Hard floor prevents collapse below rho_seed

This confirms the SSB shape is the right model for
bounded self-correction — coherence or mutation bounds.

---

## What Is NOT Proven

1. Biological tubulin operates as a quantum two-level system at 310K
   (Penrose-Hameroff hypothesis — active scientific controversy)

2. Warm quantum coherence survives long enough to matter
   (decoherence timescales at biological temperature are very short)

3. The specific constants (γ=0.08, RTZ=0.05) are physically derived
   (they are consistent with the tower, not independently measured)

---

## Falsifiable Test

If the coherence-TAU mapping is to be promoted:
```
Test: At TAU = TAU_ESCAPE_FLOOR (0.75), system enters rescue basin
      At TAU < 0.75, system cannot self-rescue without external intervention
Pass: Sensor readings below TAU_FLOOR always precede unrecoverable drift
      (measurable in ignition.py replay data once A010 closes)
```

---

## What Labyrinth-OS Can Use Now

The physical interpretation enriches documentation only.
No code changes required. No new constants.

The interpretation goes in ARCHITECTURE.md or spec/SIGNALS.md:
"TAU_ESCAPE_FLOOR = 0.75 represents the minimum coherence
threshold below which sensor state cannot self-rescue.
Physical analogue: quantum coherence rescue basin (RTZ floor)."

---

## Labyrinth-OS Mapping

| Quantum Simulation | Labyrinth-OS |
|-------------------|-----------|
| Coherence ρ₀₁ | τ-escape ratio |
| RTZ floor (rho_seed) | TAU_ESCAPE_FLOOR = 0.75 |
| Collapse basin | τ < TAU_FLOOR → CRITICAL severity |
| SSB rescue term | SSB self-correction in DeferredNode bounds |
| γ = 0.08 dephasing | DRIFT_THRESHOLD = 0.12 (analogous role) |
| No rescue → collapse | Guardian BLOCK → system cannot recover without intervention |

*Archived: Labyrinth-OS — X @LabyrinthCoder*
