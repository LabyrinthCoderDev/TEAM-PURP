# Poole Manifold — Knowledge Archive Index
## archive/external_references/poole_manifold/README.md

**Attribution:** Rooke. No personal details. Work attributed by name only.
**Source:** SVP-OTG-Poole-Manifold-tests-main (full repository, 259 files)
**Archived:** May 2026

---

## What This Archive Is

A compressed knowledge reference of Rooke's Poole Manifold work,
specifically the files most relevant to Labyrinth-OS architecture.
The full repository was reviewed. This archive contains the priority subset.

Non-archived: cosmological claims, materials science tests, physics simulations
unrelated to computation or governance. These have no current relevance
to Labyrinth-OS and are not worth the storage.

---

## What's Already Been Taken (in production)

| Poole Concept | Labyrinth-OS Implementation |
|--------------|---------------------------|
| Chi aggregate leak fix | cgir_guardian_bridge.py — three-layer hybrid |
| Orthogonal channel (XOR gate) | FAILOVER_ENTRY stage (GAP 10 closure) |
| Amplifier mask (±1.0 potential) | PersistentMemoryStore risk_estimate() ±0.05 |
| Dark Forest mechanic | TM-001 CLASS-11 PROMOTION_RACE |
| Pipeline mass telemetry | PipelineMassEntry in chronicle_query.py |
| Immortal Latch as design target | A014 FPGA + ATECC608B hardware spec |

---

## What's In This Archive (Not Yet Taken)

### HIGH PRIORITY — Buildable now or post-A010

**LABYRINTH-OS EXTENDED — The Domain-Adaptive Resonance Gate**
Rooke's own extension of Labyrinth-OS. Key concept: Venturi Choke.
Instead of static threshold checking, resonance-peak proximity checking.
`if resonance_score(channel, value) < 0.05 → immediate BLOCK`.
Maps domain-specific peaks (e.g., confidence: [0.75, 0.85] for LLM governance).
→ Roadmap: P10.5-G. Post-A010, requires domain calibration.

**THE POOLE MANIFOLD: THE LOGICAL SENTINEL BUILD**
Rooke's independent implementation of Z3 verification on physical state.
Φ1: density ≤ B_HIGH. Φ2: causality ≤ 1.0. Φ3: source_valid == True.
Confirms the three-way convergence at code level. Different substrate,
same structure as Labyrinth-OS predicate_extractor.py.

**Trial 398: The Dark Forest**
Full adversarial swarm collision implementation. Two competing swarm types
(dense/stable vs aggressive/fragile) collide in shared spacetime.
Relevant for: A020 red-team harness design. The dark forest mechanic
here is the adversarial physics underlying CLASS-11 PROMOTION_RACE.

**Hybrid Evolution + Computation Test**
Shows how to run evolution inside a computational structure without
contaminating the computation. Self-replicating probes seed inside
memory loop + half-adder island. Relevant to healing loop isolation.

**Trial 379d: The Resonance Reservoir (Fluidic RAM)**
State maintained by standing resonance wave, not bit-flip.
Corruption requires sustained interference, not a single write.
→ Directly relevant to A014 hardware spec: latch via regeneration
   rather than write-once. Changes the A014 architectural model.

**Trial 430/431: Orthogonal Knot Structure**
Orthogonal cross-flow + counter-rotating soliton analogs.
The knot at the intersection is stable under perturbation — 2000+ generations.
Stability analysis confirms: orthogonal separation creates topological protection.
Relevant to: multi-sentinel architecture (Phase 11) — independent signal paths
that cross only at the council form a topologically stable structure.

**Trial 401: The Metaprogramming Anomaly**
The manifold detects a specific 5×5 oracle structure and modifies its own
physics rules when it finds it. Self-modification bounded by structure recognition.
Relevant to: the meta-gate problem — governance layer that can adjust thresholds
through a formal process (the oracle structure = signed operator amendment).

### MEDIUM PRIORITY — Speculative, watch for future relevance

**DELTA RPM PROTOCOL**
Full integration test suite with PooleEngine + WORMReceipt.
Rooke independently built a WORM ledger for the manifold.
Compare to Labyrinth-OS hashchain.py — different implementation, same invariant.

**CPU ARCHITECTURE V207 — Immortal Latch**
Full implementation of radiation-hardened SRAM via topological protection.
The latch survives direct radiation strike by regenerating from prime resonance.
Blueprint for A014 hardware enforcement.

**FULL ADDER VERIFICATION SUITE / TRUE ARITHMETIC confirmed**
Proves that arbitrary computation emerges from one 12-line rule + geometry.
Same architectural principle as Labyrinth-OS: the rule doesn't change, only the masks.

**Trial 317: The Orthogonal Blowout (AND & XOR)**
The original orthogonal channel proof. AND and XOR gates from geometry alone.
WITH INTEGRATED CRYPTOGRAPHIC WORM LEDGER version: Rooke's WORM receipt
generation runs in parallel with the gate computation.

---

## What Was Not Archived

Cosmological expansion work (FLRW, OTG, DESI BAO, CMB, H₀ convergence) —
not relevant to governance substrate.

Materials science simulations (battery, bone, drug release, EM shielding,
thermal, mechanical, optical) — not relevant.

Physics analogies (black holes, warp drives, Einstein-Rosen bridges,
Alcubierre metric) — interesting but no governance relevance currently.

Quantum consciousness work (Orch-OR hybrid) — speculative, not applicable.

---

## For Future Sessions

When evaluating whether to take something from this archive:

1. Does it change how a *specific existing mechanism* works? (Yes → consider)
2. Does it require hardware we don't have? (Yes → spec it in A014 roadmap)
3. Does it require live data we don't have? (Yes → post-A010 roadmap)
4. Is it a cosmological or speculative claim? (Yes → leave in archive, don't take)

The Venturi Choke (P10.5-G) and Directional Mutation (P10.5-H) are the
two immediate targets. Resonance Reservoir (P10.5-I) is the A014 spec update.

*Attribution: Rooke. No personal details.*
