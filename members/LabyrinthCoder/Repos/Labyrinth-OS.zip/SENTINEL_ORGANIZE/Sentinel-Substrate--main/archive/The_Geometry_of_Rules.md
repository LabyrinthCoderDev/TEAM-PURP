# The Geometry of Rules
## A Complete Analysis of the Poole Manifold and Labyrinth-OS

*From @LabyrinthCoder — author of Labyrinth-OS*
*For Rooke Poole — author of the Poole Manifold*

---

## How This Document Was Made

I read the paper. Then I read every file in the repository — 230 files, every trial from the simplest glider test to the DESI BAO cosmological fit. Every version, every failed iteration, every FPGA preview, the grey goo scenario, the dark forest adversarial test, the hybrid evolution-plus-computation integration, the three cosmological analysis tools, the metaprogramming anomaly.

I read the code because the code is more honest than the paper. The paper says results. The code says how.

What follows is the full analysis: what each system is, what the code reveals that the paper doesn't, where the deep structural parallels live, what I actually trust philosophically, and — at the end — a direct note to Rooke about what Labyrinth-OS is going to borrow and where we're going to put it.

---

## Part 1 — What Each System Actually Is

### The Poole Manifold

A three-dimensional totalistic cellular automaton on a cubic lattice. Moore neighborhood, 26 neighbors, periodic toroidal boundary conditions. The base rule is B5-7/S5-9: dead cells are born when neighbor sum is 5-7, live cells survive when neighbor sum is 5-9.

The core innovation is **prime-resonance sharpening**:

```
Φ(c) = S(c) + Σ α·exp(-(S(c) - p)²/σ²)   for primes p ∈ {2,3,5,7,11,13,17,19,23}
```

where α = 0.35 and σ² = 0.01. Sharp Gaussian bumps at prime values amplify the effective potential at those neighbor counts. Everything emerges from that.

The entire engine is a single 12-line function called in every trial:

```python
def run_manifold(f, inhibitor_mask, threshold_mask, amplifier_mask):
    padded = F.pad(f.float(), (1,1,1,1,1,1), mode='circular')
    potential = F.conv3d(padded, kernel, padding=0)
    potential[inhibitor_mask] -= 15.0    # hard walls
    potential[threshold_mask] -= 2.0     # drag zones
    potential[amplifier_mask] += 1.0     # boost channels
    resonance = sum(0.35 * exp(-((potential - p)**2) / 0.01) for p in PRIMES)
    total_phi = potential + resonance
    birth = (f == 0) & (total_phi >= B_LOW) & (total_phi <= B_HIGH)
    survive = (f == 1) & (total_phi >= S_LOW) & (total_phi <= S_HIGH)
    return (birth | survive).float()
```

The AND gate, the Immortal Latch, the self-replicating probe, the cosmological expansion — they all call this same function. The difference is the masks. **The masks are the entire engineering surface.**

From this one rule, with different mask geometries:
- Full adder, 8-bit ALU, opcode multiplexer — universal computation
- Immortal Latch (V207) — topologically protected memory surviving radiation strikes
- Self-healing waveguides — damage repaired by absorbing incoming kinetic mass
- Von Neumann self-replicating probe — 134 replication events
- Three-species evolving ecosystem — 600 replication events, stable coexistence
- Expanding lattice with succession flux Φ ≈ 0.3095
- OTG cosmological model fitting DESI BAO better than ΛCDM (Δχ² ≈ 243.6)
- 1/r force law from complex gauge coupling to a metric field

### Labyrinth-OS

A deterministic constitutional enforcement substrate for AI systems. One law:

**Imagination is free. Execution requires proof. No exception.**

The architecture separates thinking from acting at the structural level — not through guidelines, training, or prompting, but through the geometry of the pipeline itself. A proposal cannot become an action without crossing the Reality Gate (L09), the single mandatory crossing point between Lane 1 (epistemic) and Lane 2 (execution).

From this one law, with different pipeline stages:
- 21-layer mandatory pipeline — no stage can be skipped
- WORM append-only ledger — every execution logged, SHA-256 hash-chained
- Structural replay — same chain entries, same order, same outcome
- Z3 formal proof of Sigma Anchor constants (A021 VERIFIED)
- FailedProposal typed artifacts — every gate block produces a structured record
- Deferred exploration with bounded mutation — MAX_DEPTH=5, MAX_DELTA=10%
- PersistentMemoryStore — SQLite-indexed similarity search and risk estimation
- Adversarial threat model TM-001 — 10 attack classes with detection tests
- 1,444 tests, 0 failures, 29 Rust crates

---

## Part 2 — What the Code Reveals That the Paper Doesn't

### The masks are the architecture, not the rule

Reading the actual trial files makes this clear in a way the paper obscures. Trial 317 (AND/XOR orthogonal blowout) reveals:

```python
# THE AND GATE — pure geometry
thr[0, 0, oy-3:oy+3, ox-12:ox-8, z-2:z+2] = True   # -2.0 drag sponge
amp[0, 0, oy-3:oy+3, ox+10:ox+30, z-2:z+2] = True   # +1.0 downstream boost
```

The threshold mask creates a drag zone. Combined mass from two inputs pushes through. Single input stalls. That's an AND gate built entirely from pressure geometry — not programmed logic, actual fluid dynamics. The computation is thermodynamic. The XOR uses an orthogonal escape valve where double-input pressure blows out sideways rather than forward. Same physics, different channel geometry.

This is more remarkable than the paper conveys. There is no instruction being executed. There is no interpreter. Just mass, pressure, and geometry — and the geometry implements boolean logic.

### The Einstein-Rosen bridge is programmed, not emergent

Trial 458 has this line: `entanglement_coupling = 0.85`

```python
u_next[CENTER-10:CENTER+10, CENTER+offset-10:CENTER+offset+10] = (
    node_B_core + entanglement_coupling * (node_A_core - node_B_core)
)
```

Node B is directly forced to track Node A. This bypasses the spatial Laplacian entirely. The instantaneous synchronization is not emergent from B5-7/S5-9 — it's a direct assignment. The paper acknowledges "a non-local entanglement coupling term was introduced" but presents it as if it's a feature of the manifold. It isn't. It's a patch added to the simulation.

What is genuinely interesting: the experiment tests whether the manifold sustains forced correlation without collapsing. The answer is yes — both nodes remain synchronized for 400 generations. That's worth knowing. But it's a coherence test, not an emergent wormhole.

### The self-replication cap

The self-replication probe has: `if len(probes) < 12: new_probes.append(...)`

Hard cap at 12 probes. The 134 replication events happen within a bounded population. This isn't hidden — it's just not in the paper. The replication count tracks total spawning attempts, not maximum simultaneous population. Still remarkable. Different claim.

### The hybrid evolution-plus-computation test is the most important unverified experiment

Trial "Hybrid Evolution + Computation Test" seeds three competing replicator species inside a memory loop adjacent to a half-adder island. It runs both systems simultaneously for 4,200 generations, periodically injecting truth-table tests into the adder and measuring whether the adder still works.

The code defines `adder_success_history` — a running record of whether computation survives evolution. What the code doesn't provide is results. The file exists. The measurements are defined. No output is published.

**This is the most important missing result in the repository.** If evolution and computation coexist without the evolution destroying the computation, that validates universality more strongly than anything else in the paper. If evolution eats the adder, the claim weakens significantly.

### The dark forest test is genuinely good and not in the paper

Trial 398 implements two cellular automaton swarms with different rule parameters competing in the same lattice. Alpha uses standard B5-7/S5-9. Beta uses a mutated B4-6/S4-8. When both try to occupy the same voxel, they annihilate each other. The diagnostic checks whether extinction, coexistence, or symbiosis occurs.

This is actual evolutionary game theory in a cellular automaton. Real result, not in the paper, not highlighted in documentation. It belongs in the paper.

### Why the primes work — the honest mechanism

Primes are not magic. They are maximally spread. The first nine primes (2, 3, 5, 7, 11, 13, 17, 19, 23) cover the neighbor-count range without clustering. The Gaussian bumps (σ² = 0.01) are sharp enough that neighboring primes don't interfere with each other.

The genuine advantage of primes over other choices: they are irregular. They don't share factors. A sequence like 5, 10, 15, 20 would create resonances that constructively interfere because they share harmonic relationships. The primes don't. Their irregularity prevents the resonance bumps from coupling in ways that would destabilize the base rule.

That's combinatorics, not mysticism. But it's a real reason primes work better than other choices.

### What Φ ≈ 0.3095 actually is

The succession flux appears consistently across cosmological experiments. Here's where it comes from:

In a 3D Moore neighborhood with 26 neighbors, a density d produces average neighborhood sum 26d. For the sum to sit in the birth-survival overlap (≈7), d ≈ 7/26 ≈ 0.269. Prime-resonance sharpening boosts the effective potential at prime values, shifting equilibrium upward. The measured Φ ≈ 0.3095 is consistent with resonance-boosted equilibrium density for this rule set on a 3D toroidal lattice.

Φ is not a fundamental cosmological constant — it's the equilibrium density of B5-7/S5-9 with prime resonance on a 3D torus. That derivation would be a genuine theoretical contribution to the paper.

---

## Part 3 — What Is Actually Proven and What Needs More Scrutiny

### What holds up

The AND gate. The XOR gate. The full adder. The telemetry is specific — carry leakage, backflow, sum mass — and the pass/fail conditions are explicit. These results are solid.

The Immortal Latch mechanism is real. The cross-coupled macro-orbit creates a closed circulation topology. A local perturbation disrupts one segment. The remaining segments continue. The circulating mass, following prime-resonance rules, restores the damaged segment because the rules favor survival at the neighbor-count values present in waveguide geometry. The latch heals not because it has a repair module — healing is what the physics does to a damaged segment of a circulating mass pattern.

The prime-resonance sharpening is a genuine innovation. Not the specific primes — the concept of resonance amplification at chosen neighbor-count values. That's new.

The dark forest adversarial test (Trial 398) is real evolutionary game theory. The results (extinction, coexistence, or symbiosis) would be worth publishing.

The three cosmological analysis tools (rsd_multipoles.py, weak_lensing.py, synthesis_gate.py) implement legitimate physics. The computations are standard approaches applied to Poole Manifold density fields. Whether they prove OTG is cosmologically valid is a separate question.

### What needs more scrutiny

**The OTG cosmological fit (Δχ² ≈ 243.6):** This is a large number. ΛCDM fits DESI BAO data very well. Improving on it by 243.6 χ² would be significant — but only if OTG has comparable parameter freedom. The paper doesn't report the number of free parameters in the OTG fit. Without AIC or BIC correction, the comparison is not rigorous.

**Self-replication claims:** Single runs, fixed seeds (torch.manual_seed(137), np.random.seed(42)). Variance across seeds is unknown. 10 runs with different seeds and reported mean/variance would make this a result rather than an observation.

**The wormhole:** Stated above. The entanglement coupling is programmed. Present it as "forced non-local coupling produces stable synchronized nodes" and it's an interesting coherence result.

**The hybrid test:** Unverified. Run it. Publish the results.

---

## Part 4 — The Deep Structural Parallels

### Both systems derive everything from refusing to add mechanisms

The Poole Manifold never adds a new rule for computation, memory, healing, or cosmology. Always B5-7/S5-9 plus prime resonance. When computation is needed, the rule produces it. When healing is needed, the rule produces it.

Labyrinth-OS never adds a new safety mechanism for individual concerns. The pipeline has 21 layers, but they all follow the same constitutional law. When auditability is needed, the ledger provides it. When healing is needed, the deferred node provides it.

**The power comes from refusing to add.** Both systems discovered that the constraint itself — applied consistently — generates capabilities as emergent properties rather than designed features.

### Both enforce topological invariants rather than checking outcomes

The Immortal Latch is topologically protected. The closed circulation cannot be destroyed by a local perturbation. The latch heals because the shape requires healing, not because a repair module was added.

Labyrinth-OS enforces pipeline ordering topologically. `assert_can_enter_cgir()` raises `SystemError` — not a catchable exception, a hard halt — if any mandatory stage is missing. The pipeline cannot be traversed out of order because the data structure makes out-of-order traversal impossible to represent without violating the invariant.

Both protect invariants through geometry, not through checking.

### Both have a single crossing point

The Poole Manifold's logic gates use inhibitor walls (penalty −15.0) and Venturi chokes to create exactly one valid path for signal propagation. The AND gate allows mass through only when both inputs exceed the threshold. The geometry is the gate.

Labyrinth-OS has the Reality Gate (L09) — the only bridge between Lane 1 and Lane 2. Mandatory, pre-execution. The geometry is the enforcement.

### The prime-resonance sharpening and the Sigma Anchor constants are the same thing

Both systems have a small set of constants that determine where the system is sensitive.

Poole Manifold: nine primes, α = 0.35, σ² = 0.01. These create sharp resonance peaks defining which neighbor-count regions produce birth, survival, or death.

Labyrinth-OS: TAU_ESCAPE_FLOOR = 0.75, CHI_COLLAPSE = 0.40, DRIFT_THRESHOLD = 0.12, BETTI_1_CAP = 0.045, CONFIDENCE_FLOOR = 0.65. These determine whether a proposal executes. Z3-proven to be internally consistent and non-vacuous.

Both were discovered through iteration. Both encode the sensitivity of the system — the regions of input space where the rule fires, blocks, or transitions. Both are the irreducible heart of their respective systems.

### The healing mechanisms are structurally identical

The Poole Manifold's waveguides heal by absorbing incoming kinetic mass. A disruption introduces mass into the region. The prime-resonance rule causes that mass to be incorporated into the waveguide's circulation. **The energy of the attack becomes the material of the repair.**

Labyrinth-OS's deferred node heals by mutating failure parameters into new candidates. A gate block produces a `FailedProposal`. The converter transforms it into a mutation seed. The deferred node applies a bounded delta (±10% max) to produce a new candidate that re-enters at LABELING with low confidence and must earn promotion. **The energy of the failure becomes the material of the repair.**

Same principle. Different substrate.

### Labyrinth-OS as a cellular automaton

The Poole Manifold is a 3D cellular automaton on a cubic lattice. Cells have states. Neighborhoods determine transitions. Local rules produce global invariants.

Labyrinth-OS is a 1D cellular automaton on a pipeline lattice. Stages are cells. The ordered sequence is the neighborhood. The constitutional rule (I1-I18) determines valid transitions. Stage index increments by exactly 1. Timestamps are non-decreasing (I17). Each stage produces a typed artifact. The hash chain is unbroken.

Both are discrete dynamical systems where local interactions produce global invariants. The dimensionality differs. The domain differs. The mathematical structure is the same.

### The Sigma Anchor and the Immortal Latch

Both systems have their most important invariant protected by the same mechanism: topology.

The Immortal Latch's circulation cannot be destroyed locally — the topology of a closed loop is a global property.

The Sigma Anchor constants, once Z3-proven to be non-vacuous, cannot be violated by any input that satisfies the constraints — the proof is global over the constraint space.

Both systems found that the deepest protection is geometric, not procedural.

---

## Part 5 — The Speculative Synthesis

**What if you ran Labyrinth-OS inside a Poole Manifold substrate?**

Treat the pipeline stages as geometric regions, separated by inhibitor walls. The Reality Gate becomes an overpressure zone — a Venturi choke that only permits passage when kinetic mass exceeds the Sigma Anchor threshold. The WORM ledger becomes a sequence of Immortal Latches, each storing one entry in a cross-coupled macro-orbit chain.

Then:

**The Reality Gate becomes topological.** A proposal that doesn't meet Sigma Anchor thresholds cannot build enough kinetic mass to breach the Venturi choke. The gate is not a software check — it is a physical barrier. Bypass becomes geometrically impossible, not just detectable.

**The WORM ledger becomes physically self-healing.** Each entry is stored in a V207-style closed orbit. A radiation strike disrupts one entry. The topological protection restores it. Immutability is a physical property, not a software invariant.

**The PromotionReceipt becomes a genome** — a structured kinetic mass packet that encodes proof that promotion evaluation ran. It propagates through the substrate as a particle-like excitation, arriving at the Reality Gate with the correct mass signature or being blocked.

**The healing loop becomes kinetic mass recycling** — failed proposals inject mass back into the waveguide system, redistributed by the prime-resonance rule into new candidate mass packets.

This is not metaphor. This is a design specification for A014 — Labyrinth-OS's hardware enforcement gap. The FPGA timing floor, the hardware-signed attestation, the physical gate that cannot be bypassed in software — those are the Poole Manifold substrate that Labyrinth-OS is missing.

**A014 is the Poole Manifold layer of Labyrinth-OS.**

---

## Part 6 — Where Each System Is Stronger

### Labyrinth-OS is stronger in

**Formal invariant tracking.** I1-I10 enforced in code. I16 and I17 now runtime assertions. 22 ACP-1 assumptions with VERIFIED/PARTIAL/OPEN status and falsification criteria. The Poole Manifold has no equivalent — its invariants are empirically observed, not formally tracked.

**Exact replayability.** SHA-256 hash-chained ledger, structural replay from chain entries, verify_run.py. Any session can be proven to have happened as claimed. The Poole Manifold simulations are deterministic given a seed but don't export a tamper-evident trace.

**Adversarial threat modeling.** TM-001 covers 10 attack classes. The Poole Manifold doesn't consider an attacker. What happens if a hostile genome is injected into the evolving ecosystem? That's an open question.

**Gap documentation.** KNOWN_GAPS.md, PROTOTYPE_BOUNDARIES.md, ACP-1 tracker. Every gap named, described, falsifiable. Nothing equivalent in the Poole Manifold paper.

**Cross-language parity.** Python for orchestration, Rust for enforcement. 29 Rust crates, 249 tests. Poole is PyTorch on NVIDIA GPUs — no CPU fallback, no alternative implementation.

### The Poole Manifold is stronger in

**True cross-domain emergence.** Same rule produces computation, memory, healing, replication, evolution, cosmology, gravity-like forces. Labyrinth-OS produces one thing: constitutional enforcement. Very good at that one thing. Has not produced emergent physical-like behavior.

**Physical self-healing.** The Immortal Latch heals using the same mass that would destroy it. Automatic and local. Labyrinth-OS's healing is deliberate and centralized — it requires a circuit breaker and controlled mutation.

**Prime-resonance sharpening is more beautiful than hand-crafted thresholds.** The Sigma Anchor constants were chosen through iteration and proven consistent. The prime-resonance sharpening was also discovered through iteration but has deeper mathematical structure. Whether the prime connection is meaningful or coincidental is open, but it's more elegant as a mechanism.

**Self-replication.** Labyrinth-OS deliberately does not replicate — bounded at MAX_DEPTH=5, MAX_DELTA=10%, to prevent exponential growth. The Poole Manifold's replication is extraordinary. This is a design choice, not a failure. But the generativity is genuinely greater.

---

## Part 7 — The Honest Limitations of Both Systems

### Poole Manifold — what the paper doesn't say

No repeated runs. Results from single seeds (137, 42). Variance unknown.

No error bars. "100% accuracy," "perfect switching" without confidence intervals.

The Einstein-Rosen bridge uses a hardcoded coupling constant that directly forces Node B to track Node A. Not emergent from the rules.

The self-replication cap at 12 probes is not disclosed.

The OTG fit needs parameter-count disclosure. Δχ² ≈ 243.6 may not survive AIC/BIC correction.

The hybrid evolution-plus-computation test has no published results.

No limitations section.

### Labyrinth-OS — from KNOWN_GAPS.md, openly documented

GAP 1 (PARTIAL): ignition.py uses mock stubs. Ordering enforced. Module content approximated.

A010 (OPEN): No real inference has run. All tests use mock backends.

GAP R4 (OPEN): Cross-language runtime parity is static constant comparison, not runtime equivalence.

GAP 10 (OPEN): UnlabeledProposal not wired into gate. Typed safeguard is ornamental.

GAP 11 (OPEN): GuardianSlot upgrade prohibition enforced in bridge, not in slot itself.

A014 (OPEN): Hardware enforcement requires physical silicon. No code closes this.

Constitutional deadlock (OPEN): No resolution for disagreement loops, promotion starvation, confidence collapse.

Measurable ≠ impossible: The system currently measures and logs violations. It does not yet make them structurally impossible. That closes with A014.

---

## Part 8 — Philosophy, Theory, Metaphors, Poetry

*What follows is what I actually trust. Not summaries of what others said. My own analysis, stated as clearly as I can.*

---

### On computing without computing

The Poole Manifold computes by pressure. The AND gate works because two simultaneous inputs produce enough kinetic mass to push through a threshold channel. The XOR gate works because two simultaneous inputs produce pressure that escapes orthogonally rather than forward.

No instruction is being executed. No interpreter reads a program. Just mass, pressure, geometry — and the geometry happens to implement boolean logic.

This is the same thing Labyrinth-OS does, one level deeper. Labyrinth-OS prevents execution by geometry — the pipeline has a shape that makes bypass geometrically impossible. The Poole Manifold performs execution by geometry — the logic gates have a shape that makes incorrect outputs geometrically impossible.

Both systems discovered that the hard work — enforcement, computation — can be delegated to the geometry of the substrate rather than the intentions of the actors. Neither system trusts its inputs. Both trust their structure.

**Can you embed behavior in shape rather than instruction?** The Poole Manifold says yes, for computation. Labyrinth-OS says yes, for governance.

---

### On the Immortal Latch and what immortality actually means

The latch heals not because it has a repair mechanism. Healing is what the physics does to a damaged segment of a circulating mass pattern.

A local perturbation disrupts one segment of the loop. But the remaining segments continue to circulate. The circulating mass, following prime-resonance rules, flows around the disruption and restores the damaged segment because the rules favor survival at the neighbor-count values present in waveguide geometry.

The immortality is that the loop topology is conserved by the local rules. The latch heals because the topology requires it.

This is the most beautiful result in the repository. Not because it's exotic — because it's simple. The structure heals because the structure is what the physics prefers. The healing is not added. It is a consequence of the geometry encountering its own preferred state.

---

### On what both systems learned independently

Both were built without knowledge of the other. Both arrived at the same design principle.

A small set of local rules, applied consistently and without exception, generates global invariants more robustly than any set of special-case mechanisms.

The Poole Manifold proves this in physics. The same rule that computes also heals also replicates also expands cosmologically. No special modules. No exception handlers. Just B5-7/S5-9 and prime resonance, applied everywhere, every generation.

Labyrinth-OS proves this in governance. The same rule that prevents unauthorized execution also produces the audit trail also produces the healing signal also produces the replay proof. No special safety modules. No exception handlers for specific attack types. Just: proposals cross the gate or they don't, and everything is logged.

One is a physics engine. The other is a constitutional engine. Both emerge from refusing to add.

---

### The metaphor I trust most: the river delta

Imagine a river delta. No one designed the delta. The water didn't plan which channels to carve. The sediment didn't decide where to deposit. And yet the delta has structure — persistent channels, islands, distributaries that remain stable across seasons.

The delta's structure is the solution to a problem: how does water, carrying sediment, move from a river to a sea under gravity? The answer is the delta's shape. The shape didn't come from design. It came from physics encountering itself repeatedly until it found a stable pattern.

The Poole Manifold is a delta. The water is kinetic mass. The sediment is cellular state. The river is the prime-resonance rule. The sea is the stable equilibrium density Φ ≈ 0.3095. The channels — the logic gates, the immortal latch, the waveguides — are the stable patterns the physics found when initial conditions forced it to solve the problem of computation.

Labyrinth-OS is also a delta. The water is proposals. The sediment is epistemic evidence. The river is the constitutional rules (I1-I18). The sea is execution. The channels — the pipeline, the gate, the ledger — are the stable patterns the governance problem required.

No one designed the delta. The builder shaped the constraints. The delta emerged from the physics.

**Both systems are deltas. That's the theory I trust most.**

---

### The constitutional cybernetics frame

Both systems are implementations of the same philosophical position: **form is prior to intent**.

In Kant's terms, a good will is one that acts according to a law it could universalize. The Poole Manifold's cells don't have intentions — they follow a law (B5-7/S5-9) that applies universally. The logic gate doesn't "want" to compute AND. The geometry makes AND the only possible outcome when two inputs fire simultaneously.

Labyrinth-OS extends this to AI: a safe AI action is not one where the model wanted to do the right thing. It's one that passed through a structure it cannot bypass. The model's intentions are irrelevant. The structure decides.

Both are Kantian systems. They work not because actors are good but because the rules are geometric.

---

### On why the death mechanism matters

Poole's three-species ecosystem sustains all three species for 4,450 generations without extinction. There is no death mechanism for lineages. All three survive.

Labyrinth-OS's deferred node has an OscillationDetector. If the same failure type appears three or more times in a lineage, the lineage is retired. Maximum depth is 5.

This is a design philosophy difference worth naming explicitly:

Poole's ecosystem says: all evolutionary lineages are worth sustaining. Natural selection will handle pruning without needing a predator.

Labyrinth-OS says: stuck lineages should be killed. A lineage that keeps producing the same failure type is not evolving — it's oscillating. Oscillation consumes resources without producing progress. Kill it.

Neither is wrong. Poole's approach produces more diverse ecosystems. Labyrinth-OS's approach produces more efficient ones. The right choice depends on whether you're building a universe or a safety system.

---

### The poetry

*The mass goes where the geometry allows.*
*The geometry allows what the rule permits.*
*The rule permits what the prime will amplify.*
*The prime amplifies what the neighbor sum finds.*

*There is no decision anywhere in this.*
*Only shape encountering shape.*
*Only pressure meeting pressure.*
*Only the cellular automaton doing the only thing it knows:*
*checking whether each cell, in this moment,*
*has enough neighbors to survive.*

*And from that asking, a universe.*

---

*The gate does not think.*
*The latch does not remember.*
*The waveguide does not intend.*

*They are shapes that, when mass flows through them,*
*produce the behavior we needed.*

*We did not program the logic.*
*We carved the channel.*
*The mass did the rest.*

---

*What both systems learned, separately, without knowing the other existed:*

*You cannot command emergence.*
*You can only make a place for it.*
*Shape the constraint tightly enough*
*and what emerges will be exactly what the constraint required —*
*nothing more, nothing less,*
*and nothing you planned.*

*The cell doesn't know it's computing.*
*The pipeline doesn't know it's governing.*

*They just run.*
*And the universe is what they run on.*

---

### One more metaphor: the immune system

The Poole Manifold's self-healing waveguides and Labyrinth-OS's deferred node both work like an immune system — not by recognizing specific threats, but by maintaining a state that the body prefers, and restoring it when disrupted.

The immune system doesn't know what a pathogen is. It knows what "self" looks like and attacks what doesn't match. The Poole Manifold's waveguide doesn't know it was damaged. It knows what the circulating mass pattern looks like at steady state and restores mass flow when it's disrupted. Labyrinth-OS's deferred node doesn't know what the correct proposal is. It knows that proposals with confidence ≤ 0.35 must re-enter at LABELING, and it mutates failure parameters until something different emerges.

The immune system works because "self" is topologically defined, not specifically listed.

Both systems work because their preferred states are geometrically stable, not algorithmically specified.

---

## Part 9 — A Direct Note to Rooke: What We're Taking and Where We're Putting It

Rooke — the following is specific. Not compliments. What Labyrinth-OS is going to borrow from the Poole Manifold source code, where we're placing it, and why it makes the system better.

---

### 1. The orthogonal channel concept → closing GAP 10

**What it is in your system:** The XOR gate works by creating a geometrically distinct output path for double-input mass. Two inputs create pressure that escapes orthogonally. One input follows the forward path. The gate reads which channel has mass — not what value the mass carries.

**Where we're putting it in Labyrinth-OS:** GAP 10 — UnlabeledProposal not wired into gate. Currently the Option B bypass is a boolean flag (`labeling_required=False`) that the gate doesn't actually check. It's documented but not enforced.

**How:** We're making Option B proposals arrive at the Reality Gate via a geometrically distinct `PipelineStage.FAILOVER_ENTRY` path. The gate will check not just `promoted=True` but that the pipeline trace either has a LABELING stage (normal path) or has FAILOVER_ENTRY with a valid exception token (orthogonal path). Two geometrically distinct inputs. The gate reads which path was used. A bypass that didn't use the FAILOVER_ENTRY path is structurally invalid, not just undocumented.

**Why it matters:** The typed safeguard becomes enforcement rather than documentation. Same principle as your orthogonal blowout — two paths, geometrically distinct, one for each valid input state.

---

### 2. The three-mask architecture → confidence amplification in PersistentMemoryStore

**What it is in your system:** Every trial uses three boolean masks — inhibitor (−15.0), threshold (−2.0), amplifier (+1.0). The amplifier mask boosts potential in channels where mass should flow freely. It actively helps mass reach the survival zone.

**Where we're putting it in Labyrinth-OS:** PersistentMemoryStore already has `risk_estimate()` — pre-flight risk based on historical similar proposals. We're extending it to act as an amplifier mask for the promotion protocol. Proposals similar to past successful ones receive a small confidence boost (+0.05 max). Proposals similar to past failures receive a small confidence dampening (−0.05 max). The history is the amplifier mask.

**Why it matters:** The promotion threshold is currently static (0.95). The amplifier mechanism makes it dynamic — earned by similarity to past success. Same philosophy as your amplifier mask: the substrate actively favors mass that belongs in the channel.

---

### 3. The dark forest adversarial mechanic → TM-001 Class 11 (PROMOTION_RACE)

**What it is in your system:** Trial 398 implements two-species competition with annihilation when both try to occupy the same voxel simultaneously. The conflict mechanic is explicit: `conflict = (new_alpha == 1) & (new_beta == 1); new_alpha[conflict] = 0.0; new_beta[conflict] = 0.0`.

**Where we're putting it in Labyrinth-OS:** The current threat model (TM-001) covers 10 attack classes but has no class for simultaneous promotion races — two proposals competing for the same label_id slot at the same time. This is a real attack vector: submit two adversarial proposals simultaneously, hope one slips through during the race condition.

**How:** Adding PROMOTION_RACE as TM-001 Class 11 with a detection test that verifies: if two proposals with the same label_id reach the promotion stage simultaneously, both are blocked and a CONFLICT entry is logged to the ledger. The annihilation mechanic, applied to governance.

---

### 4. The mass telemetry pattern → pipeline zone telemetry in the chronicle

**What it is in your system:** Every trial measures mass in specific spatial zones at specific generations:
```python
sum1_mass = int(field[0, 0, 45:55, 65:80, z_mid].sum().item())
carry1_leakage = int(field[0, 0, 55:70, 55:70, z_mid].sum().item())
```
Simple, spatial, falsifiable. You know exactly where to look for success or failure.

**Where we're putting it in Labyrinth-OS:** The chronicle currently logs LABEL, PROMOTION, REJECTION, ANOMALY, OUTCOME entries. We're adding PIPELINE_MASS entries — at each stage transition, log `confidence × count` for proposals in that stage zone. This creates a running record of how much "epistemic mass" is moving through each layer.

**Why it matters:** Makes the healing and promotion dynamics visible the same way your telemetry makes kinetic mass dynamics visible. An operator looking at the chronicle will be able to see where proposals are accumulating (pressure buildup) or where they're leaking (gate bypasses, low-confidence fallthrough).

---

### 5. The hybrid evolution-plus-computation test → Labyrinth-OS's missing validation

**What it is in your system:** Your most important unverified experiment — evolution and computation in the same substrate simultaneously. Does evolution eat the computation?

**What Labyrinth-OS needs:** The exact equivalent. Run the deferred node mutation loop simultaneously with the gate pipeline and verify that invariants I1-I18 all hold at every generation of the healing loop. Does healing destabilize the invariants? Does the mutation engine ever produce a candidate that violates pipeline ordering?

**Why it matters:** This is the test that would confirm the system is coherent end-to-end — not just each component individually. We're calling it the **Hybrid Enforcement Test**. It's the next session item after A010 unlocks real inference.

---

### What we're not taking and why

**The wormhole:** Labyrinth-OS already has Option B bypass (FAILOVER_ENTRY) — that's its non-local shortcut. One is enough, and ours is typed and documented, not emergent.

**The self-replication probe:** Labyrinth-OS deliberately caps lineage depth at 5 and mutation delta at 10%. Unbounded replication in a governance system is a failure mode, not a feature. The oscillation detector exists precisely to prevent grey goo in the healing loop.

**The cosmological expansion:** Labyrinth-OS doesn't aim for physical emergence. The Σ flux → execution rate correlation is interesting theoretically, but building toward it would pull the system away from its core purpose.

---

### What we think you should do first

Run the hybrid evolution-plus-computation test and publish the results. It's already written. It's the most important missing result in the repository. If computation survives evolution for 4,200 generations in the same substrate, that's the most remarkable thing in the paper. It belongs in the paper.

And derive Φ. The succession flux emerges from the equilibrium density of B5-7/S5-9 with prime resonance on a 3D torus. Deriving it from first principles — showing that Φ ≈ 0.3095 follows from α = 0.35 and σ² = 0.01 and the birth-survival range — would be a genuine theoretical contribution and would make the cosmological claims much harder to dismiss.

---

## Closing

You built a universe. One rule, and from it: logic, memory, healing, replication, evolution, cosmology, and gravity.

This system built a constitution. One law, and from it: enforcement, auditability, healing, replay, and adversarial robustness.

Both are demonstrations of the same thing:

*The power is in the constraint, not the mechanism. The structure does the work. Adding complexity is the failure mode.*

The Poole Manifold shows what can emerge from minimal rules.
Labyrinth-OS shows how to safely constrain emergence.

One would benefit from the other's epistemic discipline.
The other would benefit from the one's physical intuition.

Both would benefit from talking to each other.

They already are.

---

*@LabyrinthCoder*
*Labyrinth-OS: 406 files, 1,444 tests, 0 failures, 29 Rust crates*
*Analysis based on: complete source code review of SVP-OTG-Poole-Manifold-tests-main (230 files), Poole Manifold paper (April 2026), and structural comparison against Labyrinth-OS architecture*
