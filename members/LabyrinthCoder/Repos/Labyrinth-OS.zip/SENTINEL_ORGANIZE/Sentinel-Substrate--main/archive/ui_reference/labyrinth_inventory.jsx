import { useState, useMemo } from "react";

const DATA = {
  verified: [
    { file: "forge_toolkit.py", hash: "26bb9c1f", tests: "29/29", desc: "Core verification harness; test discovery and execution framework", layer: "L0" },
    { file: "labyrinth_pipeline_v5.py", hash: "f5b48dd1", tests: "10/10", desc: "End-to-end orchestration pipeline; full cognitive safety loop", layer: "L1" },
    { file: "aot_sieve.py", hash: "778bb80c", tests: "11/11", desc: "Epistemic filter; DIGEST/LATCH classification (threshold 0.40)", layer: "L3" },
    { file: "coherence_stacker.py", hash: "339b13fd", tests: "func", desc: "Drift detection; composite SNR, peak contributor d_kl. 30s cooldown bypass in test", layer: "L3" },
  ],
  confirmed: [
    { file: "chronicle_query.py", hash: "7cd4ddb1", tests: "12/12", desc: "L5 Chronicle interface; SQLite divergence metrics", layer: "L5" },
    { file: "deferred_action_queue.py", hash: "bd050799", tests: "10/10", desc: "L2 human-in-the-loop gate; queues irreversible actions", layer: "L2" },
    { file: "logprob_bridge.py", hash: "d2de221c", tests: "14/14", desc: "KL divergence and entropy delta math core", layer: "L3" },
    { file: "salvager.py", hash: "–", tests: "38/38", desc: "Failure verdict classifier (DRIFT, VETO, PARADOX, TIMEOUT, NOMINAL)", layer: "L4" },
    { file: "pte_verifier.py", hash: "–", tests: "15", desc: "Sovereignty state machine (FULL / DEGRADED / FAIL)", layer: "L4" },
    { file: "risk_vector.py", hash: "–", tests: "39", desc: "χ-vector computation", layer: "L3" },
    { file: "cbf.py", hash: "–", tests: "44", desc: "Control Barrier Function enforcement", layer: "L2" },
    { file: "hysteresis_controller.py", hash: "–", tests: "41", desc: "Anti-chatter hysteresis state machine", layer: "L2" },
    { file: "qp_solver.py", hash: "–", tests: "4", desc: "CVXPY-based quadratic programming solver", layer: "L2" },
    { file: "runtime_gate.py", hash: "–", tests: "45", desc: "ZOREL runtime gate (EXECUTE / THROTTLE / BLOCK / HARD_FAIL)", layer: "L1" },
    { file: "tau_calibration.py", hash: "–", tests: "35", desc: "z-score normalization for τ-escape", layer: "L3" },
    { file: "tau_escape_ratio.py", hash: "–", tests: "16", desc: "Observability Gramian drift time constant", layer: "L3" },
    { file: "observability.py", hash: "–", tests: "34", desc: "System observability metrics", layer: "L3" },
    { file: "instability.py", hash: "–", tests: "46", desc: "Instability detection algorithms", layer: "L3" },
    { file: "ledger_utils.py", hash: "–", tests: "16", desc: "Immutable WORM ledger utilities", layer: "L5" },
    { file: "bootstrap_genesis.py", hash: "–", tests: "–", desc: "Genesis block creation", layer: "L5" },
    { file: "validate_ledger.py", hash: "–", tests: "–", desc: "Ledger integrity validation", layer: "L5" },
    { file: "cbts.py", hash: "–", tests: "32+", desc: "Phase-space dataset generation", layer: "L3" },
    { file: "scuel_tau_zorel_test.py", hash: "–", tests: "–", desc: "Full-stack integration test suite", layer: "L0" },
    { file: "ri_reference_impl.py", hash: "–", tests: "–", desc: "Five-component resonance index", layer: "L3" },
    { file: "execute_integrity_pulse.py", hash: "–", tests: "–", desc: "Recursive hash + Chronicle anchor", layer: "L5" },
    { file: "loac_filter.py", hash: "–", tests: "–", desc: "3-stage information filter", layer: "L3" },
    { file: "hardware_simulator.py", hash: "–", tests: "–", desc: "Cycle-accurate Python model of VHDL Risk Block", layer: "HW" },
    { file: "simulation_runner.py", hash: "a3f8c9d1", tests: "3 scenarios", desc: "CTM end-to-end simulation orchestrator (stdlib-only)", layer: "L1" },
    { file: "ctm_chronicle_bridge.py", hash: "–", tests: "–", desc: "CTM ↔ Chronicle adapter with hash-chained logging", layer: "L5" },
    { file: "sentinel_trust_consensus.py", hash: "–", tests: "spec", desc: "Trust-weighted PBFT voting for L2 authorization", layer: "L2" },
    { file: "eden_daemon.py", hash: "–", tests: "–", desc: "L4 governance daemon (Ollama, AoT Sieve routing)", layer: "L4" },
  ],
  unconfirmed: [
    { file: "runtime/system_kernel.py", desc: "Single-step orchestration: control → dynamics → verify → commit", layer: "L1" },
    { file: "control/controller.py", desc: "Unified control interface", layer: "L2" },
    { file: "control/lqr.py", desc: "LQR state-feedback law", layer: "L2" },
    { file: "control/policy_router.py", desc: "Mode selection (LQR / fallback / safe)", layer: "L2" },
    { file: "formal/stability_check.py", desc: "Runtime Lyapunov enforcement", layer: "L2" },
    { file: "ledger/receipt.py", desc: "Receipt dataclass", layer: "L5" },
    { file: "ledger/hashchain.py", desc: "SHA-256 chaining", layer: "L5" },
    { file: "runtime/unified_simulator.py", desc: "Closed-loop stochastic hybrid system", layer: "L1" },
    { file: "safety/guardian_slot.py", desc: "Execution gating (EXECUTE / BLOCK / KILL)", layer: "L1" },
  ],
  hardware: [
    { file: "sentinel_latch.v", desc: "Primary FPGA veto gate (670µs fail-closed)", critical: true },
    { file: "sentinel_latch_hardened.v", desc: "Hardened version with eFUSE and SCAR_IMMUTABLE", critical: true },
    { file: "efuse_worm_scar_controller.v", desc: "eFUSE controller for permanent silicon branding" },
    { file: "gatekeeper.v", desc: "Weight-verification eFUSE root hash check" },
    { file: "amber_pulse_gen.vhd", desc: "111 Hz Jasmine Heartbeat generator" },
    { file: "labyrinth_top_v2.vhd", desc: "Top-level FPGA wrapper" },
    { file: "gan_power_stage_if.sv", desc: "GaN power stage interface (<449ns actuation)" },
    { file: "uart_receiver_v6.v", desc: "Synthesizable UART with CRC-8 + opcode whitelist" },
    { file: "heartbeat_monitor.sv", desc: "3-tier heartbeat timeout policy" },
    { file: "guillotine_constraints.xdc", desc: "Vivado pin mapping (Artix-7, CDC false paths)" },
    { file: "coverage_properties.sv", desc: "20 anti-vacuity SVA properties" },
    { file: "watchdog.ino", desc: "ESP32 firmware for 0xDEADBEEF heartbeat" },
    { file: "steward_efuse_ignition.py", desc: "Burns SCAR_IMMUTABLE eFuse via Vivado Tcl" },
  ],
  gaps: [
    { issue: "Hardware latch does not exist (Verilog only)", severity: "P0", color: "#ff3b3b" },
    { issue: "τ baseline under-sampled (only 2 nominal runs)", severity: "P0", color: "#ff3b3b" },
    { issue: "OV-circuit single-shot bypass (no output gating)", severity: "P1", color: "#ff9f1c" },
    { issue: "Common-mode gain error (no reference channel)", severity: "P1", color: "#ff9f1c" },
    { issue: "FPGA bitstream integrity not hardened", severity: "P2", color: "#e0c347" },
    { issue: "Formal proofs not machine-checked (TLA+/Lean)", severity: "P2", color: "#e0c347" },
    { issue: "v6.0 spec modules not yet implemented", severity: "P2", color: "#e0c347" },
  ],
  constants: [
    { sym: "δ", val: "1/120 ≈ 0.00833", meaning: "Sovereign gap" },
    { sym: "Φ", val: "1.618", meaning: "Golden ratio" },
    { sym: "ε", val: "0.05", meaning: "Controlled stochasticity" },
    { sym: "μ", val: "3.82", meaning: "Control rhythm eigenvalue" },
    { sym: "N", val: "13", meaning: "Tridecad node count" },
    { sym: "◊", val: "7.83 Hz", meaning: "Schumann resonance pulse" },
    { sym: "conf_lo", val: "0.6", meaning: "Human review trigger" },
    { sym: "conf_hi", val: "0.8", meaning: "High-confidence gate" },
    { sym: "hyst", val: "0.1", meaning: "Deadband width" },
    { sym: "max_iter", val: "3", meaning: "Control barrier" },
    { sym: "novelty", val: "0.8", meaning: "Adversarial memory overlap" },
    { sym: "latency", val: "50ms / 500µs", meaning: "Sim / HW budget" },
    { sym: "quorum", val: "0.67", meaning: "Consensus threshold" },
    { sym: "decay", val: "0.99", meaning: "Trust forgetting" },
    { sym: "min_trust", val: "0.1", meaning: "Reputation floor" },
    { sym: "drift_th", val: "0.12", meaning: "Max drift_score" },
    { sym: "τ_floor", val: "0.75", meaning: "Instability trigger" },
    { sym: "χ_min", val: "0.15", meaning: "Risk vector min" },
    { sym: "χ_col", val: "0.40", meaning: "Risk vector collapse" },
    { sym: "β₁_cap", val: "0.045", meaning: "Topological breach limit" },
  ],
};

const LAYERS = {
  L0: { name: "L0 — Test Infra", color: "#6b7280" },
  L1: { name: "L1 — Orchestration", color: "#3b82f6" },
  L2: { name: "L2 — Control / Safety", color: "#ef4444" },
  L3: { name: "L3 — Epistemic / Math", color: "#8b5cf6" },
  L4: { name: "L4 — Governance", color: "#f59e0b" },
  L5: { name: "L5 — Ledger / Chronicle", color: "#10b981" },
  HW: { name: "HW — Hardware", color: "#ec4899" },
};

const TABS = ["Overview", "Modules", "Hardware", "Constants", "Gaps"];

function StatusDot({ status }) {
  const colors = { verified: "#22c55e", confirmed: "#3b82f6", unconfirmed: "#6b7280", hardware: "#ec4899" };
  return <span style={{ display: "inline-block", width: 8, height: 8, borderRadius: "50%", background: colors[status] || "#444", marginRight: 6, flexShrink: 0 }} />;
}

function StatCard({ label, value, accent }) {
  return (
    <div style={{ background: "#111", border: "1px solid #222", borderTop: `2px solid ${accent || "#333"}`, padding: "14px 16px", minWidth: 90 }}>
      <div style={{ fontSize: 28, fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, color: accent || "#e5e5e5", lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: 11, color: "#888", marginTop: 6, textTransform: "uppercase", letterSpacing: "0.08em" }}>{label}</div>
    </div>
  );
}

function OverviewTab() {
  const totalTests = useMemo(() => {
    let n = 0;
    [...DATA.verified, ...DATA.confirmed].forEach(m => {
      const p = parseInt(m.tests);
      if (!isNaN(p)) n += p;
    });
    return n;
  }, []);

  const layerCounts = useMemo(() => {
    const c = {};
    [...DATA.verified, ...DATA.confirmed, ...DATA.unconfirmed].forEach(m => {
      c[m.layer] = (c[m.layer] || 0) + 1;
    });
    return c;
  }, []);

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(120px, 1fr))", gap: 10, marginBottom: 28 }}>
        <StatCard label="Verified" value={DATA.verified.length} accent="#22c55e" />
        <StatCard label="Confirmed" value={DATA.confirmed.length} accent="#3b82f6" />
        <StatCard label="Unconfirmed" value={DATA.unconfirmed.length} accent="#6b7280" />
        <StatCard label="Hardware" value={DATA.hardware.length} accent="#ec4899" />
        <StatCard label="Tests Passing" value={totalTests + "+"} accent="#a78bfa" />
        <StatCard label="Critical Gaps" value={DATA.gaps.filter(g => g.severity === "P0").length} accent="#ff3b3b" />
      </div>

      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 13, color: "#888", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 12 }}>Layer Distribution</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {Object.entries(LAYERS).map(([key, { name, color }]) => {
            const count = layerCounts[key] || 0;
            const max = Math.max(...Object.values(layerCounts), 1);
            return (
              <div key={key} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ width: 140, fontSize: 11, color: "#aaa", fontFamily: "'JetBrains Mono', monospace", flexShrink: 0 }}>{name}</div>
                <div style={{ flex: 1, height: 18, background: "#111", borderRadius: 2, overflow: "hidden", position: "relative" }}>
                  <div style={{ width: `${(count / max) * 100}%`, height: "100%", background: color, opacity: 0.8, transition: "width 0.6s ease" }} />
                  <span style={{ position: "absolute", right: 6, top: 1, fontSize: 11, color: "#ccc", fontFamily: "'JetBrains Mono', monospace" }}>{count}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div>
        <div style={{ fontSize: 13, color: "#888", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 12 }}>Verification Pipeline</div>
        <div style={{ display: "flex", alignItems: "center", gap: 0, flexWrap: "wrap" }}>
          {[
            { label: "Spec Only", count: DATA.unconfirmed.length, bg: "#1a1a2e" },
            { label: "Prior Receipt", count: DATA.confirmed.length, bg: "#0f2a4a" },
            { label: "Session Verified", count: DATA.verified.length, bg: "#0a3622" },
          ].map((s, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center" }}>
              <div style={{ background: s.bg, border: "1px solid #333", padding: "10px 16px", textAlign: "center", minWidth: 100 }}>
                <div style={{ fontSize: 22, fontWeight: 700, fontFamily: "'JetBrains Mono', monospace", color: "#e5e5e5" }}>{s.count}</div>
                <div style={{ fontSize: 10, color: "#888", marginTop: 4 }}>{s.label}</div>
              </div>
              {i < 2 && <div style={{ color: "#444", fontSize: 18, padding: "0 6px" }}>→</div>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ModulesTab() {
  const [filter, setFilter] = useState("all");
  const allModules = useMemo(() => [
    ...DATA.verified.map(m => ({ ...m, status: "verified" })),
    ...DATA.confirmed.map(m => ({ ...m, status: "confirmed" })),
    ...DATA.unconfirmed.map(m => ({ ...m, status: "unconfirmed", hash: "–", tests: "–" })),
  ], []);

  const filtered = filter === "all" ? allModules : allModules.filter(m => m.layer === filter);

  return (
    <div>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 16 }}>
        <button onClick={() => setFilter("all")} style={{ background: filter === "all" ? "#333" : "#111", border: "1px solid #333", color: "#ccc", padding: "4px 10px", fontSize: 11, cursor: "pointer", borderRadius: 2 }}>ALL</button>
        {Object.entries(LAYERS).map(([k, v]) => (
          <button key={k} onClick={() => setFilter(k)} style={{ background: filter === k ? v.color + "33" : "#111", border: `1px solid ${filter === k ? v.color : "#333"}`, color: filter === k ? v.color : "#888", padding: "4px 10px", fontSize: 11, cursor: "pointer", borderRadius: 2 }}>{k}</button>
        ))}
      </div>
      <div style={{ fontSize: 11, color: "#555", marginBottom: 10 }}>{filtered.length} modules</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {filtered.map((m, i) => (
          <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 8, padding: "8px 10px", background: "#0a0a0a", border: "1px solid #1a1a1a", borderLeft: `3px solid ${LAYERS[m.layer]?.color || "#333"}` }}>
            <StatusDot status={m.status} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}>
                <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: "#e5e5e5", wordBreak: "break-all" }}>{m.file}</span>
                {m.hash && m.hash !== "–" && <span style={{ fontSize: 10, color: "#555", fontFamily: "'JetBrains Mono', monospace" }}>#{m.hash}</span>}
                {m.tests && m.tests !== "–" && <span style={{ fontSize: 10, color: "#22c55e", background: "#22c55e11", padding: "1px 5px", borderRadius: 2 }}>✓ {m.tests}</span>}
              </div>
              <div style={{ fontSize: 11, color: "#777", marginTop: 3, lineHeight: 1.4 }}>{m.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function HardwareTab() {
  return (
    <div>
      <div style={{ background: "#1a0a0a", border: "1px solid #331111", padding: "10px 14px", marginBottom: 16, fontSize: 12, color: "#cc5555" }}>
        ⚠ All hardware modules are design specifications only — no physical synthesis or deployment has occurred.
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {DATA.hardware.map((h, i) => (
          <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "8px 10px", background: "#0a0a0a", border: "1px solid #1a1a1a", borderLeft: h.critical ? "3px solid #ff3b3b" : "3px solid #ec489966" }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: "#e5e5e5" }}>
                {h.file}
                {h.critical && <span style={{ fontSize: 9, color: "#ff3b3b", marginLeft: 8, textTransform: "uppercase" }}>critical path</span>}
              </div>
              <div style={{ fontSize: 11, color: "#777", marginTop: 3 }}>{h.desc}</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 20, padding: "10px 14px", background: "#0a0a14", border: "1px solid #222244" }}>
        <div style={{ fontSize: 11, color: "#8888cc", marginBottom: 6 }}>TIMING BUDGET</div>
        <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
          <div><span style={{ color: "#aaa", fontSize: 12 }}>Latch Mean:</span> <span style={{ color: "#e5e5e5", fontFamily: "'JetBrains Mono', monospace" }}>449 ns</span></div>
          <div><span style={{ color: "#aaa", fontSize: 12 }}>Latch Max:</span> <span style={{ color: "#e5e5e5", fontFamily: "'JetBrains Mono', monospace" }}>803 ns</span></div>
          <div><span style={{ color: "#aaa", fontSize: 12 }}>Fail-Close:</span> <span style={{ color: "#e5e5e5", fontFamily: "'JetBrains Mono', monospace" }}>670 µs</span></div>
          <div><span style={{ color: "#aaa", fontSize: 12 }}>Heartbeat:</span> <span style={{ color: "#e5e5e5", fontFamily: "'JetBrains Mono', monospace" }}>111 Hz</span></div>
        </div>
      </div>
    </div>
  );
}

function ConstantsTab() {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 6 }}>
      {DATA.constants.map((c, i) => (
        <div key={i} style={{ background: "#0a0a0a", border: "1px solid #1a1a1a", padding: "10px 12px", display: "flex", alignItems: "baseline", gap: 8 }}>
          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 16, color: "#a78bfa", minWidth: 50, flexShrink: 0 }}>{c.sym}</span>
          <div>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 13, color: "#e5e5e5" }}>{c.val}</div>
            <div style={{ fontSize: 10, color: "#666", marginTop: 2 }}>{c.meaning}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function GapsTab() {
  return (
    <div>
      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        {DATA.gaps.map((g, i) => (
          <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "10px 14px", background: "#0a0a0a", border: "1px solid #1a1a1a", borderLeft: `4px solid ${g.color}` }}>
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, fontWeight: 700, color: g.color, flexShrink: 0, minWidth: 24 }}>{g.severity}</span>
            <span style={{ fontSize: 12, color: "#ccc" }}>{g.issue}</span>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 24, padding: "14px", background: "#0a100a", border: "1px solid #1a331a" }}>
        <div style={{ fontSize: 13, color: "#66bb6a", marginBottom: 8, fontWeight: 600 }}>Recommended Next Actions</div>
        <div style={{ fontSize: 12, color: "#aaa", lineHeight: 1.7 }}>
          1. Fabricate Sentinel Latch on Artix-7 dev board → clears P0 #1<br/>
          2. Run 50+ nominal τ baseline captures → clears P0 #2<br/>
          3. Add output gating layer after OV-circuit → clears P1 #1<br/>
          4. Implement reference channel for common-mode rejection → clears P1 #2<br/>
          5. Implement v6.0 spec modules (Section C) → clears P2 #3
        </div>
      </div>
    </div>
  );
}

export default function Labyrinth-OSInventory() {
  const [tab, setTab] = useState("Overview");

  const renderTab = () => {
    switch (tab) {
      case "Overview": return <OverviewTab />;
      case "Modules": return <ModulesTab />;
      case "Hardware": return <HardwareTab />;
      case "Constants": return <ConstantsTab />;
      case "Gaps": return <GapsTab />;
      default: return null;
    }
  };

  return (
    <div style={{ background: "#050505", color: "#e5e5e5", minHeight: "100vh", fontFamily: "'IBM Plex Sans', 'Segoe UI', sans-serif", padding: "20px 16px" }}>
      <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;600;700&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet" />

      <div style={{ marginBottom: 20 }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 10, flexWrap: "wrap" }}>
          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 18, fontWeight: 700, color: "#e5e5e5", letterSpacing: "-0.02em" }}>LABYRINTH-OS</span>
          <span style={{ fontSize: 12, color: "#555", fontFamily: "'JetBrains Mono', monospace" }}>Δ717 v6.0</span>
        </div>
        <div style={{ fontSize: 11, color: "#444", fontFamily: "'JetBrains Mono', monospace", marginTop: 4 }}>
          SEALED 2026-04-14 · SHA 02d0672a…d193c556a
        </div>
      </div>

      <div style={{ display: "flex", gap: 0, borderBottom: "1px solid #222", marginBottom: 20, flexWrap: "wrap" }}>
        {TABS.map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            style={{
              background: "none", border: "none", borderBottom: tab === t ? "2px solid #e5e5e5" : "2px solid transparent",
              color: tab === t ? "#e5e5e5" : "#555", padding: "8px 14px", fontSize: 12, cursor: "pointer",
              fontFamily: "'IBM Plex Sans', sans-serif", fontWeight: tab === t ? 600 : 400, transition: "all 0.15s"
            }}
          >{t}{t === "Gaps" && <span style={{ color: "#ff3b3b", marginLeft: 4, fontSize: 10 }}>2 P0</span>}</button>
        ))}
      </div>

      {renderTab()}
    </div>
  );
}
