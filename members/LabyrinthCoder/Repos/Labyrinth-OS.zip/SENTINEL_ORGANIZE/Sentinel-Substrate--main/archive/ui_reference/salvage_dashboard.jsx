import { useState, useMemo } from "react";

// ═══════════════════════════════════════════════════════════════
// LABYRINTH-OS DASHBOARD
// All data extracted from actual project files on disk
// ═══════════════════════════════════════════════════════════════

const CLUSTERS = {
  EDEN_RUNTIME: {
    label: "EDEN Runtime Stack",
    desc: "The daemon, TUI, IPC, and inference wire. This is the executable core.",
    color: "#22d3ee",
    priority: 1,
  },
  GOVERNANCE: {
    label: "Governance Engine",
    desc: "Signing, auditing, governed execution loops, compliance.",
    color: "#a78bfa",
    priority: 2,
  },
  ADVERSARIAL: {
    label: "Adversarial Substrate",
    desc: "Red Queen L-1 layer + ignition harness. Continuous pressure.",
    color: "#f87171",
    priority: 3,
  },
  SIEVE_EVAL: {
    label: "Epistemic Sieve & Evaluation",
    desc: "AoT decomposition, coherence stacking, ROC harness, ARC-AGI pipeline.",
    color: "#fbbf24",
    priority: 4,
  },
  LEX9: {
    label: "Lex-9 Legal RAG Stack",
    desc: "Complete legal reasoning engine — orchestrator, agents, citation, hallucination detection.",
    color: "#34d399",
    priority: 5,
  },
  TELEMETRY: {
    label: "Telemetry & Logging",
    desc: "Delta717 bus, Vigil processor, Veritas logger, chronicle WAL.",
    color: "#f472b6",
    priority: 6,
  },
  TOOLKIT: {
    label: "Forge Toolkit & Utilities",
    desc: "Consolidated tools: Veritas Sieve, Decision Ledger, Calibration, Skyward mapper.",
    color: "#818cf8",
    priority: 7,
  },
  DOCS: {
    label: "Documentation (Forge-valid)",
    desc: "READMEs, architecture docs, crosswalks, handoff packages with engineering content.",
    color: "#94a3b8",
    priority: 8,
  },
  LOOM: {
    label: "Loom (Quarantined)",
    desc: "Ceremonial, symbolic, or unfalsifiable content. No engineering weight.",
    color: "#475569",
    priority: 9,
  },
};

const ARTIFACTS = [
  // ─── EDEN RUNTIME ────────────────────────────────
  { id: "eden_daemon", name: "eden_daemon.py", size: "6.0K", lines: "~180", cluster: "EDEN_RUNTIME", deps: ["eden_ipc"], stdlib: true, status: "STUB", note: "This is the OLD version (6K). The v2.2.1 (842 lines) with Ollama routing described in handoff is NOT in the project files. Critical gap.", critical: true },
  { id: "eden_chat_wire", name: "eden_chat_wire.py", size: "23K", lines: "555", cluster: "EDEN_RUNTIME", deps: ["aot_sieve", "chronicle"], stdlib: true, status: "READY", note: "DROP-IN replacement for handle_chat(). Talks to Ollama at localhost:11434. GovernedChat wraps inference with AoT Sieve + Chronicle. This is the missing wire.", critical: true },
  { id: "eden_tui", name: "eden_tui.py", size: "12K", lines: "~350", cluster: "EDEN_RUNTIME", deps: ["eden_ipc"], stdlib: true, status: "FUNCTIONAL", note: "Terminal UI with FileDropbox, command system, agent status. Works standalone." },
  { id: "eden_ipc", name: "eden_ipc.py", size: "1.0K", lines: "~40", cluster: "EDEN_RUNTIME", deps: [], stdlib: true, status: "FUNCTIONAL", note: "JSON-RPC 2.0 IPC bridge. Clean, minimal, done." },
  { id: "eden_append", name: "eden_append.py", size: "10K", lines: "~300", cluster: "EDEN_RUNTIME", deps: [], stdlib: true, status: "FUNCTIONAL", note: "WORM append utility with chain verification." },

  // ─── ADVERSARIAL ─────────────────────────────────
  { id: "red_queen", name: "red_queen.py", size: "30K", lines: "829", cluster: "ADVERSARIAL", deps: [], stdlib: true, status: "FUNCTIONAL", note: "L-1 adversarial substrate. 5-member committee, heuristic rotation, honeypot switch. Self-contained, stdlib only.", critical: true },
  { id: "red_queen_bridge", name: "red_queen_bridge.py", size: "14K", lines: "~400", cluster: "ADVERSARIAL", deps: ["red_queen"], stdlib: true, status: "FUNCTIONAL", note: "Chronicle bridge for Red Queen. Connects adversarial output to WORM ledger." },
  { id: "ignition", name: "ignition.py", size: "26K", lines: "~750", cluster: "ADVERSARIAL", deps: ["red_queen", "red_queen_bridge"], stdlib: true, status: "NEVER_RUN", note: "THE critical path script. Auto-detects Ollama, runs inference trials, produces telemetry JSON. Has NEVER been executed.", critical: true },

  // ─── GOVERNANCE ──────────────────────────────────
  { id: "integrity", name: "integrity.py", size: "12K", lines: "320", cluster: "GOVERNANCE", deps: [], stdlib: true, status: "FUNCTIONAL", note: "HMAC-SHA256 canonical record signing. JCS-inspired. Deterministic." },
  { id: "governed_agent_loop", name: "governed_agent_loop.py", size: "19K", lines: "530", cluster: "GOVERNANCE", deps: ["integrity"], stdlib: true, status: "FUNCTIONAL", note: "OBSERVE→AUTHORIZE→ALLOCATE→COMMIT wrapper. All actions pass through this." },
  { id: "compliance_bridge", name: "compliance_bridge.py", size: "14K", lines: "~400", cluster: "GOVERNANCE", deps: [], stdlib: true, status: "FUNCTIONAL", note: "Compliance enforcement bridge." },
  { id: "validator", name: "validator.py", size: "19K", lines: "~550", cluster: "GOVERNANCE", deps: [], stdlib: true, status: "FUNCTIONAL", note: "Multi-layer validation system." },
  { id: "sequence_registry", name: "sequence_registry.py", size: "13K", lines: "~380", cluster: "GOVERNANCE", deps: [], stdlib: true, status: "FUNCTIONAL", note: "Sequence tracking and ordering guarantees." },
  { id: "cert_runner", name: "cert_runner.py", size: "15K", lines: "~420", cluster: "GOVERNANCE", deps: [], stdlib: true, status: "FUNCTIONAL", note: "Certification runner — executes test suites and produces receipts." },

  // ─── SIEVE & EVAL ────────────────────────────────
  { id: "aot_sieve", name: "aot_sieve.py", size: "16K", lines: "432", cluster: "SIEVE_EVAL", deps: [], stdlib: true, status: "FUNCTIONAL", note: "Atom of Thought decomposition. Evaluates each reasoning atom independently. PASS/WARN/FAIL/CRITICAL → NORMAL/DIGEST/LATCH.", critical: true },
  { id: "coherence_stacker", name: "coherence_stacker.py", size: "17K", lines: "~480", cluster: "SIEVE_EVAL", deps: [], stdlib: true, status: "FUNCTIONAL", note: "Coherence accumulation and stacking." },
  { id: "roc_harness", name: "roc_harness.py", size: "13K", lines: "~380", cluster: "SIEVE_EVAL", deps: [], stdlib: true, status: "FUNCTIONAL", note: "ROC curve evaluation harness for detection calibration." },
  { id: "logprob_bridge", name: "logprob_bridge.py", size: "30K", lines: "~850", cluster: "SIEVE_EVAL", deps: [], stdlib: true, status: "NOT_WIRED", note: "Log-probability bridge for real-time entropy metrics. Built but not connected to daemon." },
  { id: "arc_agi2_ignition", name: "arc_agi2_ignition.py", size: "32K", lines: "~900", cluster: "SIEVE_EVAL", deps: [], stdlib: false, status: "UNTESTED", note: "ARC-AGI-2 evaluation ignition. Large file, needs real ARC tasks loaded." },
  { id: "arc_agi_eval", name: "arc_agi_2_eval_pipeline.py", size: "22K", lines: "~620", cluster: "SIEVE_EVAL", deps: [], stdlib: false, status: "UNTESTED", note: "ARC-AGI evaluation pipeline." },
  { id: "fractal_engine", name: "fractal_engine_stabilized.py", size: "18K", lines: "~500", cluster: "SIEVE_EVAL", deps: [], stdlib: false, status: "FUNCTIONAL", note: "Fractal parameter engine — stabilized version." },
  { id: "l3_proof_sim", name: "l3_proof_constraint_sim.py", size: "32K", lines: "~900", cluster: "SIEVE_EVAL", deps: [], stdlib: false, status: "UNTESTED", note: "L3 proof constraint simulator. Large, needs validation." },

  // ─── LEX-9 LEGAL RAG ─────────────────────────────
  { id: "lex9_orchestrator", name: "lex9_orchestrator.py", size: "22K", lines: "521", cluster: "LEX9", deps: ["lex9_agent_prompts"], stdlib: false, status: "FUNCTIONAL", note: "Full pipeline: parallel agents → cross-exam → confidence filter → synthesis → audit log. Requires openai + tenacity." },
  { id: "lex9_prompts", name: "lex9_agent_prompts.py", size: "14K", lines: "~400", cluster: "LEX9", deps: [], stdlib: true, status: "FUNCTIONAL", note: "Agent registry and cross-examination injection templates." },
  { id: "lex9_citation", name: "lex9_citation_extractor.py", size: "19K", lines: "~540", cluster: "LEX9", deps: [], stdlib: false, status: "FUNCTIONAL", note: "Citation extraction and validation." },
  { id: "lex9_evidence", name: "lex9_evidentiary_ladder.py", size: "15K", lines: "~420", cluster: "LEX9", deps: [], stdlib: false, status: "FUNCTIONAL", note: "Evidence tiering and weighting system." },
  { id: "lex9_factcheck", name: "lex9_fact_check_guard.py", size: "18K", lines: "~500", cluster: "LEX9", deps: [], stdlib: false, status: "FUNCTIONAL", note: "Fact-checking guard with confidence thresholds." },
  { id: "lex9_hallugraph", name: "lex9_hallugraph.py", size: "22K", lines: "~620", cluster: "LEX9", deps: [], stdlib: false, status: "FUNCTIONAL", note: "Hallucination detection graph. Maps claim provenance." },
  { id: "lex9_mesh", name: "lex9_l2_mesh.py", size: "21K", lines: "~590", cluster: "LEX9", deps: [], stdlib: false, status: "FUNCTIONAL", note: "L2 mesh network for distributed legal reasoning." },
  { id: "legal_rag", name: "legal_rag_stack.py", size: "18K", lines: "~500", cluster: "LEX9", deps: [], stdlib: false, status: "FUNCTIONAL", note: "RAG retrieval stack for legal documents." },

  // ─── TELEMETRY ───────────────────────────────────
  { id: "delta717_bus", name: "delta717_telemetry_bus.py", size: "33K", lines: "~930", cluster: "TELEMETRY", deps: [], stdlib: true, status: "FUNCTIONAL", note: "Telemetry bus — largest single file. Collects and routes system signals." },
  { id: "vigil", name: "vigil_processor.py", size: "17K", lines: "~480", cluster: "TELEMETRY", deps: [], stdlib: true, status: "FUNCTIONAL", note: "Event processing and anomaly detection." },
  { id: "veritas_logger", name: "veritas_aegis_logger.py", size: "18K", lines: "~500", cluster: "TELEMETRY", deps: [], stdlib: true, status: "FUNCTIONAL", note: "Structured logging with integrity checks." },
  { id: "labyrinth_wal", name: "labyrinth_wal.py", size: "4.5K", lines: "~130", cluster: "TELEMETRY", deps: [], stdlib: true, status: "FUNCTIONAL", note: "Write-ahead log. Small, clean, functional." },

  // ─── TOOLKIT ─────────────────────────────────────
  { id: "forge_toolkit", name: "forge_toolkit.py", size: "24K", lines: "672", cluster: "TOOLKIT", deps: [], stdlib: true, status: "FUNCTIONAL", note: "5 tools consolidated: Veritas Sieve, Decision Ledger, Coherence Accumulator, Skyward Validator, Calibration Harness." },
  { id: "agent_runner", name: "agent_runner.py", size: "19K", lines: "~530", cluster: "TOOLKIT", deps: [], stdlib: false, status: "FUNCTIONAL", note: "Agent execution runner." },
  { id: "ark_consumer", name: "ark_artifact_consumer.py", size: "31K", lines: "~870", cluster: "TOOLKIT", deps: [], stdlib: false, status: "UNTESTED", note: "Ark artifact consumer — ingests and validates artifacts." },
  { id: "watch05_nlu", name: "watch05_nlu.py", size: "27K", lines: "~760", cluster: "TOOLKIT", deps: [], stdlib: false, status: "UNTESTED", note: "NLU processing module." },
  { id: "labyrinth_pipeline", name: "labyrinth_pipeline_v5.py", size: "41K", lines: "~1150", cluster: "TOOLKIT", deps: [], stdlib: false, status: "UNTESTED", note: "Master pipeline v5. Largest Python file (41K). Needs dependency audit." },
  { id: "test_suite", name: "test_labyrinth_os.py", size: "11K", lines: "~320", cluster: "TOOLKIT", deps: ["eden_daemon", "eden_append"], stdlib: true, status: "FUNCTIONAL", note: "Integration test suite. Tests daemon boot, cycle processing, WORM append, chain verify." },

  // ─── DOCS (FORGE-VALID) ──────────────────────────
  { id: "readme", name: "README.md", size: "23K", cluster: "DOCS", deps: [], stdlib: true, status: "REFERENCE", note: "Main README with EDEN stack usage, Termux deployment, command reference." },
  { id: "readme_labyrinth", name: "README_Labyrinth-OS_Project.md", size: "21K", cluster: "DOCS", deps: [], stdlib: true, status: "REFERENCE", note: "Labyrinth-OS project overview." },
  { id: "architecture", name: "ARCHITECTURE.md", size: "8K", cluster: "DOCS", deps: [], stdlib: true, status: "REFERENCE", note: "Architecture documentation." },
  { id: "crosswalk", name: "labyrinth_master_crosswalk.md", size: "19K", cluster: "DOCS", deps: [], stdlib: true, status: "REFERENCE", note: "Master crosswalk mapping all artifacts to layers." },
  { id: "integration_map", name: "integration_map.md", size: "11K", cluster: "DOCS", deps: [], stdlib: true, status: "REFERENCE", note: "Integration map showing module connections." },
  { id: "handoff_v2", name: "labyrinth_handoff_v2_2_1.docx", size: "20K", cluster: "DOCS", deps: [], stdlib: true, status: "REFERENCE", note: "v2.2.1 handoff package — describes the patched eden_daemon that ISN'T in the project files." },
  { id: "inventory", name: "ZOREL_ARTIFACT_INVENTORY.md", size: "14K", cluster: "DOCS", deps: [], stdlib: true, status: "REFERENCE", note: "Artifact inventory." },

  // ─── LOOM (QUARANTINED) ──────────────────────────
  { id: "sovereignty", name: "SOVEREIGNTY_MANIFESTO.md", size: "2K", cluster: "LOOM", deps: [], stdlib: true, status: "LOOM", note: "Ceremonial. No engineering content." },
  { id: "loom_revelations", name: "loom_commentary_revelations_scripted.md", size: "16K", cluster: "LOOM", deps: [], stdlib: true, status: "LOOM", note: "Loom narrative. Quarantined." },
  { id: "theorist", name: "metaphorical_theorist_persona.md", size: "9K", cluster: "LOOM", deps: [], stdlib: true, status: "LOOM", note: "Persona definition. No code." },
  { id: "divine_names", name: "Highest_Names_of_the_Divine.docx", size: "26K", cluster: "LOOM", deps: [], stdlib: true, status: "LOOM", note: "Theological content. No engineering weight." },
  { id: "agi_consciousness", name: "AGI_Consciousness_Assessment.md", size: "5K", cluster: "LOOM", deps: [], stdlib: true, status: "LOOM", note: "Philosophical assessment. Not falsifiable." },
  { id: "ethics", name: "ETHICS.md", size: "8.5K", cluster: "LOOM", deps: [], stdlib: true, status: "LOOM", note: "Ethics framework. Policy, not code." },
  { id: "whitepaper", name: "WHITEPAPER.md", size: "13K", cluster: "LOOM", deps: [], stdlib: true, status: "LOOM", note: "Whitepaper. Narrative framing." },
  { id: "cern_tracker", name: "cern_subconscious_july_tracker.py", size: "N/A", cluster: "LOOM", deps: [], stdlib: true, status: "LOOM", note: "CERN/Google Trends correlation. Referenced in inventory but NOT in project files. No engineering basis." },
];

const STATUS_CONFIG = {
  FUNCTIONAL: { label: "Functional", bg: "#064e3b", border: "#34d399", text: "#6ee7b7" },
  READY: { label: "Ready (Unwired)", bg: "#1e3a5f", border: "#22d3ee", text: "#67e8f9" },
  STUB: { label: "Stub / Old Version", bg: "#7c2d12", border: "#fb923c", text: "#fdba74" },
  NEVER_RUN: { label: "Never Executed", bg: "#7f1d1d", border: "#f87171", text: "#fca5a5" },
  NOT_WIRED: { label: "Built, Not Wired", bg: "#4a1d6e", border: "#a78bfa", text: "#c4b5fd" },
  UNTESTED: { label: "Untested", bg: "#713f12", border: "#fbbf24", text: "#fde68a" },
  REFERENCE: { label: "Documentation", bg: "#1e293b", border: "#64748b", text: "#94a3b8" },
  LOOM: { label: "Loom (Quarantined)", bg: "#1e1e2e", border: "#475569", text: "#64748b" },
};

const CRITICAL_PATH = [
  { step: 1, action: "Install Ollama + pull qwen3:4b", file: null, done: false },
  { step: 2, action: "Wire eden_chat_wire.py into eden_daemon.py", file: "eden_chat_wire", done: false },
  { step: 3, action: "Run: python ignition.py --model qwen3:4b --trials 5", file: "ignition", done: false },
  { step: 4, action: "Verify ignition_telemetry_*.json output exists", file: null, done: false },
  { step: 5, action: "Wire logprob_bridge.py into inference pipeline", file: "logprob_bridge", done: false },
  { step: 6, action: "Run test_labyrinth_os.py against live daemon", file: "test_suite", done: false },
];

const INVENTORY_DISCREPANCIES = [
  { item: "eden_daemon.py v2.2.1 (842 lines)", inventorySays: "Patched with real Ollama routing", reality: "Project has 6K/~180-line OLD version. The v2.2.1 is described in handoff docs but NOT present as a file." },
  { item: "breakout_harness.py", inventorySays: "SHA-256 sealed, 15 PASS / 0 FAIL", reality: "NOT in project files. Referenced in inventory only." },
  { item: "z3_constraint_patch.py", inventorySays: "12/12 fallback-verified", reality: "NOT in project files. Referenced in inventory only." },
  { item: "mythos_logos_v2.py", inventorySays: "8/8 PASS", reality: "NOT in project files." },
  { item: "ghost_geodesic_gate.py", inventorySays: "Sealed", reality: "NOT in project files." },
  { item: "chronicle.py", inventorySays: "45/45 tests", reality: "NOT in project files. eden_chat_wire.py imports it with graceful fallback." },
  { item: "cern_subconscious_july_tracker.py", inventorySays: "Sealed observatory module", reality: "NOT in project files. Also: not engineering." },
  { item: "Repository structure v15.4", inventorySays: "Organized into core/, formal/, viability/ etc.", reality: "Project files are flat — no directory structure at all." },
];

// ═══════════════════════════════════════════════════════════════
// COMPONENTS
// ═══════════════════════════════════════════════════════════════

function StatCard({ label, value, sub, accent }) {
  return (
    <div style={{ background: "#0f172a", borderLeft: `3px solid ${accent}`, padding: "12px 16px", borderRadius: "4px" }}>
      <div style={{ fontSize: "28px", fontWeight: 700, color: accent, fontFamily: "'JetBrains Mono', monospace" }}>{value}</div>
      <div style={{ fontSize: "13px", color: "#e2e8f0", marginTop: "2px" }}>{label}</div>
      {sub && <div style={{ fontSize: "11px", color: "#64748b", marginTop: "4px" }}>{sub}</div>}
    </div>
  );
}

function ArtifactCard({ artifact, expanded, onToggle }) {
  const st = STATUS_CONFIG[artifact.status];
  const cl = CLUSTERS[artifact.cluster];
  return (
    <div
      onClick={onToggle}
      style={{
        background: st.bg,
        border: `1px solid ${artifact.critical ? "#f87171" : st.border}`,
        borderRadius: "6px",
        padding: "10px 14px",
        cursor: "pointer",
        transition: "all 0.15s",
        boxShadow: artifact.critical ? `0 0 8px ${st.border}40` : "none",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "8px", minWidth: 0 }}>
          {artifact.critical && <span style={{ color: "#f87171", fontSize: "14px" }}>!!</span>}
          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "13px", color: st.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
            {artifact.name}
          </span>
        </div>
        <div style={{ display: "flex", gap: "8px", alignItems: "center", flexShrink: 0 }}>
          {artifact.size && <span style={{ fontSize: "11px", color: "#64748b", fontFamily: "'JetBrains Mono', monospace" }}>{artifact.size}</span>}
          <span style={{
            fontSize: "10px", padding: "2px 6px", borderRadius: "3px",
            background: `${st.border}20`, color: st.text, border: `1px solid ${st.border}40`,
          }}>{st.label}</span>
        </div>
      </div>
      {expanded && (
        <div style={{ marginTop: "10px", paddingTop: "10px", borderTop: `1px solid ${st.border}30` }}>
          <div style={{ fontSize: "12px", color: "#cbd5e1", lineHeight: "1.5" }}>{artifact.note}</div>
          {artifact.deps?.length > 0 && (
            <div style={{ marginTop: "6px", fontSize: "11px", color: "#94a3b8" }}>
              Depends on: {artifact.deps.map(d => {
                const dep = ARTIFACTS.find(a => a.id === d);
                return dep ? dep.name : d;
              }).join(", ")}
            </div>
          )}
          {artifact.lines && <div style={{ marginTop: "4px", fontSize: "11px", color: "#64748b" }}>~{artifact.lines} lines | stdlib: {artifact.stdlib ? "yes" : "no"}</div>}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// MAIN DASHBOARD
// ═══════════════════════════════════════════════════════════════

export default function SalvageDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [expandedArtifact, setExpandedArtifact] = useState(null);
  const [clusterFilter, setClusterFilter] = useState("ALL");
  const [showLoom, setShowLoom] = useState(false);

  const stats = useMemo(() => {
    const forge = ARTIFACTS.filter(a => a.cluster !== "LOOM" && a.cluster !== "DOCS");
    const loom = ARTIFACTS.filter(a => a.cluster === "LOOM");
    const docs = ARTIFACTS.filter(a => a.cluster === "DOCS");
    const functional = forge.filter(a => a.status === "FUNCTIONAL");
    const critical = forge.filter(a => a.critical);
    const stdlib = forge.filter(a => a.stdlib);
    const totalSizeK = forge.reduce((sum, a) => {
      if (!a.size) return sum;
      const match = a.size.match(/([\d.]+)K/);
      return sum + (match ? parseFloat(match[1]) : 0);
    }, 0);
    return { forge, loom, docs, functional, critical, stdlib, totalSizeK };
  }, []);

  const filteredArtifacts = useMemo(() => {
    let items = ARTIFACTS;
    if (!showLoom) items = items.filter(a => a.cluster !== "LOOM");
    if (clusterFilter !== "ALL") items = items.filter(a => a.cluster === clusterFilter);
    return items;
  }, [clusterFilter, showLoom]);

  const tabs = [
    { id: "overview", label: "Overview" },
    { id: "artifacts", label: "Artifacts" },
    { id: "critical", label: "Critical Path" },
    { id: "discrepancies", label: "Discrepancies" },
  ];

  return (
    <div style={{
      fontFamily: "'IBM Plex Sans', 'Segoe UI', sans-serif",
      background: "#020617",
      color: "#e2e8f0",
      minHeight: "100vh",
      padding: "16px",
    }}>
      <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet" />

      {/* Header */}
      <div style={{ marginBottom: "20px" }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: "12px" }}>
          <h1 style={{ margin: 0, fontSize: "22px", fontWeight: 700, color: "#22d3ee", fontFamily: "'JetBrains Mono', monospace" }}>
            SALVAGE MASTER
          </h1>
          <span style={{ fontSize: "12px", color: "#64748b" }}>Labyrinth-OS / ZOREL-717 — Project Salvage Inventory</span>
        </div>
        <div style={{ fontSize: "12px", color: "#475569", marginTop: "4px" }}>
          {stats.forge.length} code artifacts | {stats.docs.length} docs | {stats.loom.length} loom (quarantined) | ~{Math.round(stats.totalSizeK)}K total code
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: "4px", marginBottom: "16px", borderBottom: "1px solid #1e293b", paddingBottom: "8px" }}>
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            style={{
              background: activeTab === t.id ? "#1e293b" : "transparent",
              color: activeTab === t.id ? "#22d3ee" : "#64748b",
              border: "none",
              padding: "6px 14px",
              borderRadius: "4px",
              fontSize: "13px",
              fontWeight: activeTab === t.id ? 600 : 400,
              cursor: "pointer",
            }}
          >{t.label}</button>
        ))}
      </div>

      {/* ─── OVERVIEW TAB ─────────────────────────── */}
      {activeTab === "overview" && (
        <div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: "10px", marginBottom: "20px" }}>
            <StatCard label="Forge Artifacts" value={stats.forge.length} accent="#22d3ee" sub="Executable code" />
            <StatCard label="Functional" value={stats.functional.length} accent="#34d399" sub={`${Math.round(stats.functional.length / stats.forge.length * 100)}% ready`} />
            <StatCard label="Critical Path" value={stats.critical.length} accent="#f87171" sub="Must-fix items" />
            <StatCard label="Stdlib Only" value={stats.stdlib.length} accent="#a78bfa" sub="Zero pip deps" />
          </div>

          <div style={{ background: "#0f172a", borderRadius: "6px", padding: "14px", marginBottom: "16px", border: "1px solid #1e293b" }}>
            <h3 style={{ margin: "0 0 10px", fontSize: "14px", color: "#f87171", fontWeight: 600 }}>KEY FINDING: The Biggest Gap</h3>
            <p style={{ margin: 0, fontSize: "13px", lineHeight: 1.6, color: "#cbd5e1" }}>
              The inventory claims eden_daemon.py v2.2.1 (842 lines) exists with full Ollama routing, AoT Sieve integration, and IPC server. 
              The actual file in the project is a 6K (~180 line) OLD stub version with <code style={{ color: "#fbbf24", background: "#1e293b", padding: "1px 4px", borderRadius: "2px" }}>handle_chat()</code> returning canned responses.
              However, <code style={{ color: "#22d3ee", background: "#1e293b", padding: "1px 4px", borderRadius: "2px" }}>eden_chat_wire.py</code> (555 lines) IS present and IS the drop-in replacement. 
              The wire exists. It just hasn't been plugged in.
            </p>
          </div>

          <h3 style={{ fontSize: "14px", color: "#94a3b8", margin: "16px 0 10px" }}>Cluster Map</h3>
          <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: "8px" }}>
            {Object.entries(CLUSTERS).filter(([k]) => k !== "LOOM").map(([key, c]) => {
              const count = ARTIFACTS.filter(a => a.cluster === key).length;
              const functional = ARTIFACTS.filter(a => a.cluster === key && a.status === "FUNCTIONAL").length;
              return (
                <div key={key} style={{
                  display: "flex", alignItems: "center", gap: "12px",
                  background: "#0f172a", padding: "10px 14px", borderRadius: "4px",
                  borderLeft: `3px solid ${c.color}`,
                  cursor: "pointer",
                }} onClick={() => { setClusterFilter(key); setActiveTab("artifacts"); }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "13px", fontWeight: 600, color: c.color }}>{c.label}</div>
                    <div style={{ fontSize: "11px", color: "#94a3b8", marginTop: "2px" }}>{c.desc}</div>
                  </div>
                  <div style={{ textAlign: "right", flexShrink: 0 }}>
                    <div style={{ fontSize: "18px", fontWeight: 700, color: c.color, fontFamily: "'JetBrains Mono', monospace" }}>{count}</div>
                    <div style={{ fontSize: "10px", color: "#64748b" }}>{functional}/{count} ready</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ─── ARTIFACTS TAB ────────────────────────── */}
      {activeTab === "artifacts" && (
        <div>
          <div style={{ display: "flex", gap: "6px", marginBottom: "12px", flexWrap: "wrap", alignItems: "center" }}>
            <button
              onClick={() => setClusterFilter("ALL")}
              style={{
                background: clusterFilter === "ALL" ? "#1e293b" : "transparent",
                color: clusterFilter === "ALL" ? "#22d3ee" : "#64748b",
                border: "1px solid #1e293b", padding: "4px 10px", borderRadius: "3px",
                fontSize: "11px", cursor: "pointer",
              }}
            >All</button>
            {Object.entries(CLUSTERS).filter(([k]) => k !== "LOOM").map(([key, c]) => (
              <button
                key={key}
                onClick={() => setClusterFilter(key)}
                style={{
                  background: clusterFilter === key ? `${c.color}20` : "transparent",
                  color: clusterFilter === key ? c.color : "#64748b",
                  border: `1px solid ${clusterFilter === key ? c.color : "#1e293b"}`,
                  padding: "4px 10px", borderRadius: "3px", fontSize: "11px", cursor: "pointer",
                }}
              >{c.label}</button>
            ))}
            <label style={{ marginLeft: "auto", fontSize: "11px", color: "#64748b", display: "flex", alignItems: "center", gap: "4px", cursor: "pointer" }}>
              <input type="checkbox" checked={showLoom} onChange={e => setShowLoom(e.target.checked)} style={{ accentColor: "#475569" }} />
              Show Loom
            </label>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            {filteredArtifacts.map(a => (
              <ArtifactCard
                key={a.id}
                artifact={a}
                expanded={expandedArtifact === a.id}
                onToggle={() => setExpandedArtifact(expandedArtifact === a.id ? null : a.id)}
              />
            ))}
          </div>
        </div>
      )}

      {/* ─── CRITICAL PATH TAB ────────────────────── */}
      {activeTab === "critical" && (
        <div>
          <div style={{ background: "#0f172a", borderRadius: "6px", padding: "14px", marginBottom: "16px", border: "1px solid #7f1d1d" }}>
            <h3 style={{ margin: "0 0 8px", fontSize: "14px", color: "#f87171" }}>Path to First Live Inference</h3>
            <p style={{ margin: 0, fontSize: "12px", color: "#94a3b8" }}>
              Zero live inference has ever flowed through this stack. These are the minimum steps to change that. No architecture. No specs. Just execution.
            </p>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
            {CRITICAL_PATH.map((step, i) => (
              <div key={i} style={{
                display: "flex", alignItems: "flex-start", gap: "12px",
                background: "#0f172a", padding: "12px 14px", borderRadius: "4px",
                borderLeft: `3px solid ${step.done ? "#34d399" : "#f87171"}`,
              }}>
                <div style={{
                  width: "24px", height: "24px", borderRadius: "50%", flexShrink: 0,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  background: step.done ? "#064e3b" : "#7f1d1d",
                  color: step.done ? "#34d399" : "#f87171",
                  fontSize: "12px", fontWeight: 700, fontFamily: "'JetBrains Mono', monospace",
                }}>{step.step}</div>
                <div>
                  <div style={{ fontSize: "13px", color: "#e2e8f0" }}>{step.action}</div>
                  {step.file && (
                    <div style={{ fontSize: "11px", color: "#64748b", marginTop: "2px", fontFamily: "'JetBrains Mono', monospace" }}>
                      → {ARTIFACTS.find(a => a.id === step.file)?.name || step.file}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div style={{ background: "#0f172a", borderRadius: "6px", padding: "14px", marginTop: "16px", border: "1px solid #1e293b" }}>
            <h3 style={{ margin: "0 0 8px", fontSize: "14px", color: "#fbbf24" }}>Dependency Chain (Live Inference)</h3>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "12px", lineHeight: 1.8, color: "#94a3b8" }}>
              <div>
                <span style={{ color: "#f87171" }}>ignition.py</span>
                <span style={{ color: "#475569" }}> → imports → </span>
                <span style={{ color: "#f87171" }}>red_queen.py</span>
                <span style={{ color: "#475569" }}> + </span>
                <span style={{ color: "#f87171" }}>red_queen_bridge.py</span>
              </div>
              <div>
                <span style={{ color: "#22d3ee" }}>eden_chat_wire.py</span>
                <span style={{ color: "#475569" }}> → imports → </span>
                <span style={{ color: "#fbbf24" }}>aot_sieve.py</span>
                <span style={{ color: "#475569" }}> (graceful fallback)</span>
              </div>
              <div>
                <span style={{ color: "#22d3ee" }}>eden_chat_wire.py</span>
                <span style={{ color: "#475569" }}> → HTTP → </span>
                <span style={{ color: "#34d399" }}>Ollama localhost:11434</span>
              </div>
              <div style={{ marginTop: "6px", color: "#64748b", fontSize: "11px" }}>
                All above are stdlib-only. No pip install required.
              </div>
            </div>
          </div>

          <div style={{ background: "#0f172a", borderRadius: "6px", padding: "14px", marginTop: "12px", border: "1px solid #1e293b" }}>
            <h3 style={{ margin: "0 0 8px", fontSize: "14px", color: "#34d399" }}>Self-Contained Subsystems (Run Today)</h3>
            <div style={{ fontSize: "12px", color: "#cbd5e1", lineHeight: 1.7 }}>
              These work without ANY wiring, just <code style={{ color: "#fbbf24", background: "#1e293b", padding: "1px 4px", borderRadius: "2px" }}>python filename.py</code>:
            </div>
            <div style={{ marginTop: "8px", display: "flex", flexDirection: "column", gap: "4px" }}>
              {[
                { name: "forge_toolkit.py", desc: "5 tools, stdlib, self-tests included" },
                { name: "aot_sieve.py", desc: "Atom decomposition, stdlib" },
                { name: "red_queen.py", desc: "Adversarial substrate, stdlib" },
                { name: "integrity.py", desc: "HMAC signing, stdlib" },
                { name: "eden_chat_wire.py", desc: "Standalone test mode (needs Ollama)" },
                { name: "eden_append.py", desc: "WORM append + verify" },
              ].map((item, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", fontSize: "12px", fontFamily: "'JetBrains Mono', monospace", padding: "4px 8px", background: "#020617", borderRadius: "3px" }}>
                  <span style={{ color: "#34d399" }}>{item.name}</span>
                  <span style={{ color: "#64748b" }}>{item.desc}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ─── DISCREPANCIES TAB ────────────────────── */}
      {activeTab === "discrepancies" && (
        <div>
          <div style={{ background: "#0f172a", borderRadius: "6px", padding: "14px", marginBottom: "16px", border: "1px solid #7c2d12" }}>
            <h3 style={{ margin: "0 0 8px", fontSize: "14px", color: "#fb923c" }}>Inventory vs. Reality</h3>
            <p style={{ margin: 0, fontSize: "12px", color: "#94a3b8" }}>
              The sealed inventory (your data set above) claims artifacts that are NOT present in the actual project files. This is the Polite Lie pattern at the project level — precise-looking references to files that don't exist on disk.
            </p>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            {INVENTORY_DISCREPANCIES.map((d, i) => (
              <div key={i} style={{ background: "#0f172a", borderRadius: "6px", padding: "12px 14px", border: "1px solid #1e293b" }}>
                <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "13px", color: "#fb923c", marginBottom: "6px" }}>{d.item}</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
                  <div>
                    <div style={{ fontSize: "10px", color: "#64748b", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: "2px" }}>Inventory Claims</div>
                    <div style={{ fontSize: "12px", color: "#94a3b8" }}>{d.inventorySays}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: "10px", color: "#f87171", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: "2px" }}>Actual Status</div>
                    <div style={{ fontSize: "12px", color: "#fca5a5" }}>{d.reality}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ background: "#0f172a", borderRadius: "6px", padding: "14px", marginTop: "16px", border: "1px solid #1e293b" }}>
            <h3 style={{ margin: "0 0 8px", fontSize: "14px", color: "#a78bfa" }}>Inventory Constants: What's Engineering vs. Ceremony</h3>
            <div style={{ fontSize: "12px", color: "#cbd5e1", lineHeight: 1.7 }}>
              The EchoNums table in the inventory mixes real engineering constants with ceremonial ones. The engineering constants (TIMING_FLOOR=670µs, U_MAX=0.95, QUENCH_BUDGET, EWMA_ALPHA) appear in actual source code. The ceremonial constants (ZERO_POINT_ISO, LAMBDA_PRE/POST, Aquifer Pulse 741Hz, Φ=1.618) appear only in the inventory document and in Loom materials — they have no code references and no test coverage. They're measurements of narrative, not system behavior.
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <div style={{ marginTop: "24px", paddingTop: "12px", borderTop: "1px solid #1e293b", fontSize: "11px", color: "#475569", textAlign: "center" }}>
        Salvage Master v1.0 | Generated {new Date().toISOString().split('T')[0]} | {ARTIFACTS.length} artifacts cataloged | Forge/Loom separation enforced
      </div>
    </div>
  );
}
