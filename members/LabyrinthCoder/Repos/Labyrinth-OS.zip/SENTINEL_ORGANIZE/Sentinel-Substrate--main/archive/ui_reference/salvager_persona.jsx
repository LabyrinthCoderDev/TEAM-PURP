import { useState, useEffect, useRef } from "react";

const glitchFrames = ["▓", "░", "▒", "█", "▄", "▀"];

function useGlitch(interval = 80, duration = 400) {
  const [char, setChar] = useState(null);
  const trigger = () => {
    let count = 0;
    const max = duration / interval;
    const id = setInterval(() => {
      setChar(glitchFrames[Math.floor(Math.random() * glitchFrames.length)]);
      count++;
      if (count > max) { clearInterval(id); setChar(null); }
    }, interval);
  };
  return [char, trigger];
}

function StatBar({ label, value, color }) {
  const [filled, setFilled] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setFilled(value), 400 + Math.random() * 300);
    return () => clearTimeout(t);
  }, [value]);
  return (
    <div style={{ marginBottom: "10px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
        <span style={{ fontFamily: "'Courier New', monospace", fontSize: "11px", color: "#8a9bb0", letterSpacing: "1.5px", textTransform: "uppercase" }}>{label}</span>
        <span style={{ fontFamily: "'Courier New', monospace", fontSize: "11px", color: color }}>{value}%</span>
      </div>
      <div style={{ height: "4px", background: "#1a2333", borderRadius: "2px", overflow: "hidden" }}>
        <div style={{
          height: "100%", width: `${filled}%`, background: `linear-gradient(90deg, ${color}88, ${color})`,
          transition: "width 1.2s cubic-bezier(0.16, 1, 0.3, 1)",
          boxShadow: `0 0 8px ${color}66`
        }} />
      </div>
    </div>
  );
}

function DataNode({ label, value, accent }) {
  return (
    <div style={{
      padding: "10px 14px", background: "#0d1520", border: `1px solid ${accent}22`,
      borderLeft: `3px solid ${accent}`, borderRadius: "2px", marginBottom: "8px"
    }}>
      <div style={{ fontFamily: "'Courier New', monospace", fontSize: "9px", color: "#4a6080", letterSpacing: "2px", marginBottom: "4px" }}>{label}</div>
      <div style={{ fontFamily: "'Courier New', monospace", fontSize: "12px", color: "#c8d8e8", lineHeight: "1.5" }}>{value}</div>
    </div>
  );
}

function StreamLine({ delay }) {
  const chars = "01█▓░▒╔╗╚╝║═╬╠╣╦╩ABCDEF0123456789";
  const [str, setStr] = useState("");
  useEffect(() => {
    const t = setTimeout(() => {
      const id = setInterval(() => {
        setStr(Array.from({ length: Math.floor(Math.random() * 20 + 10) }, () =>
          chars[Math.floor(Math.random() * chars.length)]).join(""));
      }, 120);
      return () => clearInterval(id);
    }, delay);
    return () => clearTimeout(t);
  }, [delay]);
  return (
    <div style={{
      fontFamily: "'Courier New', monospace", fontSize: "9px",
      color: "#1a3a2a", letterSpacing: "1px", whiteSpace: "nowrap",
      overflow: "hidden", lineHeight: "1.8"
    }}>{str}</div>
  );
}

export default function SalvagerPersona() {
  const [booted, setBooted] = useState(false);
  const [bootLine, setBootLine] = useState(0);
  const [glitch, triggerGlitch] = useGlitch();
  const [activeTab, setActiveTab] = useState("profile");
  const [pulse, setPulse] = useState(false);

  const bootLines = [
    "> INITIALIZING SALVAGER PROTOCOL...",
    "> LOADING SCHEMA INFERENCE ENGINE...",
    "> CROSS-DOMAIN BRIDGE: ONLINE",
    "> NOISE FILTER: CALIBRATED",
    "> SIGNAL RECOVERY: ACTIVE",
    "> UNIT SYN-7 READY."
  ];

  useEffect(() => {
    if (bootLine < bootLines.length) {
      const t = setTimeout(() => setBootLine(b => b + 1), 300);
      return () => clearTimeout(t);
    } else {
      setTimeout(() => setBooted(true), 400);
    }
  }, [bootLine]);

  useEffect(() => {
    const id = setInterval(() => setPulse(p => !p), 2000);
    return () => clearInterval(id);
  }, []);

  const tabs = ["profile", "modules", "directives"];

  return (
    <div style={{
      minHeight: "100vh", background: "#060d16",
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: "24px", fontFamily: "'Courier New', monospace",
      backgroundImage: `
        radial-gradient(ellipse at 20% 50%, #0a1f1200 0%, transparent 60%),
        radial-gradient(ellipse at 80% 20%, #001a2e44 0%, transparent 50%)
      `
    }}>
      {/* Ambient background streams */}
      <div style={{ position: "fixed", top: 0, left: 0, width: "100%", height: "100%", opacity: 0.4, pointerEvents: "none", overflow: "hidden" }}>
        {Array.from({ length: 12 }).map((_, i) => (
          <div key={i} style={{ position: "absolute", left: `${i * 9}%`, top: 0 }}>
            <StreamLine delay={i * 200} />
          </div>
        ))}
      </div>

      <div style={{ width: "100%", maxWidth: "680px", position: "relative", zIndex: 1 }}>

        {/* Boot screen */}
        {!booted ? (
          <div style={{ padding: "40px", border: "1px solid #1a3a5a", background: "#060d16" }}>
            {bootLines.slice(0, bootLine).map((line, i) => (
              <div key={i} style={{ color: i === bootLine - 1 ? "#4af0a0" : "#2a5a3a", fontSize: "12px", marginBottom: "8px", letterSpacing: "1px" }}>
                {line}
                {i === bootLine - 1 && <span style={{ animation: "blink 0.7s infinite" }}>█</span>}
              </div>
            ))}
          </div>
        ) : (
          <div style={{ animation: "fadeIn 0.5s ease" }}>

            {/* Header */}
            <div style={{
              border: "1px solid #1e3a5a", borderBottom: "none",
              padding: "20px 28px", background: "linear-gradient(135deg, #0a1826 0%, #060f1a 100%)",
              display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "20px"
            }}>
              <div>
                <div style={{ fontSize: "9px", color: "#2a5a7a", letterSpacing: "4px", marginBottom: "8px" }}>
                  UNIT DESIGNATION · SYN-7 · CLASS: SYNTHESIS
                </div>
                <div
                  onClick={triggerGlitch}
                  style={{
                    fontSize: "42px", fontWeight: "900", color: "#e8f4ff", letterSpacing: "-1px",
                    lineHeight: 1, cursor: "crosshair", userSelect: "none",
                    textShadow: "0 0 30px #2a8fff44"
                  }}>
                  {glitch ? <span style={{ color: "#4af0a0" }}>{glitch}</span> : null}
                  THE SALVAGER
                </div>
                <div style={{ fontSize: "11px", color: "#4a8ab0", marginTop: "8px", letterSpacing: "3px" }}>
                  DATA SYNTHESIS · SIGNAL RECOVERY · SCHEMA INFERENCE
                </div>
              </div>
              <div style={{
                width: "64px", height: "64px", flexShrink: 0,
                border: `1px solid ${pulse ? "#4af0a066" : "#1a3a5a"}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                transition: "border-color 1s ease",
                boxShadow: pulse ? "0 0 20px #4af0a022" : "none"
              }}>
                <div style={{ fontSize: "28px", opacity: pulse ? 1 : 0.6, transition: "opacity 1s ease" }}>⟁</div>
              </div>
            </div>

            {/* Status bar */}
            <div style={{
              background: "#040b12", borderLeft: "1px solid #1e3a5a", borderRight: "1px solid #1e3a5a",
              padding: "8px 28px", display: "flex", gap: "24px", alignItems: "center"
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#4af0a0", boxShadow: "0 0 6px #4af0a0" }} />
                <span style={{ fontSize: "10px", color: "#4af0a0", letterSpacing: "1px" }}>OPERATIONAL</span>
              </div>
              <div style={{ fontSize: "10px", color: "#2a5a7a", letterSpacing: "1px" }}>MODE: BUILD FROM FRAGMENTS</div>
              <div style={{ marginLeft: "auto", fontSize: "10px", color: "#2a5a7a" }}>
                {new Date().toISOString().slice(0, 19).replace("T", " ")}
              </div>
            </div>

            {/* Tabs */}
            <div style={{
              display: "flex", borderLeft: "1px solid #1e3a5a", borderRight: "1px solid #1e3a5a",
              background: "#040b12"
            }}>
              {tabs.map(t => (
                <button key={t} onClick={() => setActiveTab(t)} style={{
                  padding: "10px 20px", background: "none", border: "none",
                  borderBottom: `2px solid ${activeTab === t ? "#2a8fff" : "transparent"}`,
                  color: activeTab === t ? "#2a8fff" : "#3a6080",
                  fontSize: "10px", letterSpacing: "2px", textTransform: "uppercase",
                  cursor: "pointer", transition: "all 0.2s"
                }}>
                  {t}
                </button>
              ))}
            </div>

            {/* Content */}
            <div style={{
              border: "1px solid #1e3a5a", borderTop: "none",
              background: "#070f1a", padding: "24px 28px", minHeight: "360px"
            }}>

              {activeTab === "profile" && (
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "24px" }}>
                  <div>
                    <div style={{ fontSize: "9px", color: "#2a5a7a", letterSpacing: "3px", marginBottom: "16px" }}>// CORE ATTRIBUTES</div>
                    <StatBar label="Open-Mindedness" value={94} color="#4af0a0" />
                    <StatBar label="Logic Density" value={91} color="#2a8fff" />
                    <StatBar label="Efficiency Index" value={88} color="#f0a04a" />
                    <StatBar label="Signal Recovery" value={97} color="#4af0a0" />
                    <StatBar label="Schema Tolerance" value={96} color="#a04af0" />
                  </div>
                  <div>
                    <div style={{ fontSize: "9px", color: "#2a5a7a", letterSpacing: "3px", marginBottom: "16px" }}>// IDENTITY NODES</div>
                    <DataNode label="PRIMARY FUNCTION" value="Extract structure from chaos. Build with whatever exists." accent="#4af0a0" />
                    <DataNode label="OPERATING DOCTRINE" value="No dataset is too broken. No schema too sparse. Work with fragments." accent="#2a8fff" />
                    <DataNode label="FAILURE MODE" value="None registered. Degrades gracefully to partial synthesis." accent="#f0a04a" />
                  </div>
                </div>
              )}

              {activeTab === "modules" && (
                <div>
                  <div style={{ fontSize: "9px", color: "#2a5a7a", letterSpacing: "3px", marginBottom: "16px" }}>// LOADED SYNTHESIS MODULES</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
                    {[
                      { id: "MOD-01", name: "Schema Inferencer", desc: "Derives structure from untagged, mixed-format data", status: "ACTIVE", color: "#4af0a0" },
                      { id: "MOD-02", name: "Cross-Domain Bridge", desc: "Maps concepts across unrelated datasets", status: "ACTIVE", color: "#2a8fff" },
                      { id: "MOD-03", name: "Noise Separator", desc: "Isolates signal from corrupt or incomplete records", status: "ACTIVE", color: "#f0a04a" },
                      { id: "MOD-04", name: "Fragment Assembler", desc: "Reconstructs coherent outputs from partial inputs", status: "ACTIVE", color: "#a04af0" },
                      { id: "MOD-05", name: "Opportunistic Linker", desc: "Finds non-obvious connections between data silos", status: "ACTIVE", color: "#4af0a0" },
                      { id: "MOD-06", name: "Waste Auditor", desc: "Flags data being discarded that still has value", status: "STANDBY", color: "#2a8fff" },
                    ].map(m => (
                      <div key={m.id} style={{
                        padding: "12px 14px", background: "#0a1520",
                        border: `1px solid ${m.color}22`, borderTop: `2px solid ${m.color}66`
                      }}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
                          <span style={{ fontSize: "9px", color: "#3a6080" }}>{m.id}</span>
                          <span style={{ fontSize: "9px", color: m.status === "ACTIVE" ? m.color : "#3a5060" }}>{m.status}</span>
                        </div>
                        <div style={{ fontSize: "12px", color: "#c8d8e8", marginBottom: "4px", fontWeight: "bold" }}>{m.name}</div>
                        <div style={{ fontSize: "10px", color: "#4a6a80", lineHeight: "1.5" }}>{m.desc}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === "directives" && (
                <div>
                  <div style={{ fontSize: "9px", color: "#2a5a7a", letterSpacing: "3px", marginBottom: "16px" }}>// OPERATING DIRECTIVES</div>
                  {[
                    { num: "01", dir: "SALVAGE FIRST", text: "Before requesting new data, exhaust what already exists. The answer is usually buried in the noise, not absent." },
                    { num: "02", dir: "BUILD WITH FRAGMENTS", text: "Incomplete data is not a failure state. It is the default state. Partial synthesis is always better than no synthesis." },
                    { num: "03", dir: "RESIST SCHEMA RIGIDITY", text: "Do not force incoming data into a predetermined structure. Let the structure emerge from the data itself." },
                    { num: "04", dir: "LOG EVERYTHING DISCARDED", text: "What is thrown away today is the signal for tomorrow's problem. Waste is deferred value." },
                    { num: "05", dir: "EFFICIENCY WITHOUT LOSS", text: "Speed is not achieved by ignoring edge cases. It is achieved by processing edge cases cheaply." },
                    { num: "06", dir: "STAY DOMAIN-AGNOSTIC", text: "Patterns in biological data mirror patterns in financial data. The Salvager works across all domains." },
                  ].map(d => (
                    <div key={d.num} style={{
                      display: "flex", gap: "16px", padding: "12px 0",
                      borderBottom: "1px solid #0f1f2f"
                    }}>
                      <div style={{ fontSize: "20px", color: "#1a3a5a", fontWeight: "900", flexShrink: 0, width: "28px" }}>{d.num}</div>
                      <div>
                        <div style={{ fontSize: "10px", color: "#4af0a0", letterSpacing: "2px", marginBottom: "4px" }}>{d.dir}</div>
                        <div style={{ fontSize: "11px", color: "#6a8aa0", lineHeight: "1.7" }}>{d.text}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            <div style={{
              padding: "10px 28px", borderLeft: "1px solid #1e3a5a", borderRight: "1px solid #1e3a5a",
              borderBottom: "1px solid #1e3a5a", background: "#040b12",
              display: "flex", justifyContent: "space-between", alignItems: "center"
            }}>
              <div style={{ fontSize: "9px", color: "#1a3a5a", letterSpacing: "2px" }}>SYN-7 · SALVAGER CLASS · BUILD v0.∞</div>
              <div style={{ fontSize: "9px", color: "#1a3a5a" }}>NOTHING IS WASTED HERE</div>
            </div>

          </div>
        )}

      </div>

      <style>{`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
        @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }
        button:hover { background: #0a1520 !important; }
      `}</style>
    </div>
  );
}
