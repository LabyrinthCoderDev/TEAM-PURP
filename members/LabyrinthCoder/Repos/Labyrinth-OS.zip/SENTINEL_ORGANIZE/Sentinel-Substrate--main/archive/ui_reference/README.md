# UI Reference — Labyrinth-OS

React component reference for Labyrinth-OS visualization and dashboards.
These are not pipeline code — they are UI artifacts for monitoring and understanding.

## Files

- `salvage_dashboard.jsx` — Full project status dashboard. Clusters by module group
  (Eden Runtime, Governance Engine, Adversarial Substrate, Epistemic Sieve).
  Tracks verified/confirmed/unconfirmed module status.

- `labyrinth_inventory.jsx` — File inventory with verification status, test counts,
  and layer assignments. Good starting point for understanding what exists and where.

- `salvager_persona.jsx` — Animated Salvager persona component with stat bars and
  glitch effects. Visual interface concept for the system monitor.

These components reference real data from the project files.
They are the foundation for a live dashboard when the system goes online.
