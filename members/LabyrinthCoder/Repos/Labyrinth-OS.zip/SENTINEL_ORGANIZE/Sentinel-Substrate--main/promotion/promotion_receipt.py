# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          promotion_receipt.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
promotion_receipt.py — Labyrinth-OS
=====================================
Typed receipt produced by PromotionProtocol.evaluate().

CGIR entry requires a PromotionReceipt — not just a timestamp.
This closes the semantic gap in GAP 1: stage presence ≠ stage semantics.

Without a PromotionReceipt, assert_can_enter_cgir() cannot verify
that real promotion logic ran — only that something ran.

With a PromotionReceipt:
  - The receipt carries a content_hash of what was evaluated
  - The receipt carries approved=True/False from real criteria
  - CGIR entry checks receipt.approved — not just receipt presence

PROTOTYPE NOTE: In the ignition stub path, a PromotionReceipt is
generated from mock evaluation. The approved field reflects stub logic,
not real Lane 1 criteria. This is the documented partial gap.

ROADMAP (post-prototype): ignition must call real PromotionProtocol.evaluate()
and pass its receipt to assert_can_enter_cgir().
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class PromotionReceipt:
    """
    Typed receipt produced by promotion evaluation.
    Required for CGIR entry — proves promotion ran, not just that a stage exists.
    
    Fields
    ------
    idea_id        The idea/label that was evaluated
    approved       Whether promotion criteria were met
    confidence     Confidence at time of evaluation
    evidence_hash  SHA-256 of the evidence bundle evaluated
    stage_hash     SHA-256 of this receipt — used for artifact continuity
    timestamp      Unix epoch when promotion ran
    is_mock        True if produced by stub path (ignition GAP 1)
    """
    idea_id:       str
    approved:      bool
    confidence:    float
    evidence_hash: str
    stage_hash:    str
    timestamp:     float
    is_mock:       bool = False
    notes:         str  = ""

    @classmethod
    def mock(cls, idea_id: str, confidence: float = 0.75) -> "PromotionReceipt":
        """
        Produce a mock receipt for stub paths.
        
        PROTOTYPE NOTE: mock receipts are labeled is_mock=True.
        They satisfy stage presence checks but carry the is_mock flag
        so that downstream components can distinguish real vs stub enforcement.
        CGIR entry should warn (not halt) on is_mock=True in prototype stage.
        Post-prototype: is_mock=True should be treated as BLOCK.
        """
        ts = time.time()
        evidence_hash = hashlib.sha256(f"mock:{idea_id}:{ts}".encode()).hexdigest()
        stage_hash = hashlib.sha256(
            f"mock_receipt:{idea_id}:{confidence}:{ts}".encode()
        ).hexdigest()
        return cls(
            idea_id=idea_id,
            approved=confidence >= 0.65,
            confidence=confidence,
            evidence_hash=evidence_hash,
            stage_hash=stage_hash,
            timestamp=ts,
            is_mock=True,
            notes="PROTOTYPE — mock stub path. See GAP 1 in KNOWN_GAPS.md.",
        )

    @classmethod
    def from_evaluation(cls, idea_id: str, approved: bool,
                        confidence: float, evidence: dict) -> "PromotionReceipt":
        """Produce a real receipt from actual promotion evaluation."""
        ts = time.time()
        evidence_hash = hashlib.sha256(
            str(sorted(evidence.items())).encode()
        ).hexdigest()
        stage_hash = hashlib.sha256(
            f"real_receipt:{idea_id}:{approved}:{confidence}:{ts}".encode()
        ).hexdigest()
        return cls(
            idea_id=idea_id,
            approved=approved,
            confidence=confidence,
            evidence_hash=evidence_hash,
            stage_hash=stage_hash,
            timestamp=ts,
            is_mock=False,
        )

    def verify(self) -> bool:
        """Basic self-consistency check."""
        return (
            bool(self.idea_id)
            and bool(self.evidence_hash)
            and bool(self.stage_hash)
            and len(self.evidence_hash) == 64
            and len(self.stage_hash) == 64
            and 0.0 <= self.confidence <= 1.0
        )


# ── TEST SUITE ─────────────────────────────────────────────────────────────────

def _test_mock_receipt_produces_valid_structure() -> bool:
    r = PromotionReceipt.mock("idea-001", confidence=0.80)
    assert r.is_mock
    assert r.idea_id == "idea-001"
    assert r.verify()
    return True

def _test_mock_receipt_below_floor_not_approved() -> bool:
    r = PromotionReceipt.mock("idea-001", confidence=0.50)
    assert not r.approved  # 0.50 < 0.65 floor
    return True

def _test_real_receipt_not_mock() -> bool:
    r = PromotionReceipt.from_evaluation(
        "idea-002", approved=True, confidence=0.90,
        evidence={"runs": 5, "consistent": True}
    )
    assert not r.is_mock
    assert r.approved
    assert r.verify()
    return True

def _test_stage_hash_is_64_chars() -> bool:
    r = PromotionReceipt.mock("idea-003")
    assert len(r.stage_hash) == 64
    assert len(r.evidence_hash) == 64
    return True

def _test_different_ideas_different_hashes() -> bool:
    r1 = PromotionReceipt.mock("idea-A")
    r2 = PromotionReceipt.mock("idea-B")
    assert r1.stage_hash != r2.stage_hash
    return True

def _test_frozen_dataclass_immutable() -> bool:
    r = PromotionReceipt.mock("idea-001")
    try:
        r.approved = False  # type: ignore
        return False  # should not reach here
    except Exception:
        return True  # frozen=True prevents mutation

def _test_mock_flag_visible_to_downstream() -> bool:
    """Downstream can distinguish mock vs real enforcement."""
    mock_r = PromotionReceipt.mock("idea-001")
    real_r = PromotionReceipt.from_evaluation(
        "idea-001", True, 0.90, {"k": "v"}
    )
    assert mock_r.is_mock and not real_r.is_mock
    return True


def run_tests() -> tuple:
    tests = sorted([(n, o) for n, o in globals().items()
                    if n.startswith("_test_") and callable(o)])
    passed = failed = 0
    results = []
    for name, fn in tests:
        try:
            fn(); passed += 1; results.append((name, "PASS", None))
        except Exception as e:
            failed += 1; results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    p, f, results = run_tests()
    for name, status, err in results:
        print(f"  {'✓' if status=='PASS' else '✗'} {name}" +
              (f": {err}" if err else ""))
    print(f"\n  {p}/{p+f} passed")
    if f: raise SystemExit(1)
