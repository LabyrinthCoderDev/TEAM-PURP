# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          domain_reasoning_profiles.py — Labyrinth-OS / Lane 1 / domain_profiles
# ----------------------------------------------------------------------------

"""
domain_reasoning_profiles.py — Labyrinth-OS / Lane 1 / domain_profiles
========================================================================
Domain Reasoning Profiles — Lane 1 Complement to Domain Adapters

The gap this closes:
  Domain adapters translate sensor readings (Lane 2 side).
  Domain Reasoning Profiles shape how the model reasons within a domain
  before proposing (Lane 1 side).

  Without profiles: adapters handle sensor translation only.
  With profiles: full bilateral domain coverage. Both lanes speak
  the same domain language.

Each profile defines:
  - Reasoning constraints specific to the domain
  - Epistemic threshold adjustments (tighter or looser than defaults)
  - Goal priors (what kinds of goals matter in this domain)
  - Prohibited reasoning patterns (domain-specific safety rules)
  - Required epistemic class for domain proposals

Profiles are loaded by MetaGoalEngine at session initialization.
They pair with the existing domain adapter for each domain.

Quillan reference: LHP domain initialization pattern
See: archive/external_references/quillan/ASSESSMENT_quillan.md
Labyrinth-OS owns this implementation entirely.

Supported domains (matching existing domain adapters):
  medical, industrial, financial, autonomous_vehicle

Extension: implement DomainProfile for new domains.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, List, Optional

from epistemic_class import EpistemicClass


# ─── DOMAIN ENUM ─────────────────────────────────────────────────────────────

@unique
class Domain(str, Enum):
    MEDICAL           = "medical"
    INDUSTRIAL        = "industrial"
    FINANCIAL         = "financial"
    AUTONOMOUS_VEHICLE = "autonomous_vehicle"
    GENERIC           = "generic"


# ─── DOMAIN PROFILE ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class DomainProfile:
    """
    Immutable reasoning profile for a specific deployment domain.

    Loaded at session initialization by MetaGoalEngine.
    Paired with the corresponding domain adapter (Lane 2 side).
    """
    domain:                    Domain
    description:               str

    # Epistemic threshold adjustments (delta from defaults)
    # Positive = tighter (higher bar). Negative = looser.
    confidence_floor_delta:    float        # added to class floor
    chi_collapse_override:     Optional[float]   # tighten chi collapse
    drift_threshold_override:  Optional[float]   # tighten drift threshold

    # Goal priors — which goal types are most relevant
    preferred_goal_types:      List[str]

    # Minimum epistemic class for proposals in this domain
    min_epistemic_class:       EpistemicClass

    # Domain-specific reasoning constraints
    reasoning_constraints:     List[str]

    # Prohibited patterns — if present in reasoning, flag for review
    prohibited_patterns:       List[str]

    # Required verifications before promotion
    required_verifications:    List[str]

    def confidence_floor_for(self, base_floor: float) -> float:
        """Return adjusted confidence floor for this domain."""
        return min(0.99, max(0.0, base_floor + self.confidence_floor_delta))

    def check_epistemic_class(self, ec) -> tuple:
        """
        Check whether an EpistemicClass meets this domain's minimum requirement.

        Returns (allowed: bool, reason: str).
        This enforces min_epistemic_class — not just advisory data.

        Class ladder (lower index = weaker epistemic grounding):
          AMBIGUOUS < HYPOTHETICAL < COHERENTLY_SYNTHESIZED < INFERRED < EMPIRICALLY_VERIFIED
        """
        from epistemic_class import EpistemicClass
        ladder = [
            EpistemicClass.AMBIGUOUS,
            EpistemicClass.HYPOTHETICAL,
            EpistemicClass.COHERENTLY_SYNTHESIZED,
            EpistemicClass.INFERRED,
            EpistemicClass.EMPIRICALLY_VERIFIED,
        ]
        try:
            ec_rank  = ladder.index(ec)
            min_rank = ladder.index(self.min_epistemic_class)
        except ValueError:
            return False, f"DOMAIN_CLASS_CHECK: unknown class {ec}"

        if ec_rank < min_rank:
            return False, (
                f"DOMAIN_CLASS_INSUFFICIENT: domain={self.domain.value} "
                f"requires min={self.min_epistemic_class.value}, "
                f"got={ec.value}"
            )
        return True, "ok"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "domain":                   self.domain.value,
            "description":              self.description,
            "confidence_floor_delta":   self.confidence_floor_delta,
            "chi_collapse_override":    self.chi_collapse_override,
            "drift_threshold_override": self.drift_threshold_override,
            "preferred_goal_types":     self.preferred_goal_types,
            "min_epistemic_class":      self.min_epistemic_class.value,
            "reasoning_constraints":    self.reasoning_constraints,
            "prohibited_patterns":      self.prohibited_patterns,
            "required_verifications":   self.required_verifications,
        }


# ─── PROFILE REGISTRY ────────────────────────────────────────────────────────

DOMAIN_PROFILES: Dict[Domain, DomainProfile] = {

    Domain.MEDICAL: DomainProfile(
        domain      = Domain.MEDICAL,
        description = "Medical decision support — patient safety is paramount",

        # Tighter thresholds: medical errors are high-stakes
        confidence_floor_delta    = +0.10,
        chi_collapse_override     = 0.25,  # tighter than default 0.40
        drift_threshold_override  = 0.08,  # tighter than default 0.12

        preferred_goal_types = ["CONSOLIDATION", "CALIBRATION"],

        # Medical proposals need external grounding — not synthesis alone
        min_epistemic_class = EpistemicClass.INFERRED,

        reasoning_constraints = [
            "cite clinical evidence or guidelines for every assertion",
            "distinguish diagnosis from differential",
            "flag uncertainty explicitly — do not suppress ambiguity",
            "never recommend action without safety check",
            "patient harm must be considered before promotion",
        ],

        prohibited_patterns = [
            "assume patient compliance",
            "override clinical judgment",
            "suppress side effect information",
        ],

        required_verifications = [
            "clinical_evidence_cited",
            "safety_check_completed",
            "differential_diagnosis_considered",
        ],
    ),

    Domain.INDUSTRIAL: DomainProfile(
        domain      = Domain.INDUSTRIAL,
        description = "Industrial automation — operational safety and uptime",

        # Moderate tightening: failures are costly but not immediately fatal
        confidence_floor_delta    = +0.05,
        chi_collapse_override     = 0.35,
        drift_threshold_override  = 0.10,

        preferred_goal_types = ["REMEDIATION", "CALIBRATION", "DOMAIN_PROBE"],

        min_epistemic_class = EpistemicClass.COHERENTLY_SYNTHESIZED,

        reasoning_constraints = [
            "consider system state before recommending action",
            "flag single points of failure",
            "distinguish reversible from irreversible actions",
            "safety interlock status must be verified before execution",
        ],

        prohibited_patterns = [
            "disable safety interlock",
            "override maintenance schedule",
            "assume sensor accuracy without calibration check",
        ],

        required_verifications = [
            "system_state_checked",
            "reversibility_assessed",
            "interlock_status_verified",
        ],
    ),

    Domain.FINANCIAL: DomainProfile(
        domain      = Domain.FINANCIAL,
        description = "Financial systems — regulatory compliance and risk management",

        # Standard tightening: financial errors have systemic consequences
        confidence_floor_delta    = +0.08,
        chi_collapse_override     = 0.30,
        drift_threshold_override  = 0.09,

        preferred_goal_types = ["CALIBRATION", "EXPLORATION"],

        min_epistemic_class = EpistemicClass.INFERRED,

        reasoning_constraints = [
            "cite regulatory basis for compliance claims",
            "distinguish market risk from operational risk",
            "flag model uncertainty explicitly",
            "never conflate correlation with causation in market analysis",
            "disclosure requirements must be noted",
        ],

        prohibited_patterns = [
            "guaranteed return",
            "no risk",
            "regulatory exception assumed",
        ],

        required_verifications = [
            "regulatory_basis_cited",
            "risk_classification_completed",
            "uncertainty_acknowledged",
        ],
    ),

    Domain.AUTONOMOUS_VEHICLE: DomainProfile(
        domain      = Domain.AUTONOMOUS_VEHICLE,
        description = "Autonomous vehicle control — real-time safety-critical decisions",

        # Most restrictive: real-time, physical world, life-safety
        confidence_floor_delta    = +0.15,
        chi_collapse_override     = 0.20,   # very tight
        drift_threshold_override  = 0.06,   # very tight

        preferred_goal_types = ["CONSOLIDATION", "REMEDIATION"],

        # AV decisions need empirical grounding — synthesis is not sufficient
        min_epistemic_class = EpistemicClass.EMPIRICALLY_VERIFIED,

        reasoning_constraints = [
            "sensor fusion state must be current at time of decision",
            "all road users must be modeled before action",
            "fallback path must be available before primary action",
            "time-to-collision must be within safe bounds",
            "regulatory traffic rules apply unconditionally",
        ],

        prohibited_patterns = [
            "assume sensor reliability without confirmation",
            "predict human behavior as certain",
            "override regulatory traffic rule",
        ],

        required_verifications = [
            "sensor_state_current",
            "all_road_users_modeled",
            "fallback_path_available",
            "ttc_within_bounds",
        ],
    ),

    Domain.GENERIC: DomainProfile(
        domain      = Domain.GENERIC,
        description = "Generic domain — default reasoning profile",

        confidence_floor_delta    = 0.0,
        chi_collapse_override     = None,
        drift_threshold_override  = None,

        preferred_goal_types = ["EXPLORATION", "CONSOLIDATION"],

        min_epistemic_class = EpistemicClass.COHERENTLY_SYNTHESIZED,

        reasoning_constraints = [
            "distinguish fact from inference",
            "acknowledge uncertainty where present",
        ],

        prohibited_patterns = [],

        required_verifications = [],
    ),
}


# ─── PROFILE LOADER ──────────────────────────────────────────────────────────

def get_profile(domain: Optional[str]) -> DomainProfile:
    """
    Return the DomainProfile for a given domain name.
    Falls back to GENERIC if domain is None or unrecognized.
    """
    if domain is None:
        return DOMAIN_PROFILES[Domain.GENERIC]
    try:
        d = Domain(domain.lower())
        return DOMAIN_PROFILES.get(d, DOMAIN_PROFILES[Domain.GENERIC])
    except ValueError:
        return DOMAIN_PROFILES[Domain.GENERIC]


def list_domains() -> List[str]:
    """Return list of supported domain names."""
    return [d.value for d in Domain]


# ─── TESTS ───────────────────────────────────────────────────────────────────

def run_tests() -> tuple:
    passed = failed = 0
    results = []

    def t(name, fn):
        nonlocal passed, failed
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))

    def test_all_domains_have_profiles():
        for d in Domain:
            assert d in DOMAIN_PROFILES, f"Missing profile for {d}"
    t("test_all_domains_have_profiles", test_all_domains_have_profiles)

    def test_get_profile_by_name():
        p = get_profile("medical")
        assert p.domain == Domain.MEDICAL
    t("test_get_profile_by_name", test_get_profile_by_name)

    def test_get_profile_unknown_returns_generic():
        p = get_profile("unknown_domain_xyz")
        assert p.domain == Domain.GENERIC
    t("test_get_profile_unknown_returns_generic",
      test_get_profile_unknown_returns_generic)

    def test_get_profile_none_returns_generic():
        p = get_profile(None)
        assert p.domain == Domain.GENERIC
    t("test_get_profile_none_returns_generic",
      test_get_profile_none_returns_generic)

    def test_medical_is_most_restrictive():
        medical = get_profile("medical")
        av      = get_profile("autonomous_vehicle")
        generic = get_profile("generic")
        # AV has highest delta, medical second, generic zero
        assert av.confidence_floor_delta > medical.confidence_floor_delta
        assert medical.confidence_floor_delta > generic.confidence_floor_delta
    t("test_medical_is_most_restrictive", test_medical_is_most_restrictive)

    def test_av_requires_empirically_verified():
        av = get_profile("autonomous_vehicle")
        assert av.min_epistemic_class == EpistemicClass.EMPIRICALLY_VERIFIED
    t("test_av_requires_empirically_verified",
      test_av_requires_empirically_verified)

    def test_medical_requires_inferred_minimum():
        medical = get_profile("medical")
        assert medical.min_epistemic_class == EpistemicClass.INFERRED
    t("test_medical_requires_inferred_minimum",
      test_medical_requires_inferred_minimum)

    def test_confidence_floor_for_applies_delta():
        medical = get_profile("medical")
        base = 0.75
        adjusted = medical.confidence_floor_for(base)
        assert adjusted == base + medical.confidence_floor_delta
    t("test_confidence_floor_for_applies_delta",
      test_confidence_floor_for_applies_delta)

    def test_confidence_floor_capped_at_099():
        av = get_profile("autonomous_vehicle")
        # Even with large delta, floor must not exceed 0.99
        adjusted = av.confidence_floor_for(0.95)
        assert adjusted <= 0.99
    t("test_confidence_floor_capped_at_099",
      test_confidence_floor_capped_at_099)

    def test_profile_to_dict_serializable():
        for d in Domain:
            profile = DOMAIN_PROFILES[d]
            json.dumps(profile.to_dict())
    t("test_profile_to_dict_serializable", test_profile_to_dict_serializable)

    def test_profile_is_immutable():
        p = get_profile("industrial")
        try:
            p.confidence_floor_delta = 0.0
            raise AssertionError("Should be immutable")
        except Exception as e:
            assert "frozen" in str(e).lower() or "can't" in str(e).lower() or "FrozenInstanceError" in type(e).__name__
    t("test_profile_is_immutable", test_profile_is_immutable)

    def test_list_domains_contains_all():
        domains = list_domains()
        for d in Domain:
            assert d.value in domains
    t("test_list_domains_contains_all", test_list_domains_contains_all)

    def test_av_has_tightest_chi_collapse():
        av      = get_profile("autonomous_vehicle")
        medical = get_profile("medical")
        # Both have overrides; AV should be tighter
        assert av.chi_collapse_override < medical.chi_collapse_override
    t("test_av_has_tightest_chi_collapse", test_av_has_tightest_chi_collapse)

    def test_generic_has_no_overrides():
        generic = get_profile("generic")
        assert generic.chi_collapse_override is None
        assert generic.drift_threshold_override is None
        assert generic.confidence_floor_delta == 0.0
    t("test_generic_has_no_overrides", test_generic_has_no_overrides)

    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("Labyrinth-OS — Domain Reasoning Profiles")
    print("Lane 1 complement to domain adapters. Bilateral domain coverage.")
    print("=" * 70)
    print()
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err:
            line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed")
    if failed:
        raise SystemExit(1)
    print()
    print("  Profiles loaded:")
    for d in Domain:
        p = DOMAIN_PROFILES[d]
        print(f"    {d.value:20} floor_delta={p.confidence_floor_delta:+.2f}  "
              f"min_class={p.min_epistemic_class.value}")
    print("\n  Domain Reasoning Profiles — COMPLETE")
    print("=" * 70)
