# Promotion Pipeline — Labyrinth-OS / L6.5

## Purpose

The promotion pipeline is the **decision boundary** between the epistemic side
(labels, watchers, council) and the execution side (Reality Gate → CGIR).

A label that passes promotion has earned the right to cross the Reality Gate.

## Position in the Architecture

```
Labeling (L3.5) → Archive (L5.5) → Promotion (L6.5) → Reality Gate (L10.5) → CGIR (L10)
                        ↑
                Observability (L5.75) feeds anomaly reports back
```

## Promotion Rules

| Rule | Condition |
|------|-----------|
| 1 — Confidence | `confidence ≥ 0.95` |
| 2 — Test Harness | TestHarness must pass all thresholds |
| 3 — No Archive Contradiction | Pattern must not have high failure rate |
| 4 — Historical Failure Rate | `historical_failure_rate ≤ 0.20` |
| 5 — Consecutive Runs | `consecutive_runs ≥ 3` (DEFERRED if not met) |

## Promotion Outcomes

| Outcome | Meaning |
|---------|---------|
| `APPROVED` | All rules passed — may cross Reality Gate |
| `DEFERRED` | Rules pass but insufficient run history |
| `REJECTED` | One or more rules failed — must not cross Reality Gate |

## Modules

| File | Role |
|------|------|
| `promotion_rules.py` | 5-rule evaluation engine |
| `test_harness.py` | Coherence/risk/latency/cost/compliance gating |
| `audit_trail.py` | Immutable promotion decision log |
| `rollback_protocol.py` | Revert and log production failures |
| `promotion_tests.py` | Unit + end-to-end tests |

## Invariants

- **I14** — Promotion Auditability: every promotion recorded with justification.
- **I10** — Fail Closed: default to REJECTED on any ambiguity.
- **I12** — Archive Integrity: promotion records written to archive before Gate.

## Non-Negotiable Rules

1. `APPROVED` requires ALL 5 rules to pass (not just majority).
2. Every promotion or rejection must be recorded in AuditTrail.
3. Rollbacks must be recorded in RollbackProtocol immediately.
4. No label may cross the Reality Gate without an `APPROVED` AuditRecord.
