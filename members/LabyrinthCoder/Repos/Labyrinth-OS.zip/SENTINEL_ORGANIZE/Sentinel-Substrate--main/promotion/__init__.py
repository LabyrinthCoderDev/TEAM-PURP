# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          promotion — Labyrinth-OS / Promotion Pipeline (L6.5)
# ----------------------------------------------------------------------------

"""
promotion — Labyrinth-OS / Promotion Pipeline (L6.5)
=====================================================
Promotion pipeline: rules, test harness, audit trail, rollback protocol.

Exports:
    PromotionRules, PromotionDecision   — rule engine
    TestHarness, HarnessResult          — pre-promotion testing
    AuditTrail, AuditRecord             — immutable promotion log
    RollbackProtocol, RollbackRecord    — revert promoted labels
"""

from promotion_rules import PromotionRules, PromotionDecision
from test_harness import TestHarness, HarnessResult
from audit_trail import AuditTrail, AuditRecord
from rollback_protocol import RollbackProtocol, RollbackRecord

__all__ = [
    "PromotionRules",
    "PromotionDecision",
    "TestHarness",
    "HarnessResult",
    "AuditTrail",
    "AuditRecord",
    "RollbackProtocol",
    "RollbackRecord",
]
