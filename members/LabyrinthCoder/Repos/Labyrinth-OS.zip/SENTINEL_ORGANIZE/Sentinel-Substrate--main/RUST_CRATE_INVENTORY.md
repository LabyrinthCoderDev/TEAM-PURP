# Labyrinth-OS — Rust Crate Inventory
## 29 Crates Mapped to Subsystems
## Ω Cipher · June 2026

> GPT external review (June 2026): "The Python side is becoming increasingly
> structured, but the Rust side is still largely isolated from the audit path.
> I would eventually add a single inventory file that maps each crate to the
> subsystem it belongs to."
>
> This file is the answer to that observation.

---

## How to Navigate the Rust Architecture

The 29 crates form five subsystems, each corresponding to a layer in the
Labyrinth-OS pipeline. The dependency flow is:

```
INPUT (sensors, shadow-ghost)
  ↓
LANE 1 REASONING (concept-engine, world-model, planner, council-resolver)
  ↓
GATE ENFORCEMENT (gate, signal-algebra, contracts, chancery-core)
  ↓
EXECUTION (cgir-*, aegis-cesk, ledger-chronicle, replay-gnosis)
  ↓
HARDWARE (hardware-rot, cgir-hardware)
```

---

## Subsystem 1 — Input and Observation Layer
*What enters the system before reasoning begins.*

| Crate | Purpose | Python Equivalent |
|-------|---------|-------------------|
| `shadow-ghost` | LLM boundary adapter — receives model output, strips raw text into structured signals | `logprob_bridge_adapter.py` |
| `vector-sensors` | Sensor observation layer — reads tau, chi, drift, betti_1, confidence from hardware or simulation | `humanoid_robot_adapter.py` |
| `common` | Shared types used across all crates — EpistemicLabel, ProposalId, ConfidenceScore | `epistemic_types.py` |

**Input Constitution note:** These three crates operate before the gate.
They are the first point where IC-1 (model identity) and IC-2 (input
provenance) controls would be inserted when the Input Constitution is built.

---

## Subsystem 2 — Lane 1 Reasoning Layer
*Analytical, creative, and epistemic processing before the gate.*

| Crate | Purpose | Python Equivalent |
|-------|---------|-------------------|
| `concept-engine` | Concept graph for Lane 1 L04 Analytical Core — builds semantic relationships | `meta_goal_engine.py` |
| `world-model` | World model state for Lane 1 — tracks environment state across trials | `continuous_learning_loop.py` |
| `planner` | Execution plan builder — sequences proposals into coherent plans | `ignition.py` (plan phase) |
| `council-resolver` | Merges Watcher A + Watcher B outputs into a single Council decision | `council_resolver.py` |
| `watcher-a` | Internal consistency auditor — structural signal analysis | `watcher_a_stub.py` |
| `watcher-b` | Adversarial signal auditor — contradiction and attack detection | `watcher_b_stub.py` |
| `transfer-engine` | Knowledge transfer between sessions — continuity across ignition runs | `archive_memory.py` |
| `offline-evolution` | Offline evolution engine — bounded mutation outside live pipeline | `promotion_rules.py` |

---

## Subsystem 3 — Gate Enforcement Layer
*Sigma Anchor checking, formal contracts, permit verification.*

| Crate | Purpose | Python Equivalent |
|-------|---------|-------------------|
| `gate` | Pre-CGIR gate with Sigma Anchor enforcement — tau/chi/drift/betti/confidence | `gate_function.py` |
| `signal-algebra` | Sigma Anchor signal algebra — formal properties of tau, chi, drift | `sigma_anchors.py` |
| `contracts` | Value contracts and risk contracts — formal behavioral boundaries | `gate_proof.py` |
| `chancery-core` | Verification harness for language-agent tool calls — capability typing | `predicate_extractor.py` |

---

## Subsystem 4 — Execution and Ledger Layer
*CGIR compilation, AEGIS execution, WORM ledger, replay.*

| Crate | Purpose | Python Equivalent |
|-------|---------|-------------------|
| `cgir-types` | Strongly-typed primitives for the CGIR system | `cgir_types.py` |
| `cgir-core` | Causal Graph IR core graph model | `cgir_core.py` |
| `cgir-compiler` | Full CGIR compilation pipeline | `cgir_compiler.py` |
| `cgir-codegen` | CGIR → deterministic bytecode code generation | `cgir_codegen.py` |
| `cgir-validator` | CGIR graph validation pipeline | `cgir_ledger.py` |
| `cgir-logical` | Logical inference over CGIR graphs | `z3_sovereignty_spec.py` |
| `cgir-signal` | Signal routing between CGIR layers | `sigma_anchors.py` |
| `cgir-temporal` | Temporal constraint checking for CGIR nodes | `timeline_validator.py` |
| `cgir-fuzzer` | Property-based fuzzing for CGIR invariants | `test_property_based.py` |
| `aegis-cesk` | AEGIS deterministic CESK runtime — pure execution engine | `aegis_cesk.py` |
| `ledger-chronicle` | WORM append-only ledger with hash chaining | `cgir_ledger.py` + `hashchain.py` |
| `replay-gnosis` | Exact chain replay and audit | `replay_gnosis.py` |

---

## Subsystem 5 — Hardware Enforcement Layer
*Silicon-level gates. Phase 10 (A014). Not yet active.*

| Crate | Purpose | Status |
|-------|---------|--------|
| `hardware-rot` | Hardware Root of Trust interface — FPGA + ATECC608B binding | Deferred — A014 |
| `cgir-hardware` | Hardware enforcement boundary — maps CGIR decisions to hardware signals | Deferred — A014 |

---

## Audit Status by Subsystem

| Subsystem | Crates | Python Tests Cover It | Rust Tests (cargo) | Notes |
|-----------|--------|-----------------------|-------------------|-------|
| Input/Observation | 3 | Partial | 249 total (all crates) | IC-1/IC-2 gap lives here |
| Lane 1 Reasoning | 8 | Yes — stubs tested | 249 total | council-resolver has 2 TODO markers |
| Gate Enforcement | 4 | Yes — fully tested | 249 total | Merkle permit now wired |
| Execution/Ledger | 12 | Yes — fully tested | 249 total | Z3 on owner machine |
| Hardware | 2 | N/A | N/A | Deferred A014 |

---

## The Rust/Python Differential

For each crate, the Python side contains the authoritative implementation
during the prototype phase. The Rust crates implement the same logic for
performance and hardware binding. The differential is tracked in:

  `tests/test_rust_python_differential.py` — 15 tests
  `KNOWN_GAPS.md` — GAP R4 (Rust/Python runtime parity)

When a constant or decision rule changes in Python (`sigma_anchors.py`,
`promotion_rules.py`), the corresponding Rust crate must be updated.
GAP R4 is PARTIAL until this is automated.

---

*Ω Cipher · June 2026*
*GPT external review recommendation — implemented*
