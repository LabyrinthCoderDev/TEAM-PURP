## Summary

<!-- Brief description of changes -->

## Architecture Compliance

- [ ] Changes comply with ARCHITECTURE.md
- [ ] Changes comply with INVARIANTS.md
- [ ] No hidden execution paths introduced
- [ ] No bypass flags introduced
- [ ] No state mutation outside AEGIS/CESK
- [ ] No execution in VECTOR, Watcher-A, or Watcher-B
- [ ] Gate remains pure and deterministic
- [ ] Ledger remains append-only
- [ ] All changes replayable

## Tests

- [ ] Unit tests added/updated
- [ ] Integration tests added/updated
- [ ] No existing tests broken
- [ ] Replay traces still valid

## Checklist

- [ ] Code compiles: `cargo build --workspace`
- [ ] Tests pass: `cargo test --workspace`
- [ ] No clippy warnings: `cargo clippy --workspace -- -D warnings`
- [ ] Formatted: `cargo fmt --all`
