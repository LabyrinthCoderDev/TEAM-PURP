---
name: Invariant Violation
about: Report a violation of a system invariant
labels: invariant-violation, critical
---

## Invariant Violated

<!-- Which invariant? I1-I10? -->

## Description

<!-- How is the invariant violated? -->

## Evidence

<!-- Replay trace, ledger entry, CGIR graph, or test case -->

## Impact

<!-- What is the impact of this violation? -->
