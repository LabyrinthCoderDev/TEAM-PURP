---
name: Bug Report
about: Report a bug in the Labyrinth-OS
labels: bug
---

## Bug Description

<!-- Clear description of the bug -->

## Affected Layer

<!-- Which layer is affected? L0-L15? Which crate? -->

## Invariant Violation

<!-- Does this violate any system invariant (I1-I10)? -->

## Reproduction Steps

1.
2.
3.

## Expected Behavior

<!-- What should happen? -->

## Actual Behavior

<!-- What actually happens? -->

## Replay Trace

<!-- If applicable, attach a ledger/replay trace that demonstrates the bug -->
