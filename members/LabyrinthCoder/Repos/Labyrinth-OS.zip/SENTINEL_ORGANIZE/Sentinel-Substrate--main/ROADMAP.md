# ROADMAP — Labyrinth-OS 

## Current State (May 2026)

All phases below are complete unless marked as blocked on external dependency.

---

## Phase 1 — Core Types ✓ COMPLETE
- [x] cgir-types: Severity, Confidence, TimeRange, Sigma Anchor constants
- [x] cgir-core: CGIRGraph, CGIRNode, edge types
- [x] common: Shared types, ContentHash, SessionId, Lane enum
- [x] signal-algebra: Severity merge rules, confidence computation

## Phase 2 — Validation Layer ✓ COMPLETE
- [x] cgir-validator: Graph validation pipeline
- [x] cgir-logical: Proposition tree, evaluate()
- [x] cgir-temporal: LogicalTime, TemporalConstraint
- [x] cgir-signal: SignalRouter, RoutedSignal
- [x] cgir-hardware: HardwareBoundary, hardware decision enforcement

## Phase 3 — Gate and Contracts ✓ COMPLETE
- [x] gate: GateFunction, GateVerdict, deterministic gate logic
- [x] contracts: Value contracts, risk contracts

## Phase 4 — Epistemic Layer ✓ COMPLETE
- [x] vector-sensors: Sensor observation structs
- [x] watcher-a: Internal consistency audit
- [x] watcher-b: Adversarial audit, TM-001 detection
- [x] council-resolver: Watcher merge → single SignalNode
- [x] cgir-compiler: Full compilation pipeline, fail-closed stages
- [x] cgir-codegen: CGIR → bytecode, deterministic

## Phase 5 — Execution Kernel ✓ COMPLETE
- [x] aegis-cesk: Deterministic CESK runtime
- [x] ledger-chronicle: WORM append-only ledger, hash chaining
- [x] replay-gnosis: Replay validator

## Phase 6 — Extended Layer ✓ COMPLETE
- [x] planner: ExecutionPlan, dependency validation
- [x] shadow-ghost: LLM boundary adapter (proposals only, always UNVERIFIED)
- [x] world-model: Lane 1 belief state, WorldModel
- [x] concept-engine: Concept graph, ConceptEdge, Relation types
- [x] transfer-engine: Session knowledge transfer, eligibility enforcement
- [x] offline-evolution: Offline mutation candidates, EntryPoint::Labeling only
- [x] hardware-rot: Root of Trust interface, simulation + silicon modes
- [x] cgir-fuzzer: Property-based adversarial testing

---

## Phase 7 — Compile + Verify ✓ COMPLETE (A012 VERIFIED)
- [x] cargo build --workspace — 29 crates, 0 errors
- [x] cargo test --workspace — 249 tests, 0 failures
- [x] rustc 1.75.0 compatible (uuid=1.6.1, chrono=0.4.38 pinned)

---

## Phase 8 — Real Inference (A010) — BLOCKED: needs API key
- [ ] python runtime/ignition.py --backend anthropic --model claude-sonnet-4-20250514 --trials 5
- [ ] verify_run.py confirms chain valid, A010 closed
- [ ] a010_monitor.py shows healthy signal distribution

## Phase 9 — Formal Verification — FUTURE
- [ ] TLA+ specs for ledger invariants
- [ ] Lean 4 state machine proof
- [ ] KeYmaera X control safety proof

## Phase 10 — Hardware Enforcement — BLOCKED: needs FPGA
- [ ] A002: 670µs FOLD timing on physical MachXO2
- [ ] A003: ATECC608B hardware attestation
- [ ] A014: Silicon validation under realistic load

## Multi-Sentinel Architecture — Xi-Jensen Pattern Available (ROADMAP Phase 11)

The Xi-Jensen pipeline (`archive/external_references/reactive_research_tools/
xi_jensen_pipeline/`) has already solved the multi-sentinel merging problem:

- Fast approximate scan (candidate generation)
- Certified deepcheck (verification layer)
- `certified_merge_v2.py` — iteration-safe merging: existing certified labels
  preserved if no new deepcheck row supplied. Failed deepchecks do not destroy
  existing certification.

This is the blueprint for the planned multi-sentinel architecture. The merging
logic is already implemented in a different domain — port it when Phase 11 begins.

## Phase 11 — Distributed Topology — FUTURE (post-A010)
- [ ] Multi-sentinel single machine
- [ ] Multi-node distributed ledger sync
- [ ] Byzantine consensus (< 1/3 failure tolerance)
- Reference: epistemic/experimental/distributed_topology_ref.md

---

## Effective Boolean Filter Integration (post-A010)

**Source:** `archive/external_references/reactive_research_tools/`
**Assessment:** `archive/external_references/reactive_research_tools/ASSESSMENT.md`

The Effective Boolean Filter is an independently built deterministic argument
evaluation pipeline that checks whether a yes/no argument preserves its polarity
under transformations. Its `trace_gate.py` independently arrived at the same
PipelineTrace / PromotionGate / RealityGate pattern as Labyrinth-OS — validating
that the pattern is fundamental, not domain-specific.

### Planned integration

**Stage 1 (hook wired):** Polarity evaluation hook is live in PromotionGate.
Attempts import of `effective_boolean_filter`, runs if present, skips gracefully
if absent. Functional conditional integration — not a stub.

    from effective_boolean_filter import evaluate_argument

    # In PromotionProtocol.evaluate():
    polarity_report = evaluate_argument(
        claim=proposal.claim,
        argument=proposal.reasoning,
        context=proposal.context,
        strictness="medium",
    )
    if polarity_report.effective_polarity == "untracked_shift":
        return receipt(approved=False, reason="untracked polarity shift in reasoning")

Promotion would then require:
  (a) confidence >= CONFIDENCE_FLOOR
  (b) no untracked polarity shifts in the proposal's reasoning

**Stage 2 (multi-sentinel):** Use Xi-Jensen two-layer pattern as model for
multi-sentinel certification: fast sentinel screens, certified sentinel gates.

**Stage 3 (long-term):** Full logical structure evaluation of LLM proposals
before they are allowed to cross the Reality Gate.

### Why this matters

Current Labyrinth-OS promotion evaluates confidence and run count.
It does not evaluate whether the reasoning is logically coherent.
A proposal with high confidence but an epistemic-to-ontological slip in its
reasoning chain should be blocked. This integration closes that gap.

---

## Phase 10.5 — Poole Manifold Integration (Post-A010)

*Design patterns borrowed from the Poole Manifold (Rooke Poole, April 2026)
after full source-code analysis (230 files). Each item below has a specific
source pattern, a specific target in Labyrinth-OS, and a specific reason.*

### P10.5-A: Orthogonal Channel → Close GAP 10 (HIGH)

**Source:** Trial 317 XOR gate — orthogonal escape valve for double-input mass.
**Target:** Reality Gate assertion logic in assert_can_enter_cgir().
**What:** Gate checks whether pipeline trace has LABELING stage (normal path)
OR FAILOVER_ENTRY with valid exception token (orthogonal path).
Neither path = structurally invalid, not just undocumented.
**Closes:** GAP 10 (UnlabeledProposal ornamental).

### P10.5-B: Three-Mask Architecture → Confidence Amplification (MEDIUM)

**Source:** Inhibitor/Threshold/Amplifier mask system — boost channels where
mass should flow freely, resist channels where mass should not.
**Target:** PromotionRules.evaluate() — wire PersistentMemoryStore.risk_estimate()
to apply ±0.05 confidence delta based on historical similarity.
**What:** Proposals similar to past successes get a small boost.
Proposals similar to past failures get a small dampening.
History becomes the amplifier mask.

### P10.5-C: Dark Forest Mechanic → TM-001 Class 11 PROMOTION_RACE (HIGH)

**Source:** Trial 398 — two-species competition with annihilation on voxel conflict.
**Target:** promotion_rules.py + tests/adversarial/threat_model.py.
**What:** Two proposals with same label_id reaching promotion simultaneously
both get blocked. CONFLICT entry logged to ledger.
**Closes:** Undocumented race condition attack vector.

### P10.5-D: Mass Telemetry → Pipeline Zone Telemetry (MEDIUM)

**Source:** Every Poole trial measures mass in specific spatial zones.
**Target:** chronicle_query.py — add PIPELINE_MASS entry type.
At each stage transition, log confidence×count for proposals in that stage.
**What:** Makes healing and promotion dynamics visible to operators.
Pressure buildup, leakage, and healing loop performance all observable.

### P10.5-E: Domain Adapter Pattern → Cross-Domain Specification (MEDIUM)

**Source:** Same Poole rule produces radically different behavior by changing
what gets fed into it (mask geometry).
**Target:** New document: DOMAIN_ADAPTER_SPEC.md
**What:** Formal specification for translating any domain's physical measurements
into the five Sigma Anchor channels (tau, chi, drift, betti_1, confidence).
Five domains: AI governance, industrial automation, medical, financial, autonomous vehicles.

### P10.5-F: Approval Flux Monitoring → L19 Observability (LOW, future)

**Source:** Succession flux Φ ≈ 0.3095 — equilibrium density of the manifold.
**Target:** L19 Observability layer.
**What:** At large scale, gate approval rate should converge to a characteristic
value. Deviation from that value is an early warning signal for gate
miscalibration or adversarial pressure.
**Note:** Deferred until system runs at scale with real inference data.
ApprovalFluxMonitor class already exists in chronicle_query.py. Calibrate post-A010.

### P10.5-G: Venturi Choke → Domain Resonance Gate (POST-A010)

**Source:** Rooke — "LABYRINTH-OS EXTENDED: The Domain-Adaptive Resonance Gate"
**Target:** execution/gate/cgir_gate.py domain adapter interface
**What:** Replace static Sigma Anchor threshold checking with resonance-peak
proximity checking. Instead of `tau < 0.75 → BLOCK`, use:
`if gaussian_distance(tau, domain_peaks["tau"]) < 0.05 → CHOKE → BLOCK`

The Venturi Choke fires when a reading is too far from the domain's ideal
operating peaks, not just when it crosses an absolute floor. More nuanced:
a tau of 0.80 passes our current threshold gate but might be far from a
domain's ideal 0.92-0.96 operating range.

**DomainResonanceProfile:** maps each domain to its ideal peaks per channel.
Alpha=0.35, sigma_sq=0.01 (same as Poole prime resonance parameters).
**Requires:** A010 live data to establish domain peaks empirically.
**Status:** NOT YET BUILT. Design: LABYRINTH-OS EXTENDED file in archive.

### P10.5-H: Directional Mutation → Channel-Aware Healing (BUILT — May 2026)

**Source:** Rooke — kinetic mass recycling principle (Poole Manifold healing).
**Target:** lane1/07_deferred_exploration/deferred_node.py
**What:** The failure type and blocked channel now shape the mutation direction.
Previously: ±10% on all parameters regardless of which channel failed.
Now: CHI failure → reduce chi-related parameters; CONFIDENCE failure → raise
confidence parameters; PREDICATE failure → reduce propagation scope; TAU failure
→ raise signal-health parameters.

The failure energy is directional — the nature of the failure shapes the repair.
**Status:** BUILT. 4 new tests passing. 1,556 total Python tests, 0 failures.

### P10.5-I: Resonance Latch → A014 Architecture Update (POST-A010)

**Source:** Rooke — CPU ARCHITECTURE V207: Immortal Latch (Radiation-Hardened SRAM)
**Target:** A014 hardware design spec (currently: FPGA + ATECC608B)
**What:** The Immortal Latch maintains state via continuous prime-resonance
regeneration, not bit-flip. An attacker must suppress the resonance continuously
rather than flip a single bit once. This changes the A014 architectural model:

Current A014 model: write-once enforcement (hardware prevents gate bypass).
Resonance Latch model: continuous enforcement (hardware regenerates correct state
after perturbation — radiation-hardened by topology, not just by write protection).

**Implication:** A014 specification should be updated to include regenerative
enforcement as the target, not just write-once protection. The Immortal Latch
is a stronger security guarantee than SRAM-style bit protection.
**Status:** NOT YET BUILT. Update A014 spec post-A010. Requires FPGA design.

---

### What We Are Not Taking (and Why, and When)

Non-local coupling: not now. Relevant for Phase 11 distributed topology.
Unbounded self-replication: never for single-node governance.
  Relevant for offline LLM swarm coordination as a separate module.
Cosmological expansion: subsumed by approval flux monitoring above (P10.5-F).
Materials science simulations: not applicable to governance substrate.
Quantum consciousness (Orch-OR): speculative, no current governance relevance.


### P10.5-J: Rooke Physics Sentinel — JAX/MPNN Hardware Layer (PARTIAL)

**Source:** Rooke — Albedo JAX/MPNN kinetic patch (May 2026)
**Status:** Python fallback BUILT + tested (12 tests). JAX path STUBBED.
**Location:** ALBEDO_MINI/physics_sentinel.py

Python fallback enforces the 7.0 Poole density invariant at ~50µs.
JAX MPNN path (PolynomialPeanoGlobalLayer) stubbed — awaiting Master
Hive Architecture codebase from Rooke.

When JAX layer is available:
  Replace stub in _compute_density_jax() with:
  from hive_architecture import PolynomialPeanoGlobalLayer
  layer = PolynomialPeanoGlobalLayer(cull_config)
  physics_state = layer(node_features)
  cull_certainty = float(physics_state[0, -1])

### EvolutionEngine — Runtime threshold adaptation (BUILT)

**Source:** labyrinth_os_portable_v2 audit fix (May 2026)
**Status:** BUILT, 7 tests passing.
**Location:** execution/gate/circuit_breaker.py

Adjusts session-level Sigma Anchor thresholds when block rate is
persistently high or low. Bounded at 10% per step (relative, not absolute).
Never modifies Z3-proven baseline constants. Session-scope only.
