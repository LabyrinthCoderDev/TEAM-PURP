# SECURITY — Labyrinth-OS

## Security Model

Labyrinth-OS enforces a **causally-closed, fail-closed** security model.

### Threat Model

- Untrusted intelligence in the proposal stratum is assumed adversarial.
- VECTOR observers may be manipulated but cannot write.
- Watchers are assumed to potentially fail independently.
- The Ledger is the ground truth; any tampering is detectable.

### The Operator Problem — Who Guards the Gate from the Gatekeeper?

This is the deepest political problem in the system. It is not the malicious
outsider. It is the legitimate actor who wants one exception.

**Current state:** Human overrides are logged as structured fields (G9) with
`override_signature="PENDING_HARDWARE_ATTESTATION"`. The override is embedded
in the receipt hash — it cannot be erased without breaking the chain. But it
is not cryptographically signed. A motivated operator with system access can
still alter thresholds, bypass the gate, or reset the ledger.

**What closes this:** A014 — FPGA + ATECC608B hardware enforcement.
Hardware converts "violation is detectable" into "violation is structurally
impossible." That is not an optimization. It is the difference between a
constitution and a suggestion.

**Until A014:** The system is fail-closed against external adversaries.
It is not yet fail-closed against the gatekeeper. Honest boundary.

---

### Security Boundary: Detection vs. Blocking

**This is the most important limitation to understand before evaluating this system.**

Labyrinth-OS blocks proposals whose Sigma Anchor readings cross formal thresholds.
It does not block proposals whose readings stay within thresholds even if
watcher signals indicate anomaly.

Specifically:

- Watcher-A detects internal logical contradiction.
- Watcher-B detects adversarial patterns from TM-001 attack classes.
- Both feed their signals into the Council.
- The Council produces a SignalNode with a severity level.
- The Gate blocks only if the severity causes a Sigma Anchor threshold to be crossed.

A well-crafted adversarial proposal that stays within all five Sigma thresholds
(tau, chi, drift, betti_1, confidence) will NOT be blocked by the gate — even
if watchers flag anomalies — unless those anomalies are severe enough to drive
sensor readings above the thresholds.

The predicate layer (predicate_extractor.py, LogicalSentinel) adds a second axis:
formal predicate verification that operates independently of sensor readings.
A proposal that passes all Sigma thresholds but fails Φ1, Φ2, or Φ3 will be
blocked. But the predicate patterns are still heuristic — a well-constructed
proposal that passes keyword extraction while being semantically harmful will
pass predicate verification.

**Summary:** The system detects more than it blocks. Detection evidence is logged
to the WORM ledger and is replayable. Blocking occurs only when formal thresholds
are crossed. This is a design choice, not a bug — the formal thresholds are
Z3-proven consistent (A021), which means they will not produce spurious blocks.
The trade-off is that sophisticated adversarial proposals within threshold bounds
are logged but not stopped. This limitation is documented in KNOWN_GAPS.md GAP 13.

### Security Properties

1. **No hidden execution paths** — all execution must pass through Gate and AEGIS.
2. **No bypass flags** — there are no flags, environment variables, or code paths that skip validation.
3. **Fail closed** — all ambiguous, invalid, or expired states result in rejection or fallback.
4. **Deterministic Gate** — Gate is a pure function; no randomness, no side effects.
5. **Immutable Ledger** — append-only, hash-chained, Hardware RoT attested.
6. **TM-001 Verified** — all 11 attack classes have detection tests (CONFIDENCE_SPOOF, GATE_EVASION, INVARIANT_STRIP, PARTIAL_WRITE, PHASE_SKIP, PROMOTION_RACE, REPLAY_ATTACK, SIGNAL_INJECTION, SPLIT_BRAIN, TEMPORAL_SPLICE, TIME_ORDER_MANIP). A017 VERIFIED.
6. **Read-only VECTOR** — no sensing layer can write.
7. **Watcher independence** — Watcher-A and Watcher-B operate independently and cannot execute.

### Reporting Vulnerabilities

If you discover a security vulnerability in this system, please report it privately.
Do not create public issues for security vulnerabilities.

Contact: [security contact TBD]

### Fuzzing

The cgir-fuzzer crate continuously generates hostile CGIR graphs.
See [docs/fuzzing/](docs/fuzzing/) for fuzzing documentation.
CI runs fuzzing targets on every pull request.

### Hardware Root of Trust

See [spec/HARDWARE_ROT.md](spec/HARDWARE_ROT.md) and the hardware-rot crate.
