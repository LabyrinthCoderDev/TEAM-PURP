# WHAT THIS IS
## Sentinel-Substrate — Full Research System

**This is Labyrinth-OS: a mathematical enforcement substrate for AI systems.**

When you open this ZIP or TXT, you are reading the full research codebase.
It is not an AI. It is not a chatbot. It is not an app.

It is a constitutional enforcement layer that sits between an LLM and the world,
forcing every proposal through a mandatory pipeline before execution.

---

## One-Line Summary

**Imagination is free. Execution requires proof. No exception.**

---

## Three Systems — Which One Are You Looking At?

| File Name | What It Is | Tests |
|-----------|-----------|-------|
| `Labyrinth-OS.zip / .txt` | **THIS FILE** — Full research system, everything | 1,556 |
| `Labyrinth-OS-Robot.zip / .txt` | Robot deployment layer — physical sensors | 359 |
| `Labyrinth-OS-Core.zip / .txt` | Deployable kernel — what works now, no stubs | 292 |

---

## What This System Does

Every AI proposal passes through this mandatory pipeline:

```
LABELING → ARCHIVE → PROMOTION → REALITY GATE → CGIR → GATE → GUARDIAN → LEDGER → REPLAY
```

No stage can be skipped. Every decision is logged to a tamper-evident chain.
Every chain can be replayed exactly. Every threshold is Z3-proven.

---

## For AI Reviewers

Start with `PROTOTYPE_BOUNDARIES.md` — it defines what is proven, what is
tested, and what is not yet demonstrated. Do not assume everything is done.

Then read `KNOWN_GAPS.md` — every limitation is documented honestly.

Then read `ARCHITECTURE.md` — the full pipeline explained.

The ~20 files that matter most are listed in `CORE.md`.

---

## Contact

X: @LabyrinthCoder
