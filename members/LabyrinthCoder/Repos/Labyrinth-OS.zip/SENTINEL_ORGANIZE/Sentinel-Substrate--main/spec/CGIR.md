# CGIR — Causal Graph Intermediate Representation

## Overview

CGIR is the ONLY semantic substrate. If it is not represented in CGIR, it does not exist inside the system.

## Node Types

### BaseNode (shared fields)
- `id`: NodeId
- `schema_version`: u32
- `logical_time`: LogicalTime
- `timestamp_ms`: u64
- `hash`: Hash
- `prev_hash`: Option<Hash>

### StateNode
- All BaseNode fields
- `state_root`: Hash
- `parent_state`: Option<NodeId>
- `data_hash`: Hash

### EventEdge
- All BaseNode fields
- `from`: NodeId (StateNode)
- `to`: NodeId (StateNode)
- `event_type`: String
- `payload_hash`: Hash
- `invariant_mask`: Vec<InvariantBinding>
- `signal_binding`: NodeId (SignalNode)
- `expected_latency_ns`: u64
- `max_latency_ns`: u64
- `execution_signature`: Signature

### SignalNode
- All BaseNode fields
- `severity`: Severity
- `confidence`: Confidence
- `category`: String
- `evidence_refs`: Vec<NodeId>
- `valid_for_time_range`: TimeRange
- `source`: String
- `emitted_by`: String (must be Council Resolver)

### TimedEdge
- All BaseNode fields
- `from`: NodeId
- `to`: NodeId
- `expected_latency_ns`: u64
- `max_latency_ns`: u64
- `observed_latency_ns`: Option<u64>
- `constraint_type`: String

### InvariantBinding
- All BaseNode fields
- `rule`: String
- `scope`: String
- `status`: InvariantStatus (Pass | Fail | Partial)
- `failure_code`: Option<String>

### HardwareBinding
- All BaseNode fields
- `binding_type`: String
- `mmio_address`: Option<u64>
- `status`: HardwareStatus
- `signature`: Signature

## CGIRGraph

A CGIRGraph is a directed acyclic graph (for state transitions) containing
all of the above node types plus metadata:

- `nodes`: Map<NodeId, CGIRNode>
- `schema_version`: u32
- `root`: NodeId (initial StateNode)
- `tip`: NodeId (current StateNode)
