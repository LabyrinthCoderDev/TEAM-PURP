# LABELING — Formal Labeling Specification

## Overview

The labeling layer (L3.5) is the first classification step for every epistemic
artifact in the Labyrinth-OS pipeline.  It assigns a **LabelCategory** and a
**confidence score** to every proposal that emerges from the sensor fabric.

## Label Categories

```
VALID      — passed all validation; may advance to promotion
UNCERTAIN  — below confidence floor; needs more sensor signal
REJECTED   — failed validation; must not advance
DEFERRED   — structurally valid but out of current scope
```

## Confidence Tiers

```
HIGH          ≥ 0.85  — eligible for promotion
MEDIUM        ≥ 0.60  — valid but not promotable
LOW           ≥ 0.35  — uncertain; needs more signal
UNINITIALIZED < 0.35  — not yet scored
```

## Confidence Components

```
composite = 0.40 × sensor_agreement
          + 0.35 × historical_success
          + 0.25 × temporal_consistency
```

## Validation Rules

1. `label_id` — non-empty string, globally unique within a session.
2. `source` — non-empty string identifying the originating module.
3. `confidence` — float in [0.0, 1.0] or None.
4. `VALID` category requires `confidence ≥ 0.60`.
5. `REJECTED` category requires `rejection_reason` to be set.
6. Labels must not exceed their TTL.
7. Duplicate `label_id` is always rejected.

## Rejection Reasons

| Reason | Trigger |
|--------|---------|
| `SCHEMA_VIOLATION` | Required field missing or wrong type |
| `CONFIDENCE_BELOW_THRESHOLD` | Score below 0.60 |
| `POLICY_VIOLATION` | Contradicts a hard policy rule |
| `STALE_LABEL` | Exceeded TTL |
| `ARCHIVE_CONTRADICTION` | Contradicts archived pattern |
| `DUPLICATE_LABEL` | Same label_id already registered |
| `MISSING_SOURCE` | No originating sensor chain |

## Promotion Threshold

To advance beyond the labeling layer into the promotion pipeline:
- `confidence ≥ 0.85`
- `category == VALID`
- No TTL violation

## Invariant: I11 — Labeling Closure

> Only VALID labels with confidence ≥ 0.85 may reach the Reality Gate.

Enforced by: `label_validator.py`, `gate_binding.py`

## Archive Integration

Every sealed LabelRecord is written to the MemoryStore as an `EntryType.LABEL`
entry.  The `seal_hash()` method produces the hash anchored to the chain.
