# SHADOW / GHOST MODE — Specification

## Overview

For every real execution, N shadow branches run in parallel.
Shadow branches NEVER modify live state.

## Comparison Metrics

| Metric | Description |
|--------|-------------|
| Coherence | Internal consistency of shadow output |
| Causal lift | Improvement in causal structure |
| Risk | Risk score of shadow path |
| Latency | Expected execution latency |
| Cost | Computational cost |
| Contract compliance | Contract satisfaction rate |
| Failure rate | Observed failure frequency |

## Promotion Path

```
Shadow → Replay → Value Contract → Gate Promotion
```

1. Shadow branch produces candidate
2. Candidate is replayed for validation
3. Value Contract evaluates suitability
4. Gate Promotion proposal is submitted for offline Gate review

## Non-Negotiable

- Live self-modification is NEVER allowed
- Shadow results are PROPOSALS until Gate-promoted
- All promotions happen offline
