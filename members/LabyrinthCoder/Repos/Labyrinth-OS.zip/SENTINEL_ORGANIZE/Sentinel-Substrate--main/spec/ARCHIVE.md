# ARCHIVE — Formal Archive Memory Specification

## Overview

The archive (L5.5) is the **epistemic memory** of Labyrinth-OS.  It is an
append-only, SHA-256-chained record of every epistemic event — analogous to
the Ledger (L13) but for the epistemic side of the pipeline.

## Append-Only Guarantee

- No record may be deleted.
- No record may be modified.
- Every record is linked to the previous via SHA-256 (`prev_hash`).
- `MemoryStore.verify()` recomputes the chain from genesis and detects any tampering.

## Entry Types

| Type | Meaning |
|------|---------|
| `LABEL` | A sealed LabelRecord |
| `PROMOTION` | A promotion decision (APPROVED/REJECTED/DEFERRED) |
| `REJECTION` | A Reality Gate rejection |
| `ANOMALY` | An observability anomaly |
| `OUTCOME` | The observed outcome of a promoted label in production |

## Hash Chain

```
entry_hash = SHA-256(
  entry_id | entry_type | label_id | payload | timestamp_ms | prev_hash
)
```

Genesis entry: `prev_hash = "0" * 64`

## Pattern Catalog

The PatternCatalog maintains an index over archived labels:

```python
PatternIndex:
  pattern_key      = f"{category}|{source}|{content[:32]}"
  occurrences      int
  successes        int
  failures         int
  avg_confidence   float
  last_seen        float
  success_rate     = successes / (successes + failures)  # default 0.5
```

## Confidence Record

Tracks: label → outcome → was_confidence_right?

```
confidence_was_right:
  outcome == SUCCESS and predicted_conf ≥ 0.60  →  True
  outcome == FAILURE and predicted_conf < 0.60   →  True
  otherwise                                      →  False
```

Global accuracy = |correct| / |resolved|

## Recall Protocol

```python
recall.similar_patterns(category, min_occurrences=2)
  → RecallResult:
      historical_success  weighted mean success rate
      recommendation      "PROMOTE" (≥0.80) | "CAUTION" (≥0.50) | "BLOCK"
```

## Invariant: I12 — Archive Integrity

> The archive is append-only.  Any modification or deletion of a record
> is detectable via SHA-256 chain verification.

Enforced by: `memory_store.py` (no delete/modify methods, chain verified by `verify()`)
