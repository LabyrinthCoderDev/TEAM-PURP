# HARDWARE ROOT OF TRUST — Specification

## Overview

The Hardware RoT (L15) provides cryptographic attestation, timing,
and fail-closed guarantees.

## Capabilities

| Capability | Description |
|-----------|-------------|
| Signing | Signs ledger entries with hardware key |
| TEE | Trusted Execution Environment isolation stubs |
| FPGA latch | Hardware state latch stubs |
| Timestamp core | Monotonic hardware timestamp |
| Kill-switch | Fail-closed halt |

## Ledger Integration

Every ledger entry includes an RoT receipt (hardware signature).
This makes tampering detectable.

## Kill-Switch

On invalid state, invalid signal, or hardware fault, the RoT kill-switch
triggers a fail-closed halt. The system does NOT continue in an invalid state.

## Stubs

Current implementation provides stubs for all capabilities.
Production integration requires hardware binding.
