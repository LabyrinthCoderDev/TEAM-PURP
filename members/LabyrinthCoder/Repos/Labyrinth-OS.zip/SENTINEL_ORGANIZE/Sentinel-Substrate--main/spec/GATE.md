# GATE — Decision Authority

## Overview

Gate is the ONLY decision authority. Gate is a pure deterministic function.

```
Gate(CGIR, SignalNode, Contract) → GateDecision
```

## GateDecision Values

| Decision | Meaning |
|----------|---------|
| ALLOW | Execute as proposed |
| MODIFY | Execute with constraints |
| THROTTLE | Execute at reduced rate |
| FALLBACK | Execute π₀ fallback instead |
| HARD_FAIL | Reject, do not execute |

## Decision Priority

Evaluated in strict priority order:

1. **Ledger violation** → HARD_FAIL
2. **Critical SignalNode** → HARD_FAIL
3. **Temporal / hardware violation** → HARD_FAIL or FALLBACK
4. **Contract violation** → THROTTLE or FALLBACK
5. **VECTOR risk score** → THROTTLE or MODIFY
6. **Planner proposal quality** → MODIFY or ALLOW

## Invariants

- Gate is pure (no side effects, no I/O)
- Gate is deterministic (same inputs → same output)
- Gate is the ONLY authority (nothing bypasses Gate)
- Gate never self-modifies

## Implementation

See the `gate` crate.
