# NOTES — Specification Notes

## Design Decisions

### Why CGIR?

CGIR provides a formal, machine-checkable semantic substrate. By requiring all
execution to be represented in CGIR, we eliminate hidden execution paths and
ensure every action is auditable, replayable, and formally verifiable.

### Why exactly one SignalNode per cycle?

Multiple competing signals create ambiguity at Gate. The Council Resolver
enforces a single normalized signal, ensuring Gate always has a clear,
deterministic input.

### Why fail-closed?

Security-critical systems must fail safely. A system that continues in an
ambiguous or invalid state is more dangerous than a system that halts.

## Open Questions

- TODO: Define precise χ (chi) stability metric formula
- TODO: Define C2G-RL (Causal-to-Gate Response Latency) bounds
- TODO: Define exact MMIO address space for hardware bindings
- TODO: Finalize TEE integration approach (SGX? TrustZone? other?)

## References

- CESK machines: Felleisen & Friedman, 1987
- TLA+: Lamport, 2002
- Hardware RoT: TCG specifications
