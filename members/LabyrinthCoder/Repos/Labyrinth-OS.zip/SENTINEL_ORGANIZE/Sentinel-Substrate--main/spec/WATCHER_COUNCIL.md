# WATCHER COUNCIL — Specification

## Overview

Two independent watchers produce audit signals.
Council Resolver merges them into exactly one SignalNode.

## Watcher-A (L3) — Internal Consistency Auditor

Checks:
- System invariants
- Expected behavior patterns
- System sanity
- Replay assumptions

Cannot execute. Cannot mutate state. Cannot bypass Gate.

## Watcher-B (L4) — Adversarial Auditor

Checks:
- Same evidence as Watcher-A (independently)
- Watcher-A for bias drift
- Watcher-A for audit corruption
- Watcher-A for silent failure
- Watcher-A for false confidence

Cannot execute. Cannot mutate state. Cannot bypass Gate.

## Council Resolver (L5)

Resolution rules:

| Condition | Severity Effect | Confidence Effect |
|-----------|-----------------|-------------------|
| Agreement | Unchanged | Reinforced |
| Disagreement | Escalated | Reduced |
| Critical disagreement | CRITICAL | Minimum |

Output: exactly one normalized SignalNode.

## Invariants

- I4: Exactly one SignalNode per event cycle
- I8: Resolution is deterministic
