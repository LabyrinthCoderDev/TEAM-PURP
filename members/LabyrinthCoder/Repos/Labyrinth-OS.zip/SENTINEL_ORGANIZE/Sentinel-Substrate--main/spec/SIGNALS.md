# SIGNALS — SignalNode Specification

## Overview

Signals annotate. Signals NEVER decide.

## SignalNode Fields

- `severity`: Severity (Info | Warning | Error | Critical)
- `confidence`: Confidence (f64 in [0.0, 1.0])
- `category`: String
- `evidence_refs`: Vec<NodeId>
- `valid_for_time_range`: TimeRange
- `source`: String (VECTOR, Watcher-A, Watcher-B, Council)
- `emitted_by`: String (must be Council Resolver for CGIR-bound signals)

## Invariants

- Exactly one SignalNode enters CGIR per event cycle (I4)
- Signals must be valid for their logical time (I5)
- Only Council Resolver may emit CGIR-bound SignalNodes
- Signal severity and confidence merge is deterministic (I8)

## Severity Levels

| Level | Value | Meaning |
|-------|-------|---------|
| Info | 0 | Informational annotation |
| Warning | 1 | Elevated risk observed |
| Error | 2 | Significant risk or inconsistency |
| Critical | 3 | Immediate HARD_FAIL required |

## Signal Algebra

See the `signal-algebra` crate for aggregation, decay, and escalation rules.
