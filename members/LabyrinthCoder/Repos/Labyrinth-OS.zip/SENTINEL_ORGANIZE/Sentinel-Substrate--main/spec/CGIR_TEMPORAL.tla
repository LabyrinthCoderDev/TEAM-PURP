---- MODULE CGIR_TEMPORAL ----
\* TLA+ specification for CGIR temporal properties
\* TODO: Implement full TLA+ model

EXTENDS Naturals, Sequences

\* Temporal validity: logical time is monotonically increasing
MonotonicLogicalTime == \A i, j \in DOMAIN ExecutionTrace :
    i < j => ExecutionTrace[i].logical_time <= ExecutionTrace[j].logical_time

\* Latency bounds: expected <= max
LatencyBounds == \A edge \in CGIREdges :
    edge.expected_latency_ns <= edge.max_latency_ns

\* No negative latency
NoNegativeLatency == \A edge \in CGIREdges :
    edge.expected_latency_ns >= 0 /\ edge.max_latency_ns >= 0

\* Signal temporal validity
SignalValidity == \A signal \in Signals :
    signal.bound =>
        signal.logical_time \in signal.valid_for_time_range

\* TODO: Complete TLA+ temporal model
====
