# LEDGER — Chronicle Specification

## Overview

The Ledger is the truth layer. All committed executions are recorded.
No entry may ever be modified or deleted.

## Ledger Entry

| Field | Type | Description |
|-------|------|-------------|
| state_before | Hash | StateNode hash before execution |
| proposal | Hash | CGIR edge hash |
| signals | Vec<SignalNode> | Bound SignalNodes |
| gate_decision | GateDecision | Gate output |
| contracts | Vec<Hash> | Evaluated contract hashes |
| timing | TimingRecord | Timestamps and latency |
| state_after | Hash | StateNode hash after execution |
| hash | Hash | This entry's content hash |
| receipt | Signature | Hardware RoT attestation |

## Hash Chaining

Each entry's `hash` includes the previous entry's hash.
This creates a tamper-evident chain.

## Invariants

- I6: Ledger is canonical history (no modification, no deletion)
- I9: All committed executions must be replayable from ledger
