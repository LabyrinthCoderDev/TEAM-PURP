-------------------------------- MODULE EPISTEMIC --------------------------------
(* TLA+ Specification for the Labyrinth-OS Epistemic Pipeline *)
(* Layers L3.5 (Labeling) through L6.5 (Promotion)            *)

EXTENDS Integers, Sequences, FiniteSets

CONSTANTS
    LabelIDs,          (* Set of all possible label identifiers *)
    ConfidenceValues,  (* Modelled as integers 0..100 scaled by 1/100 *)
    MaxConsecutiveRuns (* Minimum consecutive runs required = 3 *)

VARIABLES
    labels,            (* Function: LabelID → LabelRecord *)
    archive,           (* Append-only sequence of ArchiveEntries *)
    promoted,          (* Set of LabelIDs that are APPROVED *)
    audit_records,     (* Sequence of AuditRecords *)
    gate_decisions     (* Sequence of GateDecisions *)

(* ─── TYPE INVARIANTS ───────────────────────────────────────────────────── *)

LabelCategories == {"VALID", "UNCERTAIN", "REJECTED", "DEFERRED"}

TypeInvariant ==
    /\ \A id \in DOMAIN labels :
        /\ labels[id].category \in LabelCategories
        /\ labels[id].confidence \in 0..100 \cup {-1}  (* -1 = None *)
    /\ \A i \in 1..Len(archive) :
        /\ archive[i].entry_type \in {"LABEL","PROMOTION","REJECTION","ANOMALY","OUTCOME"}
    /\ \A id \in promoted :
        /\ id \in DOMAIN labels
        /\ labels[id].category = "VALID"

(* ─── I11: LABELING CLOSURE ─────────────────────────────────────────────── *)
(*                                                                             *)
(* Only VALID labels with confidence ≥ 85 may be promoted.                   *)

LabelingClosure ==
    \A id \in promoted :
        /\ labels[id].category = "VALID"
        /\ labels[id].confidence >= 85

(* ─── I12: ARCHIVE INTEGRITY ─────────────────────────────────────────────── *)
(*                                                                             *)
(* The archive is append-only: its length is non-decreasing.                 *)

ArchiveMonotonicity ==
    Len(archive) >= 0  (* Trivially true; enforced by append-only API *)

(* ─── I14: PROMOTION AUDITABILITY ──────────────────────────────────────────── *)
(*                                                                               *)
(* Every element of promoted has a corresponding AuditRecord.                   *)

PromotionAuditability ==
    \A id \in promoted :
        \E i \in 1..Len(audit_records) :
            /\ audit_records[i].label_id = id
            /\ audit_records[i].outcome = "APPROVED"

(* ─── I15: FEEDBACK LOOP CLOSURE ─────────────────────────────────────────── *)
(*                                                                              *)
(* Anomalies in the archive must not increase label confidence.                *)
(*                                                                              *)
(* Modelled as: for any label that has ANOMALY entries,                        *)
(* its confidence is no higher than at the time of the first anomaly.          *)

FeedbackLoopClosure ==
    \A id \in DOMAIN labels :
        LET anomalies == SelectSeq(archive, LAMBDA e :
                            /\ e.entry_type = "ANOMALY"
                            /\ e.label_id = id)
        IN  Len(anomalies) > 0 =>
                labels[id].confidence <= labels[id].confidence_at_first_anomaly

(* ─── GATE DETERMINISM ───────────────────────────────────────────────────── *)
(*                                                                             *)
(* Gate decisions are deterministic: two decisions with the same inputs       *)
(* produce the same verdict.                                                  *)

GateDeterminism ==
    \A i, j \in 1..Len(gate_decisions) :
        gate_decisions[i].inputs = gate_decisions[j].inputs
        =>
        gate_decisions[i].verdict = gate_decisions[j].verdict

(* ─── SPEC ───────────────────────────────────────────────────────────────── *)

Spec == TypeInvariant
     /\ LabelingClosure
     /\ ArchiveMonotonicity
     /\ PromotionAuditability
     /\ GateDeterminism

================================================================================
