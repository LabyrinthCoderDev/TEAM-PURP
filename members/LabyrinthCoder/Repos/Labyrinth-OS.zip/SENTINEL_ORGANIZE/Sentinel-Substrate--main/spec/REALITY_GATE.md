# REALITY_GATE — Formal Reality Gate Specification

## Overview

The Reality Gate (L10.5) is the explicit architectural boundary between the
epistemic side and the execution substrate.  It is the last checkpoint before
a label enters CGIR.

## Decision Logic

```
Input:  label_id, confidence, promoted, label_category

Check 1: promoted == True          →  if False → NO (NOT_PROMOTED)
Check 2: label_category == "VALID" →  if False → NO (INVALID_CATEGORY)
Check 3: confidence ≥ 0.85         →  if False → NO (CONFIDENCE_TOO_LOW)

Output: YES  (label may enter CGIR)
     or NO   (label is blocked + rejection logged)
```

## Determinism Guarantee

The gate is a **pure function**.  Same inputs → same outputs.  No state,
no randomness, no side effects.

```
decision_hash = SHA-256(
  label_id | confidence | promoted | verdict | timestamp_ms
)
```

## Gate Binding Rules

All five binding rules must pass for a YES decision:

| Rule | Requirement |
|------|-------------|
| `MUST_BE_PROMOTED` | Promotion pipeline returned APPROVED |
| `MUST_HAVE_AUDIT_RECORD` | AuditRecord exists in AuditTrail |
| `MUST_HAVE_CGIR_PROOF` | CGIR proof attached to edge |
| `CONFIDENCE_ABOVE_THRESHOLD` | confidence ≥ 0.85 |
| `CATEGORY_MUST_BE_VALID` | category == "VALID" |

## Gate Proof

Every YES decision issues a GateProof:

```
proof_hash = SHA-256(
  label_id | decision_hash | audit_trail_hash | confidence | timestamp_ms
)
```

The proof is anchored to the Ledger (L13) for immutability.
`GateProof.verify()` allows reconstruction and tamper detection.

## Rejection Reasons

| Reason | Trigger |
|--------|---------|
| `CONFIDENCE_TOO_LOW` | confidence < 0.85 |
| `NOT_PROMOTED` | promotion pipeline did not return APPROVED |
| `POLICY_VIOLATION` | hard policy rule violated |
| `UNREVIEWED` | label has not been reviewed |
| `INVALID_CATEGORY` | category ≠ VALID |
| `BINDING_RULE_FAILED` | one or more binding rules failed |

Rejections are logged in `GateRejector`.  If rejection count ≥ escalation
threshold, an escalation alert is raised.

## Invariants

### I2 — Gate Determinism

> The Reality Gate is a pure function.  Same inputs → same decision.

Enforced by: `gate_function.py` (no state, no side effects)

### I5 — Gate Precedence

> Reality Gate NO is binding.  The CGIR Gate (L11) may only further restrict,
> never upgrade, a Reality Gate NO to YES.

### I10 — Fail Closed

> On any ambiguity: NO, not YES.

Enforced by: `gate_function.py` — all rejection conditions block first.
