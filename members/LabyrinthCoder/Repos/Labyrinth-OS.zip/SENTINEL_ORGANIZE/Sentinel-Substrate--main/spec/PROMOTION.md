# PROMOTION — Formal Promotion Specification

## Overview

Promotion is the process by which an epistemic label earns the right to cross
the **Reality Gate** and enter the execution substrate.

Promotion is the last epistemic checkpoint before execution begins.

## Two-Threshold Design

Labyrinth-OS uses two distinct confidence thresholds:

| Stage | Threshold | Purpose |
|-------|-----------|---------|
| Promotion (L6.5) | **0.95** | Label must have very high confidence before being APPROVED |
| Reality Gate (L10.5) | **0.85** | Last-mile check — confidence must still hold at crossing time |

The promotion threshold (0.95) is higher than the Reality Gate floor (0.85) because
a label's confidence can decay between promotion approval and gate crossing.  The gate
provides a safety net for that decay window.  Both thresholds are intentional — this
is **defense-in-depth**.

## Promotion Rules

A candidate must satisfy **all five rules** to receive `APPROVED` status.

### Rule 1 — Confidence Threshold
```
candidate.confidence ≥ 0.95
```

### Rule 2 — Test Harness
```
TestHarness.run(candidate).passed == True

  where:
    coherence         ≥ 0.80
    risk              ≤ 0.20
    latency_ms        ≤ 5000
    cost_units        ≤ 100
    compliance_score  ≥ 0.90
```

### Rule 3 — No Archive Contradiction
```
PatternCatalog.lookup(candidate).success_rate ≥ 0.30
OR pattern has < 3 occurrences (insufficient data → neutral)
```

### Rule 4 — Historical Failure Rate
```
historical_failure_rate ≤ 0.20
```

### Rule 5 — Consecutive Runs (soft)
```
consecutive_runs ≥ 3
(violation → DEFERRED, not REJECTED)
```

## Promotion Outcomes

| Outcome | Meaning |
|---------|---------|
| `APPROVED` | All 5 rules satisfied |
| `DEFERRED` | Rules 1–4 pass, Rule 5 not yet met |
| `REJECTED` | One or more of Rules 1–4 failed |

## Audit Trail Format

Every promotion decision (APPROVED, DEFERRED, or REJECTED) is recorded in the
`AuditTrail` with:

```
audit_id        Sequential integer
label_id        Candidate label
outcome         APPROVED | DEFERRED | REJECTED
approved_by     Approver identity (steward, agent, or None for auto)
justification   Human-readable reason
decision_reasons List of rule outcomes
harness_summary TestHarness result summary string
timestamp       Unix epoch float
```

The AuditTrail is **append-only** — no record may be modified or deleted.

## Rollback Conditions

| Condition | Trigger |
|-----------|---------|
| `PRODUCTION_FAILURE` | Promoted label causes execution failure |
| `SAFETY_VIOLATION` | Safety invariant violated in production |
| `COHERENCE_COLLAPSE` | τ drops below 0.75 in production |
| `MANUAL_OVERRIDE` | Steward or operator forces rollback |
| `ARCHIVE_CONTRADICTION` | Archive analysis reveals past failure |

## Invariant: I14 — Promotion Auditability

> All promotions are recorded in the AuditTrail with justification.
> No promotion may occur without an AuditRecord.

Enforced by: `audit_trail.py`, `gate_binding.py` (MUST_HAVE_AUDIT_RECORD rule)
