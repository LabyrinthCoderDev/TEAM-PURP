# REPLAY — Gnosis Specification

## Overview

Replay must reconstruct all valid executions from the Ledger.
Replay is the primary validation mechanism.

## Capabilities

- Full execution replay from ledger entries
- Causal chain tracing
- Root-cause analysis (RCA)
- Invariant verification over replay trace
- Divergence detection

## Replay Procedure

1. Load ledger entries in order
2. For each entry:
   a. Reconstruct CESK state from `state_before`
   b. Apply the CGIR edge (via AEGIS read-only simulation)
   c. Verify resulting state matches `state_after`
   d. Verify all invariants hold
3. Report any divergence

## Invariant: I9 Replayability

If any committed execution cannot be replayed exactly, that is a CRITICAL failure.
