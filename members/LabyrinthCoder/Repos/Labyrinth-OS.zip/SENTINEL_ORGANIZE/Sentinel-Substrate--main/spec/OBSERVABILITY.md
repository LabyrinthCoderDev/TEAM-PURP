# OBSERVABILITY — Formal Observability Specification

## Overview

The observability layer (L5.75) provides full visibility into the epistemic
pipeline by tracking metrics, detecting drift, logging anomalies, and closing
the feedback loop.

## Metrics

### Σ Anchor Constants

| Constant | Value | Violation |
|----------|-------|-----------|
| `TAU_ESCAPE_FLOOR` | 0.75 | τ below → CRITICAL |
| `DRIFT_THRESHOLD` | 0.12 | drift ≥ → ERROR |
| `CHI_WARN` | 0.15 | χ ≥ → WARN |
| `CHI_COLLAPSE` | 0.40 | χ ≥ → CRITICAL |
| `BETTI_1_CAP` | 0.045 | β₁ ≥ → ERROR |

### Health Classification

```
CRITICAL  if  τ < 0.75  OR  χ ≥ 0.40
ERROR     if  drift ≥ 0.12  OR  β₁ ≥ 0.045
WARN      if  χ ≥ 0.15
OK        otherwise
```

## Drift Detection

The DriftDetector compares incoming snapshots to a rolling baseline
(last 30 snapshots).  A drift alert is raised when:

```
|current - baseline| ≥ DRIFT_THRESHOLD (0.12)
```

Alert severity:
```
delta ≥ 2 × DRIFT_THRESHOLD  →  CRITICAL
delta ≥ DRIFT_THRESHOLD       →  ERROR
```

## Anomaly Log

The AnomalyLog is append-only.  Every entry carries:
- `severity`    WARN | ERROR | CRITICAL
- `metric`      which metric triggered the anomaly
- `description` human-readable
- `label_id`    associated label (if any)
- `confidence`  at time of anomaly

## Feedback Loop

The FeedbackLoop translates anomaly counts into confidence adjustments:

```
adjustment = (
  -0.08 × critical_count
  -0.03 × error_count
  -0.01 × warn_count
)
adjusted_conf = max(0.0, current_confidence + adjustment)
demote_flag  = adjusted_conf < 0.60
promote_flag = adjusted_conf ≥ 0.85
```

The adjustment is always ≤ 0 (anomalies reduce confidence, never increase it).

## Invariants

### I13 — Observability Completeness

> All metrics are logged at each pipeline stage.

Enforced by: `MetricsCollector.emit()` called at every stage boundary.

### I15 — Feedback Loop Closure

> Anomalies flow back to the labeling layer via the feedback loop.

Enforced by: `FeedbackLoop.process()` called at end of each evaluation cycle.
