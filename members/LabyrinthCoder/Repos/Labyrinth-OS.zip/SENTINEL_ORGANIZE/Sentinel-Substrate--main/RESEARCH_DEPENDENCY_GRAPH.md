# Labyrinth-OS — Research Dependency Graph
## Causal Dependencies Between System Capabilities
## Ω Cipher · June 2026

> GPT external review (June 2026): "Your system has reached the size where
> causal dependencies matter more than file counts. Not code dependencies.
> Research dependencies."
>
> This file maps the causal chain — what must exist before what else can exist.

---

## The Full Dependency Chain

```
INPUT CONSTITUTION (GAP 13 — MISSING)
         │
         │  Without this: every downstream layer reasons about
         │  information whose provenance is unverified.
         │
         ▼
IDENTITY LAYER (IC-1 partial at A010)
  Model fingerprint in ledger entries
  provenance_chain field on proposals
         │
         ▼
SIGMA ANCHOR VALIDATION
  tau_escape_floor, chi_warn, chi_collapse
  drift_threshold, betti_1_cap, confidence_floor
  (Z3 proven — A021 VERIFIED)
         │
         ▼
BOUNDED SENSOR GATE
  Rate gate, bound gate, staleness gate
  Before PhysicsSentinel and pipeline
         │
         ▼
MERKLE PERMIT SET
  12 permitted action types committed
  Unknown action types structurally excluded
         │
         ▼
REALITY GATE (L09)
  Checks: permit → promoted → category → confidence
  CGIR gate: tau/chi/drift/betti/confidence
  GateProof with Z3 verification
         │
         ▼
CGIR EXECUTION (L10–L16)
  Causal Graph IR compilation
  AEGIS deterministic CESK runtime
         │
         ▼
WORM LEDGER (L13)
  SHA-256 hash chain
  contract_version on all entries
  RetentionPolicy: EPHEMERAL/SESSION/DURABLE/PERMANENT
         │
         ▼
REPLAY AND AUDIT (L14, L18)
  Exact chain replay
  Chronicle query with retention filtering
         │
         ▼
LEARNING LOOP (Runtime)
  TrialReflection — named lessons per trial
  cue_pattern_miner — aggregate failure patterns
  continuous_learning_loop — session continuity
         │
         ▼
PROMOTION PROTOCOL (L08)
  SPECULATIVE → TRUTH with evidence threshold
  PromotionDecision with maturity labels
  Z3 proven promotion rules (PR1-PR8)
         │
         ▼
EVOLUTION CONSTITUTION (SKETCHED)
  Bounded mutation
  Governance receipts
  W3C Verifiable Credentials export
         │
         ▼
HARDWARE ENFORCEMENT (A014 — DEFERRED)
  FPGA + ATECC608B Sentinel Latch
  Silicon-level gate enforcement
  hardware-rot crate
```

---

## What Is Gated By What

### Things that cannot be properly tested until A010 (first live inference):
- TrialReflection lesson calibration (what lessons matter on real data)
- JouleWork cost estimation (what does inference actually cost)
- tally_reflections() session aggregation
- Provider health routing (needs multi-trial data)
- Logprob bridge accuracy (needs real logprobs, not mocks)

### Things that cannot be built until A015 (fractal parameters calibrated):
- Triad intent check (Sun Tzu axis on council resolver)
- betti_1 real values (currently placeholder 0.0)
- Significance scoring thresholds for archive filtering

### Things that cannot be built until A014 (hardware):
- Sentinel Latch physical enforcement
- hardware-rot crate activation
- cgir-hardware boundary enforcement
- IC-1 hardware model attestation

### Things that can be built now, independent of A010/A014/A015:
- IC-2 provenance_chain field on proposals (small, next session)
- Soterion headers on 208 remaining Python files (mechanical, one session)
- tally_reflections() stub (implement pattern, calibrate later)
- Rust/Python differential test expansion (GAP R4)

---

## The Input Constitution Dependency

```
INPUT CONSTITUTION
         │
         ├─ IC-1: Model Identity Attestation
         │    ├─ Partial at A010: record API fingerprint in ledger
         │    └─ Full at A014+: hardware model attestation
         │
         ├─ IC-2: Input Provenance Tracking
         │    ├─ Partial now: provenance_chain field on proposals
         │    ├─ Partial at A010: auto-populate from API response
         │    └─ Partial future: source verification in predicate extractor
         │
         └─ IC-3: Training Provenance
              └─ Long horizon: requires ecosystem infrastructure
                 Not currently in scope — acknowledged boundary
```

The execution constitution (this system) enforces behavioral constraints
at execution time. It does not verify what produced the input.
Both are necessary. Only one is built.

---

## Why This Graph Matters

When a new component is proposed, the question to ask is:
**Where does it sit in this chain?**

If it sits above the Input Constitution gap (IC-1/IC-2), it reasons
about potentially unverified provenance. That is acceptable in the
prototype phase but must be acknowledged explicitly.

If it sits below the Input Constitution (downstream of the gate),
it is protected from execution-time violations but not from upstream
contamination.

If it requires A010 data to calibrate — mark it deferred until A010.
If it requires A014 hardware — mark it deferred until A014.
If it requires calibrated sensor data (betti_1, fractal params) — mark it
deferred until A015.

Misclassifying a deferred component as wired is the root cause of
packaging drift. This graph is the tool to prevent that.

---

*Ω Cipher · June 2026*
*GPT external review recommendation — implemented*
