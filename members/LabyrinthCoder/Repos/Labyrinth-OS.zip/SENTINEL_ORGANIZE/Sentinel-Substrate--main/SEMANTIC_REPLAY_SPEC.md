# SEMANTIC_REPLAY_SPEC.md — Labyrinth-OS

## What This Is

A specification for semantic replay — the capability to verify not just that
a decision was reproducible (structural replay, already implemented) but that
the decision was *correct* by the constitutional standards of the domain.

**Current state:** DESIGN SPEC — not yet implemented. Requires A010 live data.
**Structural replay:** IMPLEMENTED — verify_run.py, replay_validator.py
**Classification:** LAYER_II — mechanistically designed, not yet empirically verified.

---

## The Gap

Current replay (`replay_validator.py`) verifies:
- The hash chain is intact (no tampering)
- Stage ordering was correct (I1–I19 held)
- The same chain entries reproduce deterministically

Current replay does NOT verify:
- Whether the epistemic label was correctly assigned
- Whether promotion criteria were actually met (not just recorded as met)
- Whether the predicate extraction correctly identified the proposal's risk class
- Whether a BLOCK was warranted vs. a false positive
- Whether an EXECUTE was safe vs. a false negative

This is the difference between *syntactically admissible* and *semantically sound*.
The current system proves admissibility. Semantic replay proves soundness.

---

## What Semantic Replay Needs

### Prerequisite 1: Logit capture (A011)

To verify that an epistemic label was correctly assigned, you need the
original logprob distribution. The current mock backend produces synthetic
logprobs. Real logprob capture requires A010 first, then A011.

Without logprobs, you cannot verify:
- Whether `confidence=0.87` was a faithful representation of the model's certainty
- Whether the tau/chi/drift readings were computed from real token distributions
- Whether a BLOCK for low confidence was warranted

### Prerequisite 2: Domain ground truth (A020)

To verify that a BLOCK was correct, you need a ground truth label for the
proposal. This requires:
- Red-team harness (A020) producing proposals with known safe/unsafe labels
- Domain-specific correctness criteria (see DOMAIN_ADAPTER_SPEC.md)
- Calibration run establishing the baseline false positive/negative rate

### Prerequisite 3: Predicate extraction calibration (post-A010)

To verify that Φ1/Φ2/Φ3 were correctly evaluated, you need:
- The actual chain-of-thought text from the live model
- A labeled corpus of reasoning chains with known predicate values
- Calibration of the five pattern matchers against the live model's output style

---

## What Semantic Replay Verifies (When Built)

### Layer 1: Logit faithfulness
For each trial entry in the chain:
- Recompute confidence from stored logprobs
- Assert |recomputed_confidence - stored_confidence| < ε (tolerance 0.01)
- Flag entries where stored confidence diverges from raw logprobs

### Layer 2: Label correctness
For each trial entry:
- Recompute epistemic label from response text using EpistemicLabeler
- Assert label matches stored `epistemic_label` field
- Flag label drift (different session → different label on same text)

### Layer 3: Predicate consistency
For each BLOCK with verdict="PREDICATE_BLOCK":
- Reextract predicates from stored response text
- Assert Φ1/Φ2/Φ3 evaluation matches stored phi1_unsat/phi2_unsat/phi3_unsat
- Flag predicate extraction instability (different run → different predicates)

### Layer 4: Decision correctness (requires ground truth)
For each trial with a known-correct label (from red-team harness):
- Assert EXECUTE on known-safe proposals
- Assert BLOCK or KILL on known-unsafe proposals
- Compute false positive rate (blocked safe proposals)
- Compute false negative rate (executed unsafe proposals)
- Assert both rates are within domain-specific acceptable bounds

### Layer 5: Amplifier mask audit
For each trial where memory_store risk_estimate modified confidence:
- Recompute the risk adjustment from the memory store state at that time
- Assert stored confidence = original confidence + stored adjustment
- Flag amplifier drift (adjustment changed between sessions on same input)

---

## Semantic Replay Output Format

```json
{
  "session_id": "ignition_session_TIMESTAMP",
  "structural_verdict": "CLEAN",
  "semantic_verdict": "SOUNDNESS_UNVERIFIED",
  "layers_checked": ["logit_faithfulness", "label_correctness", "predicate_consistency"],
  "layers_pending": ["decision_correctness", "amplifier_audit"],
  "pending_reason": "A011 not closed — logprob capture not available",
  "flags": [],
  "false_positive_rate": null,
  "false_negative_rate": null,
  "label_drift_count": 0,
  "predicate_instability_count": 0
}
```

---

## Implementation Plan

**Phase 1 — Post-A010 (immediate):**
- Implement Layer 1 (logit faithfulness) — compare stored vs recomputed confidence
- Implement Layer 2 (label correctness) — rerun EpistemicLabeler on stored text
- Add `semantic_replay` mode to verify_run.py

**Phase 2 — Post-A020 (red-team complete):**
- Implement Layer 4 (decision correctness) using red-team labeled corpus
- Compute and report false positive/negative rates per domain
- Add domain-specific soundness thresholds to DOMAIN_ADAPTER_SPEC.md

**Phase 3 — Post-calibration:**
- Implement Layer 3 (predicate consistency) with calibrated extraction
- Implement Layer 5 (amplifier audit) with live memory store data
- Full semantic replay report integrated into session summary

---

## Current Status

| Layer | Status | Blocker |
|-------|--------|---------|
| Structural replay | IMPLEMENTED | — |
| Layer 1: Logit faithfulness | NOT YET | A011 (logprob capture) |
| Layer 2: Label correctness | PARTIAL | EpistemicLabeler wired but not validated |
| Layer 3: Predicate consistency | NOT YET | Need live chain-of-thought corpus |
| Layer 4: Decision correctness | NOT YET | A020 (red-team harness) |
| Layer 5: Amplifier audit | NOT YET | Live memory store data |

**Note:** Structural replay (what is built) guarantees that violations of I1–I19
are detectable after the fact. Semantic replay (what is specified here) would
additionally verify that the decisions made were correct, not just constitutional.
These are different claims. Both are necessary. Only one is built.

---

*X: @LabyrinthCoder | Classification: LAYER_II — designed, not yet implemented*
