# PROTOTYPE_BOUNDARIES.md — Labyrinth-OS

**Read this before forming strong opinions about what the system does or doesn't prove.**

---

## Formal Verification Taxonomy

Every claim in this system falls into one of four categories.
Use this taxonomy when reading any documentation or code comment.

| Category | Meaning | Examples |
|----------|---------|---------|
| **Z3-PROVEN** | Machine-checked by Z3 SMT solver. Unconditionally true given the model. | Sigma Anchor constants (A021), z3_sovereignty_spec.py, z3_promotion_proof.py (PR1-PR8), z3_predicate_proof.py (PP1-PP9) |
| **TEST-VERIFIED** | Proved by passing test suite. True under tested conditions. | Pipeline ordering (I1-I10, I17), hash chain integrity, replay CLEAN verdict, invariants I11-I18 |
| **PROTOTYPE-WIRED** | Code exists and runs but is connected to mock/stub inputs. True in prototype shape, not yet in live data. | ignition.py session ordering (real), module calls (stubs), promotion heuristics |
| **NOT YET DEMONSTRATED** | Designed and documented. Not yet run. | Live inference (A010), hardware attestation (A002, A003), adapter calibration, semantic replay |

When you see "formally verified" in this documentation: check which category applies.
Z3-PROVEN means one thing. Test-verified means something different. Neither is less valuable
in its category — but conflating them misrepresents the system.

**What A021 proves:** The five Sigma Anchor threshold constants are internally consistent,
non-vacuous, and correctly ordered. A021 does NOT prove that the whole pipeline is safe,
that adapters are correctly calibrated, or that live adversarial proposals are blocked.

---

## What This Is

Labyrinth-OS is working architecture research.

It is not production safety infrastructure.
It is not a certified AI governance system.
It is not a complete formal proof of AI alignment.

It is a prototype constitutional substrate — a demonstration that deterministic
enforcement patterns, typed execution graphs, immutable ledgers, and formal
assumption tracking can be wired together into a coherent whole.

The pattern is proven. The implementation is prototype.

---

## The Kernel (What Is Actually Enforced)

These are the load-bearing elements. They work. They are tested. They enforce.

```
pipeline_wire.py         Stage ordering with timestamps and fatal SystemError
sigma_anchors.py         Single source of truth for all Sigma thresholds
reality_gate.py          The only crossing point between Lane 1 and Lane 2
cgir_gate.py             Sigma Anchor threshold check — ALLOW or BLOCK, binary
aegis_cesk.py            Deterministic execution kernel — same input = same output
hashchain.py             WORM hash-chained ledger — tamper-evident, append-only (thread-safe)
replay_validator.py      Structural replay — same chain entries, same order
z3_sovereignty_spec.py   Z3 SMT proof of threshold consistency (A021) — Z3-PROVEN
acp1_tracker.py          22 assumptions with explicit VERIFIED/PARTIAL/OPEN status
predicate_extractor.py   LogicalSentinel — Z3 predicate verification (second axis)
acp1_dependency_graph.py Collapse propagation — AT_RISK inherits from OPEN parents
```

These files enforce what they claim. The tests prove they enforce it.

---

## The Prototype Layer (What Is Partially Wired)

These work correctly but are not yet connected to real external systems.

```
runtime/ignition.py      Session runner with MOCK stages for archive/promote/gate
                         Ordering enforcement is real. Module calls are local stubs.
                         A proposal rejected by real Lane 1 can still pass ignition.
                         This gap is documented in KNOWN_GAPS.md as GAP 1.

runtime/verify_run.py    Exact chain replay only — EQUIVALENT mode removed (May 2026,
                         security fix: absent chain_entries now raises SystemError).

lane1/*/                 Lane 1 modules are implemented and tested in isolation.
                         Not yet called from ignition.py in the live path.

promotion/               Promotion rules are heuristic (confidence threshold,
                         run count). Not yet formally verified like the gate constants.
```

**Important:** "Prototype layer" does not mean "broken." It means "correct in
isolation, not yet integrated into the live execution path."

---

## The Research Shell (Reference Only, Not Executed)

These exist as reference material, experimental ideas, or future integration targets.
None of these are in the live execution path.

```
archive/external_references/     Archived external projects for pattern reference
epistemic/experimental/          Distributed topology, resonance theory references
crates/                          Rust substrate — proven separately, not called from Python
lane1/L15-L16/                   Experimental and verified exec paths (sandboxed)
```

---

## What "Verified" Means Here

Every use of "verified" in this repo has a specific scope. The scope is never
"real-world safety proven." It is always one of:

| Claim | What it actually means |
|-------|------------------------|
| "Z3 verified" | Internal mathematical consistency of threshold logic — NOT real-world alignment |
| "WORM ledger" | Tamper-evident append-only structure — NOT encrypted or access-controlled |
| "Exact replay" | Structural replay of chain entries — NOT semantic replay of LLM token streams |
| "ACP-1 VERIFIED" | Proven by concrete evidence and tests — NOT mathematically formal (except A021) |
| "Tests pass" | The system behaves as specified in the test environment — NOT production hardened |
| "Fatal if bypassed" | Raises SystemError in the prototype — NOT cryptographically impossible |

---

## The Single Most Important Distinction

> **"Measurable violation" ≠ "Structurally impossible violation."**

The prototype measures, logs, and records violations. It does not yet make them
impossible. That is the honest state of the system.

The production target is: **impossible to violate**.
The current prototype is: **measurable when violated**.

That gap closes with: A010 (live inference), real module wiring in ignition.py,
and hardware attestation (Phase 10).

---

## What the System Is Strongest At

- **Audit substrate** — the ledger, chain integrity, and replay are solid
- **Pattern demonstration** — the architecture is coherent and internally consistent
- **Formal assumption tracking** — ACP-1 is unusually honest about what is and isn't proven
- **Invariant documentation** — invariants I1-I19 agree with each other and with the code

## What the System Is Not Yet Strong At

- **Semantic enforcement** — labeling is a semantic inference problem; the substrate
  contains execution but does not guarantee that labeling decisions are correct
- **Live adversarial hardening** — no red-team testing against a live system (A020)
- **Replay under real nondeterminism** — LLM outputs without logit capture cannot
  be replayed semantically, only structurally
- **Constitutional deadlock resolution** — circuit breaker built; human escalation
  path not yet wired

---

## The Deepest Unsolved Problem — Admissibility vs. Correctness

**Syntactically admissible ≠ semantically sound.**

The gate can say: *this action followed the constitution.*
The gate cannot always say: *this action was correct.*

A proposal can be geometrically within Sigma Anchor thresholds, logically
consistent by predicate verification, confidently promoted with clean history —
and still be wrong. The gate checks constitutional form, not truth content.

The current system makes actions **admissible**. It does not make them **correct**.

Closing this gap requires semantic replay (A015) — verifying not just that a
decision was reproducible but that it was right by the standards of the domain.
That requires live data, domain calibration, and criteria for correctness that
vary by context. It is the hardest unsolved problem in the system.

Do not blur this boundary. Every formal claim in this repo is about admissibility.
None are claims about correctness.

---

## The Operator Problem

**Who guards the gate from the gatekeeper?**

Until A014 (FPGA + ATECC608B), a motivated operator with system access can alter
thresholds, bypass the gate, or reset the ledger. Human overrides are logged as
structured fields (G9, May 2026) but not cryptographically signed. The gate is
fail-closed against external adversaries; it is not yet fail-closed against the
operator who controls it.

> The deepest political problem in the system is not the malicious outsider.
> It is the legitimate actor who wants one exception.

Hardware enforcement converts "violation is detectable" into "violation is
structurally impossible." That is the architectural purpose of A014. It is not
an optimization — it is the difference between a constitution and a suggestion.

---

## One More Thing

The system is built without institutional backing or peer review.
It has not been certified or deployed in production.

It demonstrates that the pattern is sound.
It does not certify that any specific deployment is safe.

That is the honest scope.

---

X: @LabyrinthCoder
