# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          run_ignition.py — Labyrinth-OS / Runtime
# ----------------------------------------------------------------------------

"""
run_ignition.py — Labyrinth-OS / Runtime
=========================================
Ignition Launcher with Option A / Option B fallback.

Option A: Sentinel-Substrate--main root (all modules co-located)
Option B: Sentinel package structure (files spread across subdirs)

Tries A first. Falls back to B. Prints which mode activated.

Usage (identical to ignition.py):
  python run_ignition.py --backend anthropic --model claude-sonnet-4-20250514 --trials 5
  python run_ignition.py --backend openai    --model gpt-4o --trials 5
  python run_ignition.py --backend ollama    --model qwen3:4b --trials 5
"""

import os
import sys
import subprocess

THIS_DIR  = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.abspath(os.path.join(THIS_DIR, "..", ".."))

# Option A: flat directory candidates
OPTION_A_CANDIDATES = [
    THIS_DIR,
    os.path.join(THIS_DIR, "cgir"),
    os.path.join(REPO_ROOT, "cgir"),
]

# Option B: Sentinel subdirectory paths
OPTION_B_PATHS = [
    os.path.join(REPO_ROOT, "execution", "cgir"),
    os.path.join(REPO_ROOT, "execution", "gate"),
    os.path.join(REPO_ROOT, "execution", "ledger"),
    os.path.join(REPO_ROOT, "execution", "aegis"),
    os.path.join(REPO_ROOT, "execution", "replay"),
    os.path.join(REPO_ROOT, "epistemic", "council"),
    os.path.join(REPO_ROOT, "epistemic", "signal-aggregation"),
    os.path.join(REPO_ROOT, "epistemic", "watcher-a"),
    os.path.join(REPO_ROOT, "epistemic", "watcher-b"),
    os.path.join(REPO_ROOT, "epistemic", "vector"),
    os.path.join(REPO_ROOT, "epistemic", "logprob-bridge"),
    os.path.join(REPO_ROOT, "runtime"),
    os.path.join(REPO_ROOT, "steward"),
]


def probe_imports(paths):
    """Return True if core imports resolve from these paths."""
    checks = "\n".join(f"sys.path.insert(0, {p!r})" for p in paths)
    code = (
        "import sys\n"
        + checks + "\n"
        + "from api_adapter import APIAdapter\n"
        + "from cgir_types import GateDecision\n"
        + "from hashchain import HashChain\n"
        + "print('OK')\n"
    )
    r = subprocess.run([sys.executable, "-c", code],
                       capture_output=True, text=True)
    return r.stdout.strip() == "OK"


def resolve_mode():
    """
    Returns (ignition_path, sys_paths, mode_label).
    mode_label: 'A' or 'B'.
    Raises SystemExit if neither mode resolves.
    """
    # Try Option A
    for d in OPTION_A_CANDIDATES:
        ignition = os.path.join(d, "ignition.py")
        if os.path.isfile(ignition) and probe_imports([d]):
            return ignition, [d], "A"

    # Try Option B
    b_ignition = (
        os.path.join(REPO_ROOT, "runtime", "ignition.py")
        if os.path.isfile(os.path.join(REPO_ROOT, "runtime", "ignition.py"))
        else os.path.join(THIS_DIR, "ignition.py")
    )
    if os.path.isfile(b_ignition) and probe_imports(OPTION_B_PATHS):
        return b_ignition, OPTION_B_PATHS, "B"

    # Neither worked
    print("\n  ERROR: Cannot resolve imports via Option A or Option B.")
    print("  Fastest fix — run directly from the Sentinel-Substrate--main root:")
    print("    cd labyrinth-os/cgir")
    print("    python ignition.py --backend anthropic --model claude-sonnet-4-20250514 --trials 5")
    sys.exit(1)


def main():
    print("=" * 70)
    print("LABYRINTH-OS RUN_IGNITION")
    print("=" * 70)

    ignition_path, paths, mode = resolve_mode()
    desc = "Sentinel-Substrate--main root" if mode == "A" else "Sentinel package structure"
    print(f"\n  Mode {mode} active — {desc}")
    print(f"  Script: {ignition_path}\n")

    # Run ignition.py directly as a subprocess with augmented PYTHONPATH
    env = os.environ.copy()
    existing = env.get("PYTHONPATH", "")
    extra = os.pathsep.join(paths)
    env["PYTHONPATH"] = extra + (os.pathsep + existing if existing else "")

    result = subprocess.run(
        [sys.executable, ignition_path] + sys.argv[1:],
        env=env,
    )
    sys.exit(result.returncode)


if __name__ == "__main__":
    main()


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_option_a_candidate_list_nonempty() -> bool:
    assert len(OPTION_A_CANDIDATES) > 0
    return True

def _test_this_dir_in_candidates() -> bool:
    assert THIS_DIR in OPTION_A_CANDIDATES
    return True

def _test_repo_root_computed() -> bool:
    assert os.path.isabs(REPO_ROOT)
    return True

def _test_option_a_candidates_are_absolute() -> bool:
    for c in OPTION_A_CANDIDATES:
        assert os.path.isabs(c), f"Candidate not absolute: {c}"
    return True

def _test_ignition_py_findable() -> bool:
    """At least one candidate directory should contain ignition.py."""
    found = any(
        os.path.exists(os.path.join(c, "ignition.py"))
        for c in OPTION_A_CANDIDATES
    )
    assert found, f"ignition.py not found in any candidate: {OPTION_A_CANDIDATES}"
    return True


def run_tests() -> tuple:
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn(); passed += 1; results.append((name, "PASS", None))
        except Exception as e:
            failed += 1; results.append((name, "FAIL", str(e)))
    return passed, failed, results
