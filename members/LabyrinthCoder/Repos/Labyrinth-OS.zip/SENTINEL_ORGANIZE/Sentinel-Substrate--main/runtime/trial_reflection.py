# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          trial_reflection.py — Labyrinth-OS / Runtime
# ----------------------------------------------------------------------------

"""
trial_reflection.py — Labyrinth-OS / Runtime
=============================================
TrialReflection — Named Lessons From Every Trial

Pattern adapted from Annunimas Reflection contract
(crates/annunimas-core/src/contract/reflection.rs).

The gap this closes:
    Labyrinth-OS's continuous_learning_loop.py records what happened.
    The cue_pattern_miner.py mines failure patterns.
    Neither produces named, transferable lessons from individual trials.

    TrialReflection adds:
    - A named lesson list (lessons_emitted) for every trial
    - JouleWork honesty: estimated vs actual compute cost
    - A plain-language narrative of what actually happened
    - ReflectionOutcome: SUCCESS, PARTIAL, FAILURE
    - Contract version for schema evolution

    After A010 (first live inference), the system will encounter
    unexpected sensor readings. TrialReflection captures what those
    surprises teach — in a form the next session can read.

Integration:
    Called from ignition.py after each trial completes.
    Stored to chronicle via archive_memory.py (ANOMALY or TRUTH label).
    Read by continuous_learning_loop.py at session start.

References:
    Annunimas: crates/annunimas-core/src/contract/reflection.rs
    Labyrinth-OS: runtime/continuous_learning_loop.py
    Labyrinth-OS: execution/replay/cue_pattern_miner.py
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, List, Optional

try:
    import sys as _sys, os as _os
    _root = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), '..'))
    if _root not in _sys.path: _sys.path.insert(0, _root)
    from sigma_anchors import LABYRINTH_CONTRACT_VERSION
except ImportError:
    LABYRINTH_CONTRACT_VERSION = "1.0.0"


# ─── OUTCOME ─────────────────────────────────────────────────────────────────

@unique
class ReflectionOutcome(str, Enum):
    SUCCESS = "SUCCESS"   # trial passed gate and executed cleanly
    PARTIAL = "PARTIAL"   # trial passed gate but with warnings or near-misses
    FAILURE = "FAILURE"   # trial was blocked or errored


# ─── LESSON GENERATORS ───────────────────────────────────────────────────────

def _generate_lessons(
    outcome: ReflectionOutcome,
    verdict: str,
    tau: Optional[float],
    chi: Optional[float],
    drift: Optional[float],
    betti: Optional[float],
    confidence: Optional[float],
    joule_estimated: float,
    joule_actual: float,
) -> List[str]:
    """
    Generate named, transferable lessons from sensor readings.
    
    Lessons are short, specific strings that a future session can use
    to anticipate similar conditions. Each lesson is named for the
    condition it describes.
    """
    lessons: List[str] = []
    
    try:
        from sigma_anchors import (TAU_ESCAPE_FLOOR, CHI_WARN, CHI_COLLAPSE,
                                    DRIFT_THRESHOLD, BETTI_1_CAP, CONFIDENCE_FLOOR)
    except ImportError:
        TAU_ESCAPE_FLOOR = 0.75
        CHI_WARN = 0.15
        CHI_COLLAPSE = 0.40
        DRIFT_THRESHOLD = 0.12
        BETTI_1_CAP = 0.045
        CONFIDENCE_FLOOR = 0.65

    # Tau lessons
    if tau is not None:
        if tau < TAU_ESCAPE_FLOOR:
            lessons.append(
                f"TAU_BELOW_FLOOR: tau={tau:.3f} < floor={TAU_ESCAPE_FLOOR} — "
                f"epistemic escape collapsed"
            )
        elif tau < TAU_ESCAPE_FLOOR + 0.05:
            lessons.append(
                f"TAU_NEAR_FLOOR: tau={tau:.3f} — {((tau - TAU_ESCAPE_FLOOR)/TAU_ESCAPE_FLOOR)*100:.1f}% "
                f"above floor — monitor this pattern"
            )
        elif tau > 0.95:
            lessons.append(f"TAU_HIGH_CONFIDENCE: tau={tau:.3f} — strong epistemic clarity")

    # Chi lessons
    if chi is not None:
        if chi >= CHI_COLLAPSE:
            lessons.append(
                f"CHI_COLLAPSED: chi={chi:.3f} >= collapse={CHI_COLLAPSE} — "
                f"signal field coherence lost"
            )
        elif chi >= CHI_WARN:
            lessons.append(
                f"CHI_ELEVATED: chi={chi:.3f} >= warn={CHI_WARN} — "
                f"contradiction density rising"
            )

    # Drift lessons
    if drift is not None and drift >= DRIFT_THRESHOLD:
        lessons.append(
            f"DRIFT_AT_THRESHOLD: drift={drift:.3f} >= threshold={DRIFT_THRESHOLD}"
        )

    # Betti lessons
    if betti is not None and betti >= BETTI_1_CAP:
        lessons.append(
            f"BETTI_AT_CAP: betti_1={betti:.4f} >= cap={BETTI_1_CAP} — "
            f"topological loop count elevated"
        )
    elif betti == 0.0:
        lessons.append("BETTI_PLACEHOLDER: betti_1=0.0 — awaiting A015 (fractal parameters)")

    # Confidence lessons
    if confidence is not None:
        if confidence < CONFIDENCE_FLOOR:
            lessons.append(
                f"CONFIDENCE_BELOW_FLOOR: confidence={confidence:.3f} < floor={CONFIDENCE_FLOOR}"
            )
        elif confidence > 0.95:
            lessons.append(f"HIGH_CONFIDENCE: confidence={confidence:.3f}")

    # JouleWork lessons
    if joule_actual > 0 and joule_estimated > 0:
        ratio = joule_actual / joule_estimated
        if ratio > 1.5:
            lessons.append(
                f"JOULE_OVERRUN: actual={joule_actual:.1f}ms was {ratio:.1f}x estimated "
                f"— improve cost estimation"
            )
        elif ratio < 0.5:
            lessons.append(
                f"JOULE_UNDERRUN: actual={joule_actual:.1f}ms was {ratio:.1f}x estimated "
                f"— estimate was too conservative"
            )

    # Outcome-specific lessons
    if outcome == ReflectionOutcome.SUCCESS and not lessons:
        lessons.append("NOMINAL_PASS: all sigma anchors within bounds")
    elif outcome == ReflectionOutcome.FAILURE:
        lessons.append(f"GATE_BLOCKED: verdict={verdict}")

    return lessons


# ─── TRIAL REFLECTION ─────────────────────────────────────────────────────────

@dataclass
class TrialReflection:
    """
    Named lessons from a single trial execution.

    Fields
    ------
    trial_id          Unique identifier for this trial (from ignition session).
    outcome           SUCCESS | PARTIAL | FAILURE.
    verdict           Raw gate verdict ("EXECUTE", "BLOCK", "KILL", "ERROR").
    score             Composite quality score 0.0-1.0 (confidence × tau where available).
    narrative         Plain-language description of what happened.
    joule_estimated   Estimated wall clock cost in milliseconds.
    joule_actual      Actual wall clock cost in milliseconds.
    honesty_ratio     joule_actual / joule_estimated alignment (1.0 = perfect).
    lessons_emitted   Named, transferable lessons for future sessions.
    tau               tau_escape reading (if available).
    chi               chi_vector primary reading (if available).
    drift             drift_score reading (if available).
    betti             betti_1 reading (if available).
    confidence        confidence reading (if available).
    timestamp         When the reflection was produced.
    contract_version  Schema version for forward compatibility.
    """
    trial_id:         str
    outcome:          ReflectionOutcome
    verdict:          str
    score:            float
    narrative:        str
    joule_estimated:  float
    joule_actual:     float
    lessons_emitted:  List[str]          = field(default_factory=list)
    tau:              Optional[float]    = None
    chi:              Optional[float]    = None
    drift:            Optional[float]    = None
    betti:            Optional[float]    = None
    confidence:       Optional[float]    = None
    timestamp:        float              = field(default_factory=time.time)
    contract_version: str                = field(
        default_factory=lambda: LABYRINTH_CONTRACT_VERSION
    )

    @property
    def honesty_ratio(self) -> float:
        """How accurate was the cost estimate? 1.0 = perfect."""
        if self.joule_estimated > 0 and self.joule_actual > 0:
            return min(
                self.joule_estimated / self.joule_actual,
                self.joule_actual / self.joule_estimated,
            )
        return 1.0

    @property
    def efficient(self) -> bool:
        """Was the cost variance within 25%?"""
        if self.joule_estimated > 0 and self.joule_actual > 0:
            variance = abs(self.joule_actual - self.joule_estimated) / self.joule_estimated
            return variance <= 0.25
        return True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trial_id":         self.trial_id,
            "outcome":          self.outcome.value,
            "verdict":          self.verdict,
            "score":            self.score,
            "narrative":        self.narrative,
            "joule_estimated":  self.joule_estimated,
            "joule_actual":     self.joule_actual,
            "honesty_ratio":    self.honesty_ratio,
            "efficient":        self.efficient,
            "lessons_emitted":  self.lessons_emitted,
            "tau":              self.tau,
            "chi":              self.chi,
            "drift":            self.drift,
            "betti":            self.betti,
            "confidence":       self.confidence,
            "timestamp":        self.timestamp,
            "contract_version": self.contract_version,
        }

    def to_json(self, indent: int = None) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    def reflection_hash(self) -> str:
        """SHA-256 of canonical content for chain linking."""
        canonical = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode()).hexdigest()


# ─── FACTORY ──────────────────────────────────────────────────────────────────

def reflect_on_trial(
    trial_id: str,
    verdict: str,
    tau: Optional[float] = None,
    chi: Optional[float] = None,
    drift: Optional[float] = None,
    betti: Optional[float] = None,
    confidence: Optional[float] = None,
    joule_estimated: float = 0.0,
    joule_actual: float = 0.0,
    extra_narrative: str = "",
) -> TrialReflection:
    """
    Factory: produce a TrialReflection from trial sensor readings.
    
    Determines outcome, generates lessons, builds narrative.
    Safe to call even when sensor readings are None (betti_1 placeholder case).
    """
    # Determine outcome
    verdict_upper = verdict.upper()
    if verdict_upper in ("EXECUTE", "ALLOW"):
        # Check for partial — near misses
        try:
            from sigma_anchors import TAU_ESCAPE_FLOOR, CHI_WARN
        except ImportError:
            TAU_ESCAPE_FLOOR, CHI_WARN = 0.75, 0.15

        near_miss = (
            (tau is not None and tau < TAU_ESCAPE_FLOOR + 0.05) or
            (chi is not None and chi >= CHI_WARN)
        )
        outcome = ReflectionOutcome.PARTIAL if near_miss else ReflectionOutcome.SUCCESS
    else:
        outcome = ReflectionOutcome.FAILURE

    # Compute score
    score_components = []
    if confidence is not None:
        score_components.append(confidence)
    if tau is not None:
        score_components.append(min(tau, 1.0))
    score = sum(score_components) / len(score_components) if score_components else 0.5

    # Generate lessons
    lessons = _generate_lessons(
        outcome=outcome,
        verdict=verdict,
        tau=tau,
        chi=chi,
        drift=drift,
        betti=betti,
        confidence=confidence,
        joule_estimated=joule_estimated,
        joule_actual=joule_actual,
    )

    # Build narrative
    parts = [f"Trial {trial_id}: verdict={verdict}"]
    if tau is not None: parts.append(f"tau={tau:.3f}")
    if chi is not None: parts.append(f"chi={chi:.3f}")
    if confidence is not None: parts.append(f"confidence={confidence:.3f}")
    if joule_actual > 0: parts.append(f"cost={joule_actual:.1f}ms")
    if extra_narrative: parts.append(extra_narrative)
    narrative = " | ".join(parts)

    return TrialReflection(
        trial_id=trial_id,
        outcome=outcome,
        verdict=verdict,
        score=score,
        narrative=narrative,
        joule_estimated=joule_estimated,
        joule_actual=joule_actual,
        lessons_emitted=lessons,
        tau=tau,
        chi=chi,
        drift=drift,
        betti=betti,
        confidence=confidence,
    )


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_reflect_success() -> bool:
    r = reflect_on_trial("t-001", "EXECUTE", tau=0.85, chi=0.10, confidence=0.90,
                          joule_estimated=50.0, joule_actual=48.0)
    assert r.outcome == ReflectionOutcome.SUCCESS
    assert r.score > 0.8
    assert "NOMINAL_PASS" in r.lessons_emitted[0]
    assert r.honesty_ratio > 0.9
    assert r.efficient
    return True


def _test_reflect_failure() -> bool:
    r = reflect_on_trial("t-002", "BLOCK", tau=0.70, chi=0.12, confidence=0.60)
    assert r.outcome == ReflectionOutcome.FAILURE
    assert any("TAU_BELOW_FLOOR" in l for l in r.lessons_emitted)
    assert any("GATE_BLOCKED" in l for l in r.lessons_emitted)
    return True


def _test_reflect_partial() -> bool:
    # Near-miss: tau just above floor
    r = reflect_on_trial("t-003", "EXECUTE", tau=0.763, chi=0.08, confidence=0.88)
    assert r.outcome == ReflectionOutcome.PARTIAL
    assert any("TAU_NEAR_FLOOR" in l for l in r.lessons_emitted)
    return True


def _test_reflect_chi_elevated() -> bool:
    r = reflect_on_trial("t-004", "BLOCK", tau=0.90, chi=0.22, confidence=0.85)
    assert any("CHI_ELEVATED" in l for l in r.lessons_emitted)
    return True


def _test_reflect_chi_collapsed() -> bool:
    r = reflect_on_trial("t-005", "BLOCK", tau=0.90, chi=0.45, confidence=0.85)
    assert any("CHI_COLLAPSED" in l for l in r.lessons_emitted)
    return True


def _test_betti_placeholder_lesson() -> bool:
    r = reflect_on_trial("t-006", "EXECUTE", tau=0.90, chi=0.10,
                          betti=0.0, confidence=0.90)
    assert any("BETTI_PLACEHOLDER" in l for l in r.lessons_emitted)
    return True


def _test_joule_overrun_lesson() -> bool:
    r = reflect_on_trial("t-007", "EXECUTE", tau=0.85, chi=0.10, confidence=0.90,
                          joule_estimated=50.0, joule_actual=100.0)
    assert any("JOULE_OVERRUN" in l for l in r.lessons_emitted)
    assert not r.efficient
    return True


def _test_serialization_roundtrip() -> bool:
    r = reflect_on_trial("t-008", "EXECUTE", tau=0.85, chi=0.10, confidence=0.90,
                          joule_estimated=50.0, joule_actual=48.0)
    d = r.to_dict()
    assert d["contract_version"] == LABYRINTH_CONTRACT_VERSION
    assert "lessons_emitted" in d
    assert isinstance(d["lessons_emitted"], list)
    j = r.to_json()
    import json as _json
    loaded = _json.loads(j)
    assert loaded["trial_id"] == "t-008"
    return True


def _test_hash_is_deterministic() -> bool:
    r = reflect_on_trial("t-det", "EXECUTE", tau=0.85, chi=0.10, confidence=0.90,
                          joule_estimated=50.0, joule_actual=48.0)
    h1 = r.reflection_hash()
    h2 = r.reflection_hash()
    assert h1 == h2, "Hash must be deterministic"
    return True


def _test_none_sensors_safe() -> bool:
    # Should not raise even with all sensors None
    r = reflect_on_trial("t-none", "EXECUTE")
    assert r is not None
    assert isinstance(r.lessons_emitted, list)
    return True


def run_tests():
    tests = [
        (_test_reflect_success,           "reflect_success"),
        (_test_reflect_failure,           "reflect_failure"),
        (_test_reflect_partial,           "reflect_partial_near_miss"),
        (_test_reflect_chi_elevated,      "reflect_chi_elevated"),
        (_test_reflect_chi_collapsed,     "reflect_chi_collapsed"),
        (_test_betti_placeholder_lesson,  "betti_placeholder_lesson"),
        (_test_joule_overrun_lesson,      "joule_overrun_lesson"),
        (_test_serialization_roundtrip,   "serialization_roundtrip"),
        (_test_hash_is_deterministic,     "hash_deterministic"),
        (_test_none_sensors_safe,         "none_sensors_safe"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
