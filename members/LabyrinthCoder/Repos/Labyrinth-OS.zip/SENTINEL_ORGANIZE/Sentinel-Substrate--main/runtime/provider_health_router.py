# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⚡ (Runtime/Execution)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          Provider health routing -- multi-provider fallback with health tracking
# ----------------------------------------------------------------------------

"""
provider_health_router.py -- Labyrinth-OS / Runtime
=====================================================
Provider Health Routing

Multi-provider routing with health-aware fallback. Tracks the health
of each configured provider and routes inference requests to the
healthiest available provider.

When A010 (first live inference) runs, this module captures real
latency, error rate, and availability data per provider. Until then,
it operates in STUB mode -- routes correctly but uses synthetic
health scores.

Design pattern: CHARON (from Annunimas cross-pollination)
  - Each provider has a health score [0.0, 1.0]
  - Requests route to the highest-scoring available provider
  - Failed requests decrease health score (exponential decay)
  - Successful requests recover health score (slow recovery)
  - Providers below MIN_HEALTH_THRESHOLD are quarantined

Calibration status
------------------
Health decay and recovery rates are conservative defaults.
Calibrate after A010 when real latency distributions are available.
The routing logic and health tracking are correct now.

References
----------
  ACP-1 A010      -- first live inference (calibration gate)
  runtime/api_adapter.py  -- Provider enum, APIAdapter, make_adapter
  runtime/joulework.py    -- cost accounting per provider
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Dict, List, Optional, Tuple

try:
    import sys as _sys, os as _os
    _root = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), '..'))
    if _root not in _sys.path:
        _sys.path.insert(0, _root)
    from sigma_anchors import LABYRINTH_CONTRACT_VERSION
    _SIGMA_OK = True
except ImportError:
    LABYRINTH_CONTRACT_VERSION = "1.0.0"
    _SIGMA_OK = False


# ---- PROVIDER HEALTH STATUS -------------------------------------------------

MIN_HEALTH_THRESHOLD:  float = 0.20   # below this: quarantine provider
RECOVERY_RATE:         float = 0.05   # health recovered per successful call
DECAY_RATE:            float = 0.30   # health lost per failed call
QUARANTINE_DURATION_S: float = 60.0  # seconds before re-checking quarantined provider


@unique
class ProviderStatus(str, Enum):
    HEALTHY     = "HEALTHY"      # health >= 0.70
    DEGRADED    = "DEGRADED"     # health between MIN_THRESHOLD and 0.70
    QUARANTINED = "QUARANTINED"  # health < MIN_THRESHOLD, not yet retried
    UNAVAILABLE = "UNAVAILABLE"  # not configured


@dataclass
class ProviderHealth:
    """Health record for one provider."""
    provider_id:        str
    health_score:       float          = 1.0    # starts healthy
    success_count:      int            = 0
    failure_count:      int            = 0
    consecutive_failures: int          = 0
    last_success_at:    Optional[float] = None
    last_failure_at:    Optional[float] = None
    quarantined_at:     Optional[float] = None
    mean_latency_ms:    float          = 0.0    # updated after A010 live data
    contract_version:   str            = LABYRINTH_CONTRACT_VERSION

    @property
    def status(self) -> ProviderStatus:
        if self.health_score < MIN_HEALTH_THRESHOLD:
            return ProviderStatus.QUARANTINED
        if self.health_score < 0.70:
            return ProviderStatus.DEGRADED
        return ProviderStatus.HEALTHY

    @property
    def error_rate(self) -> float:
        total = self.success_count + self.failure_count
        return self.failure_count / total if total > 0 else 0.0

    def record_success(self, latency_ms: float = 0.0) -> None:
        self.success_count += 1
        self.consecutive_failures = 0
        self.last_success_at = time.time()
        # Slow recovery -- health rebuilds gradually
        self.health_score = min(1.0, self.health_score + RECOVERY_RATE)
        # Update running mean latency
        if latency_ms > 0:
            n = self.success_count
            self.mean_latency_ms = (self.mean_latency_ms * (n - 1) + latency_ms) / n
        self.quarantined_at = None

    def record_failure(self) -> None:
        self.failure_count += 1
        self.consecutive_failures += 1
        self.last_failure_at = time.time()
        # Fast decay -- health drops quickly on failure
        self.health_score = max(0.0, self.health_score - DECAY_RATE)
        if self.health_score < MIN_HEALTH_THRESHOLD and self.quarantined_at is None:
            self.quarantined_at = time.time()

    def is_retryable(self, now: Optional[float] = None) -> bool:
        """Returns True if a quarantined provider can be retried."""
        if self.status != ProviderStatus.QUARANTINED:
            return True
        if self.quarantined_at is None:
            return True
        elapsed = (now or time.time()) - self.quarantined_at
        return elapsed >= QUARANTINE_DURATION_S

    def to_dict(self) -> dict:
        return {
            "provider_id":          self.provider_id,
            "health_score":         round(self.health_score, 4),
            "status":               self.status.value,
            "success_count":        self.success_count,
            "failure_count":        self.failure_count,
            "consecutive_failures": self.consecutive_failures,
            "error_rate":           round(self.error_rate, 4),
            "mean_latency_ms":      round(self.mean_latency_ms, 2),
            "contract_version":     self.contract_version,
        }


# ---- ROUTING RESULT ---------------------------------------------------------

@dataclass
class RoutingDecision:
    """Result of a routing request."""
    selected_provider:   str
    fallback_chain:      List[str]      # ordered list of providers tried/available
    all_unavailable:     bool           = False
    reason:              str            = ""

    @property
    def routable(self) -> bool:
        return not self.all_unavailable


# ---- PROVIDER HEALTH ROUTER -------------------------------------------------

class ProviderHealthRouter:
    """
    Routes inference requests to the healthiest available provider.

    Usage
    -----
        router = ProviderHealthRouter(["anthropic", "openai", "ollama"])
        decision = router.select()
        # ... run inference on decision.selected_provider ...
        if success:
            router.record_success(decision.selected_provider, latency_ms=320.0)
        else:
            router.record_failure(decision.selected_provider)

    Calibration
    -----------
    Health decay and recovery rates use conservative defaults.
    Calibrate after A010 with real provider latency distributions.
    """

    def __init__(
        self,
        providers: List[str],
        preferred: Optional[str] = None,
    ) -> None:
        self._health: Dict[str, ProviderHealth] = {
            p: ProviderHealth(provider_id=p) for p in providers
        }
        self._preferred = preferred
        self._routing_count = 0

    def select(self, now: Optional[float] = None) -> RoutingDecision:
        """
        Select the best available provider.

        Priority:
        1. Preferred provider if healthy
        2. Highest health score among available providers
        3. Retryable quarantined providers (after cooldown)
        4. all_unavailable=True if nothing available
        """
        self._routing_count += 1
        _now = now or time.time()

        # Build candidate list
        candidates: List[Tuple[float, str]] = []
        for pid, health in self._health.items():
            if health.status == ProviderStatus.QUARANTINED:
                if health.is_retryable(_now):
                    # Allow retry but with low priority
                    candidates.append((health.health_score * 0.5, pid))
            else:
                candidates.append((health.health_score, pid))

        if not candidates:
            return RoutingDecision(
                selected_provider="",
                fallback_chain=[],
                all_unavailable=True,
                reason="All providers quarantined and not yet retryable",
            )

        # Sort by health score descending
        candidates.sort(key=lambda x: -x[0])

        # Prefer the preferred provider if it's in the top tier
        if self._preferred and self._preferred in self._health:
            pref_health = self._health[self._preferred].health_score
            if pref_health >= MIN_HEALTH_THRESHOLD:
                # Bump preferred to front if within 20% of best
                best_score = candidates[0][0]
                if pref_health >= best_score * 0.80:
                    candidates = [(pref_health, self._preferred)] + [
                        c for c in candidates if c[1] != self._preferred
                    ]

        selected = candidates[0][1]
        fallback_chain = [c[1] for c in candidates]

        return RoutingDecision(
            selected_provider=selected,
            fallback_chain=fallback_chain,
            reason=f"health={self._health[selected].health_score:.3f} "
                   f"status={self._health[selected].status.value}",
        )

    def record_success(self, provider_id: str, latency_ms: float = 0.0) -> None:
        if provider_id in self._health:
            self._health[provider_id].record_success(latency_ms)

    def record_failure(self, provider_id: str) -> None:
        if provider_id in self._health:
            self._health[provider_id].record_failure()

    def health_snapshot(self) -> Dict[str, dict]:
        return {pid: h.to_dict() for pid, h in self._health.items()}

    def add_provider(self, provider_id: str) -> None:
        if provider_id not in self._health:
            self._health[provider_id] = ProviderHealth(provider_id=provider_id)

    @property
    def stats(self) -> dict:
        return {
            "routing_count": self._routing_count,
            "providers":     len(self._health),
            "healthy":       sum(1 for h in self._health.values()
                                 if h.status == ProviderStatus.HEALTHY),
            "degraded":      sum(1 for h in self._health.values()
                                 if h.status == ProviderStatus.DEGRADED),
            "quarantined":   sum(1 for h in self._health.values()
                                 if h.status == ProviderStatus.QUARANTINED),
        }


# ---- MODULE-LEVEL DEFAULT ---------------------------------------------------
# Pre-configured for standard Labyrinth-OS provider set
LABYRINTH_ROUTER = ProviderHealthRouter(
    providers=["anthropic", "openai", "grok", "ollama", "mock"],
    preferred="anthropic",
)


# ---- TEST SUITE -------------------------------------------------------------

def _test_initial_all_healthy() -> bool:
    router = ProviderHealthRouter(["anthropic", "openai", "ollama"])
    for pid, health in router._health.items():
        assert health.status == ProviderStatus.HEALTHY
    return True


def _test_selects_preferred_when_healthy() -> bool:
    router = ProviderHealthRouter(["anthropic", "openai"], preferred="anthropic")
    d = router.select()
    assert d.selected_provider == "anthropic"
    assert d.routable
    return True


def _test_falls_back_after_failures() -> bool:
    router = ProviderHealthRouter(["anthropic", "openai"], preferred="anthropic")
    # Hammer anthropic with failures
    for _ in range(5):
        router.record_failure("anthropic")
    d = router.select()
    # anthropic should now be quarantined or degraded, openai takes over
    assert d.selected_provider == "openai"
    return True


def _test_health_recovers_after_success() -> bool:
    router = ProviderHealthRouter(["anthropic"])
    router.record_failure("anthropic")
    initial = router._health["anthropic"].health_score
    router.record_success("anthropic", latency_ms=200.0)
    recovered = router._health["anthropic"].health_score
    assert recovered > initial
    return True


def _test_quarantine_blocks_routing() -> bool:
    router = ProviderHealthRouter(["anthropic"])
    # Drive to quarantine
    for _ in range(10):
        router.record_failure("anthropic")
    h = router._health["anthropic"]
    assert h.status == ProviderStatus.QUARANTINED
    return True


def _test_quarantine_retry_after_cooldown() -> bool:
    router = ProviderHealthRouter(["anthropic"])
    for _ in range(10):
        router.record_failure("anthropic")
    h = router._health["anthropic"]
    # Simulate cooldown elapsed
    h.quarantined_at = time.time() - QUARANTINE_DURATION_S - 1
    assert h.is_retryable()
    return True


def _test_all_unavailable_when_all_quarantined() -> bool:
    router = ProviderHealthRouter(["anthropic"])
    for _ in range(10):
        router.record_failure("anthropic")
    # No cooldown elapsed
    d = router.select(now=time.time())
    # Either routes to quarantined (retry allowed) or all_unavailable
    assert isinstance(d.routable, bool)
    return True


def _test_fallback_chain_ordered() -> bool:
    router = ProviderHealthRouter(["anthropic", "openai", "ollama"])
    # Degrade anthropic slightly
    router.record_failure("anthropic")
    d = router.select()
    # Fallback chain should exist and have multiple options
    assert len(d.fallback_chain) >= 1
    return True


def _test_to_dict_serializable() -> bool:
    import json
    router = ProviderHealthRouter(["anthropic", "openai"])
    router.record_success("anthropic", latency_ms=250.0)
    snapshot = router.health_snapshot()
    json.dumps(snapshot)
    return True


def _test_error_rate_calculation() -> bool:
    h = ProviderHealth("test")
    h.record_success()
    h.record_success()
    h.record_failure()
    assert abs(h.error_rate - 1/3) < 0.001
    return True


def _test_module_level_router() -> bool:
    assert isinstance(LABYRINTH_ROUTER, ProviderHealthRouter)
    assert "anthropic" in LABYRINTH_ROUTER._health
    d = LABYRINTH_ROUTER.select()
    assert d.routable
    return True


def run_tests():
    tests = [
        (_test_initial_all_healthy,             "initial_healthy"),
        (_test_selects_preferred_when_healthy,   "preferred_selected"),
        (_test_falls_back_after_failures,        "fallback_after_failures"),
        (_test_health_recovers_after_success,    "recovery"),
        (_test_quarantine_blocks_routing,        "quarantine"),
        (_test_quarantine_retry_after_cooldown,  "quarantine_retry"),
        (_test_all_unavailable_when_all_quarantined, "all_unavailable"),
        (_test_fallback_chain_ordered,           "fallback_chain"),
        (_test_to_dict_serializable,             "to_dict"),
        (_test_error_rate_calculation,           "error_rate"),
        (_test_module_level_router,              "module_router"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
