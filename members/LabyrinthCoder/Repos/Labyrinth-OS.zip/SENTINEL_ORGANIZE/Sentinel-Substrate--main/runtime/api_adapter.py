# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          api_adapter.py — Labyrinth-OS / Runtime
# ----------------------------------------------------------------------------

"""
api_adapter.py — Labyrinth-OS / Runtime
========================================
Provider-Agnostic LLM API Adapter

Single interface for all supported backends:
  - openai      (OpenAI API: gpt-4o, gpt-4-turbo, etc.)
  - anthropic   (Anthropic API: claude-* models)
  - grok        (xAI API: grok-* models, OpenAI-compatible)
  - ollama      (Local Ollama: qwen3:4b, llama3, etc.)
  - openai_compat (Any OpenAI-compatible endpoint)

Returns a normalized APIResponse regardless of provider.
Fail closed: any error → APIResponse with success=False.
Never raises — errors are captured in APIResponse.error.

Logprob availability is provider/model dependent:
  - openai:     available when logprobs=True in request
  - anthropic:  NOT available (no logprob API)
  - grok:       available on some models (OpenAI-compatible)
  - ollama:     available via /api/generate with logprobs field

When logprobs unavailable, metrics_incomplete=True is set.
The logprob extractor and ledger record this gap explicitly.
DO NOT infer or fake D_KL when logprobs are missing.

ACP-1 A010: This module makes A010 achievable via API backend,
not just Ollama. A010 closes when ignition.py produces its
first Chronicle entry with a LIVE_INFERENCE event.

References:
  ARCHITECTURE.md      — L1 Orchestration / EDEN
  ACP-1.yaml           — A010, A011, A022
  logprob_bridge_adapter.py — consumer of extracted logprobs
  ignition.py          — entry point
"""

from __future__ import annotations

# ── Cross-pollination: SEDA Oracle patterns (MIT) + BoundedSensorGate ──────────
# extract_from_json: safe JSON path traversal ported from SEDA common/fetch.rs
# BoundedSensorGate: staleness + rate + bound checking on API response values
try:
    import sys as _sys, os as _os
    _root = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), '..'))
    if _root not in _sys.path: _sys.path.insert(0, _root)
    from execution.pre_cgir_gate.bounded_sensor_gate import (
        extract_from_json,
        safe_median_float,
        BoundedSensorGate,
        SENSOR_STALENESS_THRESHOLD_S,
    )
    _BOUNDED_GATE_AVAILABLE = True
except ImportError:
    _BOUNDED_GATE_AVAILABLE = False
    def extract_from_json(data, json_path):  # type: ignore
        """Fallback: simple path traversal without validation."""
        current = data
        for seg in json_path:
            try:
                current = current[int(seg)] if isinstance(current, list) else current[seg]
            except (KeyError, IndexError, ValueError, TypeError):
                return None
        return float(current) if isinstance(current, (int, float, str)) else None

import json
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, List, Optional


# ─── PROVIDERS ────────────────────────────────────────────────────────────────

@unique
class Provider(str, Enum):
    OPENAI        = "openai"
    ANTHROPIC     = "anthropic"
    GROK          = "grok"
    OLLAMA        = "ollama"
    OPENAI_COMPAT = "openai_compat"
    MOCK          = "mock"   # dry-run: no network, deterministic response


# ─── NORMALIZED TOKEN LOGPROB ─────────────────────────────────────────────────

@dataclass(frozen=True)
class TokenLogprob:
    """One token with its log probability."""
    token:   str
    logprob: float    # log probability (natural log, typically negative)
    bytes:   Optional[List[int]] = None


# ─── NORMALIZED API RESPONSE ──────────────────────────────────────────────────

@dataclass
class APIResponse:
    """
    Normalized response from any provider.

    success          — False if any error occurred
    text             — full response text (empty string on error)
    provider         — which backend produced this
    model            — model identifier used
    token_logprobs   — list of TokenLogprob (empty if unavailable)
    metrics_incomplete — True if logprobs were requested but not returned
    input_tokens     — token count for the prompt (0 if unavailable)
    output_tokens    — token count for the response (0 if unavailable)
    latency_ms       — wall clock time for the API call
    error            — error message if success=False
    raw              — raw provider response dict (for debugging)
    """
    success:            bool
    text:               str
    provider:           Provider
    model:              str
    token_logprobs:     List[TokenLogprob] = field(default_factory=list)
    metrics_incomplete: bool = False
    input_tokens:       int = 0
    output_tokens:      int = 0
    latency_ms:         float = 0.0
    error:              str = ""
    raw:                Dict[str, Any] = field(default_factory=dict)

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success":            self.success,
            "provider":           self.provider.value,
            "model":              self.model,
            "text_length":        len(self.text),
            "logprob_count":      len(self.token_logprobs),
            "metrics_incomplete": self.metrics_incomplete,
            "input_tokens":       self.input_tokens,
            "output_tokens":      self.output_tokens,
            "latency_ms":         round(self.latency_ms, 2),
            "error":              self.error,
        }


# ─── API CONFIG ───────────────────────────────────────────────────────────────

@dataclass
class APIConfig:
    """
    Configuration for one API call.

    provider        — which backend
    model           — model string (e.g. "gpt-4o", "claude-sonnet-4-20250514")
    api_key         — API key (None for Ollama local)
    base_url        — override endpoint (for openai_compat or custom Ollama)
    max_tokens      — maximum response tokens
    temperature     — sampling temperature
    request_logprobs — whether to request logprobs (not all providers support)
    timeout_s       — HTTP request timeout in seconds
    system_prompt   — optional system prompt
    """
    provider:         Provider
    model:            str
    api_key:          Optional[str] = None
    base_url:         Optional[str] = None
    max_tokens:       int = 512
    temperature:      float = 0.7
    request_logprobs: bool = True
    timeout_s:        int = 30
    system_prompt:    str = ""


# ─── PROVIDER DEFAULTS ────────────────────────────────────────────────────────

PROVIDER_DEFAULTS: Dict[Provider, Dict[str, Any]] = {
    Provider.OPENAI:        {"base_url": "https://api.openai.com/v1"},
    Provider.ANTHROPIC:     {"base_url": "https://api.anthropic.com/v1"},
    Provider.GROK:          {"base_url": "https://api.x.ai/v1"},
    Provider.OLLAMA:        {"base_url": "http://localhost:11434"},
    Provider.OPENAI_COMPAT: {"base_url": None},  # must be provided
}

# Providers that support logprobs in their API
LOGPROB_CAPABLE: Dict[Provider, bool] = {
    Provider.OPENAI:        True,
    Provider.ANTHROPIC:     False,   # Anthropic does not expose logprobs
    Provider.GROK:          True,    # grok-3 and above support logprobs
    Provider.OLLAMA:        True,    # via /api/generate
    Provider.OPENAI_COMPAT: True,    # assume capable; fallback handles failure
    Provider.MOCK:          True,    # mock returns synthetic logprobs
}


# ─── HTTP HELPER ──────────────────────────────────────────────────────────────

def _post_json(url: str, payload: Dict, headers: Dict,
               timeout: int) -> Dict[str, Any]:
    """Make a POST request with JSON body. Returns parsed response dict."""
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


# ─── PROVIDER ADAPTERS ────────────────────────────────────────────────────────

def _call_openai_compat(
    config: APIConfig, prompt: str, is_anthropic: bool = False
) -> APIResponse:
    """
    Call OpenAI-compatible endpoint (OpenAI, Grok, openai_compat).
    Anthropic uses a different protocol — handled separately.
    """
    base_url = (
        config.base_url
        or PROVIDER_DEFAULTS[config.provider]["base_url"]
    )
    url = f"{base_url}/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {config.api_key}",
    }

    messages = []
    if config.system_prompt:
        messages.append({"role": "system", "content": config.system_prompt})
    messages.append({"role": "user", "content": prompt})

    payload: Dict[str, Any] = {
        "model": config.model,
        "messages": messages,
        "max_tokens": config.max_tokens,
        "temperature": config.temperature,
    }

    # Request logprobs if capable and requested
    capable = LOGPROB_CAPABLE.get(config.provider, True)
    if config.request_logprobs and capable:
        payload["logprobs"] = True
        payload["top_logprobs"] = 1

    t0 = time.perf_counter()
    try:
        raw = _post_json(url, payload, headers, config.timeout_s)
    except Exception as exc:
        return APIResponse(
            success=False, text="", provider=config.provider,
            model=config.model, error=str(exc),
            metrics_incomplete=True,
        )
    latency_ms = (time.perf_counter() - t0) * 1000

    # Extract text
    try:
        text = raw["choices"][0]["message"]["content"] or ""
    except (KeyError, IndexError):
        return APIResponse(
            success=False, text="", provider=config.provider,
            model=config.model, error="Unexpected response structure",
            raw=raw, metrics_incomplete=True,
            latency_ms=latency_ms,
        )

    # Extract token counts
    usage = raw.get("usage", {})
    input_tokens  = usage.get("prompt_tokens", 0)
    output_tokens = usage.get("completion_tokens", 0)

    # Extract logprobs
    token_logprobs: List[TokenLogprob] = []
    metrics_incomplete = False

    if config.request_logprobs:
        if not capable:
            metrics_incomplete = True  # provider doesn't support logprobs
        else:
            try:
                lp_content = raw["choices"][0].get("logprobs", {})
                if lp_content and "content" in lp_content:
                    for item in lp_content["content"]:
                        token_logprobs.append(TokenLogprob(
                            token=item.get("token", ""),
                            logprob=item.get("logprob", 0.0),
                            bytes=item.get("bytes"),
                        ))
                elif lp_content is None or lp_content == {}:
                    metrics_incomplete = True
            except (KeyError, TypeError):
                metrics_incomplete = True

    return APIResponse(
        success=True, text=text, provider=config.provider,
        model=config.model, token_logprobs=token_logprobs,
        metrics_incomplete=metrics_incomplete,
        input_tokens=input_tokens, output_tokens=output_tokens,
        latency_ms=latency_ms, raw=raw,
    )


def _call_anthropic(config: APIConfig, prompt: str) -> APIResponse:
    """
    Call Anthropic Messages API.
    Note: Anthropic does NOT expose logprobs. metrics_incomplete=True always.
    """
    base_url = config.base_url or PROVIDER_DEFAULTS[Provider.ANTHROPIC]["base_url"]
    url = f"{base_url}/messages"
    headers = {
        "Content-Type": "application/json",
        "x-api-key": config.api_key or "",
        "anthropic-version": "2023-06-01",
    }

    payload: Dict[str, Any] = {
        "model": config.model,
        "max_tokens": config.max_tokens,
        "messages": [{"role": "user", "content": prompt}],
    }
    if config.system_prompt:
        payload["system"] = config.system_prompt

    t0 = time.perf_counter()
    try:
        raw = _post_json(url, payload, headers, config.timeout_s)
    except Exception as exc:
        return APIResponse(
            success=False, text="", provider=Provider.ANTHROPIC,
            model=config.model, error=str(exc),
            metrics_incomplete=True,
        )
    latency_ms = (time.perf_counter() - t0) * 1000

    try:
        text = raw["content"][0]["text"] or ""
    except (KeyError, IndexError):
        return APIResponse(
            success=False, text="", provider=Provider.ANTHROPIC,
            model=config.model, error="Unexpected Anthropic response structure",
            raw=raw, metrics_incomplete=True, latency_ms=latency_ms,
        )

    usage = raw.get("usage", {})
    return APIResponse(
        success=True, text=text, provider=Provider.ANTHROPIC,
        model=config.model,
        token_logprobs=[],
        metrics_incomplete=True,   # Anthropic never exposes logprobs
        input_tokens=usage.get("input_tokens", 0),
        output_tokens=usage.get("output_tokens", 0),
        latency_ms=latency_ms, raw=raw,
    )


def _call_ollama(config: APIConfig, prompt: str) -> APIResponse:
    """
    Call local Ollama via /api/generate.
    Supports logprobs extraction from response metadata.
    """
    base_url = config.base_url or PROVIDER_DEFAULTS[Provider.OLLAMA]["base_url"]
    url = f"{base_url}/api/generate"
    headers = {"Content-Type": "application/json"}

    payload: Dict[str, Any] = {
        "model": config.model,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": config.temperature,
            "num_predict": config.max_tokens,
        },
    }
    if config.system_prompt:
        payload["system"] = config.system_prompt

    t0 = time.perf_counter()
    try:
        raw = _post_json(url, payload, headers, config.timeout_s)
    except Exception as exc:
        return APIResponse(
            success=False, text="", provider=Provider.OLLAMA,
            model=config.model, error=str(exc),
            metrics_incomplete=True,
        )
    latency_ms = (time.perf_counter() - t0) * 1000

    text = raw.get("response", "")
    if not text:
        return APIResponse(
            success=False, text="", provider=Provider.OLLAMA,
            model=config.model, error="Empty Ollama response",
            raw=raw, metrics_incomplete=True, latency_ms=latency_ms,
        )

    # Ollama token counts
    input_tokens  = raw.get("prompt_eval_count", 0)
    output_tokens = raw.get("eval_count", 0)

    # Ollama logprobs: returned as list of log-probabilities in context
    token_logprobs: List[TokenLogprob] = []
    metrics_incomplete = False
    if config.request_logprobs:
        lp_list = raw.get("logprobs", None)
        if lp_list and isinstance(lp_list, list):
            for i, lp in enumerate(lp_list):
                token_logprobs.append(TokenLogprob(
                    token=f"<t{i}>", logprob=float(lp),
                ))
        else:
            # Ollama didn't return logprobs — model may not support it
            metrics_incomplete = True

    return APIResponse(
        success=True, text=text, provider=Provider.OLLAMA,
        model=config.model, token_logprobs=token_logprobs,
        metrics_incomplete=metrics_incomplete,
        input_tokens=input_tokens, output_tokens=output_tokens,
        latency_ms=latency_ms, raw=raw,
    )


def _call_mock(config: APIConfig, prompt: str) -> APIResponse:
    """
    Mock provider — no network call. Deterministic synthetic response.

    Purpose: dry-run mode for testing the full ignition→verify_run pipeline
    without an API key. Swap --backend mock → --backend anthropic for A010.

    Returns synthetic logprobs so metrics_complete=True and A011 path
    can be exercised locally.
    """
    import math
    # Deterministic response based on prompt hash
    ph = hash(prompt) % 1000
    response_text = f"Mock response {ph}: reasoning complete in one step."

    # Synthetic logprobs: plausible values, not random
    words = response_text.split()
    token_logprobs = [
        TokenLogprob(token=w, logprob=-0.5 - (i * 0.05))
        for i, w in enumerate(words[:10])
    ]

    return APIResponse(
        success=True,
        text=response_text,
        provider=Provider.MOCK,
        model=config.model,
        token_logprobs=token_logprobs,
        metrics_incomplete=False,
        input_tokens=len(prompt.split()),
        output_tokens=len(words),
        latency_ms=1.0,
        raw={"mock": True},
    )



# ─── MAIN ADAPTER ─────────────────────────────────────────────────────────────

class APIAdapter:
    """
    Provider-agnostic LLM adapter.

    Usage:
        config = APIConfig(
            provider=Provider.ANTHROPIC,
            model="claude-sonnet-4-20250514",
            api_key="sk-ant-...",
        )
        adapter = APIAdapter(config)
        response = adapter.call("What is 2+2?")
        if response.success:
            print(response.text)
        if response.metrics_incomplete:
            print("Logprobs unavailable — D_KL will not be real")
    """

    def __init__(self, config: APIConfig) -> None:
        self._config = config

    def call(self, prompt: str) -> APIResponse:
        """
        Call the configured provider with a prompt.
        Returns normalized APIResponse. Never raises.
        """
        try:
            if self._config.provider == Provider.MOCK:
                return _call_mock(self._config, prompt)
            elif self._config.provider == Provider.ANTHROPIC:
                return _call_anthropic(self._config, prompt)
            elif self._config.provider == Provider.OLLAMA:
                return _call_ollama(self._config, prompt)
            else:
                # OpenAI, Grok, openai_compat
                return _call_openai_compat(self._config, prompt)
        except Exception as exc:
            return APIResponse(
                success=False, text="",
                provider=self._config.provider,
                model=self._config.model,
                error=f"Unhandled adapter error: {exc}",
                metrics_incomplete=True,
            )

    @property
    def provider(self) -> Provider:
        return self._config.provider

    @property
    def model(self) -> str:
        return self._config.model


# ─── RESPONSE VALUE EXTRACTION ───────────────────────────────────────────────

def extract_response_value(
    response_data: object,
    json_path: list,
    channel_name: str = "response",
    reading_timestamp: Optional[float] = None,
) -> Optional[float]:
    """
    Extract and validate a numeric value from an API response.

    Combines extract_from_json (SEDA MIT pattern) with optional
    staleness checking. Returns None if path missing, value invalid,
    or reading stale.

    Parameters
    ----------
    response_data:      The parsed API response dict/list.
    json_path:          Path to traverse, e.g. ["content", "0", "logprob"].
    channel_name:       Name for error messages (informational).
    reading_timestamp:  When the response was produced (for staleness check).
    """
    import time as _time
    val = extract_from_json(response_data, json_path)
    if val is None:
        return None
    if reading_timestamp is not None and _BOUNDED_GATE_AVAILABLE:
        now = _time.time()
        age = now - reading_timestamp
        if age < 0 or age > SENSOR_STALENESS_THRESHOLD_S:
            return None
    return val


# ─── FACTORY ──────────────────────────────────────────────────────────────────

def make_adapter(
    backend: str,
    model: str,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    **kwargs,
) -> APIAdapter:
    """
    Factory for ignition.py CLI usage.

    backend: "openai" | "anthropic" | "grok" | "ollama" | "openai_compat"
    model:   model string
    api_key: API key (not needed for Ollama)
    """
    try:
        provider = Provider(backend)
    except ValueError:
        raise ValueError(
            f"Unknown backend '{backend}'. "
            f"Valid: {[p.value for p in Provider]}"
        )

    if provider not in (Provider.OLLAMA, Provider.MOCK) and not api_key:
        raise ValueError(f"api_key required for backend '{backend}'")

    if provider == Provider.OPENAI_COMPAT and not base_url:
        raise ValueError("base_url required for openai_compat backend")

    config = APIConfig(
        provider=provider,
        model=model,
        api_key=api_key,
        base_url=base_url,
        **kwargs,
    )
    return APIAdapter(config)


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_provider_enum_values() -> bool:
    assert Provider.OPENAI.value == "openai"
    assert Provider.ANTHROPIC.value == "anthropic"
    assert Provider.GROK.value == "grok"
    assert Provider.OLLAMA.value == "ollama"
    assert Provider.OPENAI_COMPAT.value == "openai_compat"
    return True

def _test_api_response_defaults() -> bool:
    r = APIResponse(
        success=True, text="hello", provider=Provider.OLLAMA, model="qwen3:4b"
    )
    assert r.token_logprobs == []
    assert r.metrics_incomplete is False
    assert r.input_tokens == 0
    assert r.total_tokens == 0
    assert r.error == ""
    return True

def _test_api_response_to_dict() -> bool:
    r = APIResponse(
        success=True, text="hello", provider=Provider.OPENAI,
        model="gpt-4o", input_tokens=10, output_tokens=5,
        latency_ms=123.4,
    )
    d = r.to_dict()
    assert d["success"] is True
    assert d["provider"] == "openai"
    assert d["input_tokens"] == 10
    assert d["output_tokens"] == 5
    return True

def _test_anthropic_always_metrics_incomplete() -> bool:
    """Anthropic never exposes logprobs — metrics_incomplete must be True."""
    assert not LOGPROB_CAPABLE[Provider.ANTHROPIC]
    return True

def _test_make_adapter_valid_backends() -> bool:
    for backend in ["openai", "anthropic", "grok", "ollama"]:
        key = None if backend == "ollama" else "test-key"
        adapter = make_adapter(backend, "test-model", api_key=key)
        assert adapter.provider == Provider(backend)
    return True

def _test_make_adapter_unknown_backend_raises() -> bool:
    try:
        make_adapter("unknown_provider", "model", api_key="key")
        raise AssertionError("Should have raised ValueError")
    except ValueError as e:
        assert "unknown_provider" in str(e)
    return True

def _test_make_adapter_missing_key_raises() -> bool:
    for backend in ["openai", "anthropic", "grok"]:
        try:
            make_adapter(backend, "model", api_key=None)
            raise AssertionError(f"Should raise for {backend}")
        except ValueError:
            pass
    return True

def _test_make_adapter_openai_compat_needs_base_url() -> bool:
    try:
        make_adapter("openai_compat", "model", api_key="key", base_url=None)
        raise AssertionError("Should require base_url")
    except ValueError as e:
        assert "base_url" in str(e)
    return True

def _test_api_config_defaults() -> bool:
    config = APIConfig(provider=Provider.OLLAMA, model="qwen3:4b")
    assert config.max_tokens == 512
    assert config.temperature == 0.7
    assert config.request_logprobs is True
    assert config.timeout_s == 30
    return True

def _test_call_returns_response_on_network_failure() -> bool:
    """Call with bad endpoint returns APIResponse(success=False), does not raise."""
    config = APIConfig(
        provider=Provider.OLLAMA,
        model="qwen3:4b",
        base_url="http://localhost:99999",  # nothing listening here
        timeout_s=1,
    )
    adapter = APIAdapter(config)
    response = adapter.call("test")
    assert isinstance(response, APIResponse)
    assert response.success is False
    assert response.metrics_incomplete is True
    assert response.error != ""
    return True

def _test_fail_closed_no_raise() -> bool:
    """APIAdapter.call() never raises regardless of failure mode."""
    config = APIConfig(
        provider=Provider.OPENAI,
        model="gpt-4o",
        api_key="invalid-key-that-will-fail",
        base_url="http://localhost:99999",
        timeout_s=1,
    )
    adapter = APIAdapter(config)
    try:
        response = adapter.call("test")
        assert response.success is False
    except Exception as e:
        raise AssertionError(f"adapter.call() should never raise, got: {e}")
    return True

def _test_logprob_capable_map_complete() -> bool:
    """Every provider has an entry in LOGPROB_CAPABLE."""
    for provider in Provider:
        assert provider in LOGPROB_CAPABLE, f"{provider} missing from LOGPROB_CAPABLE"
    return True

def _test_total_tokens_sum() -> bool:
    r = APIResponse(
        success=True, text="x", provider=Provider.OPENAI, model="gpt-4o",
        input_tokens=100, output_tokens=50,
    )
    assert r.total_tokens == 150
    return True



def _test_mock_provider_exists() -> bool:
    """Provider.MOCK is a valid provider value."""
    assert Provider.MOCK.value == "mock"
    return True

def _test_mock_no_api_key_required() -> bool:
    """Mock adapter can be created without an API key."""
    adapter = make_adapter("mock", "mock-model-v1")
    assert adapter.provider == Provider.MOCK
    return True

def _test_mock_call_succeeds() -> bool:
    """Mock backend returns a successful APIResponse."""
    adapter = make_adapter("mock", "mock-model-v1")
    r = adapter.call("What is 2+2?")
    assert r.success is True
    assert len(r.text) > 0
    assert r.provider == Provider.MOCK
    return True

def _test_mock_has_logprobs() -> bool:
    """Mock backend returns synthetic logprobs (metrics_incomplete=False)."""
    adapter = make_adapter("mock", "mock-model-v1")
    r = adapter.call("Test prompt")
    assert r.metrics_incomplete is False
    assert len(r.token_logprobs) > 0
    return True

def _test_mock_is_deterministic() -> bool:
    """Same prompt → same mock response text."""
    adapter = make_adapter("mock", "mock-model-v1")
    r1 = adapter.call("stable prompt")
    r2 = adapter.call("stable prompt")
    assert r1.text == r2.text
    return True

def _test_mock_latency_is_fast() -> bool:
    """Mock latency is 1ms — clearly not a real network call."""
    adapter = make_adapter("mock", "mock-model-v1")
    r = adapter.call("test")
    assert r.latency_ms == 1.0
    return True

def run_tests() -> tuple:
    tests = sorted(
        [(name, obj) for name, obj in globals().items()
         if name.startswith("_test_") and callable(obj)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    import hashlib as _hl
    print("=" * 70)
    print("API ADAPTER — Labyrinth-OS / Runtime")
    print("=" * 70)
    print("\n  Backends: OpenAI | Anthropic | Grok | Ollama | OpenAI-compat")
    print("  Logprob support: OpenAI ✓  Grok ✓  Ollama ✓  Anthropic ✗ (by design)\n")
    print("── TEST SUITE ──\n")
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err: line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed > 0:
        raise SystemExit(1)
    with open(__file__, "rb") as f:
        fh = _hl.sha256(f.read()).hexdigest()
    print(f"\n── RECEIPT ──\n  SHA-256: {fh}\n  Tests: {passed}/{passed+failed}")
    print(f"\n{'='*70}\n  API ADAPTER — COMPLETE\n{'='*70}")
