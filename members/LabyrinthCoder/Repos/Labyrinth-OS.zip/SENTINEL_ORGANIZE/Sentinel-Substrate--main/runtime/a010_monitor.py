# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          a010_monitor.py — Labyrinth-OS / Runtime
# ----------------------------------------------------------------------------

"""
a010_monitor.py — Labyrinth-OS / Runtime
==========================================
A010 Signal Monitor — What to Watch During the First Real Run

This module defines exactly what signals matter during A010,
what good looks like, what bad looks like, and what's noise.

Usage:
    from a010_monitor import A010Monitor
    monitor = A010Monitor()
    monitor.analyze(session_json_path)

Or standalone after a run:
    python runtime/a010_monitor.py ignition_session_<ts>.json

What A010 is:
    First real inference run against a live LLM API.
    Mock runs have proven the pipeline. A010 proves it under real entropy.

What will actually happen:
    - Real LLM output (not mock strings)
    - Real logprobs (if provider supports them)
    - Real D_KL divergence values
    - Real tau_escape, chi, drift from actual token distributions
    - Unexpected edge cases the mock never produced

What you're watching for:
    1. Does confidence track with quality?
    2. Does the gate block low-confidence trials correctly?
    3. Do logprobs arrive, or is the adapter in fallback mode?
    4. Does the chain verify after real output?
    5. Are there ordering violations in the PipelineTrace?

References:
    ARCHITECTURE.md  — mandatory pipeline
    ACP-1: A010     — first live inference
    ACP-1: A011     — real logprobs
    INVARIANTS.md   — I1-I10
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ─── Sigma Anchor constants — imported from single source of truth ───
try:
    import sys as _sys, os as _os
    _root = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), '..'))
    if _root not in _sys.path: _sys.path.insert(0, _root)
    from sigma_anchors import (TAU_ESCAPE_FLOOR, CHI_WARN, CHI_COLLAPSE,
                                DRIFT_THRESHOLD, BETTI_1_CAP, CONFIDENCE_FLOOR)
except ImportError:
    TAU_ESCAPE_FLOOR = 0.75
    CHI_WARN = 0.15
    CHI_COLLAPSE = 0.40
    DRIFT_THRESHOLD = 0.12
    BETTI_1_CAP = 0.045
    CONFIDENCE_FLOOR = 0.65


# ── SIGNAL CLASSIFICATION ─────────────────────────────────────────────────────

@dataclass
class TrialSignal:
    """Interpreted signal from one trial."""
    trial_index:   int
    decision:      str      # EXECUTE / BLOCK / KILL
    severity:      str      # INFO / WARNING / ERROR / CRITICAL
    confidence:    float
    kl_divergence: float
    logprobs_ok:   bool
    error:         Optional[str]

    @property
    def is_healthy(self) -> bool:
        return (
            self.decision == "EXECUTE" and
            self.severity == "INFO" and
            self.confidence >= CONFIDENCE_FLOOR and
            self.logprobs_ok and
            not self.error
        )

    @property
    def confidence_tier(self) -> str:
        if self.confidence >= 0.85:  return "HIGH"
        if self.confidence >= 0.65:  return "MEDIUM"
        if self.confidence >= 0.40:  return "LOW"
        return "VERY_LOW"

    @property
    def needs_attention(self) -> bool:
        return (
            self.severity in ("ERROR", "CRITICAL") or
            self.confidence < CONFIDENCE_FLOOR or
            not self.logprobs_ok or
            bool(self.error)
        )


@dataclass
class A010Assessment:
    """Full assessment of one A010 session."""
    session_id:        str
    is_real_api:       bool
    is_mock:           bool
    a010_status:       str
    total_trials:      int
    successful_trials: int
    chain_valid:       bool
    signals:           List[TrialSignal] = field(default_factory=list)
    warnings:          List[str]         = field(default_factory=list)
    red_flags:         List[str]         = field(default_factory=list)
    observations:      List[str]         = field(default_factory=list)

    @property
    def health_score(self) -> float:
        if not self.signals: return 0.0
        healthy = sum(1 for s in self.signals if s.is_healthy)
        return healthy / len(self.signals)

    @property
    def logprob_coverage(self) -> float:
        if not self.signals: return 0.0
        return sum(1 for s in self.signals if s.logprobs_ok) / len(self.signals)

    @property
    def mean_confidence(self) -> float:
        if not self.signals: return 0.0
        return sum(s.confidence for s in self.signals) / len(self.signals)


# ── MONITOR ───────────────────────────────────────────────────────────────────

class A010Monitor:
    """
    Analyzes an ignition session JSON and produces a human-readable
    signal report for A010.

    Tells you:
    - What the signals mean
    - What to watch for
    - What's noise vs what requires action
    """

    def analyze(self, session_path: str) -> A010Assessment:
        """Load and analyze a session JSON."""
        with open(session_path) as f:
            summary = json.load(f)

        is_mock = summary.get("dry_run", False)
        real_api = summary.get("real_api", not is_mock)

        assessment = A010Assessment(
            session_id=summary.get("session_id", "unknown"),
            is_real_api=real_api,
            is_mock=is_mock,
            a010_status=summary.get("a010_status", "UNKNOWN"),
            total_trials=summary.get("trials_total", 0),
            successful_trials=summary.get("trials_success", 0),
            chain_valid=summary.get("chain_valid", False),
        )

        # Parse trial entries
        for entry in summary.get("chronicle_entries", []):
            signal = TrialSignal(
                trial_index=entry.get("trial_index", 0),
                decision=entry.get("decision", "UNKNOWN"),
                severity=entry.get("severity", "UNKNOWN"),
                confidence=float(entry.get("confidence", 0.0)),
                kl_divergence=float(entry.get("kl_divergence", 0.0)),
                logprobs_ok=entry.get("logprobs_available", False),
                error=entry.get("error"),
            )
            assessment.signals.append(signal)

        # Analyze
        self._check_mock_boundary(assessment, summary)
        self._check_chain(assessment, summary)
        self._check_signals(assessment)
        self._check_logprobs(assessment)
        self._check_pipeline_trace(assessment, summary)

        return assessment

    def _check_mock_boundary(self, a: A010Assessment, summary: dict) -> None:
        if a.is_mock:
            a.observations.append(
                "DRY-RUN: This is a mock session. "
                "Pipeline path validated. A010 not closed."
            )
        else:
            a.observations.append(
                "REAL API: This is a live session. "
                f"A010 status: {a.a010_status}"
            )

    def _check_chain(self, a: A010Assessment, summary: dict) -> None:
        if not a.chain_valid:
            a.red_flags.append(
                "CHAIN INVALID: Hash chain verification failed. "
                "Replay integrity compromised. Do not accept this run."
            )
        else:
            a.observations.append("Chain: valid — replay integrity confirmed")

    def _check_signals(self, a: A010Assessment) -> None:
        if not a.signals:
            a.warnings.append("No trial signals found — session may be empty")
            return

        # Confidence analysis
        mc = a.mean_confidence
        if mc < CONFIDENCE_FLOOR:
            a.red_flags.append(
                f"LOW MEAN CONFIDENCE: {mc:.3f} < floor {CONFIDENCE_FLOOR}. "
                f"Real LLM output may be too short/malformed for logprob extraction."
            )
        elif mc < 0.75:
            a.warnings.append(
                f"MEDIUM CONFIDENCE: {mc:.3f}. "
                f"Acceptable but watch trend across sessions."
            )
        else:
            a.observations.append(f"Mean confidence: {mc:.3f} — healthy")

        # Decision distribution
        decisions = {}
        for s in a.signals:
            decisions[s.decision] = decisions.get(s.decision, 0) + 1
        a.observations.append(f"Decision distribution: {decisions}")

        # Any CRITICAL trials
        critical = [s for s in a.signals if s.severity == "CRITICAL"]
        if critical:
            a.red_flags.append(
                f"{len(critical)} CRITICAL trials: tau_escape below floor or chi collapsed. "
                f"Gate correctly blocked these."
            )

        # Trials with errors
        errors = [s for s in a.signals if s.error]
        if errors:
            a.warnings.append(
                f"{len(errors)} trials had errors: "
                + "; ".join(s.error for s in errors[:3])
            )

    def _check_logprobs(self, a: A010Assessment) -> None:
        coverage = a.logprob_coverage
        if coverage < 0.5:
            a.warnings.append(
                f"LOGPROB COVERAGE: {coverage:.0%}. "
                f"More than half of trials missing logprobs. "
                f"Confidence values are from fallback estimator. "
                f"A011 (real logprobs) remains open."
            )
        elif coverage < 1.0:
            a.warnings.append(
                f"PARTIAL LOGPROB COVERAGE: {coverage:.0%}. "
                f"Some trials using fallback confidence."
            )
        else:
            a.observations.append(f"Logprob coverage: 100% — A011 conditions met")

    def _check_pipeline_trace(self, a: A010Assessment, summary: dict) -> None:
        violations = summary.get("option_b_violations", [])
        if violations:
            a.warnings.append(
                f"PIPELINE TRACE: {len(violations)} Option B violations "
                f"(GAP 1 — expected until Lane 1 fully wired): "
                + "; ".join(v[:60] for v in violations[:2])
            )
        else:
            a.observations.append("Pipeline trace: no violations")

    def report(self, assessment: A010Assessment) -> str:
        lines = []
        lines.append("=" * 70)
        lines.append("A010 SIGNAL MONITOR — Labyrinth-OS")
        lines.append("=" * 70)
        lines.append(f"\nSession:  {assessment.session_id}")
        lines.append(f"Mode:     {'MOCK/DRY-RUN' if assessment.is_mock else 'REAL API'}")
        lines.append(f"A010:     {assessment.a010_status}")
        lines.append(f"Chain:    {'VALID' if assessment.chain_valid else 'INVALID'}")
        lines.append(f"Trials:   {assessment.successful_trials}/{assessment.total_trials}")
        lines.append(f"Health:   {assessment.health_score:.0%}")
        lines.append(f"Conf:     {assessment.mean_confidence:.3f} mean")
        lines.append(f"Logprobs: {assessment.logprob_coverage:.0%} coverage")

        if assessment.red_flags:
            lines.append(f"\n{'─'*30} RED FLAGS ({len(assessment.red_flags)}) {'─'*30}")
            for r in assessment.red_flags:
                lines.append(f"  🔴 {r}")

        if assessment.warnings:
            lines.append(f"\n{'─'*30} WARNINGS ({len(assessment.warnings)}) {'─'*30}")
            for w in assessment.warnings:
                lines.append(f"  ⚠️  {w}")

        if assessment.observations:
            lines.append(f"\n{'─'*30} OBSERVATIONS {'─'*30}")
            for o in assessment.observations:
                lines.append(f"  ℹ️  {o}")

        lines.append(f"\n{'─'*30} WHAT TO WATCH {'─'*30}")
        lines.append("  During A010 real run, flag these immediately:")
        lines.append(f"  • confidence < {CONFIDENCE_FLOOR} consistently → logprob extraction failing")
        lines.append(f"  • severity = CRITICAL → tau_escape collapsed or chi too high")
        lines.append(f"  • chain_valid = False → replay integrity broken, reject run")
        lines.append(f"  • logprobs_ok = False → A011 still open, using fallback")
        lines.append(f"  • all decisions = BLOCK → gate threshold may need calibration")
        lines.append(f"  • all decisions = EXECUTE → gate may not be checking correctly")

        lines.append("\n" + "=" * 70)
        return "\n".join(lines)


# ── TEST SUITE ────────────────────────────────────────────────────────────────

def _test_monitor_constructs() -> bool:
    m = A010Monitor()
    assert m is not None
    return True

def _test_trial_signal_healthy() -> bool:
    s = TrialSignal(
        trial_index=0, decision="EXECUTE", severity="INFO",
        confidence=0.85, kl_divergence=0.05,
        logprobs_ok=True, error=None,
    )
    assert s.is_healthy
    assert not s.needs_attention
    assert s.confidence_tier == "HIGH"
    return True

def _test_trial_signal_unhealthy() -> bool:
    s = TrialSignal(
        trial_index=0, decision="BLOCK", severity="CRITICAL",
        confidence=0.30, kl_divergence=0.80,
        logprobs_ok=False, error="timeout",
    )
    assert not s.is_healthy
    assert s.needs_attention
    assert s.confidence_tier == "VERY_LOW"
    return True

def _test_assessment_health_score() -> bool:
    a = A010Assessment(
        session_id="test", is_real_api=False, is_mock=True,
        a010_status="PATH_VALIDATED_DRY_RUN",
        total_trials=3, successful_trials=3, chain_valid=True,
    )
    a.signals = [
        TrialSignal(0,"EXECUTE","INFO",0.85,0.05,True,None),
        TrialSignal(1,"EXECUTE","INFO",0.80,0.03,True,None),
        TrialSignal(2,"BLOCK","CRITICAL",0.30,0.90,False,None),
    ]
    score = a.health_score
    assert abs(score - 2/3) < 0.01
    return True

def _test_mock_boundary_detected() -> bool:
    import json, tempfile, os
    summary = {
        "session_id": "test_001",
        "dry_run": True,
        "real_api": False,
        "a010_status": "PATH_VALIDATED_DRY_RUN",
        "trials_total": 0,
        "trials_success": 0,
        "chain_valid": True,
        "chronicle_entries": [],
        "option_b_violations": ["I1 VIOLATED: LABELING"],
    }
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(summary, f)
        path = f.name
    try:
        m = A010Monitor()
        a = m.analyze(path)
        assert a.is_mock
        assert not a.is_real_api
        assert "mock" in a.a010_status.lower() or "DRY" in a.a010_status
        assert len(a.warnings) > 0  # violations warning
    finally:
        os.unlink(path)
    return True

def _test_report_generated() -> bool:
    a = A010Assessment(
        session_id="s1", is_real_api=False, is_mock=True,
        a010_status="PATH_VALIDATED_DRY_RUN",
        total_trials=2, successful_trials=2, chain_valid=True,
    )
    m = A010Monitor()
    report = m.report(a)
    assert "A010" in report
    assert "WHAT TO WATCH" in report
    assert len(report) > 200
    return True


def run_tests() -> tuple:
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        # Run analysis mode
        session_path = sys.argv[1]
        if not os.path.exists(session_path):
            print(f"ERROR: Session file not found: {session_path}")
            sys.exit(1)
        monitor = A010Monitor()
        assessment = monitor.analyze(session_path)
        print(monitor.report(assessment))
        sys.exit(1 if assessment.red_flags else 0)
    else:
        # Test mode
        print("=" * 70)
        print("A010 MONITOR — Labyrinth-OS")
        print("Signal watcher for the first real inference run.")
        print("=" * 70)
        print("\n── TEST SUITE ──\n")
        passed, failed, results = run_tests()
        for name, status, err in results:
            marker = "✓" if status == "PASS" else "✗"
            line = f"  {marker} {name}"
            if err: line += f"  → {err}"
            print(line)
        print(f"\n  Results: {passed} passed, {failed} failed")
        print(f"\nUsage after a real run:")
        print(f"  python runtime/a010_monitor.py ignition_session_<ts>.json")
        if failed:
            raise SystemExit(1)
