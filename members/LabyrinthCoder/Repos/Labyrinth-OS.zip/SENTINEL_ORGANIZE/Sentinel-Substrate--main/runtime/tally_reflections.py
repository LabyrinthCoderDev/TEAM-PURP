# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          tally_reflections.py -- Labyrinth-OS / Runtime
# ----------------------------------------------------------------------------

"""
tally_reflections.py -- Labyrinth-OS / Runtime
================================================
Session-Level Aggregation of TrialReflections

Implements the two-phase execute/tally pattern from SEDA Oracle (MIT).
Phase 1 (execute): each trial produces a TrialReflection independently.
Phase 2 (tally):   this module aggregates across all trials in a session.

The tally answers questions the individual trial cannot:
  - Which lessons appeared most frequently this session?
  - What is the median tau/chi/confidence across trials?
  - Is the system drifting between trial 1 and trial 5?
  - What is the aggregate honesty_ratio (cost estimation accuracy)?
  - How many trials passed vs blocked vs failed?

Why this pattern matters
------------------------
A single trial saying TAU_NEAR_FLOOR is a data point.
Five trials all saying TAU_NEAR_FLOOR is a signal.
The tally is what turns data points into signals.

Calibration note
----------------
The significance thresholds in this module (how many trials must
emit a lesson before it is flagged as a session pattern) are set
to conservative defaults. They will be calibrated against real data
after A010 (first live inference). The structure is correct now.
The numbers may shift.

References
----------
  runtime/trial_reflection.py  -- TrialReflection, reflect_on_trial()
  sigma_anchors.py             -- gate constants for threshold comparison
  ACP-1 A010                   -- first live inference (calibration gate)
  SEDA Oracle common           -- two-phase execute/tally pattern (MIT)
"""

from __future__ import annotations

import time
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

try:
    import sys as _sys, os as _os
    _root = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), '..'))
    if _root not in _sys.path:
        _sys.path.insert(0, _root)
    from trial_reflection import TrialReflection, ReflectionOutcome
    from sigma_anchors import (
        TAU_ESCAPE_FLOOR, CHI_WARN, CHI_COLLAPSE,
        CONFIDENCE_FLOOR, LABYRINTH_CONTRACT_VERSION,
    )
    _IMPORTS_OK = True
except ImportError:
    TAU_ESCAPE_FLOOR        = 0.75
    CHI_WARN                = 0.15
    CHI_COLLAPSE            = 0.40
    CONFIDENCE_FLOOR        = 0.65
    LABYRINTH_CONTRACT_VERSION = "1.0.0"
    _IMPORTS_OK             = False


# ---- LESSON PATTERN ---------------------------------------------------------

@dataclass(frozen=True)
class LessonPattern:
    """
    A lesson that appeared in multiple trials this session.

    frequency:     how many trials emitted this lesson
    fraction:      frequency / total_trials
    is_dominant:   True if fraction >= DOMINANT_THRESHOLD (0.6 default)
    """
    lesson:       str
    frequency:    int
    fraction:     float
    is_dominant:  bool


# ---- SESSION TALLY ----------------------------------------------------------

@dataclass
class SessionTally:
    """
    Aggregated view of all TrialReflections in one ignition session.

    Produced by tally_reflections(). Never mutates the underlying
    TrialReflections -- purely a read aggregation.

    Fields
    ------
    session_id:         Ignition session identifier.
    trial_count:        Total trials in this session.
    pass_count:         Trials with outcome SUCCESS.
    partial_count:      Trials with outcome PARTIAL.
    fail_count:         Trials with outcome FAILURE.
    pass_rate:          pass_count / trial_count.

    median_tau:         Median tau across trials with tau readings.
    median_chi:         Median chi across trials with chi readings.
    median_confidence:  Median confidence across trials.
    median_score:       Median composite quality score.

    tau_trend:          "STABLE", "DECLINING", or "RECOVERING"
                        Compares first-half median vs second-half median.
    chi_trend:          Same for chi.

    lesson_patterns:    Lessons that appeared in 2+ trials, sorted by frequency.
    dominant_lessons:   Lessons appearing in 60%+ of trials.

    mean_honesty_ratio: Mean of (joule_actual / joule_estimated).
                        1.0 = perfect cost estimation.
                        > 1.5 = JOULE_OVERRUN pattern in session.

    polite_lie_count:   Trials that detected POLITE_LIE provenance issue.
    gate_block_count:   Trials that resulted in GATE_BLOCKED.
    betti_placeholder:  True if any trial emitted BETTI_PLACEHOLDER
                        (betti_1 still 0.0, awaiting A010 calibration).

    session_health:     "HEALTHY", "DEGRADED", or "CRITICAL"
    health_reasons:     List of reasons if not HEALTHY.

    generated_at:       When this tally was produced.
    contract_version:   Schema version.
    """
    session_id:         str
    trial_count:        int
    pass_count:         int
    partial_count:      int
    fail_count:         int
    pass_rate:          float

    median_tau:         Optional[float]
    median_chi:         Optional[float]
    median_confidence:  Optional[float]
    median_score:       float

    tau_trend:          str
    chi_trend:          str

    lesson_patterns:    List[LessonPattern]
    dominant_lessons:   List[str]

    mean_honesty_ratio: float
    polite_lie_count:   int
    gate_block_count:   int
    betti_placeholder:  bool

    session_health:     str
    health_reasons:     List[str]

    generated_at:       float = field(default_factory=time.time)
    contract_version:   str   = LABYRINTH_CONTRACT_VERSION

    def to_dict(self) -> Dict:
        return {
            "session_id":        self.session_id,
            "trial_count":       self.trial_count,
            "pass_count":        self.pass_count,
            "partial_count":     self.partial_count,
            "fail_count":        self.fail_count,
            "pass_rate":         round(self.pass_rate, 4),
            "median_tau":        self.median_tau,
            "median_chi":        self.median_chi,
            "median_confidence": self.median_confidence,
            "median_score":      round(self.median_score, 4),
            "tau_trend":         self.tau_trend,
            "chi_trend":         self.chi_trend,
            "lesson_patterns":   [
                {"lesson": lp.lesson, "frequency": lp.frequency,
                 "fraction": round(lp.fraction, 3), "dominant": lp.is_dominant}
                for lp in self.lesson_patterns
            ],
            "dominant_lessons":  self.dominant_lessons,
            "mean_honesty_ratio": round(self.mean_honesty_ratio, 4),
            "polite_lie_count":  self.polite_lie_count,
            "gate_block_count":  self.gate_block_count,
            "betti_placeholder": self.betti_placeholder,
            "session_health":    self.session_health,
            "health_reasons":    self.health_reasons,
            "generated_at":      self.generated_at,
            "contract_version":  self.contract_version,
        }


# ---- UTILITIES --------------------------------------------------------------

def _safe_median(values: List[float]) -> Optional[float]:
    """Overflow-safe float median. Returns None for empty list."""
    if not values:
        return None
    sv = sorted(values)
    n = len(sv)
    if n % 2 == 1:
        return sv[n // 2]
    return (sv[n // 2 - 1] + sv[n // 2]) / 2.0


def _trend(first_half: List[float], second_half: List[float],
           higher_is_better: bool = True) -> str:
    """
    Compare first-half median vs second-half median.
    Returns "STABLE", "DECLINING", or "RECOVERING".
    """
    m1 = _safe_median(first_half)
    m2 = _safe_median(second_half)
    if m1 is None or m2 is None:
        return "STABLE"
    delta = m2 - m1
    threshold = 0.03  # 3-point change considered meaningful
    if abs(delta) < threshold:
        return "STABLE"
    if (delta > 0) == higher_is_better:
        return "RECOVERING"
    return "DECLINING"


# ---- TALLY ------------------------------------------------------------------

# Thresholds -- conservative defaults, calibrate after A010
_PATTERN_MIN_FREQUENCY:  int   = 2     # lesson must appear in 2+ trials
_DOMINANT_THRESHOLD:     float = 0.60  # 60%+ of trials = dominant
_UNHEALTHY_PASS_RATE:    float = 0.40  # below 40% pass rate = DEGRADED
_CRITICAL_PASS_RATE:     float = 0.20  # below 20% pass rate = CRITICAL
_OVERRUN_HONESTY_RATIO:  float = 1.50  # 1.5x+ cost overrun = flag


def tally_reflections(
    reflections: List["TrialReflection"],
    session_id: str = "unknown",
) -> SessionTally:
    """
    Aggregate all TrialReflections from one ignition session.

    Parameters
    ----------
    reflections:  List of TrialReflection objects from this session.
                  Can be empty (returns a zero-state tally).
    session_id:   Ignition session identifier for the tally record.

    Returns
    -------
    SessionTally with full aggregated view of the session.
    """
    n = len(reflections)

    if n == 0:
        return SessionTally(
            session_id=session_id,
            trial_count=0,
            pass_count=0, partial_count=0, fail_count=0,
            pass_rate=0.0,
            median_tau=None, median_chi=None,
            median_confidence=None, median_score=0.0,
            tau_trend="STABLE", chi_trend="STABLE",
            lesson_patterns=[], dominant_lessons=[],
            mean_honesty_ratio=1.0,
            polite_lie_count=0, gate_block_count=0,
            betti_placeholder=False,
            session_health="HEALTHY", health_reasons=["No trials in session"],
        )

    # ---- Outcome counts -----------------------------------------------------
    try:
        pass_count    = sum(1 for r in reflections
                            if r.outcome == ReflectionOutcome.SUCCESS)
        partial_count = sum(1 for r in reflections
                            if r.outcome == ReflectionOutcome.PARTIAL)
        fail_count    = sum(1 for r in reflections
                            if r.outcome == ReflectionOutcome.FAILURE)
    except Exception:
        # Fallback if ReflectionOutcome not importable
        pass_count    = sum(1 for r in reflections if r.verdict == "EXECUTE")
        partial_count = sum(1 for r in reflections if r.verdict == "BLOCK")
        fail_count    = sum(1 for r in reflections if r.verdict in ("KILL","ERROR"))

    pass_rate = pass_count / n

    # ---- Signal aggregation -------------------------------------------------
    taus   = [r.tau        for r in reflections if r.tau        is not None]
    chis   = [r.chi        for r in reflections if r.chi        is not None]
    confs  = [r.confidence for r in reflections if r.confidence is not None]
    scores = [r.score      for r in reflections]

    median_tau        = _safe_median(taus)
    median_chi        = _safe_median(chis)
    median_confidence = _safe_median(confs)
    median_score      = _safe_median(scores) or 0.0

    # ---- Trend analysis (first half vs second half) -------------------------
    mid = n // 2
    tau_trend = _trend(
        taus[:mid], taus[mid:], higher_is_better=True
    ) if len(taus) >= 4 else "STABLE"
    chi_trend = _trend(
        chis[:mid], chis[mid:], higher_is_better=False  # lower chi = better
    ) if len(chis) >= 4 else "STABLE"

    # ---- Lesson patterns ----------------------------------------------------
    all_lessons: List[str] = []
    for r in reflections:
        all_lessons.extend(r.lessons_emitted)

    lesson_counts = Counter(all_lessons)
    patterns = []
    for lesson, freq in sorted(lesson_counts.items(), key=lambda x: -x[1]):
        frac = freq / n
        if freq >= _PATTERN_MIN_FREQUENCY:
            patterns.append(LessonPattern(
                lesson=lesson,
                frequency=freq,
                fraction=frac,
                is_dominant=(frac >= _DOMINANT_THRESHOLD),
            ))

    dominant = [lp.lesson for lp in patterns if lp.is_dominant]

    # ---- Special counters ---------------------------------------------------
    polite_lie_count = sum(
        1 for r in reflections if "POLITE_LIE" in r.lessons_emitted
    )
    gate_block_count = sum(
        1 for r in reflections if "GATE_BLOCKED" in r.lessons_emitted
    )
    betti_placeholder = any(
        "BETTI_PLACEHOLDER" in r.lessons_emitted for r in reflections
    )

    # ---- Cost honesty -------------------------------------------------------
    honesty_ratios = []
    for r in reflections:
        if r.joule_estimated > 0:
            honesty_ratios.append(r.joule_actual / r.joule_estimated)
    mean_honesty = (sum(honesty_ratios) / len(honesty_ratios)
                    if honesty_ratios else 1.0)

    # ---- Session health -----------------------------------------------------
    health_reasons: List[str] = []

    if pass_rate < _CRITICAL_PASS_RATE:
        health_reasons.append(
            f"CRITICAL_PASS_RATE: {pass_rate:.0%} of trials passed"
        )
    elif pass_rate < _UNHEALTHY_PASS_RATE:
        health_reasons.append(
            f"LOW_PASS_RATE: {pass_rate:.0%} of trials passed"
        )

    if tau_trend == "DECLINING":
        health_reasons.append("TAU_DECLINING: epistemic escape eroding across session")
    if chi_trend == "DECLINING":  # for chi, DECLINING means chi is rising (bad)
        health_reasons.append("CHI_RISING: contradiction density increasing across session")
    if "POLITE_LIE" in dominant:
        health_reasons.append(
            f"POLITE_LIE_DOMINANT: {polite_lie_count}/{n} trials had unverified provenance"
        )
    if mean_honesty > _OVERRUN_HONESTY_RATIO:
        health_reasons.append(
            f"COST_OVERRUN: mean honesty_ratio={mean_honesty:.2f} (target <=1.5)"
        )
    if median_tau is not None and median_tau < TAU_ESCAPE_FLOOR:
        health_reasons.append(
            f"TAU_BELOW_FLOOR: median tau={median_tau:.3f} < floor={TAU_ESCAPE_FLOOR}"
        )
    if median_chi is not None and median_chi >= CHI_COLLAPSE:
        health_reasons.append(
            f"CHI_COLLAPSED: median chi={median_chi:.3f} >= collapse={CHI_COLLAPSE}"
        )

    if not health_reasons:
        session_health = "HEALTHY"
    elif pass_rate < _CRITICAL_PASS_RATE:
        session_health = "CRITICAL"
    else:
        session_health = "DEGRADED"

    return SessionTally(
        session_id=session_id,
        trial_count=n,
        pass_count=pass_count,
        partial_count=partial_count,
        fail_count=fail_count,
        pass_rate=pass_rate,
        median_tau=median_tau,
        median_chi=median_chi,
        median_confidence=median_confidence,
        median_score=median_score,
        tau_trend=tau_trend,
        chi_trend=chi_trend,
        lesson_patterns=patterns,
        dominant_lessons=dominant,
        mean_honesty_ratio=mean_honesty,
        polite_lie_count=polite_lie_count,
        gate_block_count=gate_block_count,
        betti_placeholder=betti_placeholder,
        session_health=session_health,
        health_reasons=health_reasons,
    )


# ---- TEST SUITE -------------------------------------------------------------

def _make_mock_reflection(
    verdict: str = "EXECUTE",
    tau: float = 0.82,
    chi: float = 0.10,
    confidence: float = 0.85,
    lessons: Optional[List[str]] = None,
    joule_est: float = 100.0,
    joule_actual: float = 110.0,
) -> "TrialReflection":
    """Build a minimal mock TrialReflection for testing."""
    from dataclasses import dataclass as _dc, field as _f
    import time as _t

    class _MockOutcome:
        SUCCESS = "SUCCESS"
        PARTIAL = "PARTIAL"
        FAILURE = "FAILURE"

    class _MockReflection:
        def __init__(self):
            self.trial_id        = f"mock-{int(_t.time()*1000)}"
            self.outcome         = _MockOutcome.SUCCESS if verdict == "EXECUTE" else _MockOutcome.FAILURE
            self.verdict         = verdict
            self.score           = round(confidence * tau, 4) if tau else confidence
            self.narrative       = "mock trial"
            self.joule_estimated = joule_est
            self.joule_actual    = joule_actual
            self.honesty_ratio   = joule_actual / joule_est if joule_est > 0 else 1.0
            self.lessons_emitted = lessons or []
            self.tau             = tau
            self.chi             = chi
            self.drift           = 0.05
            self.betti           = 0.0
            self.confidence      = confidence
            self.timestamp       = _t.time()
            self.contract_version = "1.0.0"

    return _MockReflection()


def _test_empty_session() -> bool:
    tally = tally_reflections([], session_id="empty")
    assert tally.trial_count == 0
    assert tally.session_health == "HEALTHY"
    assert tally.pass_rate == 0.0
    return True


def _test_healthy_session() -> bool:
    refs = [_make_mock_reflection("EXECUTE", tau=0.85, chi=0.10, confidence=0.88)
            for _ in range(5)]
    tally = tally_reflections(refs, "healthy-test")
    assert tally.trial_count == 5
    assert tally.pass_count == 5
    assert tally.pass_rate == 1.0
    assert tally.session_health == "HEALTHY"
    assert tally.median_tau is not None
    return True


def _test_lesson_pattern_detection() -> bool:
    refs = [
        _make_mock_reflection(lessons=["TAU_NEAR_FLOOR", "CHI_ELEVATED"]),
        _make_mock_reflection(lessons=["TAU_NEAR_FLOOR"]),
        _make_mock_reflection(lessons=["TAU_NEAR_FLOOR", "GATE_BLOCKED"]),
        _make_mock_reflection(lessons=[]),
        _make_mock_reflection(lessons=["CHI_ELEVATED"]),
    ]
    tally = tally_reflections(refs, "lesson-test")
    lessons = {lp.lesson: lp for lp in tally.lesson_patterns}
    assert "TAU_NEAR_FLOOR" in lessons
    assert lessons["TAU_NEAR_FLOOR"].frequency == 3
    assert lessons["TAU_NEAR_FLOOR"].is_dominant  # 3/5 = 60%
    return True


def _test_dominant_lesson() -> bool:
    refs = [_make_mock_reflection(lessons=["POLITE_LIE"]) for _ in range(4)]
    refs += [_make_mock_reflection(lessons=[]) for _ in range(1)]
    tally = tally_reflections(refs, "polite-lie-test")
    assert "POLITE_LIE" in tally.dominant_lessons
    assert tally.polite_lie_count == 4
    return True


def _test_degraded_health_low_pass_rate() -> bool:
    refs = (
        [_make_mock_reflection("EXECUTE") for _ in range(2)] +
        [_make_mock_reflection("BLOCK") for _ in range(8)]
    )
    tally = tally_reflections(refs, "degraded-test")
    assert tally.session_health in ("DEGRADED", "CRITICAL")
    return True


def _test_cost_honesty() -> bool:
    refs = [_make_mock_reflection(joule_est=100.0, joule_actual=200.0)
            for _ in range(3)]
    tally = tally_reflections(refs, "cost-test")
    assert tally.mean_honesty_ratio == 2.0
    assert any("COST_OVERRUN" in r for r in tally.health_reasons)
    return True


def _test_betti_placeholder_flagged() -> bool:
    refs = [
        _make_mock_reflection(lessons=["BETTI_PLACEHOLDER"]),
        _make_mock_reflection(lessons=[]),
    ]
    tally = tally_reflections(refs, "betti-test")
    assert tally.betti_placeholder is True
    return True


def _test_to_dict_serializable() -> bool:
    import json
    refs = [_make_mock_reflection() for _ in range(3)]
    tally = tally_reflections(refs, "serialize-test")
    d = tally.to_dict()
    json.dumps(d)  # must not raise
    assert "session_health" in d
    assert "lesson_patterns" in d
    return True


def _test_median_aggregation() -> bool:
    taus = [0.80, 0.82, 0.84, 0.86, 0.88]
    refs = [_make_mock_reflection(tau=t, chi=0.10, confidence=0.85)
            for t in taus]
    tally = tally_reflections(refs, "median-test")
    assert tally.median_tau == 0.84
    return True


def _test_tau_declining_trend() -> bool:
    # First half high tau, second half low tau
    refs = (
        [_make_mock_reflection(tau=0.90) for _ in range(3)] +
        [_make_mock_reflection(tau=0.76) for _ in range(3)]
    )
    tally = tally_reflections(refs, "trend-test")
    assert tally.tau_trend == "DECLINING"
    return True


def run_tests():
    tests = [
        (_test_empty_session,             "empty_session"),
        (_test_healthy_session,           "healthy_session"),
        (_test_lesson_pattern_detection,  "lesson_patterns"),
        (_test_dominant_lesson,           "dominant_lesson"),
        (_test_degraded_health_low_pass_rate, "degraded_health"),
        (_test_cost_honesty,              "cost_honesty"),
        (_test_betti_placeholder_flagged, "betti_placeholder"),
        (_test_to_dict_serializable,      "to_dict_serializable"),
        (_test_median_aggregation,        "median_aggregation"),
        (_test_tau_declining_trend,       "tau_declining_trend"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
