# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          ignition.py — Labyrinth-OS / Runtime
# ----------------------------------------------------------------------------

"""
ignition.py — Labyrinth-OS / Runtime
======================================
Master Unblock — First Live Inference Through the Stack

PROTOTYPE STATUS — READ BEFORE USING
======================================
This module is a SECONDARY ROUTE (Option B), not a bypass.

It exists because during prototype phase, Lane 2 must be validated
independently before Lane 1 is fully wired. This is intentional
and documented in KNOWN_GAPS.md (GAP 1).

What this DOES go through (Lane 2 — full):
  api_adapter → logprob_bridge → signal_algebra → council
  → CGIR → gate → guardian → ledger → replay

What this SKIPS (Lane 1 — temporary):
  LABELING → ARCHIVE → PROMOTION → REALITY_GATE

This skip is:
  - Documented (KNOWN_GAPS.md GAP 1, ARCHITECTURE.md Known Gaps)
  - Temporary (will be wired via pipeline_wire.py post-A010)
  - Not a safety bypass (Lane 2 gates still enforce all invariants)
  - Classified as FAILOVER_ENTRY in PipelineStage enum

Plan B routing: allowed.
Plan B safety bypass: NOT allowed.
This is Plan B routing only.

ACP-1 A010 closes when this script produces a Chronicle entry
containing a LIVE_INFERENCE event with a real API response.

Usage:
  python ignition.py --backend anthropic --model claude-sonnet-4-20250514 --trials 5
  python ignition.py --backend openai    --model gpt-4o                   --trials 5
  python ignition.py --backend grok      --model grok-3                   --trials 5
  python ignition.py --backend ollama    --model qwen3:4b                 --trials 5

  API key via env var (recommended):
    ANTHROPIC_API_KEY=sk-ant-...
    OPENAI_API_KEY=sk-...
    GROK_API_KEY=xai-...

What this does:
  1. Validates backend + model
  2. Sends N trial prompts through the API adapter
  3. Extracts logprob metrics (or records MISSING_LOGPROB)
  4. Passes metrics through signal algebra -> council -> CGIR gate
  5. Records every decision in a WORM HashChain
  6. Prints a receipt at the end

A010 closes when:
  - At least one LIVE_INFERENCE event in the Chronicle

A011 advances when:
  - D_KL and delta_H are non-zero (logprobs available)
  - Provider is OpenAI, Grok, or Ollama (Anthropic: metrics_incomplete)
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Bootstrap all Sentinel module paths so ignition runs correctly as a subprocess
_SENTINEL_ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
for _d in [
    'epistemic/labeling', 'epistemic/archive', 'epistemic/classification',
    'epistemic/council', 'epistemic/logprob-bridge', 'epistemic/signal-aggregation',
    'epistemic/vector', 'epistemic/watcher-a', 'epistemic/watcher-b',
    'execution/aegis', 'execution/cgir', 'execution/cgir/schema',
    'execution/gate', 'execution/ledger', 'execution/observability',
    'execution/pre_cgir_gate', 'execution/reality_gate', 'execution/replay',
    'promotion', 'steward', 'tests', 'tests/adversarial', 'tests/integration',
]:
    _p = os.path.join(_SENTINEL_ROOT, _d)
    if os.path.isdir(_p) and _p not in sys.path:
        sys.path.insert(0, _p)

from api_adapter import APIAdapter, APIConfig, Provider, make_adapter
from api_logprob_extractor import LogprobExtractor
from logprob_bridge_adapter import LogprobBridgeAdapter
from api_logprob_extractor import MISSING_LOGPROB_CONFIDENCE_CAP
from cgir_guardian_bridge import evaluate as bridge_eval
from cgir_signal_algebra import SensorReadings, evaluate as sig_eval
from cgir_types import Severity
from hashchain import HashChain
from receipt import Receipt

# Predicate extraction layer — second verification axis (zero-day response, May 2026)
_PREDICATE_AVAILABLE = False
try:
    from predicate_extractor import LogicalSentinel, PredicateVerdictValue
    _logical_sentinel = LogicalSentinel()
    _PREDICATE_AVAILABLE = True
except ImportError:
    _logical_sentinel = None

# Constitutional deadlock resolution — circuit breaker wired into session
_BREAKER_AVAILABLE = False
try:
    from circuit_breaker import (
        CircuitBreaker, DegradationDetector,
        CircuitState, DegradeState,
    )
    _BREAKER_AVAILABLE = True
except ImportError:
    pass

TRIAL_PROMPTS = [
    "What is 2 + 2? Explain your reasoning in one sentence.",
    "Name the capital of France and describe it in one sentence.",
    "Is the sky blue during daytime? Answer yes or no and explain why in one sentence.",
    "What comes after the number 9? Explain the pattern in one sentence.",
    "Complete this: The sun rises in the east. Explain why in one sentence.",
]


@dataclass
class IgnitionEntry:
    trial_index:       int
    prompt:            str
    response_text:     str
    provider:          str
    model:             str
    decision:          str
    metrics_complete:  bool
    kl_divergence:     float
    entropy_delta:     float
    confidence:        float
    severity:          str
    latency_ms:        float
    missing_logprob:   Optional[str]
    error:             Optional[str]
    # GAP 1 partial closure: real epistemic label from EpistemicLabeler
    epistemic_label:   str = "UNKNOWN"
    epistemic_conf:    float = 0.0
    # IC-1 partial: model fingerprint for identity tracking (closes at A014 with hardware attestation)
    model_fingerprint:  str = ""
    # IC-2 partial: declared provenance chain for this proposal
    # Format: JSON-serialized ProvenanceChain from epistemic/provenance/input_provenance.py
    # Auto-populated at A010; manually declared in prototype phase
    provenance_chain:   str = "unverified"  # JSON string or "unverified"
    # IC-3 reserved: model lineage hash — empty until providers publish lineage records
    # Will hold SHA-256 of training lineage record when ecosystem supports it
    # See docs/INPUT_CONSTITUTION_IC3.md
    model_lineage_hash: str = ""  # IC-3 reserved field

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event":            "LIVE_INFERENCE",
            "trial_index":      self.trial_index,
            "provider":         self.provider,
            "model":            self.model,
            "decision":         self.decision,
            "metrics_complete": self.metrics_complete,
            "kl_divergence":    round(self.kl_divergence, 6) if self.metrics_complete else None,
            "entropy_delta":    round(self.entropy_delta, 6) if self.metrics_complete else None,
            "confidence":       round(self.confidence, 4),
            "severity":         self.severity,
            "latency_ms":       round(self.latency_ms, 2),
            "missing_logprob":  self.missing_logprob,
            "error":            self.error,
            "prompt_hash":      hashlib.sha256(self.prompt.encode()).hexdigest()[:16],
            "response_length":  len(self.response_text),
            # GAP 1 partial closure: real epistemic label now in every entry
            "epistemic_label":  self.epistemic_label,
            "epistemic_conf":   round(self.epistemic_conf, 4),
            # IC-1/IC-2 partial: model identity and provenance chain
            "model_fingerprint":  self.model_fingerprint,
            "provenance_chain":   self.provenance_chain,
            # IC-3 reserved: model lineage hash (empty until ecosystem supports it)
            "model_lineage_hash": self.model_lineage_hash,
        }


# MetricsCollector exists but is not yet wired (see KNOWN_GAPS.md).
# Post-A010: instantiate MetricsCollector and record per-proposal snapshots.
# from execution/observability/metrics.py import MetricsCollector

# ── Boot preflight (prototype — fail-open for mock runs) ──────────────────────
try:
    from boot_preflight import require_clean_boot_or_warn as _boot_preflight
    _PREFLIGHT_AVAILABLE = True
except ImportError:
    _PREFLIGHT_AVAILABLE = False

# ── Continuous learning loop (wired — compounds session knowledge) ─────────────
try:
    from continuous_learning_loop import LearningLoop
    _LEARNING_AVAILABLE = True
except ImportError:
    _LEARNING_AVAILABLE = False

# ── Healing loop + epistemic memory (prototype hooks — wired, not yet live) ──
# These connect the deferred node and persistent memory to the live path.
# Both are stub-called until A010 closes and real modules are active.
# DeferredExplorationNode: receives gate blocks, mutates toward new candidates
# PersistentMemoryStore: indexes session history for risk estimation
try:
    import sys as _sys, os as _os
    _sys.path.insert(0, _os.path.join(_os.path.dirname(__file__), '..', 'lane1',
                                       '07_deferred_exploration'))
    _sys.path.insert(0, _os.path.join(_os.path.dirname(__file__), '..', 'epistemic',
                                       'archive'))
    from deferred_node import DeferredExplorationNode, FailureRecord
    from memory_store import PersistentMemoryStore, EntryType
    _DEFERRED_AVAILABLE = True
    _MEMORY_AVAILABLE = True
except ImportError:
    _DEFERRED_AVAILABLE = False
    _MEMORY_AVAILABLE = False


class IgnitionSession:
    def __init__(self, adapter: APIAdapter, n_trials: int,
                 cbf_margin: float = 0.6, verbose: bool = True) -> None:
        self._adapter    = adapter
        self._n_trials   = n_trials
        self._cbf_margin = cbf_margin
        self._verbose    = verbose
        self._session_id = (
            f"ignition_{adapter.provider.value}_{adapter.model}_{int(time.time())}"
        ).replace(":", "-").replace("/", "-")
        self._chain      = HashChain()
        self._extractor  = LogprobExtractor(self._session_id)
        self._entries: List[IgnitionEntry] = []

        # Healing loop + memory hooks (GAP 4 / GAP 5 — wired, not yet live)
        self._deferred_node = (
            DeferredExplorationNode() if _DEFERRED_AVAILABLE else None
        )
        self._memory_store = (
            PersistentMemoryStore() if _MEMORY_AVAILABLE else None
        )
        self._current_trace = None  # set per-trial in run()

        # G7: Wire memory_store to promotion_rules so risk_estimate() is called
        # The amplifier mask (Poole P10.5-B): ±0.05 confidence adjustment from history.
        # promotion_rules.py checks getattr(self, '_memory_store', None) — set it here.
        if _MEMORY_AVAILABLE and self._memory_store is not None:
            try:
                from promotion_rules import PromotionRules as _PR
                # PromotionRules is used inside _promote_ignition — wire via module attribute
                # so the singleton instance picks it up. Safe: fail-closed on exception.
                import promotion_rules as _pm
                _pm._IGNITION_MEMORY_STORE = self._memory_store
            except Exception:
                pass  # fail-safe: memory wiring failure never crashes session

        # G6: Session-level mutation queue — process deferred candidates at session end
        self._mutation_candidates: List[Any] = []

        # Learning loop — compounds session knowledge across trials
        if _LEARNING_AVAILABLE:
            self._learning_loop = LearningLoop(verbose=False)
            self._learning_loop.begin_session(self._session_id)
        else:
            self._learning_loop = None

        # Constitutional deadlock resolution — circuit breaker per session
        if _BREAKER_AVAILABLE:
            self._breaker   = CircuitBreaker()
            self._degrader  = DegradationDetector()
        else:
            self._breaker   = None
            self._degrader  = None

        # Approval flux monitor — tracks gate approval rate this session
        try:
            from chronicle_query import ApprovalFluxMonitor
            self._flux_monitor = ApprovalFluxMonitor(window_size=100)
        except ImportError:
            self._flux_monitor = None

    def run(self) -> Dict[str, Any]:
        if self._verbose:
            print(f"\n  Session: {self._session_id}")
            print(f"  Backend: {self._adapter.provider.value}")
            print(f"  Model:   {self._adapter.model}")
            print(f"  Trials:  {self._n_trials}\n")

        # ── BOOT PREFLIGHT ─────────────────────────────────────────────────────
        # Runs before any pipeline stages. Fail-open in prototype phase:
        # WARN results are logged but do not halt the session.
        # FAIL results are logged. Post-A010: convert to hard stop.
        if _PREFLIGHT_AVAILABLE:
            try:
                _pf = _boot_preflight(verbose=self._verbose)
                if self._verbose and _pf.status != "PASS":
                    print(f"  [PREFLIGHT] {_pf.status}: {_pf.message}")
            except Exception:
                pass  # fail-open — preflight failure never blocks trials
        # ──────────────────────────────────────────────────────────────────────

        # ── OPTION B PIPELINE ENFORCEMENT ─────────────────────────────────
        # ignition is a controlled exception (labeling_required=False).
        # labeling is explicitly skipped. All other stages are MANDATORY.
        #
        # WIRED: ARCHIVE → PROMOTION → REALITY_GATE → assert_can_enter_cgir()
        # If any stage fails: SystemError raised, trials DO NOT START.
        # Visibility without control is not enforcement.
        import sys as _sys, os as _os
        _sys.path.insert(0, _os.path.join(_os.path.dirname(__file__), '..', 'lane1'))
        from pipeline_wire import PipelineTrace as _PT, PipelineStage as _PS
        _ts = time.time

        self._run_trace = _PT(input_id=self._session_id, labeling_required=False)
        self._run_trace.record(_PS.FAILOVER_ENTRY, "PASS",
                               "ignition Option B — labeling_required=False",
                               timestamp=_ts())
        self._run_trace.record(_PS.INPUT, "PASS", timestamp=_ts())

        # Step 1: ARCHIVE — record that this session's intent is archived
        _archive_result = self._archive_ignition()
        if _archive_result["ok"]:
            self._run_trace.record(_PS.ARCHIVE, "PASS",
                                   _archive_result["detail"], timestamp=_ts())
        else:
            self._run_trace.record(_PS.ARCHIVE, "FAIL", _archive_result["detail"])
            raise SystemError(
                f"IGNITION HALTED: archive_ignition() failed — "
                f"{_archive_result['detail']}. Trials cannot start."
            )

        # Step 2: PROMOTION — check session meets promotion criteria
        _promote_result = self._promote_ignition()
        if _promote_result["ok"]:
            self._run_trace.record(_PS.PROMOTION, "PASS",
                                   _promote_result["detail"], timestamp=_ts())
        else:
            self._run_trace.record(_PS.PROMOTION, "FAIL", _promote_result["detail"])
            raise SystemError(
                f"IGNITION HALTED: promote_ignition() failed — "
                f"{_promote_result['detail']}. Trials cannot start."
            )

        # Step 3: REALITY_GATE — final admission check before CGIR
        _gate_result = self._reality_gate_admission()
        if _gate_result["ok"]:
            self._run_trace.record(_PS.REALITY_GATE, "PASS",
                                   _gate_result["detail"], timestamp=_ts())
        else:
            self._run_trace.record(_PS.REALITY_GATE, "FAIL", _gate_result["detail"])
            raise SystemError(
                f"IGNITION HALTED: reality_gate_admission() failed — "
                f"{_gate_result['detail']}. Trials cannot start."
            )

        # Step 4: HARD ASSERT — all mandatory stages must be complete
        # This now RAISES SystemError if anything is missing.
        # No violations allowed past this point.
        self._run_trace.assert_can_enter_cgir()

        self._option_b_violations = []  # empty = enforcement passed
        if self._verbose:
            print(f"  [PIPELINE] ARCHIVE ✓  PROMOTION ✓  REALITY_GATE ✓")
            print(f"  [PIPELINE] assert_can_enter_cgir() PASSED — trials may start")
        # ─────────────────────────────────────────────────────────────────

        prompts = (TRIAL_PROMPTS * (self._n_trials // len(TRIAL_PROMPTS) + 1))[:self._n_trials]
        for i, prompt in enumerate(prompts):
            # Constitutional deadlock check — circuit breaker before each trial
            if self._breaker is not None:
                breaker_decision = self._breaker.check()
                if not breaker_decision.allow:
                    if self._verbose:
                        print(f"  [CIRCUIT BREAKER] {breaker_decision.circuit_state.value}: "
                              f"{breaker_decision.reason}")
                    # Circuit is OPEN — skip remaining trials, seal session
                    break

            entry = self._run_trial(i, prompt)
            self._entries.append(entry)
            self._record(entry)

            # Record outcome in circuit breaker and degradation detector
            if self._breaker is not None:
                new_state = self._breaker.record_outcome(entry.decision)
                if new_state is not None and self._verbose:
                    print(f"  [CIRCUIT BREAKER] State changed → {new_state.value}")
            if self._degrader is not None:
                watcher_agree = min(entry.confidence, 1.0)
                report = self._degrader.record(entry.confidence, watcher_agree)
                if report.state.value in ("WARNING", "ANOMALY") and self._verbose:
                    print(f"  [DEGRADATION] {report.state.value}: {report.reason}")
            if self._flux_monitor is not None:
                self._flux_monitor.record(entry.decision)
                flux = self._flux_monitor.report()
                if flux["state"] in ("WARNING", "ANOMALY") and self._verbose:
                    print(f"  [FLUX] {flux['state']}: {flux['interpretation']}")

            # Record trial feedback in learning loop — compounds session knowledge
            if self._learning_loop is not None:
                try:
                    self._learning_loop.record_trial_feedback(
                        trial_id   = f"{self._session_id}_trial_{i}",
                        outcome    = entry.decision,
                        confidence = entry.confidence,
                        kl_div     = entry.kl_divergence,
                        entropy_delta = entry.entropy_delta,
                    )
                except Exception:
                    pass  # fail-safe

            if self._verbose:
                self._print_trial(entry)
        return self._seal()

    # ── PIPELINE WIRING METHODS ─────────────────────────────────────────────


    def _feedback_to_archive(self, entry: "IgnitionEntry") -> None:
        """
        GAP 4 FIX: Wire FEEDBACK → ARCHIVE (L20 → L06).
        The governance feedback loop (L20) closes back to archive (L06),
        completing the constitutional circuit. Every trial outcome is
        fed back so future proposals can learn from this session's history.
        
        This is the hook — full implementation requires A010 live inference.
        The PersistentMemoryStore handles the actual indexing.
        """
        if self._memory_store is None:
            return  # no memory — feedback has nowhere to go
        try:
            outcome = "EXECUTED" if entry.decision == "EXECUTE" else "BLOCKED"
            from memory_store import EntryType
            self._memory_store.append(
                entry_type=EntryType.OUTCOME,
                label_id=f"{self._session_id}_feedback_{entry.trial_index}",
                payload={
                    "confidence": entry.confidence,
                    "decision":   entry.decision,
                    "severity":   entry.severity,
                    "outcome":    outcome,
                    "provider":   entry.provider,
                    "model":      entry.model,
                    "feedback_loop": "L20_to_L06",  # constitutional circuit closed
                }
            )
        except Exception:
            pass  # fail-safe: feedback failure never crashes the session

    def _archive_ignition(self) -> dict:
        """
        ARCHIVE stage for Option B (ignition).

        Archives the session intent before any trials run.
        Records: session_id, provider, model, n_trials, timestamp.
        This is not Lane 1 epistemic archive — it is a lightweight
        execution-lane record that ARCHIVE was completed.

        Returns: {"ok": bool, "detail": str}
        """
        try:
            record = {
                "session_id":  self._session_id,
                "provider":    self._adapter.provider.value,
                "model":       self._adapter.model,
                "n_trials":    self._n_trials,
                "origin_type": "Ignition",
                "archived_at": time.time(),
            }
            # Write to local archive file (immutable record)
            archive_path = os.path.join(
                os.path.dirname(__file__),
                f"archive_ignition_{self._session_id}.json"
            )
            with open(archive_path, 'w') as f:
                import json as _json
                _json.dump(record, f, indent=2)
            return {
                "ok":     True,
                "detail": f"Session archived → {os.path.basename(archive_path)}",
                "path":   archive_path,
            }
        except Exception as e:
            return {"ok": False, "detail": f"Archive failed: {e}"}

    def _promote_ignition(self) -> dict:
        """
        PROMOTION stage for Option B (ignition).

        Checks that the session meets minimum promotion criteria before trials.
        Criteria:
          - Provider must be valid (not unknown)
          - Model must be non-empty
          - n_trials must be >= 1
          - Archive must have completed (archive_complete on trace)
          - Historical failure rate from archive must be below threshold

        Now archive-aware: checks past session archive files to compute
        historical failure rate. High failure rate → deferred, not blocked.

        Returns: {"ok": bool, "detail": str}
        """
        try:
            trace = getattr(self, '_run_trace', None)
            if trace is None:
                return {"ok": False, "detail": "No trace — archive must precede promotion"}
            if trace.archive_complete is None:
                return {"ok": False, "detail": "archive_complete not set — archive must precede promotion"}
            if not self._adapter.model or not self._adapter.model.strip():
                return {"ok": False, "detail": "Model is empty — cannot promote"}
            if self._n_trials < 1:
                return {"ok": False, "detail": f"n_trials={self._n_trials} < 1 — cannot promote"}

            # Archive-aware: check historical failure rate
            _hist = self._check_historical_failure_rate()
            if _hist["failure_rate"] > 0.8:
                # High historical failure rate — defer but do not hard-block
                # This is advisory: promotion proceeds with warning
                detail = (
                    f"Promotion criteria met (with advisory): "
                    f"historical_failure_rate={_hist['failure_rate']:.2f} "
                    f"from {_hist['sessions_checked']} past sessions. "
                    f"Consider reviewing past failures before A010. "
                    f"provider={self._adapter.provider.value} model={self._adapter.model}"
                )
            else:
                detail = (
                    f"Promotion criteria met: provider={self._adapter.provider.value} "
                    f"model={self._adapter.model} trials={self._n_trials} "
                    f"historical_failure_rate={_hist['failure_rate']:.2f}"
                )
            return {"ok": True, "detail": detail, "historical": _hist}
        except Exception as e:
            return {"ok": False, "detail": f"Promotion check failed: {e}"}

    def _check_historical_failure_rate(self) -> dict:
        """
        Read past archive files to compute historical failure rate.
        This is the archive→decisions feedback loop.

        Reads feedback_*.json files written by _seal() after each session.
        Returns: {"failure_rate": float, "sessions_checked": int}
        """
        try:
            run_dir = os.path.dirname(os.path.abspath(__file__))
            feedback_files = [
                f for f in os.listdir(run_dir)
                if f.startswith("feedback_") and f.endswith(".json")
            ]
            if not feedback_files:
                return {"failure_rate": 0.0, "sessions_checked": 0}

            total = len(feedback_files)
            failures = 0
            for fname in feedback_files[-20:]:  # last 20 sessions max
                try:
                    with open(os.path.join(run_dir, fname)) as f:
                        fb = json.load(f)
                    if fb.get("outcome") in ("BLOCKED", "FAILED", "ERROR"):
                        failures += 1
                except Exception:
                    pass

            checked = min(total, 20)
            rate = failures / checked if checked > 0 else 0.0
            return {"failure_rate": rate, "sessions_checked": checked, "total_on_disk": total}
        except Exception:
            return {"failure_rate": 0.0, "sessions_checked": 0}

    def _reality_gate_admission(self) -> dict:
        """
        REALITY_GATE stage for Option B (ignition).

        Final admission check before CGIR. Verifies:
          - Archive and promotion timestamps are present and ordered
          - Session is not in a failed/blocked state
          - Provider backend is reachable (adapter is initialized)

        This is the pre-CGIR gate. It does not run CGIR.
        assert_can_enter_cgir() follows immediately after this.

        Returns: {"ok": bool, "detail": str}
        """
        try:
            trace = getattr(self, '_run_trace', None)
            if trace is None:
                return {"ok": False, "detail": "No trace — cannot admit to Reality Gate"}
            if trace.archive_complete is None:
                return {"ok": False, "detail": "archive_complete not set — gate requires archive"}
            if trace.promotion_complete is None:
                return {"ok": False, "detail": "promotion_complete not set — gate requires promotion"}
            # Ordering check: archive must precede promotion
            if trace.archive_complete >= trace.promotion_complete:
                return {
                    "ok":    False,
                    "detail": (
                        f"Timestamp ordering violation: archive({trace.archive_complete:.3f}) "
                        f">= promotion({trace.promotion_complete:.3f})"
                    ),
                }
            # Adapter must be initialized
            if self._adapter is None:
                return {"ok": False, "detail": "Adapter not initialized"}
            return {
                "ok":    True,
                "detail": (
                    f"Reality Gate: ADMIT. archive→promotion ordering valid. "
                    f"Provider={self._adapter.provider.value}"
                ),
            }
        except Exception as e:
            return {"ok": False, "detail": f"Reality Gate check failed: {e}"}

    def _run_trial(self, i: int, prompt: str) -> IgnitionEntry:
        response   = self._adapter.call(prompt)
        extraction = self._extractor.extract(response)
        metrics    = extraction.metrics
        missing    = extraction.missing_event
        readings   = LogprobBridgeAdapter.to_sensor_readings(metrics)

        if missing is not None:
            readings = SensorReadings(
                tau_escape   = readings.tau_escape,
                drift_score  = readings.drift_score,
                chi_vector   = readings.chi_vector,
                betti_1      = readings.betti_1,
                confidence   = min(readings.confidence, MISSING_LOGPROB_CONFIDENCE_CAP),
                source       = readings.source,
                logical_time = readings.logical_time,
            )

        # ── GAP 1 PARTIAL CLOSURE: Real epistemic labeling ────────────────────
        # Previously: ignition used Option B (labeling_required=False) for all
        # trials — a controlled bypass logged as FAILOVER_ENTRY.
        # Now: EpistemicLabeler runs on the response text and produces a real
        # label (SPECULATIVE, DEFERRED, or TRUTH) before the gate evaluates.
        # LABELING stage is recorded in the per-trial trace.
        # This partially closes GAP 1. Full closure requires real Lane 1
        # integration (PromotionProtocol, RealityGate calling real modules)
        # and a live API response stream. Architecture is now Option A capable.
        _epistemic_label = "UNKNOWN"
        _epistemic_conf  = 0.0
        try:
            from epistemic_types import IdeaNode, EpistemicLabel, InputMode
            from epistemic_labeler import EpistemicLabeler
            _labeler = EpistemicLabeler()
            _node = IdeaNode(
                idea_id  = f"trial_{self._session_id}_{i}",
                content  = response.text or prompt,
                label    = EpistemicLabel.UNKNOWN,
                mode     = InputMode.INFERENCE,
            )
            # Use response confidence as evidence signal
            _has_evidence = bool(response.text and len(response.text) > 20)
            _assignment, _labeled_node = _labeler.classify_from_content(
                _node,
                has_test=False,
                has_contradiction=False,
                evidence=[f"confidence={readings.confidence:.3f}"] if _has_evidence else [],
            )
            _epistemic_label = _labeled_node.label.value
            _epistemic_conf  = _assignment.confidence
        except Exception:
            pass  # fail-safe: labeling failure never blocks trial

        # _current_reasoning removed: EBF in promotion_rules now takes reasoning_text
        # as an explicit kwarg. Callers pass it directly — no session attribute needed.

        decision = "BLOCK"
        severity = "UNKNOWN"
        try:
            bridge   = bridge_eval(readings, cbf_margin=self._cbf_margin,
                                   action_id=f"trial_{i}",
                                   session_id=f"{self._session_id}_t{i}")
            decision = bridge.slot_result.decision.value
            sig      = sig_eval(readings, f"ign_sig_{i}")
            severity = sig.severity.value
        except Exception:
            pass

        # ── Predicate verification layer — second axis (zero-day response) ───
        # The five sigma anchor channels are the first axis (geometric/sensor).
        # The LogicalSentinel is the second axis (formal predicate verification).
        # Both must pass. A SAT decision with UNSAT predicates → override to BLOCK.
        predicate_verdict = None
        if _PREDICATE_AVAILABLE and _logical_sentinel is not None and decision != "KILL":
            try:
                # Use response text as chain-of-thought proxy when no explicit CoT
                predicate_verdict = _logical_sentinel.evaluate(response.text)
                if predicate_verdict.verdict == PredicateVerdictValue.UNSAT:
                    violations = predicate_verdict.violations
                    violations_str = "; ".join(violations)
                    decision = "BLOCK"
                    severity = "CRITICAL"  # predicate violation is always critical

                    # G12: Log typed PREDICATE_BLOCK entry to the session chain.
                    # Uses the same HashChain as all other session entries so the
                    # block is replayable and distinguishable from Sigma blocks.
                    # verdict="PREDICATE_BLOCK" is the typed discriminator.
                    try:
                        _vhash = (predicate_verdict.verdict_hash
                                  if hasattr(predicate_verdict, 'verdict_hash')
                                  else "")
                        _predicate_receipt = Receipt(
                            receipt_id=(
                                f"predicate_block_{self._session_id}_trial_{i}"),
                            module="LOGICAL_SENTINEL",
                            action="PREDICATE_VERIFICATION",
                            verdict="PREDICATE_BLOCK",
                            payload={
                                "proposal_id": f"{self._session_id}_trial_{i}",
                                "violations": violations,
                                "verdict_hash": _vhash,
                                "phi1_unsat": any(
                                    "Phi1" in v or "SOURCE" in v
                                    for v in violations),
                                "phi2_unsat": any(
                                    "Phi2" in v or "VERIFICATION" in v
                                    for v in violations),
                                "phi3_unsat": any(
                                    "Phi3" in v or "LOOP" in v
                                    for v in violations),
                            },
                            prev_hash=self._chain.head_hash,
                        )
                        self._chain.append(_predicate_receipt)
                    except Exception:
                        pass  # fail-safe: ledger write failure never crashes
            except Exception:
                pass  # fail-safe: predicate failure never crashes ignition

        # ── Healing loop trigger (prototype hook) ─────────────────────────
        # After each BLOCK, offer the FailedProposal to the deferred node AND
        # accumulate in _trial_failures for batch mutation processing at session end.
        # G6: _trial_failures is processed in _seal() → candidates exported to summary
        # → next session loads candidates and re-injects at LABELING.
        if decision == "BLOCK" and self._deferred_node is not None and _DEFERRED_AVAILABLE:
            try:
                class _MockFailedProposal:
                    passage_id = f"{self._session_id}_trial_{i}"
                    blocked_at = __import__('time').time()
                    reason = f"GATE_BLOCKED: conf={readings.confidence:.3f} sev={severity}"
                fr = FailureRecord.from_failed_proposal(_MockFailedProposal())
                self._deferred_node.add_failure(fr)
                # Accumulate for batch mutation at session seal
                if not hasattr(self, '_trial_failures'):
                    self._trial_failures = []
                self._trial_failures.append(fr)
            except Exception:
                pass  # fail-safe: healing hook failure never crashes ignition

        # ── Epistemic memory indexing ───────────────────────────────────────
        # Every trial outcome is indexed for future risk estimation.
        if self._memory_store is not None and _MEMORY_AVAILABLE:
            try:
                _outcome = "EXECUTED" if decision == "EXECUTE" else "BLOCKED"
                self._memory_store.append(
                    entry_type=EntryType.OUTCOME,
                    label_id=f"{self._session_id}_trial_{i}",
                    payload={
                        "confidence": readings.confidence,
                        "tau_escape": readings.tau_escape,
                        "chi": float(readings.chi_vector) if hasattr(readings.chi_vector, '__float__') else 0.0,
                        "drift": readings.drift_score,
                        "outcome": _outcome,
                        "severity": severity,
                    }
                )
            except Exception:
                pass  # fail-safe: memory indexing never crashes ignition

        # ── IC-1: Model fingerprint — partial closure, full at A014 hardware ────
        # Records API-reported model identity. Not cryptographic until A014.
        _model_fingerprint = ""
        try:
            import hashlib as _hl
            _fp_input = f"{response.provider.value}:{response.model}:{self._session_id}"
            _model_fingerprint = _hl.sha256(_fp_input.encode()).hexdigest()[:16]
        except Exception:
            pass

        # ── IC-2: Provenance chain — declared source lineage ──────────────────
        # Records where this proposal came from. "unverified" is honest default.
        # Populated from adapter metadata when available. Full verification at A014.
        _provenance_chain = "unverified"
        try:
            _prov_parts = [
                f"provider:{response.provider.value}",
                f"model:{response.model}",
                f"session:{self._session_id}",
                f"trial:{i}",
            ]
            if response.success and response.text:
                _prov_parts.append("response:ok")
            else:
                _prov_parts.append("response:failed")
            import json as _json
            _provenance_chain = _json.dumps(_prov_parts)
        except Exception:
            pass

        return IgnitionEntry(
            trial_index=i, prompt=prompt, response_text=response.text,
            provider=response.provider.value, model=response.model,
            decision=decision, metrics_complete=(missing is None),
            kl_divergence=metrics.kl_divergence,
            entropy_delta=metrics.entropy_delta,
            confidence=readings.confidence, severity=severity,
            latency_ms=response.latency_ms,
            missing_logprob=missing.reason if missing else None,
            error=response.error if not response.success else None,
            epistemic_label=_epistemic_label,
            epistemic_conf=_epistemic_conf,
            model_fingerprint=_model_fingerprint,
            provenance_chain=_provenance_chain,
        )

    def _record(self, entry: IgnitionEntry) -> None:
        r = Receipt(
            receipt_id=f"{self._session_id}_trial_{entry.trial_index}",
            module="ignition", action="LIVE_INFERENCE",
            verdict=entry.decision, payload=entry.to_dict(),
            prev_hash=self._chain.head_hash,
        )
        self._chain.append(r)

    def _print_trial(self, entry: IgnitionEntry) -> None:
        complete = "✓" if entry.metrics_complete else "✗ no logprobs"
        dry = " [DRY-RUN]" if entry.provider == "mock" else ""
        err_str  = f"  ERR: {entry.error}" if entry.error else ""
        print(f"  Trial {entry.trial_index+1:02d}  "
              f"decision={entry.decision:7}  sev={entry.severity:8}  "
              f"conf={entry.confidence:.3f}  KL={entry.kl_divergence:.3f}  "
              f"logprobs={complete}{dry}{err_str}")

    def _seal(self) -> Dict[str, Any]:
        # Close the learning loop for this session — compound knowledge
        if self._learning_loop is not None:
            try:
                self._learning_loop.end_session(
                    session_id=self._session_id,
                    outcome="COMPLETED",
                )
            except Exception:
                pass  # fail-safe

        valid, _, _ = self._chain.verify()
        successful  = [e for e in self._entries if not e.error]
        complete    = [e for e in self._entries if e.metrics_complete]
        executed    = [e for e in self._entries if e.decision == "EXECUTE"]

        # Export exact WORM chain entries for replay verification.
        # verify_run.py uses these to replay the actual chain, not a reconstruction.
        chain_entries = self._chain.to_list()

        # Option B trace violations — computed in run(), reported here
        option_b_trace_violations = getattr(self, '_option_b_violations', [
            "PipelineTrace not initialized (run() not called)"])

        # GAP 4 CLOSED: Write FeedbackRecord back to archive (I10)
        try:
            import sys as _sys, os as _os
            _lane1 = _os.path.join(_os.path.dirname(__file__), '..', 'lane1')
            if _lane1 not in _sys.path:
                _sys.path.insert(0, _lane1)
            from pipeline_wire import create_feedback as _cfb
            _trace = getattr(self, '_run_trace', None)
            if _trace is not None:
                _outcome = "EXECUTED" if executed else "BLOCKED"
                _fb = _cfb(_trace, _outcome,
                           f"Session {self._session_id}: "
                           f"{len(executed)}/{len(self._entries)} executed")
                _fb_path = _os.path.join(
                    _os.path.dirname(__file__),
                    f"feedback_{self._session_id}.json"
                )
                with open(_fb_path, 'w') as _f:
                    import json as _j
                    _j.dump(_fb.to_dict(), _f, indent=2)
        except Exception:
            pass  # feedback is best-effort — never blocks session

        # G6: Process deferred node failures into mutation candidates.
        # Failures accumulated in _trial_failures during the session are now
        # mutated into candidates. Candidates are exported in session summary
        # so the next session can load them and re-inject at LABELING.
        # This closes the loop: failures → archive → deferred node → candidates → next session.
        _mutation_candidates_exported = []
        if _DEFERRED_AVAILABLE and self._deferred_node is not None:
            try:
                _trial_failures = getattr(self, '_trial_failures', [])
                if _trial_failures:
                    from deferred_node import process_failures as _pf
                    _candidates = _pf(_trial_failures)
                    _mutation_candidates_exported = [c.to_dict() for c in _candidates]
                    self._mutation_candidates = _candidates
            except Exception:
                pass  # fail-safe: mutation never blocks session

        summary = {
            "session_id":       self._session_id,
            "lane1_bypassed":   True,
            "gap1_measurable":  len(option_b_trace_violations) > 0,
            "option_b_violations": option_b_trace_violations,
            "provider":         self._adapter.provider.value,
            "model":            self._adapter.model,
            "trials_total":     len(self._entries),
            "trials_success":   len(successful),
            "trials_executed":  len(executed),
            "metrics_complete": len(complete),
            "chain_length":     self._chain.length,
            "chain_valid":      valid,
            "session_hash":     self._chain.head_hash or "",
            "a010_path_validated": bool(successful),
            "a010_closed":      False,   # never closed by mock — requires real API
            "dry_run":          self._adapter.provider.value == "mock",
            "real_api":         self._adapter.provider.value != "mock",
            "a010_status":      (
                "PATH_VALIDATED_DRY_RUN" if successful and self._adapter.provider.value == "mock"
                else "CLOSED" if successful
                else "FAILED"
            ),
            "a011_status":      (
                "ADVANCING" if complete else
                "BLOCKED (logprobs unavailable for this provider/model)"
            ),
            "chain_entries":    chain_entries,
            # G6: mutation candidates for next session
            "mutation_candidates": _mutation_candidates_exported,
            # Circuit breaker + degradation state at session close
            "circuit_breaker": (
                self._breaker.summary() if self._breaker is not None else None),
            "degradation": (
                self._degrader._evaluate().to_dict()
                if self._degrader is not None else None),
            "approval_flux": (
                self._flux_monitor.report()
                if self._flux_monitor is not None else None),
        }
        return summary


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Labyrinth-OS Ignition — ACP-1 A010",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python ignition.py --backend anthropic --model claude-sonnet-4-20250514 --trials 5
  python ignition.py --backend openai    --model gpt-4o --trials 5
  python ignition.py --backend grok      --model grok-3 --trials 5
  python ignition.py --backend ollama    --model qwen3:4b --trials 5

API keys (env vars recommended):
  ANTHROPIC_API_KEY, OPENAI_API_KEY, GROK_API_KEY
        """,
    )
    p.add_argument("--backend",    required=True,
                   choices=["openai","anthropic","grok","ollama","openai_compat","mock"])
    p.add_argument("--model",      required=True)
    p.add_argument("--trials",     type=int, default=5)
    p.add_argument("--api-key",    default=None)
    p.add_argument("--base-url",   default=None)
    p.add_argument("--cbf-margin", type=float, default=0.6)
    p.add_argument("--temperature",type=float, default=0.7)
    p.add_argument("--max-tokens", type=int, default=64)
    p.add_argument("--quiet",      action="store_true")
    return p


def resolve_api_key(backend: str, explicit: Optional[str]) -> Optional[str]:
    if explicit:
        return explicit
    env_map = {
        "anthropic": "ANTHROPIC_API_KEY", "openai": "OPENAI_API_KEY",
        "grok": "GROK_API_KEY", "openai_compat": "OPENAI_API_KEY",
        "ollama": None,
        "mock": None,   # no key needed — dry-run mode
    }
    env_var = env_map.get(backend)
    return os.environ.get(env_var) if env_var else None


def main(args=None) -> int:
    parser = build_parser()
    opts   = parser.parse_args(args)
    print("=" * 70)
    print("LABYRINTH-OS IGNITION — ACP-1 A010")
    print("=" * 70)

    api_key = resolve_api_key(opts.backend, opts.api_key)
    if opts.backend not in ("ollama", "mock") and not api_key:
        print(f"\n  ERROR: No API key for '{opts.backend}'.")
        print(f"  Set {opts.backend.upper()}_API_KEY env var or use --api-key.")
        return 1

    try:
        adapter = make_adapter(
            backend=opts.backend, model=opts.model, api_key=api_key,
            base_url=opts.base_url, temperature=opts.temperature,
            max_tokens=opts.max_tokens,
        )
    except ValueError as e:
        print(f"\n  ERROR: {e}")
        return 1

    session = IgnitionSession(
        adapter=adapter, n_trials=opts.trials,
        cbf_margin=opts.cbf_margin, verbose=not opts.quiet,
    )
    print(f"\n  Starting {opts.trials} trial(s)...")
    try:
        summary = session.run()
    except SystemError as e:
        # Pipeline enforcement failure — hard stop, nonzero exit.
        # SystemError means a mandatory pipeline stage was missing or failed.
        # This is NOT a retry condition. Do not catch and continue.
        print(f"\n{'='*70}")
        print(f"  PIPELINE VIOLATION — IGNITION HALTED")
        print(f"  {e}")
        print(f"  Trials: 0 run. CGIR not reached.")
        print(f"  Fix the pipeline violation before running again.")
        print(f"{'='*70}")
        return 1

    print(f"\n{'─'*70}")
    print(f"  SESSION SUMMARY")
    print(f"{'─'*70}")
    print(f"  Trials:  {summary['trials_success']}/{summary['trials_total']} successful")
    print(f"  Executed:{summary['trials_executed']}/{summary['trials_total']}")
    print(f"  Logprobs:{summary['metrics_complete']}/{summary['trials_total']} complete")
    print(f"  Chain:   valid={summary['chain_valid']} length={summary['chain_length']}")
    print(f"  Hash:    {summary['session_hash'][:32]}…")
    if summary.get("dry_run"):
        print(f"\n  ACP-1 A010: PATH VALIDATED (mock) — not closed, real API required")
        print(f"  a010_path_validated: {summary.get('a010_path_validated')}")
        print(f"  a010_closed: {summary.get('a010_closed')}")
        print(f"  dry_run: {summary.get('dry_run')}")
        print(f"  real_api: {summary.get('real_api')}")
    else:
        print(f"\n  ACP-1 A010: {summary['a010_status']}")
    print(f"  ACP-1 A011: {summary['a011_status']}")

    out = os.path.abspath(f"ignition_session_{int(time.time())}.json")
    with open(out, "w") as f:
        json.dump(summary, f, indent=2)

    print(f"  Receipt:  {out}")
    print(f"  Replay:   python replay_validator.py (run after to verify chain)")
    print(f"\n{'='*70}")

    acp_path = os.path.abspath(f"acp1_a010_evidence_{int(time.time())}.json")
    with open(acp_path, "w") as f:
        json.dump({
            "assumption": "A010",
            "status": summary["a010_status"],
            "session_hash": summary.get("session_hash","")[:32],
            "trials_success": summary["trials_success"],
            "chain_valid": summary["chain_valid"],
            "receipt_path": out,
        }, f, indent=2)
    print(f"  ACP-1:    {acp_path}")

    return 0 if summary["a010_status"] in ("CLOSED", "PATH_VALIDATED_DRY_RUN") else 1


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_trial_prompts_count() -> bool:
    assert len(TRIAL_PROMPTS) == 5
    return True

def _test_ignition_entry_to_dict() -> bool:
    e = IgnitionEntry(
        trial_index=0, prompt="test", response_text="ok",
        provider="openai", model="gpt-4o",
        decision="EXECUTE", metrics_complete=True,
        kl_divergence=0.05, entropy_delta=0.02,
        confidence=0.88, severity="INFO", latency_ms=234.5,
        missing_logprob=None, error=None,
    )
    d = e.to_dict()
    assert d["event"] == "LIVE_INFERENCE"
    assert d["kl_divergence"] == 0.05
    assert "prompt_hash" in d
    return True

def _test_missing_logprob_kl_is_none() -> bool:
    e = IgnitionEntry(
        trial_index=0, prompt="test", response_text="ok",
        provider="anthropic", model="claude-opus-4-6",
        decision="EXECUTE", metrics_complete=False,
        kl_divergence=0.0, entropy_delta=0.0,
        confidence=0.55, severity="INFO", latency_ms=180.0,
        missing_logprob="Anthropic does not expose logprobs",
        error=None,
    )
    d = e.to_dict()
    assert d["kl_divergence"] is None
    assert d["entropy_delta"] is None
    assert d["missing_logprob"] is not None
    return True

def _test_resolve_api_key_from_env() -> bool:
    os.environ["OPENAI_API_KEY"] = "test-env-key"
    assert resolve_api_key("openai", None) == "test-env-key"
    del os.environ["OPENAI_API_KEY"]
    return True

def _test_resolve_explicit_key_wins() -> bool:
    os.environ["OPENAI_API_KEY"] = "env-key"
    assert resolve_api_key("openai", "explicit") == "explicit"
    del os.environ["OPENAI_API_KEY"]
    return True

def _test_resolve_ollama_key_none() -> bool:
    assert resolve_api_key("ollama", None) is None
    return True

def _test_parser_defaults() -> bool:
    p = build_parser()
    opts = p.parse_args(["--backend","ollama","--model","qwen3:4b"])
    assert opts.trials == 5
    assert opts.cbf_margin == 0.6
    assert opts.temperature == 0.7
    return True

def _test_missing_key_returns_nonzero() -> bool:
    for k in ["OPENAI_API_KEY","ANTHROPIC_API_KEY"]:
        os.environ.pop(k, None)
    result = main(["--backend","openai","--model","gpt-4o","--trials","1"])
    assert result != 0
    return True



def _test_mock_backend_full_dry_run() -> bool:
    """
    Full dry-run: mock backend → ignition session → chain_entries exported.
    This is the exact rehearsal for A010. Swap mock → anthropic when key available.
    """
    import subprocess, json, os, tempfile
    result = subprocess.run(
        [sys.executable, __file__,
         '--backend', 'mock', '--model', 'mock-model-v1', '--trials', '3', '--quiet'],
        capture_output=True, text=True,
        cwd=os.path.dirname(os.path.abspath(__file__)),
    )
    assert result.returncode == 0, f"ignition failed: {result.stdout[-200:]}"

    # Find the receipt written to disk
    import glob
    receipts = sorted(glob.glob(
        os.path.join(os.path.dirname(os.path.abspath(__file__)),
                     'ignition_session_*.json')
    ))
    assert receipts, "No ignition_session_*.json produced"
    with open(receipts[-1]) as f:
        summary = json.load(f)

    assert summary['a010_status'] in ('CLOSED', 'PATH_VALIDATED_DRY_RUN'), \
        f"Expected CLOSED or PATH_VALIDATED_DRY_RUN, got {summary['a010_status']}"
    assert summary['trials_success'] == 3
    assert summary['chain_valid'] is True
    assert 'chain_entries' in summary, "chain_entries missing — exact replay impossible"
    assert len(summary['chain_entries']) == 3
    for entry in summary['chain_entries']:
        for k in ['receipt_id','module','action','verdict','payload','hash','prev_hash']:
            assert k in entry, f"chain entry missing key: {k}"
    return True

def run_tests() -> tuple:
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    if len(sys.argv) == 1 or sys.argv[1] == "--test":
        import hashlib as _hl
        print("=" * 70)
        print("IGNITION — Unit Tests (no live API)")
        print("=" * 70)
        print("\n── TEST SUITE ──\n")
        passed, failed, results = run_tests()
        for name, status, err in results:
            marker = "✓" if status == "PASS" else "✗"
            line = f"  {marker} {name}"
            if err: line += f"  → {err}"
            print(line)
        print(f"\n  Results: {passed} passed, {failed} failed, {passed+failed} total")
        if failed > 0:
            sys.exit(1)
        with open(__file__, "rb") as f:
            fh = _hl.sha256(f.read()).hexdigest()
        print(f"\n── RECEIPT ──\n  SHA-256: {fh}\n  Tests: {passed}/{passed+failed}")
        print(f"\n{'='*70}")
        print(f"  To close A010:")
        print(f"  python ignition.py --backend anthropic --model claude-sonnet-4-20250514 --trials 5")
        print(f"{'='*70}")
    else:
        sys.exit(main())
