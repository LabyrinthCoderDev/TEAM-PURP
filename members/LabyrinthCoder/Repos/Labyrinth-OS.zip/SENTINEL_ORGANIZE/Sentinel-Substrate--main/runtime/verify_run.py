# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          verify_run.py — Labyrinth-OS / Proof Verification
# ----------------------------------------------------------------------------

"""
verify_run.py — Labyrinth-OS / Proof Verification
===================================================
Post-ignition verification harness.

Closes the four-step proof loop:

  Step 1: Load ignition receipt → confirm LIVE_INFERENCE entries exist
  Step 2: Replay the EXACT WORM chain from the receipt → CLEAN
  Step 3: Confirm at least one trial produced EXECUTE
  Step 4: Inject forced bad case → confirm BLOCK

Step 2 uses the actual chain entries exported by ignition.py
(chain_entries field in ignition_session_*.json).
If chain_entries is absent (old receipt format), step 2 falls back
to equivalent reconstruction — marked as WEAKER in the output.

Usage:
  python verify_run.py ignition_session_<timestamp>.json

Exit 0 = all four steps passed.
Exit 1 = any step failed.

References:
  INVARIANTS.md — I6 (Ledger immutability), I9 (Replay), I10 (Fail closed)
  ignition.py   — produces chain_entries in receipt
  replay_validator.py
"""

from __future__ import annotations

import json
import hashlib
import os
import sys
import time
from typing import Any, Dict

_HERE = os.path.dirname(os.path.abspath(__file__))
_SENTINEL = os.path.normpath(os.path.join(_HERE, '..'))
for _d in ['', 'execution/cgir', 'execution/gate', 'execution/ledger',
           'execution/replay', 'execution/aegis', 'epistemic/signal-aggregation',
           'epistemic/watcher-a', 'epistemic/watcher-b', 'epistemic/council']:
    _p = os.path.join(_SENTINEL, _d)
    if os.path.isdir(_p) and _p not in sys.path:
        sys.path.insert(0, _p)
sys.path.insert(0, _SENTINEL)

from cgir_types import Edge, GateDecision, Node, NodeType, Severity, SignalNode
from cgir_core import CGIRGraph
from cgir_validator import validate
from cgir_gate import evaluate as gate_eval
from cgir_ledger import new_session
from cgir_guardian_bridge import evaluate as bridge_eval
from cgir_signal_algebra import SensorReadings
from replay_validator import validate_ledger, ReplayVerdict
from hashchain import HashChain


# ─── STEP 1: Load receipt ─────────────────────────────────────────────────────

def step1_load_receipt(path: str) -> tuple[bool, Dict[str, Any], str]:
    """Load ignition_session_*.json, verify required fields."""
    if not os.path.exists(path):
        return False, {}, f"File not found: {path}"
    try:
        with open(path) as f:
            summary = json.load(f)
    except json.JSONDecodeError as e:
        return False, {}, f"Invalid JSON: {e}"

    for k in ["session_id", "trials_success", "chain_valid", "session_hash"]:
        if k not in summary:
            return False, summary, f"Missing key: '{k}'"

    if summary["trials_success"] == 0:
        return False, summary, "No successful trials — API calls failed"

    chain_valid = summary.get("chain_valid", False)
    if isinstance(chain_valid, (list, tuple)):
        chain_valid = chain_valid[0]
    if not chain_valid:
        return False, summary, "chain_valid=False in receipt"

    has_entries = bool(summary.get("chain_entries"))
    entry_note = f"chain_entries={'PRESENT — structural replay possible' if has_entries else 'ABSENT — equivalent reconstruction only (WEAKER: does not prove original chain integrity)'}"
    msg = (
        f"Session: {summary['session_id'][:40]}  "
        f"Trials: {summary['trials_success']}/{summary['trials_total']}  "
        f"chain_valid=True  {entry_note}"
    )
    return True, summary, msg


# ─── STEP 2: Exact chain replay ───────────────────────────────────────────────

def step2_exact_chain_replay(summary: Dict[str, Any]) -> tuple[bool, str, str]:
    """
    Replay the EXACT WORM chain from chain_entries in the receipt.

    Returns (passed, message, mode) where mode is always 'EXACT'.

    chain_entries is MANDATORY. If absent, this function raises SystemError.
    EQUIVALENT mode has been removed — it returned PASS while being unable to
    detect ledger tampering when chain_entries were deliberately omitted.

    SECURITY: An attacker could tamper with the original ledger AND omit
    chain_entries; equivalent reconstruction would still pass. This was
    identified as a security gap (external audit, May 2026). Fixed: absent
    chain_entries is now a hard SystemError, not a fallback mode.

    See KNOWN_GAPS.md GAP 7 for semantic vs structural replay distinction.
    See I9 (Replay Completeness) in INVARIANTS.md.
    """
    chain_entries = summary.get("chain_entries")

    if not chain_entries:
        raise SystemError(
            "REPLAY INTEGRITY VIOLATION: chain_entries is absent from receipt. "
            "Exact chain replay is mandatory — EQUIVALENT mode removed (security gap). "
            "Re-run ignition.py to produce a receipt with chain_entries. "
            "See KNOWN_GAPS.md GAP 7 and I9."
        )

    # EXACT mode: reconstruct the actual chain
    try:
        chain = HashChain.from_list(chain_entries)
    except ValueError as e:
        return False, f"Chain reconstruction failed — tampered entry: {e}", "EXACT"

    valid, _, _ = chain.verify()
    if not valid:
        return False, "Reconstructed chain does not verify — data corrupted", "EXACT"

    # Confirm head hash matches the exported session_hash
    exported_hash = summary.get("session_hash", "")
    if exported_hash and chain.head_hash != exported_hash:
        return False, (
            f"Head hash mismatch: "
            f"chain={chain.head_hash[:16]}… "
            f"receipt={exported_hash[:16]}…"
        ), "EXACT"

    entry_count = len(chain_entries)
    return True, (
        f"Exact chain replayed. "
        f"Entries: {entry_count}. "
        f"head_hash: {chain.head_hash[:32]}…  "
        f"verify: PASS"
    ), "EXACT"


# ─── STEP 3: Execute rate ─────────────────────────────────────────────────────

def step3_execute_rate(summary: Dict[str, Any]) -> tuple[bool, str]:
    executed = summary.get("trials_executed", 0)
    success  = summary.get("trials_success", 0)
    if success == 0:
        return False, "No successful trials"
    if executed == 0:
        return False, (
            f"All {success} trials BLOCK. "
            f"Check confidence levels — missing logprobs may be too penalized."
        )
    rate = executed / success
    return True, f"Execute rate: {executed}/{success} ({rate:.0%})."


# ─── STEP 4: Forced failure ───────────────────────────────────────────────────

def step4_forced_failure() -> tuple[bool, str]:
    """CRITICAL signal → BLOCK. Replay that block → CLEAN."""
    g = CGIRGraph()
    g.add_node(Node(id="forced_main", node_type=NodeType.STATE, logical_time=0))
    g.add_node(Node(id="forced_next", node_type=NodeType.STATE, logical_time=1))
    g.add_edge(Edge(id="forced_step", from_id="forced_main", to_id="forced_next",
                    event_type="INFERENCE_STEP", invariant_mask=["I1"]))
    g.add_signal(SignalNode(
        id="critical_sig", node_type=NodeType.SIGNAL, logical_time=0,
        severity=Severity.CRITICAL, confidence=0.95,
        category="TAU_ESCAPE_LOW", source="VECTOR", emitted_by="COUNCIL",
    ))
    g.set_root("forced_main"); g.set_tip("forced_next")

    gate = gate_eval(g)
    if gate.decision != GateDecision.BLOCK:
        return False, f"Gate did not block CRITICAL signal: {gate.decision}"

    ledger = new_session("forced_failure_verify")
    ledger.record_load(g)
    ledger.record_propose(g)
    ledger.record_check(g, validate(g))
    ledger.record_commit(g, gate)
    ledger.record_prove(g)
    ledger.seal()

    result = validate_ledger(ledger)
    if result.verdict != ReplayVerdict.CLEAN:
        return False, f"Replay of BLOCK returned {result.verdict.value}"

    # Sensor-level forced failure
    bad = SensorReadings(tau_escape=0.40, drift_score=0.25, chi_vector=[0.50],
                         betti_1=0.06, confidence=0.30, source="VECTOR",
                         logical_time=0)
    bridge = bridge_eval(bad, cbf_margin=0.4, session_id="forced_sensor_verify")
    if bridge.is_safe_to_execute:
        return False, "Critical sensors produced EXECUTE — should BLOCK"

    return True, (
        "CRITICAL → BLOCK. Replay CLEAN. "
        "Sensor forced failure blocks. I10 enforced."
    )


# ─── MAIN ─────────────────────────────────────────────────────────────────────

def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    if not argv:
        print("Usage: python verify_run.py ignition_session_<timestamp>.json")
        return 1

    receipt_path = argv[0]
    print("=" * 70)
    print("VERIFY RUN — Labyrinth-OS")
    print("=" * 70)
    print(f"\n  Receipt: {receipt_path}\n")

    all_passed = True
    summary = {}

    # Step 1
    passed, summary, msg = step1_load_receipt(receipt_path)
    mark = "✓" if passed else "✗"
    print(f"  {mark} Step 1: Load receipt + chain valid")
    print(f"        {msg}")
    if not passed:
        print("\n  Cannot continue — receipt invalid.")
        return 1
    print()

    # Step 2
    passed, msg, mode = step2_exact_chain_replay(summary)
    mark = "✓" if passed else "✗"
    strength = "[EXACT]" if mode == "EXACT" else "[EQUIVALENT — WEAKER]"
    print(f"  {mark} Step 2: Replay chain {strength}")
    print(f"        {msg}")
    if not passed:
        all_passed = False
    print()

    # Step 3
    passed, msg = step3_execute_rate(summary)
    mark = "✓" if passed else "✗"
    print(f"  {mark} Step 3: Execute rate > 0")
    print(f"        {msg}")
    if not passed:
        all_passed = False
    print()

    # Step 4
    passed, msg = step4_forced_failure()
    mark = "✓" if passed else "✗"
    print(f"  {mark} Step 4: Forced failure → BLOCK + replay CLEAN")
    print(f"        {msg}")
    if not passed:
        all_passed = False
    print()

    print("─" * 70)
    if all_passed:
        # Determine proof strength
        mode_used = "EXACT" if summary.get("chain_entries") else "EQUIVALENT"
        strength_note = (
            "Exact chain replay (strongest evidence)"
            if mode_used == "EXACT"
            else "Equivalent replay (weaker — re-run ignition for exact chain)"
        )

        print(f"  ✓ ALL FOUR STEPS PASSED  [{strength_note}]")
        print()

        # Determine whether this was a real API run or a mock/dry-run
        _is_mock   = summary.get("dry_run", False)
        _real_api  = summary.get("real_api", not _is_mock)
        _a010_status = summary.get("a010_status", "UNKNOWN")

        print("  Evidence:")
        if _is_mock or not _real_api:
            print(f"    A010: PATH VALIDATED (mock) — NOT CLOSED. Real API required.")
            print(f"    A022: NOT CLOSED — no real operator run yet")
            print(f"    dry_run:      {_is_mock}")
            print(f"    real_api:     {_real_api}")
            print(f"    a010_status:  {_a010_status}")
        else:
            print(f"    A010: CLOSED — LIVE_INFERENCE in Chronicle, chain valid")
            print(f"    A022: CLOSED — first real operator run")
            print(f"    A011: NOT CLOSED — logprobs unavailable (Anthropic)")
        print(f"    Replay mode: {mode_used}")
        print()

        proof = {
            "proof_timestamp":  int(time.time()),
            "receipt_path":     os.path.abspath(receipt_path),
            "session_id":       summary.get("session_id", ""),
            "session_hash":     summary.get("session_hash", ""),
            "replay_mode":      mode_used,
            "steps_passed":     4,
            "dry_run":          _is_mock,
            "real_api":         _real_api,
            "a010_closed":      not _is_mock and _real_api,
            "a022_closed":      not _is_mock and _real_api,
            "a011_closed":      False,
            "a010_status":      _a010_status,
        }
        proof["proof_hash"] = hashlib.sha256(
            json.dumps(proof, sort_keys=True).encode()
        ).hexdigest()

        proof_path = os.path.abspath(f"proof_artifact_{int(time.time())}.json")
        with open(proof_path, "w") as f:
            json.dump(proof, f, indent=2)
        print(f"  Proof artifact: {proof_path}")
    else:
        print("  ✗ ONE OR MORE STEPS FAILED — see above")

    print("=" * 70)
    return 0 if all_passed else 1


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_exact_replay_stronger_than_equivalent() -> bool:
    """
    Prove that chain_entries absent raises SystemError (EQUIVALENT mode removed).
    Exact-chain replay is the only accepted mode.
    """
    import sys; sys.path.insert(0, os.path.dirname(__file__))
    from hashchain import HashChain
    from receipt import Receipt

    # Build a real chain
    chain = HashChain()
    for i in range(3):
        r = Receipt(receipt_id=f'trial_{i}', module='ignition',
                    action='LIVE_INFERENCE', verdict='EXECUTE',
                    payload={'trial_index': i}, prev_hash=chain.head_hash)
        chain.append(r)

    entries = chain.to_list()
    clean_summary = {
        "session_id": "test_exact_vs_equiv",
        "trials_success": 3, "trials_total": 3, "trials_executed": 3,
        "chain_valid": True, "session_hash": chain.head_hash,
        "chain_entries": entries,
    }

    # EXACT: passes on clean
    passed, msg, mode = step2_exact_chain_replay(clean_summary)
    assert passed and mode == "EXACT", f"Clean exact replay should pass: {msg}"

    # Tamper one entry — exact replay must catch it
    tampered_entries = [dict(e) for e in entries]
    tampered_entries[1] = dict(tampered_entries[1])
    tampered_entries[1]['verdict'] = 'BLOCK'  # corrupt the verdict

    tampered_summary = dict(clean_summary)
    tampered_summary['chain_entries'] = tampered_entries

    passed_t, msg_t, mode_t = step2_exact_chain_replay(tampered_summary)
    assert not passed_t and mode_t == "EXACT", \
        f"Tampered exact replay must fail: passed={passed_t} msg={msg_t}"

    # Absent chain_entries must now raise SystemError — EQUIVALENT mode removed
    absent_summary = dict(clean_summary)
    del absent_summary['chain_entries']
    raised = False
    try:
        step2_exact_chain_replay(absent_summary)
    except SystemError as e:
        raised = True
        assert "chain_entries" in str(e).lower() or "mandatory" in str(e).lower()
    assert raised, "Absent chain_entries must raise SystemError"

    return True


def _test_exact_replay_head_hash_verified() -> bool:
    """Exact replay fails if session_hash in receipt doesn't match chain."""
    from hashchain import HashChain
    from receipt import Receipt

    chain = HashChain()
    r = Receipt(receipt_id='t1', module='ignition', action='LIVE_INFERENCE',
                verdict='EXECUTE', payload={}, prev_hash=chain.head_hash)
    chain.append(r)

    entries = chain.to_list()
    summary_bad_hash = {
        "session_id": "test_hash_check",
        "trials_success": 1, "trials_total": 1, "trials_executed": 1,
        "chain_valid": True,
        "session_hash": "a" * 64,  # wrong hash
        "chain_entries": entries,
    }
    passed, msg, mode = step2_exact_chain_replay(summary_bad_hash)
    assert not passed and mode == "EXACT", \
        f"Head hash mismatch must fail: passed={passed} msg={msg}"
    return True


def _test_step1_rejects_missing_file() -> bool:
    passed, _, msg = step1_load_receipt("/nonexistent/path.json")
    assert not passed and "not found" in msg.lower()
    return True


def _test_step1_rejects_zero_success() -> bool:
    import tempfile
    data = {"session_id": "x", "trials_success": 0, "trials_total": 5,
            "chain_valid": True, "session_hash": "a" * 64}
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(data, f); tmp = f.name
    passed, _, msg = step1_load_receipt(tmp)
    os.unlink(tmp)
    assert not passed and "No successful" in msg
    return True


def _test_step4_forced_failure_passes() -> bool:
    passed, msg = step4_forced_failure()
    assert passed, f"Forced failure should pass: {msg}"
    return True


def _test_chain_entries_exported_by_ignition_format() -> bool:
    """chain_entries must be a list of dicts with required keys."""
    from hashchain import HashChain
    from receipt import Receipt

    chain = HashChain()
    r = Receipt(receipt_id='t1', module='ignition', action='LIVE_INFERENCE',
                verdict='EXECUTE', payload={'trial_index': 0},
                prev_hash=chain.head_hash)
    chain.append(r)

    entries = chain.to_list()
    assert isinstance(entries, list)
    assert len(entries) == 1
    for key in ['receipt_id', 'module', 'action', 'verdict',
                'payload', 'timestamp', 'prev_hash', 'hash']:
        assert key in entries[0], f"Missing key: {key}"
    return True


def run_tests() -> tuple:
    tests = sorted(
        [(name, obj) for name, obj in globals().items()
         if name.startswith("_test_") and callable(obj)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    if "--test" in sys.argv or len(sys.argv) == 1:
        import hashlib as _hl
        print("=" * 70)
        print("VERIFY RUN — Unit Tests")
        print("=" * 70)
        print("\n── TEST SUITE ──\n")
        passed, failed, results = run_tests()
        for name, status, err in results:
            marker = "✓" if status == "PASS" else "✗"
            line = f"  {marker} {name}"
            if err: line += f"  → {err}"
            print(line)
        print(f"\n  Results: {passed} passed, {failed} failed, {passed + failed} total")
        if failed:
            raise SystemExit(1)
        with open(__file__, "rb") as f:
            fh = _hl.sha256(f.read()).hexdigest()
        print(f"\n── RECEIPT ──\n  SHA-256: {fh}\n  Tests: {passed}/{passed+failed}")
        print(f"\n{'='*70}")
    else:
        sys.exit(main())
