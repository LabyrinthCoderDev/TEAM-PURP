# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          joulework.py -- Labyrinth-OS / Runtime
# ----------------------------------------------------------------------------

"""
joulework.py -- Labyrinth-OS / Runtime
========================================
JouleWork: Per-Trial Compute Cost Accounting

Tracks the actual vs estimated compute cost of every trial.
The honesty_ratio in TrialReflection (joule_actual / joule_estimated)
comes from this module.

Why this matters
----------------
A system that consistently underestimates its compute cost is a system
that will eventually be surprised by resource exhaustion. A system that
overestimates will be unnecessarily throttled. JouleWork makes the
estimation error visible so it can be corrected.

Calibration status
------------------
The cost estimation model in this module uses conservative defaults.
Wall-clock milliseconds are the proxy for energy cost (Joules) until
actual power measurement hardware is available. The structure is correct.
The calibration constants will be updated after A010 (first live inference)
provides real timing distributions.

JouleWork per trial covers:
  - Inference latency (API round-trip or local model time)
  - Gate evaluation time (sigma anchor checks)
  - Ledger write time (WORM append)
  - Provenance chain construction
  - Total wall-clock cost for the full trial

References
----------
  ACP-1 A010      -- first live inference (calibration gate)
  ACP-1 A019      -- Landauer thermodynamic budget (VERIFIED)
  trial_reflection.py -- joule_estimated, joule_actual, honesty_ratio
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

try:
    import sys as _sys, os as _os
    _root = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), '..'))
    if _root not in _sys.path:
        _sys.path.insert(0, _root)
    from sigma_anchors import LABYRINTH_CONTRACT_VERSION
    _SIGMA_OK = True
except ImportError:
    LABYRINTH_CONTRACT_VERSION = "1.0.0"
    _SIGMA_OK = False


# ---- COST COMPONENTS --------------------------------------------------------

@dataclass
class CostComponent:
    """A single timed cost component within a trial."""
    name:       str
    estimated:  float   # milliseconds
    actual:     float   # milliseconds
    timestamp:  float   = field(default_factory=time.time)

    @property
    def delta(self) -> float:
        """actual - estimated. Positive = overrun. Negative = underrun."""
        return self.actual - self.estimated

    @property
    def ratio(self) -> float:
        """actual / estimated. 1.0 = perfect. >1.5 = overrun."""
        if self.estimated <= 0:
            return 1.0
        return self.actual / self.estimated


# ---- TRIAL COST RECORD ------------------------------------------------------

@dataclass
class TrialCostRecord:
    """
    Full cost accounting for one trial.

    Built incrementally using the context manager pattern:

        with JouleWorkMeter(trial_id="trial-001") as meter:
            meter.start_component("inference")
            # ... do inference ...
            meter.end_component("inference", estimated_ms=200.0)

        record = meter.finalize()

    Or built directly from known values:

        record = TrialCostRecord.from_totals(
            trial_id="trial-001",
            estimated_ms=350.0,
            actual_ms=412.0,
        )
    """
    trial_id:         str
    components:       List[CostComponent] = field(default_factory=list)
    session_id:       str                 = ""
    contract_version: str                 = LABYRINTH_CONTRACT_VERSION

    @classmethod
    def from_totals(
        cls,
        trial_id: str,
        estimated_ms: float,
        actual_ms: float,
        session_id: str = "",
    ) -> "TrialCostRecord":
        """Build a record from known totals (no component breakdown)."""
        record = cls(trial_id=trial_id, session_id=session_id)
        record.components.append(CostComponent(
            name="total",
            estimated=estimated_ms,
            actual=actual_ms,
        ))
        return record

    @property
    def total_estimated(self) -> float:
        """Sum of all estimated component costs."""
        return sum(c.estimated for c in self.components)

    @property
    def total_actual(self) -> float:
        """Sum of all actual component costs."""
        return sum(c.actual for c in self.components)

    @property
    def honesty_ratio(self) -> float:
        """Overall ratio: actual / estimated. 1.0 = perfect."""
        if self.total_estimated <= 0:
            return 1.0
        return self.total_actual / self.total_estimated

    @property
    def overrun(self) -> bool:
        """True if actual cost exceeded 1.5x estimated."""
        return self.honesty_ratio > 1.50

    def to_dict(self) -> Dict:
        return {
            "trial_id":         self.trial_id,
            "session_id":       self.session_id,
            "total_estimated":  round(self.total_estimated, 2),
            "total_actual":     round(self.total_actual, 2),
            "honesty_ratio":    round(self.honesty_ratio, 4),
            "overrun":          self.overrun,
            "components":       [
                {"name": c.name,
                 "estimated": round(c.estimated, 2),
                 "actual": round(c.actual, 2),
                 "ratio": round(c.ratio, 4)}
                for c in self.components
            ],
            "contract_version": self.contract_version,
        }


# ---- METER ------------------------------------------------------------------

class JouleWorkMeter:
    """
    Context manager for timing trial cost components.

    Usage
    -----
        meter = JouleWorkMeter(trial_id="t-001", estimated_total_ms=300.0)
        with meter:
            meter.start_component("inference")
            time.sleep(0.05)   # simulated inference
            meter.end_component("inference", estimated_ms=50.0)

        record = meter.record
        print(f"honesty_ratio: {record.honesty_ratio:.3f}")

    Or use estimate_from_history() to get a context-aware estimate
    before running the trial (calibrates after A010).
    """

    # Default cost estimates (milliseconds) -- calibrate after A010
    DEFAULT_ESTIMATES: Dict[str, float] = {
        "inference":             200.0,   # LLM API round-trip
        "gate_evaluation":        10.0,   # sigma anchor checks
        "ledger_write":            5.0,   # WORM append
        "provenance_construction": 2.0,   # ProvenanceChain build
        "archive_write":          15.0,   # Archive memory write
        "total":                 250.0,   # conservative total
    }

    def __init__(
        self,
        trial_id: str,
        estimated_total_ms: float = 0.0,
        session_id: str = "",
    ) -> None:
        self.trial_id     = trial_id
        self.session_id   = session_id
        self.record       = TrialCostRecord(
            trial_id=trial_id, session_id=session_id
        )
        self._start_times: Dict[str, float] = {}
        self._trial_start: float = 0.0
        self._estimated_total = (
            estimated_total_ms if estimated_total_ms > 0
            else self.DEFAULT_ESTIMATES["total"]
        )

    def __enter__(self) -> "JouleWorkMeter":
        self._trial_start = time.perf_counter()
        return self

    def __exit__(self, *args) -> None:
        actual_total = (time.perf_counter() - self._trial_start) * 1000
        # If no components recorded, record as total
        if not self.record.components:
            self.record.components.append(CostComponent(
                name="total",
                estimated=self._estimated_total,
                actual=actual_total,
            ))

    def start_component(self, name: str) -> None:
        self._start_times[name] = time.perf_counter()

    def end_component(
        self,
        name: str,
        estimated_ms: Optional[float] = None,
    ) -> None:
        if name not in self._start_times:
            return
        actual_ms = (time.perf_counter() - self._start_times[name]) * 1000
        est_ms = estimated_ms or self.DEFAULT_ESTIMATES.get(name, actual_ms)
        self.record.components.append(CostComponent(
            name=name,
            estimated=est_ms,
            actual=actual_ms,
        ))
        del self._start_times[name]

    @classmethod
    def estimate_from_history(
        cls,
        history: List[TrialCostRecord],
        percentile: float = 0.75,
    ) -> float:
        """
        Estimate cost for next trial from history of prior trials.
        Uses the 75th percentile actual cost as the estimate.
        This makes the estimate slightly conservative -- better to
        overestimate than to trigger JOULE_OVERRUN on normal trials.

        Calibrates after A010 when real timing distributions are available.
        Returns DEFAULT_ESTIMATES["total"] if history is empty.
        """
        if not history:
            return cls.DEFAULT_ESTIMATES["total"]
        actuals = sorted(r.total_actual for r in history)
        n = len(actuals)
        idx = min(int(n * percentile), n - 1)
        return actuals[idx]


# ---- SESSION SUMMARY --------------------------------------------------------

@dataclass
class SessionJouleWork:
    """Aggregate JouleWork across all trials in a session."""
    session_id:          str
    trial_count:         int
    total_estimated_ms:  float
    total_actual_ms:     float
    mean_honesty_ratio:  float
    overrun_count:       int
    most_expensive_trial: Optional[str]   # trial_id
    contract_version:    str              = LABYRINTH_CONTRACT_VERSION

    @property
    def overrun_rate(self) -> float:
        if self.trial_count == 0:
            return 0.0
        return self.overrun_count / self.trial_count

    def to_dict(self) -> Dict:
        return {
            "session_id":           self.session_id,
            "trial_count":          self.trial_count,
            "total_estimated_ms":   round(self.total_estimated_ms, 2),
            "total_actual_ms":      round(self.total_actual_ms, 2),
            "mean_honesty_ratio":   round(self.mean_honesty_ratio, 4),
            "overrun_count":        self.overrun_count,
            "overrun_rate":         round(self.overrun_rate, 4),
            "most_expensive_trial": self.most_expensive_trial,
            "contract_version":     self.contract_version,
        }


def summarize_session_joule(
    records: List[TrialCostRecord],
    session_id: str = "unknown",
) -> SessionJouleWork:
    """Summarize JouleWork across all trials in a session."""
    n = len(records)
    if n == 0:
        return SessionJouleWork(
            session_id=session_id, trial_count=0,
            total_estimated_ms=0.0, total_actual_ms=0.0,
            mean_honesty_ratio=1.0, overrun_count=0,
            most_expensive_trial=None,
        )

    total_est = sum(r.total_estimated for r in records)
    total_act = sum(r.total_actual for r in records)
    ratios = [r.honesty_ratio for r in records]
    mean_ratio = sum(ratios) / n
    overruns = sum(1 for r in records if r.overrun)
    most_expensive = max(records, key=lambda r: r.total_actual).trial_id

    return SessionJouleWork(
        session_id=session_id,
        trial_count=n,
        total_estimated_ms=total_est,
        total_actual_ms=total_act,
        mean_honesty_ratio=mean_ratio,
        overrun_count=overruns,
        most_expensive_trial=most_expensive,
    )


# ---- TEST SUITE -------------------------------------------------------------

def _test_from_totals() -> bool:
    r = TrialCostRecord.from_totals("t1", 200.0, 210.0)
    assert abs(r.honesty_ratio - 1.05) < 0.001
    assert not r.overrun
    return True


def _test_overrun_detected() -> bool:
    r = TrialCostRecord.from_totals("t2", 100.0, 200.0)
    assert r.overrun
    assert r.honesty_ratio == 2.0
    return True


def _test_meter_context_manager() -> bool:
    with JouleWorkMeter("t3", estimated_total_ms=100.0) as meter:
        pass  # instant
    assert meter.record.total_actual >= 0
    assert meter.record.total_estimated == 100.0
    return True


def _test_meter_components() -> bool:
    import time as _t
    meter = JouleWorkMeter("t4")
    with meter:
        meter.start_component("inference")
        _t.sleep(0.01)  # 10ms
        meter.end_component("inference", estimated_ms=20.0)
    comp = next(c for c in meter.record.components if c.name == "inference")
    assert comp.actual >= 5.0   # at least 5ms (generous lower bound)
    assert comp.estimated == 20.0
    return True


def _test_estimate_from_history() -> bool:
    history = [
        TrialCostRecord.from_totals(f"t{i}", 200.0, 100.0 + i * 20)
        for i in range(5)
    ]
    est = JouleWorkMeter.estimate_from_history(history)
    assert est > 0
    return True


def _test_estimate_empty_history() -> bool:
    est = JouleWorkMeter.estimate_from_history([])
    assert est == JouleWorkMeter.DEFAULT_ESTIMATES["total"]
    return True


def _test_to_dict_serializable() -> bool:
    import json
    r = TrialCostRecord.from_totals("t5", 300.0, 350.0)
    json.dumps(r.to_dict())
    return True


def _test_session_summary() -> bool:
    records = [
        TrialCostRecord.from_totals(f"t{i}", 100.0, 100.0 + i * 10)
        for i in range(5)
    ]
    summary = summarize_session_joule(records, "sess-001")
    assert summary.trial_count == 5
    assert summary.total_actual_ms == sum(100.0 + i * 10 for i in range(5))
    assert summary.most_expensive_trial == "t4"
    return True


def _test_honesty_ratio_zero_estimate() -> bool:
    r = TrialCostRecord.from_totals("t6", 0.0, 100.0)
    assert r.honesty_ratio == 1.0  # safe fallback
    return True


def _test_cost_component_delta() -> bool:
    c = CostComponent("gate", estimated=10.0, actual=15.0)
    assert c.delta == 5.0
    assert abs(c.ratio - 1.5) < 0.001
    return True


def run_tests():
    tests = [
        (_test_from_totals,              "from_totals"),
        (_test_overrun_detected,          "overrun_detected"),
        (_test_meter_context_manager,     "meter_context"),
        (_test_meter_components,          "meter_components"),
        (_test_estimate_from_history,     "estimate_from_history"),
        (_test_estimate_empty_history,    "empty_history"),
        (_test_to_dict_serializable,      "to_dict"),
        (_test_session_summary,           "session_summary"),
        (_test_honesty_ratio_zero_estimate, "zero_estimate"),
        (_test_cost_component_delta,      "cost_delta"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
