# Labyrinth-OS — Formal Invariants

These invariants are structurally enforced. Violation is a system failure, not a policy failure.

---

## I1 — Execution Closure
**Only CGIR-validated edges may produce state transitions.**

No state mutation occurs except through a CGIRGraph edge that has passed `cgir_validator.validate()` and received `GateDecision.ALLOW` from `cgir_gate.evaluate()`.

Enforced by: `execution/cgir/cgir_validator.py`, `execution/gate/cgir_gate.py`, `execution/aegis/aegis_cesk.py`

---

## I2 — Gate Determinism
**The gate is a pure function. Same graph → same decision. Always.**

`cgir_gate.evaluate(graph)` has no side effects, no state, no randomness.
Given identical inputs it produces identical outputs on every machine, every run, forever.

Enforced by: `execution/gate/cgir_gate.py`

---

## I3 — Sensor Read-Only
**The VECTOR sensor fabric is read-only. It observes. It never writes.**

Sensor modules (`epistemic/signal-aggregation/cgir_signal_algebra.py`, `epistemic/vector/tau_baseline_generator.py`, `epistemic/logprob-bridge/logprob_bridge_adapter.py`) may not modify graph state, ledger state, or any external system.

Enforced by: Architecture — sensor modules have no write imports.

---

## I4 — Council Authority
**Exactly one SignalNode per execution cycle. `emitted_by="COUNCIL"` only.**

`epistemic/signal-aggregation/cgir_signal_algebra.py` emits `emitted_by="SIGNAL_ALGEBRA"` — raw sensor output.
`epistemic/council/council_resolver.py` is the only module that may emit `emitted_by="COUNCIL"`.
Only COUNCIL-emitted signals may be bound to CGIR edges.

Enforced by: `epistemic/council/council_resolver.py` hardcodes `emitted_by="COUNCIL"`. `cgir_validator.py` checks this.

---

## I5 — Gate Precedence
**CGIR Gate BLOCK is binding. GuardianSlot may only further restrict.**

```
CGIR Gate BLOCK  →  GuardianSlot MUST NOT EXECUTE. This is binding.
                     GuardianSlot may never upgrade CGIR BLOCK to EXECUTE.

CGIR Gate ALLOW  →  Necessary but not sufficient. GuardianSlot still decides.
                     GuardianSlot may BLOCK or KILL even when CGIR allows.

For EXECUTE to happen:   CGIR Gate ALLOW  AND  GuardianSlot EXECUTE
For execution to stop:   CGIR Gate BLOCK  OR   GuardianSlot BLOCK/KILL
```

CGIR Gate is the formal layer (structural validity: graph well-formed, signals clean).
GuardianSlot is the operational layer (safety margin: τ, χ, drift, confidence within bounds).
GuardianSlot may only further restrict — never upgrade — a CGIR decision.

Enforced by: `execution/gate/cgir_guardian_bridge.py` — CGIR BLOCK clips confidence below
GuardianSlot EXECUTE threshold. GuardianSlot cannot override this.

---

## I6 — Ledger Immutability
**The ledger is append-only. No modification. No deletion.**

`hashchain.py` and `execution/ledger/receipt.py` produce a WORM (Write Once Read Many) record.
Any attempted modification breaks the SHA-256 chain. `hashchain.verify()` detects this.

Enforced by: `execution/ledger/hashchain.py` — no delete/modify methods exist.

---

## I7 — Epistemic Boundary
**Epistemic signals influence confidence. They do not directly control execution.**

Sensor severity and confidence flow through `epistemic/council/council_resolver.py` → `execution/gate/cgir_guardian_bridge.py`.
They affect the GuardianSignal confidence value.
They do not bypass CGIR validation or the Gate.

The boundary: epistemic inputs are bounded inputs to the formal layer, not bypasses around it.

Enforced by: `execution/gate/cgir_guardian_bridge.py` — sensor data enters only as SensorReadings, not as gate commands.

---

## I8 — Council Determinism
**Same watcher reports + same sensor inputs → same CouncilResult.**

`epistemic/council/council_resolver.py` is deterministic. `determinism_hash` on every CouncilResult
proves this: if the hash matches across runs, the decision is identical.
The hash covers: `id, logical_time, severity, confidence, category, source, emitted_by, escalation_code, valid_for`.

Enforced by: `epistemic/council/council_resolver.py` — `determinism_hash` field, tested by `_test_same_id_different_time_different_hash`.

---

## I9 — Replay Completeness
**All committed executions are replayable from the ledger.**

Every AEGIS phase (LOAD→PROPOSE→CHECK→COMMIT→PROVE) produces a ledger entry.
`replay_validator.py` can reconstruct and verify every decision from the sealed chain.
A replay that returns anything other than `CLEAN` is evidence of tampering or non-determinism.

Enforced by: `execution/ledger/cgir_ledger.py` + `execution/replay/replay_validator.py`

---

## I10 — Fail Closed
**On any error, ambiguity, or missing input: BLOCK, not ALLOW.**

Applied at every layer:
- Missing watcher → CRITICAL (not neutral)
- Empty findings → confidence 0.0 (not 0.5)
- API error → `success=False`, `metrics_incomplete=True` (not fabricated metrics)
- Schema violation → rejected before AEGIS compiler (not passed through)
- Chain broken → `TAMPERED` verdict (not ignored)

Enforced by: All modules — every error path produces the most conservative safe outcome.

---

## Invariant Violation Severity

| Invariant | Violation | Severity | Detector |
|-----------|-----------|----------|----------|
| I1 | Unvalidated state transition | CRITICAL | cgir_validator |
| I2 | Non-deterministic gate | CRITICAL | cgir_determinism |
| I3 | Sensor writes state | CRITICAL | Architecture |
| I4 | Non-COUNCIL signal bound | ERROR | cgir_validator |
| I5 | GuardianSlot overrides CGIR BLOCK | CRITICAL | cgir_guardian_bridge |
| I6 | Ledger entry modified | CRITICAL | hashchain.verify() |
| I7 | Epistemic input bypasses gate | ERROR | cgir_guardian_bridge |
| I8 | Non-deterministic council output | ERROR | determinism_hash |
| I9 | Committed execution not replayable | ERROR | replay_validator |
| I10 | Error produces ALLOW | CRITICAL | All modules |
| I11 | Invalid label reaches Reality Gate | CRITICAL | reality_gate.py |
| I12 | Archive entry modified or deleted | CRITICAL | memory_store.py |
| I13 | Stage metric not emitted | WARNING | MetricsCollector |
| I14 | Promotion without justification record | ERROR | audit_trail.py |
| I15 | Feedback increases confidence | ERROR | feedback_loop.py |
| I16 | Promotion receipt upgraded by gate | CRITICAL | reality_gate.py |
| I17 | Timestamp regression within session | ERROR | pipeline_wire.py |
| I18 | Confidence not capped at adapter | ERROR | logprob_bridge_adapter |
| I19 | Concurrent session writes to same chain | CRITICAL | hashchain.py lock |

---

*𝕏 @LabyrinthCoder · Labyrinth-OS*

---

## I11 — Labeling Closure
**Statement:** Only proposals with a VALID label (confidence ≥ threshold) may
reach the Reality Gate. Proposals with FAILED, EXPIRED, or MISSING labels are
blocked at the labeling stage.
**Enforced by:** `epistemic/labeling/` label_validator + `lane1/09_reality_gate/reality_gate.py`
**Evidence:** EPISTEMIC_FIRST.md, spec/LABELING.md
**Status:** ENFORCED in code.

## I12 — Archive Integrity
**Statement:** The epistemic archive is append-only. No entry may be modified
or deleted after writing. The archive hash chain detects any tampering.
**Enforced by:** `epistemic/archive/memory_store.py` — append-only SQLite,
SHA-256 chained entries.
**Evidence:** spec/ARCHIVE.md
**Status:** ENFORCED in code.

## I13 — Observability Completeness
**Statement:** Every pipeline stage transition emits a metric to the observability
layer. No stage may complete silently without recording its outcome.
**Enforced by:** `execution/observability/metrics.py` — MetricsCollector.emit()
called at each stage.
**Evidence:** spec/OBSERVABILITY.md
**Status:** PARTIALLY ENFORCED — MetricsCollector wired but not called from all
paths in prototype ignition.py stubs.

## I14 — Promotion Auditability
**Statement:** Every promotion decision (pass or fail) is recorded with its
full justification: evidence list, confidence value, run count, and timestamp.
No silent promotions.
**Enforced by:** `promotion/audit_trail.py`
**Evidence:** spec/PROMOTION.md
**Status:** ENFORCED in code.

## I15 — Feedback Loop Closure
**Statement:** Feedback from anomaly detection may only decrease confidence or
leave it unchanged. Feedback never increases confidence (fail-closed anomaly
response).
**Enforced by:** `execution/observability/feedback_loop.py` — adjustment always ≤ 0
**Evidence:** EPISTEMIC_FIRST.md
**Status:** ENFORCED in code.

## I16 — Boundary Upgrade Prohibition (Promotion → Reality Gate)
**Statement:** A PromotionReceipt with approved=False may never be upgraded
to approved=True by the Reality Gate.
**Enforced by:** `lane1/09_reality_gate/reality_gate.py` — check() returns
GateBlock.NO_PROOF if proof_ref.approved is False.
**Evidence:** reality_gate.py runtime assertion (May 2026).
**Status:** ENFORCED in code.

## I17 — Non-Decreasing Timestamps Within Session
**Statement:** Within a single PipelineTrace, recorded timestamps must be
non-decreasing. A regression indicates clock error or tampering.
**Enforced by:** `pipeline_wire.py` — record() raises ValueError on regression.
**Evidence:** test_pipeline_wire.py timestamp tests.
**Status:** ENFORCED in code.

## I18 — Confidence Cap at Adapter Boundary
**Statement:** Confidence derived from LogprobMetrics must be capped at the
adapter, not downstream. A compromised adapter should not inject high confidence
without real logprob evidence reaching ignition.
**Enforced by:** Partially — MISSING_LOGPROB_CONFIDENCE_CAP defined in
api_logprob_extractor.py. Full migration from ignition.py to adapter pending.
**Status:** DOCUMENTED, partially enforced. Full enforcement post-A011.

## I19 — Session Isolation
**Statement:** Concurrent execution sessions must not interleave writes to the
same hash chain. Each session must write to a unique ledger instance. Shared
file-system ledgers require file-level locking at the caller level.

**Enforced by:**
- `execution/ledger/hashchain.py` — threading.Lock guards append() for in-process
  thread safety (fixed May 2026).
- `chronicle_query.py` — fcntl.flock guards the SQLite index for concurrent reads.
- Session design: each IgnitionSession creates its own CGIRLedger instance;
  sessions are not shared across threads in the prototype.

**Cross-process gap:** Two OS-level processes writing to the same serialized
chain file on disk are not prevented by the threading lock. Callers must use
session-specific output directories (recommended) or an external file lock.

**Status:** IN-PROCESS enforced. Cross-process requires session directory isolation.
