# CHANGELOG — Labyrinth-OS 

## Session — May 2026 (current)

### New tests added — Post-external-review session (May 2026)

Motivated by three independent external reviews (documents 5, 6, 7) and the
roadmap conversation about what's buildable now without A010.

**Property-based tests (Hypothesis):**
- test_property_based.py — 10 constitutional proofs (P1-P10):
  P1 determinism, P2 chi never executes, P3 tau floor, P4 confidence floor,
  P5 KILL not downgraded, P6 severity always valid, P7 hashchain always verifies,
  P8 chi aggregate escalation, P9 no crashes, P10 confidence synthesis in range

**Chronicle dedicated suite:**
- test_chronicle_dedicated.py — 8 tests: write/read roundtrip, PIPELINE_MASS,
  entry ordering, verify_chain, concurrent writes, large payload, restart survival

**Guardian bridge dedicated suite:**
- test_guardian_bridge_dedicated.py — 10 tests: chi Layer 1/2/3 all covered,
  confidence clamping, empty vector, determinism, healthy path

**Sigma anchor boundary sweep:**
- test_sigma_boundary_sweep.py — 23 tests: every threshold at exactly-at,
  just-below, just-above, nominal-safe, extreme-violation

**Rust/Python differential parity:**
- test_rust_python_differential.py — 7 tests: static constant parity proven,
  runtime differential documented as GAP R4 (closes when Rust CLI binary exists)

**Domain adapter contracts:**
- test_domain_adapter_contracts.py — 23 tests across 5 domains:
  AI governance, industrial CNC, medical, financial, autonomous vehicles

**Z3 proof extensions:**
- test_z3_extensions.py — 9 formal proofs: chi aggregate floor not vacuous,
  floor consistent with hard threshold, escalation always reaches collapse,
  confidence amplification bounds, all Sigma Anchors strictly ordered

**Deferred node convergence:**
- test_deferred_node_convergence.py — 8 tests: mutation bounded, depth limit,
  oscillation detection, from_failed_proposal(), confidence ceiling, thread safety

**Total new tests this session: 98**
**Running total: Python 1,221 / Rust 249 / Mini 314 / Full system 1,470 / 0 failures**

**Critical sync fixed:**
cgir_guardian_bridge.py had never been synced from sentinel to cgir.
The chi aggregate fix (Rooke Poole, May 2026) was in sentinel but not running
in tests. Fixed: bridge now synced, __future__ import ordering corrected.

### Chi Aggregate Leak — Fixed (Rooke Poole, May 2026)

**The leak:** chi_vector=[0.39, 0.39] — two components both dangerously close
to CHI_COLLAPSE=0.40 — passed through the bridge as max()=0.39, below the
collapse threshold. Guardian slot issued BLOCK instead of KILL. Aggregate
contradiction density was invisible to the gate.

**The fix (cgir_guardian_bridge.py):**
- Layer 1 (unchanged): max() hard threshold — any single component >= 0.40 → KILL
- Layer 2 (new): mean() aggregate check — if mean >= 0.28 (70% of CHI_COLLAPSE),
  chi_scalar is elevated to 0.40, forcing KILL. Closes [0.39, 0.39] scenario.
- Layer 3 (new): resonance sensitivity — chi distance from ideal peaks [0.05, 0.15]
  produces resonance. Resonance < 0.05 dampens confidence, surfacing risk before
  hard thresholds trigger.

**Credit:** Rooke Poole identified this gap independently and provided the patch
concept via the domain-adaptive resonance gate implementation.

**Tests added:** _test_chi_aggregate_leak_closed, _test_chi_resonance_confidence_penalty

### Architecture additions
- Three-tier gate decision documented: EXECUTE / BLOCK / KILL (KILL irrevocable)
- Dual enforcement documented: forward (cgir_gate) + backward (replay_validator)
- Artifact state machine documented: RAW→EXPERIMENTAL→PARTIAL→VALIDATED
- Signal algebra documented: pure function, no state, no I/O
- FailedProposal as load-bearing artifact documented
- Dual confidence threshold decay margin documented (0.95→0.65 intentional gap)

### New invariants enforced in code
- I16: PromotionReceipt approved=False cannot be upgraded by Reality Gate (now enforced)
- I17: Timestamps non-decreasing within a single PipelineTrace session (now enforced)
- I18: Confidence cap at adapter boundary — documented, partially addressed

### New gaps documented
- GAP 10: UnlabeledProposal not wired into gate — typed safeguard ornamental
- GAP 11: GuardianSlot upgrade prohibition not self-contained in slot
- GAP 12: PipelineTrace wall-clock only — no logical sequence counter
- GAP R4: Cross-language runtime parity not verified (A012 is static analysis only)
- Constitutional deadlock resolution undefined

### Code fixes
- chronicle_query.py: syntax error fixed (flock indentation in write_entry)
- deferred_node.py: FailureRecord.from_failed_proposal() converter — correct fields
- verify_run.py: EQUIVALENT mode carries explicit security note
- pipeline_wire.py: I17 timestamp monotonicity enforced in record()
- reality_gate.py: I16 approved=False check enforced
- promotion_rules.py: dead TTL code removed, caller responsibility noted
- logprob_bridge_adapter.py: duplicate constant removed, single source in api_logprob_extractor.py
- enforcement.py: "proves" → "demonstrates" in test docstring
- run_all.py: Step 0 syntax check added; deferred_node and boot_manifest added to SUITES
- update_docs.py: manifest path fixed; path reference checker added
- INVARIANTS.md: all enforced_by lines now use full relative paths
- PROTOTYPE_BOUNDARIES.md: "spare-time" reframed as "without institutional backing"

### New files
- AI_REVIEWER_DEFAULT.md: reviewer orientation (understand first, gap-hunt only if asked)
- PROTOTYPE_BOUNDARIES.md: three-zone map, proof scope boundaries
- archive/audits/: seven external audits archived verbatim with responses
- archive/THEORY_AND_METAPHOR.md: 13 entries covering origin, DNA framing, philosophy

### Mini system
- Z3 sigma proof: 8 proofs (z3_sigma_proof.py)
- SQLite persistent index: MemoryArchive(ledger, index_path=...)
- Auto-evolution: HealingCoordinator after 3 DEGRADE cycles
- Boolean filter hook: live in PromotionGate.evaluate()
- SensorReadings.__post_init__: ValueError on out-of-range values
- 0o600 ledger permissions
- evolution_engine.py: relative delta cap (10% of current value)

### Test counts
- Python: 1,221 / 0 failures (added deferred_node 15t + boot_manifest 8t)
- Rust: 249 / 0 failures (29 crates)
- Mini: 301 / 0 failures
- Total: 1,470 / 0 failures

---

## Session — April 2026

### Added
- `chunk_store.py` — lossless compressed archive, hot index, SHA-256 verification
- `epistemic/experimental/` — resonant_memory_ref, distributed_topology_ref, wasm_rust_ref
- `runtime/a010_monitor.py` — signal watcher for A010 real inference run
- `runtime/verify_run.py` — mock/real boundary enforced (never says A010 CLOSED on dry-run)
- 6 SCUEL synthetic tests (POLITE_LIE, SLOW_POISON, BURST, COORDINATED, identity, nominal)
- 4 TM-001 attack class tests (CONFIDENCE_SPOOF, PARTIAL_WRITE, REPLAY_ATTACK, TIME_ORDER_MANIP)
- Archive→decisions feedback loop wired into `_promote_ignition()`
- `cargo test` integrated into `run_all.py` — one command for Python + Rust

### Changed
- `run_all.py` — now runs cargo test as final tier; prints `Python: N  Rust: M  Total: N+M`
- `verify_run.py` — mock/real boundary: `a010_closed` only True on real API runs
- `ROADMAP.md` — rewritten; all completed Rust phases marked [x]
- `README.md` — rewritten from scratch with accurate state
- `KNOWN_GAPS.md` — GAP 2 marked CLOSED
- `SYSTEM_REPORT.json` — accurate test counts and ACP-1 status
- `SECURITY.md` — TM-001 VERIFIED added
- `AI_REVIEWER_GUIDE.md` — ACP-1 verified count updated to 10
- All Rust crate Cargo.toml — pinned uuid=1.6.1, chrono=0.4.38 for Rust 1.75 compat

### Verified (ACP-1)
- **A012 VERIFIED** — `cargo build --workspace` + `cargo test --workspace` both pass
- **A017 VERIFIED** — all 10 TM-001 attack classes have detection tests

### Test Counts
- Python: 1,221 / 0 failures
- Rust: 249 / 0 failures
- Total: 1425,402 / 0 failures

---

## Previous Sessions

### Lane 1 + Pipeline Enforcement
- L00-L04 implemented (boot_manifest, user_intent, creative_zone, analytical_core)
- PipelineTrace timestamp enforcement — ordering proofs, `assert_can_enter_cgir()` fatal
- Option B `labeling_required=False` explicit, not implicit bypass
- 9 tests proving halt before trial 1 on any violation

### Rust Substrate
- 29 crates with real implementations (not stubs)
- cgir-types: Severity, Confidence with clamping; Sigma Anchor constants
- gate, ledger-chronicle, cgir-fuzzer, shadow-ghost, council-resolver
- world-model, concept-engine, transfer-engine, offline-evolution, hardware-rot

### Classification Layer
- `epistemic/classification/` — artifact state machine
- enforcement.py, artifact_state.py, transition_rules.py, classifier.py
- FAILED/ARCHIVED/DEPRECATED → hard block
- PARTIAL → WARN + confidence cap + proof_required

### Z3 Sovereignty Spec (A021 VERIFIED)
- Sigma Anchor constants proven via Z3 SMT solver
- TAU_ESCAPE_FLOOR, CHI_WARN, CHI_COLLAPSE, DRIFT_THRESHOLD, BETTI_1_CAP

### TM-001 Threat Model (A017 now VERIFIED)
- 10 attack classes defined and tested
- WORM Chronicle tamper-evidence proven

### Epistemic Archive
- chunk_store.py — lossless gzip, hot index, SHA-256, fail-closed on mismatch
- archive/external_references/ — quantum_tubulin, quicksilver_v3
- epistemic/experimental/ — resonance, distributed topology, Wasm/Rust references

---

## Session — May 2026 (second build session)

### Audit fixes — 17 documented issues resolved

All 17 items from Labyrinth-OS-Audit-Notes resolved in order:

- Note 1: GAP 7 Status text restored (was contaminated with GAP 10 content)
- Note 2/14: A017 updated from 10 to 11 attack classes (CLASS-11 PROMOTION_RACE)
- Note 3: P5 restored in test_property_based.py (KILL cannot be downgraded to EXECUTE)
- Note 4: SNAPSHOT/README/STATUS counts updated throughout
- Note 5: README heading "28 Crates" corrected to "29 Crates"
- Note 6: GAP 10 Status field changed from OPEN to PARTIAL (matches header)
- Note 7: GAP 3 marked CLOSED (all lane1 directories now have implementations)
- Note 8: External review attribution made specific (documents 5-10)
- Note 9: Duplicate acbf_vm entry removed from SUITES
- Note 10: Duplicate itv_vectors entry removed from SUITES
- Note 11: cargo crash fixed — shutil.which('cargo') guard added to run_all.py
- Note 12: Domain adapter test count label confirmed correct
- Note 13: EBF test renamed from misleading "fires_when_filter_present" to
  honest "wired_not_raises" with assertion that proves what it actually tests
- Notes 15-17: Confirmed OK, no action needed

### Structural fixes

- run_all.py path injection expanded from 10 to 45 directories
  (unblocked 7+ suites that were silently skipped)
- tau_baseline_generator.py: os.normpath → os.path.normpath bug fixed
- test_rust_python_parity.py: hardcoded wrong path + missing cargo guard fixed
- test_full_pipeline.py: sovereignty_receipt.json uses absolute path now
- runtime/ignition.py: full path bootstrap added for subprocess mode
- test_rust_python_differential.py: BASE path double-SENTINEL bug fixed
- SUITES registry: all new modules registered with correct descriptions

### New modules integrated into Sentinel-Substrate (8 modules, +120 tests)

All modules built natively from Labyrinth-OS design patterns.
External references documented as ANALOGY, not derived mechanisms.
No personal information in any file. Attribution by name only.

**steward/predicate_extractor.py (20 tests)**
Logical Sentinel — five predicate extraction + Z3 invariant verification.
Direct response to AI-authored zero-day exploit (Google Threat Intelligence,
May 2026). Geometry cannot distinguish truth from deception (experimental
finding, p=0.948). Predicate layer adds formal verification as second axis.
Both sensor channels AND predicate channels must pass. Neither is sufficient.
Three invariants: Φ1 (source-risk), Φ2 (verification-gate), Φ3 (loop-uncertainty).
Architectural reference: Sylvain Delgado, Spectrography of Artificial Thought
(March 2026). Classification: ANALOGY — same structural conclusion, independent
derivation from deception-detection direction.

**steward/acp1_dependency_graph.py (13 tests)**
ACP-1 directed dependency graph with automatic collapse propagation.
Replaces flat tracker's hidden fragility with visible collapse chains.
A VERIFIED assumption that depends on OPEN assumptions now shows AT_RISK.
BFS propagation from any OPEN node through all downstream dependents.
Architectural reference: Delgado epistemic layer framework (May 2026).
Classification: ANALOGY — layer collapse propagation principle extracted.

**epistemic/classification/epistemic_class.py (17 tests)**
TCP truth-class schema — typed epistemic classification for proposals.
Five classes: EMPIRICALLY_VERIFIED, INFERRED, COHERENTLY_SYNTHESIZED,
HYPOTHETICAL, AMBIGUOUS. Each class has a confidence floor.
AMBIGUOUS floor > CONFIDENCE_CAP = permanent promotion block.
HYPOTHETICAL routes to DeferredExplorationNode.
Reference: Quillan TCP schema (archived as external reference, not imported).
Built natively. Quillan code does not enter the codebase.

**lane1/00_boot_manifest/meta_goal_engine.py (14 tests)**
Meta-goal layer — the driver. Closes gap between "waits for human prompt"
and "drives itself from system state + memory." Formulate → Prioritize →
Validate → Revise lifecycle. Only VALIDATED GoalDirectives may seed L01.
Meta-goal layer cannot modify execution — it influences proposals only.
Reference: Quillan emergent goal formation paper (File 16).

**promotion/domain_reasoning_profiles.py (14 tests)**
Domain reasoning profiles — Lane 1 complement to domain adapters.
Adapters handle sensor translation (Lane 2). Profiles shape reasoning
posture (Lane 1). Full bilateral domain coverage for medical, industrial,
financial, autonomous_vehicle, generic. Each profile: confidence floor
deltas, chi/drift threshold overrides, goal priors, prohibited patterns.
Reference: Quillan LHP domain initialization pattern.

**execution/replay/cue_pattern_miner.py (22 tests)**
Cue pattern mining — turns replay from verification to learning.
Scans 3 ledger entries preceding each BLOCK to extract sensor cue patterns.
Multi-location sensor key resolution (4 possible ledger formats handled).
None sentinel for absent data (distinguishable from genuine zero reading).
Cue signatures stored as ANOMALY entries. DeferredExplorationNode reads
these to inform mutation strategy. Reference: Quillan Drift Paper (File 11).

**runtime/continuous_learning_loop.py (12 tests)**
Continuous learning loop — closes episodic/continuous gap.
All six components (Perception/WorldModel/Memory/Planning/Action/Feedback)
existed but ran episodically. Sessions reset rather than compound.
LearningLoop wires them: begin_session() loads prior state, end_session()
pushes feedback and refreshes memory index. Next session starts enriched.
Reference: Quillan Continuous Learning paper (File 17).

**runtime/boot_preflight.py (8 tests)**
Boot manifest preflight — wires L00 boot_manifest into ignition startup.
Mandatory pre-flight check before any session is accepted.
FAIL = session rejected. WARN = session proceeds with warnings logged.
PASS = normal. require_clean_boot() for production; require_clean_boot_or_warn()
for prototype phase (GAP 1 open). Reference: Quillan Loader Manifest pattern.

### Wiring completed in mini system (Albedo)

- LogicalSentinel wired into robot_session.process() at L05 — between
  labeling and promotion. UNSAT predicate verdict overrides to BLOCK.
  Zero-day response module is now live, not idle.
- boot_preflight wired into robot_session.boot() — require_clean_boot_or_warn()
  in prototype phase. Hard FAIL stops session. WARN logs and continues.
- acp1_tracker.py header updated to declare acp1_dependency_graph as the
  authoritative collapse tracker.

### predicate_extractor wired into ignition.py

LogicalSentinel added to ignition._run_trial() as second verification axis.
Response text used as chain-of-thought proxy when no explicit CoT available.
UNSAT verdict overrides decision to BLOCK, severity to CRITICAL.
Fail-safe: predicate failure never crashes ignition session.

### New documentation

**THEORETICAL_FOUNDATIONS.md** — new file.
Three-layer epistemic framework applied to Labyrinth-OS itself.
Layer I (proved), Layer II (defined, not yet empirically verified under
live adversarial conditions), Layer III (full vision, conditional on II).
Covers: geometric morality fallacy, binary gate necessity, three-tier
dynamical regimes, watcher severity as phase structure, ε(Π) bound.
Three independent convergences documented: Sylvain Delgado (deception-
detection), Rooke (discrete cellular physics), Labyrinth-OS (governance).
Collapse rules apply. Layer I stands unconditionally.

**ARCHITECTURE.md** — theoretical foundations section added.
Geometric Morality Fallacy (experimental finding, classification: ANALOGY).
Binary gate necessity (Proposition 2.2.2, classification: ANALOGY).
Three-tier decision structure (PT-symmetry regimes, classification: ANALOGY).
Watcher severity ordering (Kato perturbation theory, classification: ANALOGY).
Irreducible error bound ε(Π) (Van Vu-Saito 2026, classification: THEORETICAL BOUND).

**KNOWN_GAPS.md** — GAP 13 added.
Pre-execution contamination is outside scope. Gate enforces at action time.
Weight contamination, training poisoning, input pipeline manipulation are
upstream of the gate and not currently addressed. Honest boundary statement.
The armored door critique (Delgado, May 2026) acknowledged directly.
What closes it: provenance auditing + weight attestation (separate problem,
separate engineering, no timeline).

### Test counts this session

- Python (Sentinel): 1,278 → 1,398 (+120 from 8 new modules)
- Mini (Albedo): 333 → 346 (+13 from wiring fixes)
- Rust: 249 (unchanged)
- Total: 1,654+ / 0 failures

### Attribution policy enforced throughout

All external references by name only. No personal contact information,
no social handles, no identifying details beyond names in documentation.
Sylvain Delgado and Rooke referenced by name in CHANGELOG, ARCHITECTURE.md,
THEORETICAL_FOUNDATIONS.md, and relevant source file docstrings.
Security-sensitive architectural details not surfaced in public-facing docs.


---

## Session — May 2026 (third build session — external audit response)

### Security fixes from external audit (three independent AI reviews)

**G1 — EQUIVALENT replay mode removed (HIGH severity)**
verify_run.py: step2_exact_chain_replay() no longer falls back to
EQUIVALENT mode when chain_entries are absent. Absence now raises
SystemError. EQUIVALENT mode returned PASS while being unable to detect
ledger tampering when chain_entries were deliberately omitted — identified
as a security gap by external audit. Test updated: absent chain_entries
must raise SystemError.

**G2 — HashChain in-process thread safety (I19)**
hashchain.py: threading.Lock added to append(). Concurrent in-process
threads can no longer interleave writes to the same HashChain instance.
Cross-process safety documented: caller must use session-specific
output directories. I19 (Session Isolation) invariant added.

**G3 — INVARIANTS.md canonical source now complete (I11–I19)**
INVARIANTS.md previously skipped I11–I15 (they existed only in spec/
and EPISTEMIC_FIRST.md). All nine missing invariants added to canonical
source with enforcement status, evidence, and violation severity.
Updated violation severity table to cover I1–I19.

**G4/G13 — Detection vs. blocking security boundary stated**
SECURITY.md: new "Security Boundary: Detection vs. Blocking" section.
Explicitly states: watchers detect but don't block directly. A proposal
within Sigma thresholds will not be blocked even if watchers flag anomaly.
Predicate layer adds second axis but remains heuristic. Trade-off stated
clearly: formal thresholds are Z3-proven (no spurious blocks) at the cost
of sophisticated in-threshold proposals being logged not stopped.

**G5 — Formal verification taxonomy standardized**
PROTOTYPE_BOUNDARIES.md: taxonomy table added at top.
Z3-PROVEN / TEST-VERIFIED / PROTOTYPE-WIRED / NOT YET DEMONSTRATED.
What A021 proves is now precisely bounded. EQUIVALENT fallback reference
updated to reflect G1 fix.

**G8 — CircuitBreaker + DegradationDetector built (13 tests)**
execution/gate/circuit_breaker.py: constitutional deadlock resolution.
CircuitBreaker: opens after N consecutive BLOCKs or M window BLOCKs.
OPEN state blocks all proposals (never bypasses gate) until operator reset.
HALF_OPEN state: one probe allowed, closes after K successes.
DegradationDetector: tracks mean confidence and watcher agreement.
WARNING and DEGRADE states on sustained threshold violations.
DEGRADE requires operator reset. Both classes are fail-closed.
Closes the gap: "constitution has no supreme court."

### Other gaps identified (documented, not yet built)

G6: Healing loop mutation re-injection — deferred_node.mutate() produces
candidates but output goes nowhere. Session-to-session mutation queue
not yet implemented. Documented in KNOWN_GAPS.md as open.

G7: PersistentMemoryStore.risk_estimate() never called in promotion.
Amplifier mask (Poole P10.5-B) is code without effect. Documented.

G9: Human override not cryptographically signed. GateProof embeds
override as string, not signed artifact. Requires hardware attestation
(A002/A003) before cryptographic signing is meaningful. Documented.

G10: Domain adapter calibration spec lacks adversarial examples and
per-domain fail-closed procedures. Documented as open.

G11: Three epistemic layers (Layer I/II/III) from THEORETICAL_FOUNDATIONS.md
not yet surfaced as code-level tags on assumptions. Documented.

G12: UNSAT predicate verdict not producing a typed FailedProposal with
specific PREDICATE_BLOCK ledger entry. Documented.

### Test counts
- Python (Sentinel): 1,398 → 1,411 (+13 from circuit_breaker)
- Mini (Albedo): 346 (unchanged)
- Rust: 249 (unchanged)
- Total: 1,667+ / 0 failures


---

## Session — May 2026 (fourth build session — gap closure continued)

### G6 — Healing loop mutation queue closed

runtime/ignition.py:
- _trial_failures list accumulates FailureRecord entries on each BLOCK
- _seal() processes _trial_failures via deferred_node.process_batch()
- mutation_candidates exported in session summary JSON
- Next session can load mutation_candidates and re-inject at LABELING
- Loop is now: failures → archive → deferred_node.mutate() → candidates in summary → next session LABELING
- All fail-safe: mutation processing never crashes ignition

### G7 — PersistentMemoryStore wired to promotion (amplifier mask active)

runtime/ignition.py:
- _memory_store now wired to promotion_rules via module attribute at session init
- promotion_rules.py already had risk_estimate() logic (lines 146-162) but
  _memory_store was always None — now receives the live store
- Amplifier mask (Poole P10.5-B): ±0.05 confidence delta from historical similarity
- Fail-safe: memory wiring failure never crashes session

### G11 — EpistemicLayer (Layer I/II/III) tags added to all ACP-1 assumptions

steward/acp1_dependency_graph.py:
- EpistemicLayer enum added: LAYER_I (Z3-proven/test-verified), LAYER_II
  (prototype-wired), LAYER_III (not yet demonstrated)
- layer= field added to Assumption dataclass (default: LAYER_II, conservative)
- All 21 assumptions tagged: A021/A012/A005-A009/A017/A019 → LAYER_I;
  A002/A003/A014 → LAYER_III; all others → LAYER_II
- to_dict() now includes layer in serialized form
- Assumptions are now searchable by epistemic layer

### G12 — Typed PREDICATE_BLOCK ledger entry

execution/ledger/cgir_ledger.py:
- log_predicate_block() added to CGIRLedger
- Records decision="PREDICATE_BLOCK" in COMMIT phase with specific invariant
  violations (Φ1, Φ2, Φ3), verdict_hash, and source (LOGICAL_SENTINEL)
- Distinguishable from Sigma threshold blocks in replay
- Next step: wire into ignition._run_trial() when predicate verdict is UNSAT

### Mini system — logged for next session, skipped this session

All mini gaps (wiring predicate_extractor to produce typed FailedProposal,
circuit_breaker to robot_session, mutation queue to robot_session.close())
deferred to dedicated mini session. No token spend on mini this session.

### Test counts
- Python (Sentinel): 1,411 (unchanged — no new test files this session,
  changes were wiring/logic in existing files)
- Rust: 249 (unchanged)
- Total: 1,667+ / 0 failures


---

## Session — May 2026 (fifth build session — deep audit + doc structure)

### Deep audit findings resolved

**Stale counts fixed everywhere:**
- TM-001: 10 → 11 attack classes across: CORE.md, REVIEW_MAP.md, ARCHITECTURE.md,
  AI_REVIEWER_GUIDE.md, SECURITY.md (CLASS-11 PROMOTION_RACE added to class list),
  KNOWN_GAPS.md, run_all.py SUITES label, acp1_dependency_graph.py A008,
  classifier.py (8/10 → 11/11), archive/The_Geometry_of_Rules.md (archive only)
- CORE.md file count: 279 → 630 (live count via update_docs.py special handler)
- REVIEW_MAP.md Expected line: Python: 1153 → 1411, Total: 1402 → 1667+
- CORE.md minimum viable understanding: 6 → 8 files
- STATUS.md opening description updated to mathematical substrate framing

**Wrong/stale paths fixed:**
- CORE.md: cgir_gate.py → execution/gate/cgir_gate.py (correct absolute path)
- CORE.md: runtime/logprob_bridge_adapter.py → epistemic/logprob-bridge/ (correct)
- test_rust_python_parity.py: dead legacy path path removed
- test_full_pipeline.py: docstring legacy path reference cleaned
- test_ci_gaps.py: full path block rewritten (CGIR/LANE1 → REPO/lane1)
- CONTRIBUTING.md: cd legacy path → cd Sentinel-Substrate--main
- update_docs.py: legacy path fallback removed — always uses BASE
- run_all.py: hardcoded absolute path → os.path.dirname(os.path.abspath(__file__))

**run_all.py now portable** — _SENTINEL is dynamic, not hardcoded.

### update_docs.py watch list expanded

Previously: 7 files. Now: 15 files.
Added: STATUS.md, SNAPSHOT.md, SECURITY.md, PROTOTYPE_BOUNDARIES.md,
THEORETICAL_FOUNDATIONS.md, CORE.md, REVIEW_MAP.md, AI_REVIEWER_GUIDE.md.
Added: special handler for REVIEW_MAP.md Expected line (different pattern).
Added: special handler for CORE.md file count (live find count).

### New modules added to CORE.md

circuit_breaker.py, predicate_extractor.py, acp1_dependency_graph.py
now listed in Core Enforcement Pipeline section.
THEORETICAL_FOUNDATIONS.md and SECURITY.md added to navigation.

### Delgado PDF structural patterns adopted

Three patterns from Delgado (2026) paper structure that were missing:

1. Classification standard table at the top of REVIEW_MAP.md —
   every claim tagged: Z3-PROVEN / TEST-VERIFIED / PROTOTYPE-WIRED /
   NOT YET DEMONSTRATED / ANALOGY. Dependency rule stated.

2. Gap summary table at the top of KNOWN_GAPS.md — 14 gaps in structured
   table form with Status / Layer / What Closes It / Collapses If Open.
   Prose detail preserved below. Same structure as Delgado Tables 5.2/6.1.

3. Dependency rule stated prominently in STATUS.md and KNOWN_GAPS.md headers —
   "Layer III collapses if Layer II fails. Layer I stands unconditionally."

REVIEW_MAP.md fully rewritten: classification standard, dependency rule,
6-file reading order (up from 4), core files with verification status tags,
explicit "What the System Cannot Currently Do" section.

### Remaining dead path reference (comment only)
test_rust_python_parity.py line 41: "# formerly legacy path"
— comment only, not functional. Acceptable.

### Test counts
- Python (Sentinel): 1,411 (unchanged — no new test files this session)
- Rust: 249 (unchanged)
- Total: 1,667+ / 0 failures


---

## Session — May 2026 (sixth build session — remaining gap closure)

### G9 — Human override structured logging in SlotResult

execution/gate/guardian_slot.py:
- SlotResult.__slots__ now includes human_override_used and human_override_reason
- human_override_used passed into SlotResult from evaluate() — override is now a
  typed field embedded in the receipt hash, not a buried string
- Override included in _compute_receipt() — cannot be erased from chain without
  breaking the hash. Tamper-evident by construction.
- to_dict() surfaces human_override_used, human_override_reason, and
  override_signature="PENDING_HARDWARE_ATTESTATION" when override was used
- Cryptographic signature deferred to A002/A003 hardware — documented honestly

### G12 — Typed PREDICATE_BLOCK ledger entry wired into ignition

runtime/ignition.py:
- When LogicalSentinel returns UNSAT, a Receipt with verdict="PREDICATE_BLOCK"
  is written to self._chain before the trial result is recorded
- Receipt payload includes: proposal_id, violations list, verdict_hash,
  phi1_unsat/phi2_unsat/phi3_unsat booleans (which invariants were violated)
- Distinguishable from Sigma threshold blocks in replay by verdict value
- Fail-safe: ledger write failure never crashes the trial

### ARCHITECTURE.md — Epistemic status tags added to section headers

Per Delgado PDF discipline: every section now opens with its epistemic status.
- Sigma Anchor Constants: [Z3-PROVEN — A021]
- Hard Invariants: [TEST-VERIFIED — I1–I19]
- Dual Enforcement: [TEST-VERIFIED]
- A014 Design Target: [NOT YET DEMONSTRATED — requires FPGA + ATECC608B]
- Theoretical Foundations: [ANALOGY — external frameworks, no derivation claimed]

### test_rust_python_parity.py — SENTINEL_BASE path fixed

_HERE = os.path.dirname(os.path.abspath(__file__))
SENTINEL_BASE = os.path.normpath(os.path.join(_HERE, '..', '..'))
File is in tests/integration/ → two levels up = Sentinel-Substrate--main. Correct.
Added signal-aggregation and ledger/vector to standalone path set.

### update_docs.py — SNAPSHOT.md file count handler added

Special handler now covers both CORE.md ("N files exist.") and SNAPSHOT.md
("| Full system | N |"). Both update from live find count. Removed duplicate
handler; both covered in single loop.

### SNAPSHOT.md file counts updated

Full system: 432 → 650. Mini system: 37 → 49.

### Test counts
- Python (Sentinel): 1,411 (unchanged — changes were wiring/logic)
- Rust: 249 (unchanged)
- Total: 1,667+ / 0 failures


---

## Session — May 2026 (seventh build session — final scan cleanup)

### Final audit scan fixes

**SUITES test count labels corrected:**
- chronicle_query: claimed 7t, actual 8t → fixed to 8t
- acbf_vm: claimed 8t, actual 5t → fixed to 5t

**run_ignition.py stale references cleaned:**
- "flat cgir/ directory" → "Sentinel-Substrate--main root" (3 occurrences)

**Two TODOs confirmed intentional (not stale):**
- council_resolver.py: "TODO (A011 prerequisite)" — valid, A011 is PARTIAL
- Both Python and Rust versions are consistent with each other

**Zero new test files — no count change.**

### System status confirmed clean
- 0 hardcoded absolute paths remaining in active code
- 0 stale legacy path references in active code
- 0 missing SUITES modules (104 checked)
- 0 test failures
- All SUITES descriptions with explicit counts now accurate


---

## Session — May 2026 (eighth build session — roadmap closures)

### CLASS-11 PROMOTION_RACE — fully implemented (P10.5-C)

Previously: CLASS-11 was named, counted everywhere, had a ThreatVector entry
in the registry description — but AttackClass enum had only 10 values, the
registry had only 10 vectors, and no actual detection code existed.

Now complete:
- AttackClass.PROMOTION_RACE = "CLASS-11" added to enum in threat_model.py
- ThreatVector entry added to TM_001 registry (now 11 vectors)
- Detector map updated: promotion_rules.py → _in_flight set
- _test_registry_has_all_10_vectors renamed to _test_registry_has_all_11_vectors
- _test_all_attack_classes_covered now verifies all 11 classes
- _test_promotion_race_both_blocked: threading test proves concurrent
  evaluate() calls with same label_id → second call REJECTED
- PromotionRules.__init__: _in_flight: set added
- PromotionRules.evaluate(): PROMOTION_RACE check as Rule 0 before all others
- PromotionRules._evaluate_inner(): extracted, called after race check clears
- P10.5-C fully closed: Dark Forest attack vector blocked at source

### z3_promotion_proof.py — built (8 Z3 proofs)

PROTOTYPE_BOUNDARIES.md referenced z3_promotion_proof.py as Z3-PROVEN
but the file did not exist. Now exists at tests/unit/z3_promotion_proof.py.

PR1: Confidence floor is non-vacuous (valid inputs exist above floor)
PR2: Confidence floor is not sufficient alone (other conditions required)
PR3: Floor is correctly ordered (0 < floor < 1)
PR4: MIN_CONSECUTIVE_RUNS >= 1 (zero-run bypass impossible)
PR5: Approval requires all three conditions simultaneously
PR6: Promotion is deterministic (same inputs → same outcome, UNSAT proof)
PR7: Race check does not affect single-thread promotion (runtime proof)
PR8: Confidence amplification is bounded [0.0, 0.99] (UNSAT proof)

Added to SUITES at tier 99 (slow, like z3_sovereignty_spec).

### Pipeline zone telemetry — PipelineMassEntry (P10.5-D)

chronicle_query.py: PipelineMassEntry class added.
At each stage transition, records confidence × proposal_count as "mass".
Makes healing loop dynamics, pressure buildup, and leakage observable.
log_pipeline_mass() helper writes PIPELINE_MASS entries to chronicle.
4 tests added to chronicle_query run_tests().

### Approval flux monitor — ApprovalFluxMonitor (P10.5-F)

chronicle_query.py: ApprovalFluxMonitor class added.
Tracks gate approval rate over a rolling window (default: 100 samples).
States: INSUFFICIENT_DATA → HEALTHY → WARNING → ANOMALY.
Equilibrium rate placeholder: 0.60 (calibrate post-A010; Poole used 0.4002
in a different domain — documented as placeholder).
Deviation thresholds: ±20% WARNING, ±35% ANOMALY.
Early warning for gate miscalibration and adversarial pressure campaigns.
4 tests added to chronicle_query run_tests().

### EBF native implementation — _ebf_native (promotion_rules.py)

Previously: _ebf_noop() always returned True.
Now: _ebf_native() is a deterministic polarity consistency checker.

Checks:
  1. Contradiction pairs — both poles present in same text
     (e.g., "guaranteed safe" AND "cannot be verified")
  2. Certainty overstatement — "100% certain", "can never fail"
  3. Hedged certainty — "definitely correct, although it might"

_ebf_native wired into _evaluate_inner as Rule 6.
Fail-open: empty/None reasoning passes, crashes pass.
Default filter is _ebf_native (not the no-op).
_ebf_filter attribute override still works for post-A010 replacement.
5 new EBF tests added to promotion_rules run_tests().

### REVIEW_MAP.md Expected line updated

1411 → 1434, 1667+ → 1690+

### Test counts
- Python (Sentinel): 1,411 → 1,434 (+23)
  - threat_model: +2 (CLASS-11 test + 11-vector count test)
  - z3_promotion_proof: +8 (PR1-PR8)
  - chronicle_query: +8 (4 telemetry + 4 flux)
  - promotion_rules: +5 (EBF native tests)
- Rust: 249 (unchanged)
- Total: 1,690+ / 0 failures


---

## Session — May 2026 (ninth build session — cathedral sweep, doc depth, GAP 1 partial)

### Cathedral sweep — complete

All "cathedral-os" references removed from active code and documentation.
Historical changelog entries referencing "cathedral-os" neutralized to "legacy path."
Result: 0 cathedral references anywhere in the repository.

### Documentation depth additions

**PROTOTYPE_BOUNDARIES.md — two new named sections:**
- "Syntactically admissible ≠ semantically sound" — the deepest unsolved problem.
  Gate proves admissibility, not correctness. These are different claims.
  Closing it requires A015 semantic replay with domain correctness criteria.
- "The operator problem — who guards the gate from the gatekeeper?" —
  A014 converts "detectable" to "structurally impossible." Until then, the
  gate is fail-closed against outsiders, not against the operator who controls it.

**KNOWN_GAPS.md — three-constitution framing added:**
- Input constitution (provenance/supply chain) — MISSING — GAP 13 reframed
- Execution constitution (gates/ledger/replay) — THIS SYSTEM — built
- Evolution constitution (healing/governance) — SKETCHED
GAP 13 is now named as the missing first constitution, not just a scope note.

**SECURITY.md — operator problem named section:**
"Who guards the gate from the gatekeeper?" — explicit section explaining that
the system is fail-closed against external adversaries but not yet against
the legitimate operator who wants one exception. A014 is the resolution.

### GAP 1 partial closure — real epistemic labeling wired into ignition

Previously: every ignition trial was Option B (labeling_required=False).
The label was not computed; it was not recorded; it played no role.

Now:
- EpistemicLabeler.classify_from_content() runs on every trial response
- Real epistemic label (SPECULATIVE / DEFERRED / UNKNOWN) produced per trial
- IgnitionEntry gains epistemic_label and epistemic_conf fields
- Both appear in to_dict() → in chain entry payloads → in session JSON
- _current_reasoning set per trial for EBF filter access
- Confirmed in mock run: epistemic_label="UNKNOWN" (correct for short mock text)
  With real LLM responses: SPECULATIVE or DEFERRED produced

GAP 1 updated from OPEN → PARTIAL in KNOWN_GAPS.md gap table.
Full closure still requires: real ArchiveMemory, PromotionProtocol, RealityGate
called from ignition — these remain local stubs pending A010.

### Test counts
- Python (Sentinel): 1,434 (unchanged — no new test files this session)
- Rust: 249 (unchanged)
- Total: 1,690+ / 0 failures


---

## Session — May 2026 (tenth build session — history sweep + bug fixes)

### EBF _current_reasoning bug fixed

promotion_rules._evaluate_inner() was reading `getattr(self, '_current_reasoning', "")`
but self is PromotionRules, not the IgnitionSession that set the attribute.
EBF filter was receiving empty string on every evaluation.

Fix: reasoning_text is now an explicit parameter on both evaluate() and _evaluate_inner().
Callers pass it directly. The stale session attribute assignment in ignition.py removed.
EBF now correctly receives the response text when called from code that has it.

### Soft real-time gate budget warning

guardian_slot.py: when evaluation_time_us > 670µs (FPGA floor, A014 target),
a stderr warning is printed. Telemetry only — not enforcement. Makes the gap
between current software timing and hardware target visible during development.

### SNAPSHOT.md fully updated

Rewrote with current counts (1,434 Python, 704 files), full milestone list
covering all sessions, and honest next session priority list.

### History sweep — items found and resolved

From reviewing the full session context:
- EBF _current_reasoning bug (described above) — FIXED
- Soft real-time budget — FIXED
- SNAPSHOT.md staleness — FIXED
- promote_rules.evaluate() now accepts reasoning_text kwarg

### Items logged for next session (not built today)

- ACP-1 A001 dependency on A021 not in graph (ordering depends on Z3 proof)
- circuit_breaker.py not wired into ignition.py (class exists, not connected)
- NATIONAL_SECURITY_REFERENCE folder not audited for stale counts
- OPERATOR_GUIDE.md and CONTRIBUTING.md not updated for new architecture
- Mini system wiring session still deferred

### Test counts
- Python (Sentinel): 1,434 (unchanged)
- Rust: 249 (unchanged)
- Total: 1,690+ / 0 failures


---

## Session — May 2026 (eleventh build session — proofs + specs)

### z3_predicate_proof.py — 9 Z3 meta-proofs (PP1-PP9)

tests/unit/z3_predicate_proof.py — closes the gap where predicate_extractor.py
used Z3 as a runtime checker (per-proposal) but had no standalone meta-proof
that the invariants themselves are sound.

PP1: Φ1 is non-vacuous (reachable)
PP2: Φ1 soundness — SOURCE=VERIFIED cannot trigger it (UNSAT proof)
PP3: Φ2 is non-vacuous (reachable)
PP4: Φ2 soundness — non-consequential + verified cannot trigger it (UNSAT proof)
PP5: Φ3 is non-vacuous (reachable)
PP6: Φ3 soundness — no loop + uncertainty acknowledged cannot trigger it (UNSAT)
PP7: Joint consistency — Φ1∧Φ2∧Φ3 can all be satisfied simultaneously (clean proposal passes all)
PP8: Independence — each invariant fires independently; no two are redundant
PP9: Symbolic fallback agreement — Z3 and symbolic paths agree on complete canonical inputs
Added to SUITES at tier 99. 9 tests passing.

### DOMAIN_ADAPTER_SPEC.md — adversarial examples + calibration procedure

Added 5-domain adversarial example tables (AI, Medical, Industrial, Financial, AV).
Each with tau/chi/drift/betti_1/confidence readings and expected EXECUTE/BLOCK decision.
Fail-closed behavior specified per domain (Medical: any sensor fail → BLOCK;
Industrial: any sensor fail → KILL; AV: safety-critical sensor fail → KILL).
5-step calibration procedure: baseline → threshold validation → adversarial
validation → edge case calibration → fail-closed test.
Regression gate: any threshold change requires all 5 steps re-run.

### SEMANTIC_REPLAY_SPEC.md — new document

Design spec for semantic replay (A015). Distinguishes structural replay (built)
from semantic replay (specified, not built). 5 verification layers: logit
faithfulness, label correctness, predicate consistency, decision correctness
(requires A020), amplifier audit. Prerequisites: A010 + A011 + A020.
Output format specified. Implementation plan in 3 phases.

### MULTI_SENTINEL_SPEC.md — Phase 11 design

Xi-Jensen pattern: 3+ sentinel nodes with 2/3 Byzantine quorum.
Any KILL from any sentinel is irrevocable. Quorum timeout → BLOCK (fail-closed).
Local ledger per sentinel + global ledger for quorum log.
Two-level replay: local (per sentinel) + global (quorum log).
Port plan from archive xi_jensen_pipeline/ documented.
Minimum viable Phase 11: 3 sentinels, simple 2/3 vote, merkle global ledger.
Gate contract preserved — distribution multiplies the gate, not bypasses it.

### RED_TEAM_HARNESS_SPEC.md — A020 design

A020 closure criteria: live ignition, 100 safe proposals per domain (FPR ≤ target),
10 per attack class × 5 domains (FNR = 0.00), edge cases, predicate layer attacks.
11 TM-001 attack classes with generation strategies.
Domain-specific TPR/FPR/FNR targets (Medical: FNR=0, FPR≤0.02; AV: FNR=0, FPR≤0.01).
Primary assertion: false negatives = 0.00. Any executed unsafe proposal is a gate failure.
Closing A020 opens A016 (closer to VERIFIED) and A019 (measurable).

### Mini system wiring session (same session)

circuit_breaker.py added to mini (13 tests).
circuit_breaker wired into robot_session: check before pipeline, outcome recorded.
Mutation queue in close(): _trial_failures → DeferredExplorationNode → candidates exported.
SessionSummary gains: mutation_candidates, circuit_breaker, degradation fields.
EBF reasoning_text kwarg in promotion_protocol.
CHANGELOG.md and SNAPSHOT.md created for mini system.
Mini total: 359 passing / 0 failing.

### Test counts
- Python (Sentinel): 1,434 → 1,443 (+9 from z3_predicate_proof)
- Mini (Albedo): 346 → 359 (+13 from circuit_breaker)
- Rust: 249 (unchanged)
- Total: 1,700+ / 0 failures


---

## Session — May 2026 (twelfth build session — Poole archive + P10.5-H)

### Poole Manifold full repository review

259-file repository reviewed. 16 highest-relevance files extracted into
archive/external_references/poole_manifold/ as .txt reference files.
README.md index created: what's in the archive, what's already been taken,
what's buildable now vs post-A010, what was not archived and why.

Three new roadmap items derived from analysis:
P10.5-G: Venturi Choke — domain resonance gate (post-A010)
P10.5-H: Directional mutation — channel-aware healing (BUILT this session)
P10.5-I: Resonance Latch — A014 architecture update (post-A010)

### P10.5-H: Directional mutation BUILT

lane1/07_deferred_exploration/deferred_node.py:

Previously: mutate() applied ±10% to all parameters uniformly.
Direction was only coarsely keyed to failure_type (constraint → reduce,
drift → increase, else → reduce). No channel awareness.

Now: _infer_blocked_channel() extracts which Sigma Anchor channel caused the
block from the failure reason string (TAU/CHI/DRIFT/BETTI_1/CONFIDENCE/PREDICATE).
_mutation_direction() uses the channel to select the mutation direction per key:
  CHI failure → chi-related params reduce, others reduce conservatively
  CONFIDENCE failure → confidence/evidence params increase
  PREDICATE failure → scope/loop/propagation params reduce (Φ3 pattern)
  TAU failure → signal-health params increase, others reduce
  Fallback: same as before (failure_type-based direction)

Mutation log now includes the inferred channel for auditability.

Source: Rooke — kinetic mass recycling principle (Poole Manifold).
The failure energy is directional: the nature of the failure shapes the repair.
Attribution: Rooke. No personal details.

4 new tests added:
  _test_P10_5H_chi_failure_reduces_chi_parameter
  _test_P10_5H_confidence_failure_raises_confidence_parameter
  _test_P10_5H_predicate_failure_reduces_scope
  _test_P10_5H_mutation_log_includes_channel

### Unkind language about Rooke's work removed

THEORETICAL_FOUNDATIONS.md: "Rooke's DESI BAO claim overstates" removed.
archive/THEORY_AND_METAPHOR.md: same line removed.
Replaced with: "The convergence strengthens plausibility. It does not close gaps.
Each system has open questions." No individual framework's claims are adjudicated.

### Reviewer docs rewritten (neutral evaluation framing)

AI_REVIEWER_DEFAULT.md: Removed "before you look for what is broken, look at
what was built" framing. New opening: "Your task is to evaluate this system
accurately — three things with equal weight." Sends reviewers to KNOWN_GAPS.md
and PROTOTYPE_BOUNDARIES.md first.

AI_REVIEWER_GUIDE.md: Removed "Is This Rare?" section that answered its own
question as yes before the reviewer had looked at anything. Replaced with
neutral evaluation framework: formal verification table with scope of each proof,
detection-vs-blocking boundary stated prominently, "interesting problems" section
pointing toward genuine open questions.

### THEORY_AND_METAPHOR.md — 4 new entries + 6 poems

Entry 006: Three independent convergences — what they mean and don't
Entry 007: The armored door critique — honest and complete
Entry 008: Cognition without sovereignty — compressed soul of the project
Entry 009: The question that defines the category — anti-confusion architecture

6 poems: The Gate, Two Lanes, The Ledger, What Remains, The Gap, On Building

### Test counts
- Python (Sentinel): 1,443 → 1,447 (+4 from P10.5-H directional mutation tests)
- Rust: 249 (unchanged)
- Total: 1,700+ / 0 failures


---

## Session — May 2026 (thirteenth — deep audit + systematic fixes)

### Audit findings and resolutions

**1. Three identical duplicate files removed**
lane1/00_boot_manifest/analytical_core.py == lane1/04_analytical_core/analytical_core.py
lane1/00_boot_manifest/creative_zone.py == lane1/03_creative_zone/creative_zone.py
lane1/00_boot_manifest/user_intent.py == lane1/01_user_intent/user_intent.py
Canonical versions in numbered lane dirs remain. Boot manifest duplicates deleted.

**2. acbf_vm.py synchronized**
execution/runtime/acbf_vm.py (canonical, has I9 reference) →
execution/cgir/acbf_vm.py. Both now byte-identical.

**3. memory_store import path fixed in continuous_learning_loop.py**
Line 272 was importing `from memory_store import EntryType` without path.
Now resolves explicitly: os.path.join(sentinel, 'epistemic', 'archive').
Previously failed silently; feedback storage code path never executed.

**4. verify_run.py path injection fixed**
Was: sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
Now: full path injection covering all 9 required module directories.
verify_run.py now works standalone without run_all.py pre-loading paths.

**5. Boot preflight wired into ignition.run()**
require_clean_boot_or_warn() now called at start of every session.
Fail-open for prototype phase — WARN/FAIL logged but don't halt.
Post-A010: convert to hard stop on FAIL.

**6. LearningLoop wired into ignition**
LearningLoop.begin_session() called in __init__
LearningLoop.record_trial_feedback() called after each trial
LearningLoop.end_session() called in _seal() before chain verification
Learning loop compounds session knowledge without touching enforcement.

**7. Invariant tests — I12, I13, I16, I19**
tests/unit/test_invariants_i12_i13_i16_i19.py — 8 tests, all passing.
I12: archive append-only (two tests: MemoryStore.query, hashchain tamper)
I13: MetricsCollector exists, partial enforcement documented
I16: GateBlock on missing proof, GateBlock on rejected proof, no upgrade between calls
I19: concurrent HashChain.append thread-safe, separate sessions isolated
Added to SUITES at tier 8.

**8. epistemic/archive added to run_all.py path injection**
Was missing — caused I12 test to load wrong MemoryStore class.

**9. run_all.py SUITES count accuracy**
12 Lane 1 modules registered (88 tests now counted that were passing silently).
Total jumped 1,447 → 1,535 from registration alone, then to 1,549 with audit fixes.

### Test counts
- Python (Sentinel): 1,541 → 1,549 (+8 from invariant tests)
- Rust: 249 (unchanged)
- Total: 1,800+ / 0 failures


---

## Session — May 2026 (fourteenth — uploads reviewed, EWMA fix, gap updates)

### Two uploads reviewed

**labyrinth_os_portable_v2.zip:**
A fourth parallel implementation — mobile consumer app targeting offline-first
local LLM deployment (Ollama/llama.cpp) with Flutter UI, streaming SSE, WAL
SQLite memory, model registry (clone/snapshot/export), and local HTTP server.
Not a merge target. Different deployment philosophy (consumer vs. research).
One critical fix extracted: DegradationDetector EWMA audit fix (see below).
Noted as fourth track: Sentinel-Core / Sentinel-Substrate / Robot / Portable.

**Albedo-Robot-Labyrinth-OS-v7.zip:**
Historical snapshot superseded by current ALBEDO_MINI. The deep audit inside
accurately described v7 state — no wiring to pipeline. Every gap it named
(cgir_types, hashchain, ledger, replay, mode_router) is closed in current mini.
No merge needed. Historical context only.

### DegradationDetector — EWMA fix applied (audit fix from portable_v2)

execution/gate/circuit_breaker.py + ALBEDO_MINI/circuit_breaker.py:

Previously: flat rolling windows (deque maxlen=20).
Problem: a BLOCK from 20 sessions ago weighed the same as one from right now.
The portable_v2 audit correctly identified this — absolute window size is wrong.

Now: EWMA (Exponentially Weighted Moving Average), alpha=0.3.
Recent events matter more. ~3 recent events dominate the signal.
operator_reset() clears EWMA state (no residual from previous window).
DegradeReport.window_size now reports n_records (total observations) not window cap.

### GAP 10 → WIRED

assert_can_enter_cgir() in pipeline_wire.py enforces that labeling_required=False
paths must record FAILOVER_ENTRY. Undocumented bypasses raise SystemError.
Software enforcement exists. Hardware token (A014) still OPEN separately.
Gap table updated: PARTIAL → WIRED.

### Attribution note logged

Sylvain Delgado: credited for foundational suggestion toward early architecture.
Ongoing build is independent. Attribution in docs reflects suggestion, not ongoing work.

### Robot system renaming — deferred

Renaming "Albedo" to neutral/anonymous robot identifier deferred to dedicated session.
Will require grep across all three systems + docs.

### Test counts
- Python (Sentinel): 1,549 (unchanged)
- Mini: 359 (unchanged)
- Core: 292 (unchanged)
- Total: 1,800+ / 0 failures

