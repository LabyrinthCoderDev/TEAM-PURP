# Core Files — Labyrinth-OS

**The files that actually matter for understanding and running the system.**

630 files exist. Most are support, tests, research, or docs.
These are the ones you need.

---

## Minimum Viable Understanding (8 files)

```
PROJECT_CONTEXT.md                 what this is and why it's structured this way
THEORETICAL_FOUNDATIONS.md         three epistemic layers, mathematical grounding
STATUS.md                          current state, honest
AUTHORITY.md                       who decides what
KNOWN_GAPS.md                      what isn't wired yet, collapse rules
steward/acp1_dependency_graph.py   22 assumptions + collapse propagation + layer tags
steward/acp1_tracker.py            assumption evidence and status
pipeline_wire.py                   how ordering is enforced
```

---

## Core Enforcement Pipeline

```
# Lane 1 — Epistemic
lane1/05_epistemic_labeler/epistemic_labeler.py
lane1/08_promotion_protocol/promotion_protocol.py
lane1/09_reality_gate/reality_gate.py

# Reality Gate crossing enforcement
pipeline_wire.py

# Lane 2 — Execution
execution/cgir/cgir_types.py           core types, BlockReason enum
execution/gate/cgir_gate.py            Sigma Anchor gate (ALLOW/BLOCK)
execution/gate/guardian_slot.py        final EXECUTE/BLOCK/KILL
execution/gate/circuit_breaker.py      constitutional deadlock (CLOSED/HALF_OPEN/OPEN)
execution/aegis/aegis_cesk.py          deterministic CESK runtime
execution/ledger/hashchain.py          WORM hash chain (thread-safe, I19)
execution/ledger/receipt.py            immutable receipts
execution/replay/replay_validator.py   exact replay — EXACT only (EQUIVALENT removed)

# Second verification axis (zero-day response, May 2026)
steward/predicate_extractor.py         LogicalSentinel — Φ1/Φ2/Φ3 via Z3

# Assumption tracking with collapse propagation
steward/acp1_dependency_graph.py       directed graph — AT_RISK inherits from OPEN
```

## Z3 Formal Proofs

```
execution/cgir/formal/z3_sovereignty_spec.py   Sigma Anchor constants consistent (A021) [Z3-PROVEN]
tests/unit/z3_promotion_proof.py               Promotion rules PR1-PR8 [Z3-PROVEN]
tests/unit/z3_predicate_proof.py               Predicate invariants PP1-PP9 [Z3-PROVEN]
```

## Design Specifications (post-A010 implementation targets)

```
DOMAIN_ADAPTER_SPEC.md        5-domain adversarial examples + calibration procedure
SEMANTIC_REPLAY_SPEC.md       Design for proving soundness not just admissibility (A015)
MULTI_SENTINEL_SPEC.md        Phase 11 distributed topology — Xi-Jensen quorum pattern
RED_TEAM_HARNESS_SPEC.md      A020 red-team harness design — closes false negative measurement
```

---

## Core Constants

```
sigma_anchors.py                   TAU/CHI/DRIFT/BETTI thresholds (single source)
```

---

## Core Runtime

```
runtime/ignition.py                session runner (GAP 1 noted: uses mock stages)
runtime/verify_run.py              post-run verification
runtime/a010_monitor.py            signal monitoring for A010
```

---

## Core Tests

```
run_all.py                                       runs everything (Python + cargo test)
update_docs.py                                   keeps doc counts current

tests/adversarial/threat_model.py                TM-001: all 11 attack classes
tests/adversarial/breakout_harness.py            adversarial cage falsification (5 kill paths)
tests/adversarial/z3_constraint_patch.py         Z3 upgrade for breakout harness
tests/unit/test_watcher_council_bounds.py        watcher→council influence bounds (P1-P4)
tests/unit/itv_vectors.py                        canonical ACBF VM test vectors
tests/integration/test_feedback_loop_e2e.py      feedback loop end-to-end proof (7t)
tests/integration/test_full_pipeline.py          SCUEL synthetic pipeline tests
```

---

## Core Typed Artifacts

```
promotion/promotion_receipt.py         typed proof that promotion ran (closes GAP 1 semantics)
lane1/08_promotion_protocol/unlabeled_proposal.py  explicit Option B bypass typing
execution/ledger/receipt.py            ExecutionValidity enum (VERIFIED/UNVERIFIED/MOCK_PATH)
```

## Core Formal Spec

```
spec/INVARIANTS.tla                TLA+ invariant specification
spec/EPISTEMIC.tla                 TLA+ epistemic layer
execution/cgir/formal/z3_sovereignty_spec.py  Z3 Sigma Anchor proofs (A021)
```

---

## Everything Else

**Support** (infrastructure, adapters, utilities):
`runtime/api_adapter.py`, `epistemic/logprob-bridge/logprob_bridge_adapter.py`, `epistemic/archive/chunk_store.py`, `epistemic/council/council_resolver.py`

## Zone Map — Three Tiers of the System

Every file in Labyrinth-OS belongs to one of three zones:

**ZONE 1 — Kernel (load-bearing, enforced, tested)**
These files do what they claim. Remove any one of them and the architecture breaks.

**ZONE 2 — Prototype (correct in isolation, partially wired)**
These files work correctly but are not yet connected to real external systems.
The ignition.py live path uses stubs for some of these. Documented in KNOWN_GAPS.md.

**ZONE 3 — Research (reference only, not executed)**
External references, experimental ideas, future integration targets.
None of these are in the live execution path.

See PROTOTYPE_BOUNDARIES.md for exact scope of each zone.

---

**Research** (experimental, not executed):
`epistemic/experimental/` — resonant memory, distributed topology, Wasm/Rust references

**External reference** (archived, not pipeline):
`archive/external_references/`

**Classification layer** (wired but metadata-conditional):
`epistemic/classification/` — enforcement, artifact_state, transition_rules, classifier

**Rust substrate** (compiled, tested, not primary enforcement yet):
`crates/` — 29 crates, 249 tests, all passing
`crates/chancery-core/` — verification harness for tool calls, ExecutionValidity, ML-DSA roadmap

**Extended Lane 1** (implemented, not primary):
`lane1/00_boot_manifest/` through `lane1/04_analytical_core/`

---

## How to Know if Something Is Core

Ask: "If I remove this file, does the pipeline break?"

- `pipeline_wire.py` — yes, remove it and ordering enforcement is gone
- `cgir_gate.py` — yes, remove it and the gate doesn't run
- `epistemic/experimental/resonant_memory_ref.md` — no, it's reference material

Core files break the pipeline if removed. Everything else supports, extends, or documents.
