# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_rust_python_differential.py — Labyrinth-OS / GAP R4
# ----------------------------------------------------------------------------

"""
test_rust_python_differential.py — Labyrinth-OS / GAP R4
=========================================================
Rust/Python differential parity tests.

GAP R4: Rust and Python agree on constants (VERIFIED).
        Runtime decision parity not yet verified end-to-end.

Tests:
  - All six Sigma Anchor constants match Python and Rust source
  - Python gate decision logic matches Rust gate logic for key inputs
  - Escalation semantics identical between layers
  - GAP R4 documented in KNOWN_GAPS.md
"""
from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
BASE = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'  ))


def _read_rust(relative_path):
    path = os.path.join(BASE, relative_path)
    with open(path) as f:
        return f.read()

def _rust_has_const(src, name, value):
    return name in src and str(value) in src


# ── CONSTANT PARITY ───────────────────────────────────────────────────────────

def test_rust_python_TAU_ESCAPE_FLOOR_match():
    from sigma_anchors import TAU_ESCAPE_FLOOR
    rsrc = _read_rust('crates/cgir-types/src/lib.rs')
    assert _rust_has_const(rsrc, 'TAU_ESCAPE_FLOOR', TAU_ESCAPE_FLOOR)

def test_rust_python_CHI_COLLAPSE_match():
    from sigma_anchors import CHI_COLLAPSE
    rsrc = _read_rust('crates/cgir-types/src/lib.rs')
    assert _rust_has_const(rsrc, 'CHI_COLLAPSE', CHI_COLLAPSE)

def test_rust_python_CHI_WARN_match():
    from sigma_anchors import CHI_WARN
    rsrc = _read_rust('crates/cgir-types/src/lib.rs')
    assert _rust_has_const(rsrc, 'CHI_WARN', CHI_WARN)

def test_rust_python_DRIFT_THRESHOLD_match():
    from sigma_anchors import DRIFT_THRESHOLD
    rsrc = _read_rust('crates/cgir-types/src/lib.rs')
    assert _rust_has_const(rsrc, 'DRIFT_THRESHOLD', DRIFT_THRESHOLD)

def test_rust_python_BETTI_1_CAP_match():
    from sigma_anchors import BETTI_1_CAP
    rsrc = _read_rust('crates/cgir-types/src/lib.rs')
    assert _rust_has_const(rsrc, 'BETTI_1_CAP', BETTI_1_CAP)

def test_rust_python_CONFIDENCE_FLOOR_in_gate():
    from sigma_anchors import CONFIDENCE_FLOOR
    rsrc = _read_rust('crates/gate/src/lib.rs')
    assert _rust_has_const(rsrc, 'CONFIDENCE_FLOOR', CONFIDENCE_FLOOR)

def test_rust_python_gate_constants_match():
    from sigma_anchors import TAU_ESCAPE_FLOOR, CHI_COLLAPSE, DRIFT_THRESHOLD
    rsrc = _read_rust('crates/gate/src/lib.rs')
    for name, val in [('TAU_ESCAPE_FLOOR', TAU_ESCAPE_FLOOR),
                      ('CHI_COLLAPSE', CHI_COLLAPSE),
                      ('DRIFT_THRESHOLD', DRIFT_THRESHOLD)]:
        assert _rust_has_const(rsrc, name, val)

def test_rust_python_signal_algebra_constants_match():
    from sigma_anchors import TAU_ESCAPE_FLOOR, CHI_WARN, CHI_COLLAPSE, DRIFT_THRESHOLD, BETTI_1_CAP
    rsrc = _read_rust('crates/signal-algebra/src/lib.rs')
    for name, val in [('TAU_ESCAPE_FLOOR', TAU_ESCAPE_FLOOR),
                      ('CHI_WARN', CHI_WARN),
                      ('CHI_COLLAPSE', CHI_COLLAPSE),
                      ('DRIFT_THRESHOLD', DRIFT_THRESHOLD),
                      ('BETTI_1_CAP', BETTI_1_CAP)]:
        assert _rust_has_const(rsrc, name, val)

def test_rust_python_all_anchors_in_cgir_types():
    from sigma_anchors import SIGMA_ANCHORS
    rsrc = _read_rust('crates/cgir-types/src/lib.rs')
    missing = [n for n in SIGMA_ANCHORS if n not in rsrc]
    assert len(missing) <= 1  # CONFIDENCE_FLOOR lives in gate crate


# ── DECISION LOGIC PARITY ─────────────────────────────────────────────────────

def test_rust_python_runtime_parity_python_blocks_correctly():
    """Python gate blocks when tau below floor or chi above collapse."""
    from cgir_signal_algebra import evaluate as signal_eval, SensorReadings
    from cgir_types import Severity
    test_vectors = [
        (0.70, 0.10, 0.05, 0.01, 0.85, True),
        (0.90, 0.45, 0.05, 0.01, 0.85, True),
        (0.90, 0.10, 0.05, 0.01, 0.85, False),
    ]
    for tau, chi, drift, betti, conf, expect_critical in test_vectors:
        r = SensorReadings(
            tau_escape=tau, chi_vector=[chi], drift_score=drift,
            betti_1=betti, confidence=conf,
            source="parity_test", logical_time=1
        )
        signal = signal_eval(r, signal_id="parity_test")
        is_critical = signal.severity == Severity.CRITICAL
        assert is_critical == expect_critical, (
            f"tau={tau} chi={chi}: expected critical={expect_critical}, "
            f"got severity={signal.severity}"
        )

def test_rust_python_drift_threshold_parity():
    """Python gate produces ERROR when drift at threshold."""
    from sigma_anchors import DRIFT_THRESHOLD
    from cgir_signal_algebra import evaluate as signal_eval, SensorReadings
    from cgir_types import Severity
    r = SensorReadings(
        tau_escape=0.90, chi_vector=[0.10], drift_score=DRIFT_THRESHOLD,
        betti_1=0.01, confidence=0.85, source="drift_test", logical_time=1
    )
    signal = signal_eval(r, signal_id="drift_test")
    assert signal.severity in (Severity.ERROR, Severity.CRITICAL)

def test_rust_python_betti_threshold_parity():
    """Python gate produces ERROR when betti_1 at cap."""
    from sigma_anchors import BETTI_1_CAP
    from cgir_signal_algebra import evaluate as signal_eval, SensorReadings
    from cgir_types import Severity
    r = SensorReadings(
        tau_escape=0.90, chi_vector=[0.10], drift_score=0.05,
        betti_1=BETTI_1_CAP, confidence=0.85, source="betti_test", logical_time=1
    )
    signal = signal_eval(r, signal_id="betti_test")
    assert signal.severity in (Severity.ERROR, Severity.CRITICAL)

def test_rust_python_nominal_state_passes():
    """Nominal healthy state produces INFO or WARNING."""
    from cgir_signal_algebra import evaluate as signal_eval, SensorReadings
    from cgir_types import Severity
    r = SensorReadings(
        tau_escape=0.90, chi_vector=[0.05], drift_score=0.05,
        betti_1=0.01, confidence=0.90, source="nominal_test", logical_time=1
    )
    signal = signal_eval(r, signal_id="nominal_test")
    assert signal.severity in (Severity.INFO, Severity.WARNING)

def test_gap_r4_documented():
    gaps_path = os.path.join(BASE, 'KNOWN_GAPS.md')
    with open(gaps_path) as f:
        content = f.read()
    assert 'GAP R4' in content or 'R4' in content

def test_gap_r4_partial_status():
    gaps_path = os.path.join(BASE, 'KNOWN_GAPS.md')
    with open(gaps_path) as f:
        content = f.read()
    idx = content.find('GAP R4')
    if idx < 0:
        idx = content.find('R4')
    section = content[idx:idx+200]
    assert 'PARTIAL' in section


# ── RUNNER ────────────────────────────────────────────────────────────────────

def run_tests():
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed, failed = 0, 0
    results = []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)[:200]))
    return passed, failed, results
