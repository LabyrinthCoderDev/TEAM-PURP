# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_check_consistency.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
test_check_consistency.py — Labyrinth-OS
==========================================
Tests for scripts/check_consistency.py — artifact consistency checker.
"""
import sys, os
root = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(root, 'scripts'))


def run_tests():
    from check_consistency import run_tests as _internal
    passed, failed, _ = _internal()

    # Additional tests
    extra = [
        _test_script_importable,
        _test_find_root_works,
        _test_report_readable,
    ]
    for fn in extra:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {fn.__name__}: {e}")

    return passed, failed, []


def _test_script_importable():
    import check_consistency
    assert hasattr(check_consistency, 'check')
    assert hasattr(check_consistency, 'run_tests')
    assert hasattr(check_consistency, 'ConsistencyResult')


def _test_find_root_works():
    import check_consistency
    root = check_consistency._find_root()
    assert (root / 'run_all.py').exists(), "Root must contain run_all.py"


def _test_report_readable():
    import check_consistency
    root = check_consistency._find_root()
    passed, date = check_consistency.read_report(root)
    assert passed is not None, "SYSTEM_REPORT.json must be readable"
    assert passed >= 1530, f"Report must show >= 1530 passing, got {passed}"
    assert date is not None
