# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_sensor_gate_and_permits.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
test_sensor_gate_and_permits.py — Labyrinth-OS
================================================
Integration tests for:
  - bounded_sensor_gate.py (BoundedSensorGate, extract_from_json, safe_median)
  - merkle_permit_set.py (MerklePermitSet, OperationPermit)
  - sigma_anchors.py sensor constants
  - api_adapter.py extract_response_value wiring
"""
import sys, os
root = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, root)
sys.path.insert(0, os.path.join(root, 'execution', 'pre_cgir_gate'))
sys.path.insert(0, os.path.join(root, 'runtime'))


def run_tests():
    passed = failed = 0
    tests = [
        _test_sensor_constants_in_sigma_anchors,
        _test_bounded_sensor_gate_internal,
        _test_merkle_permit_internal,
        _test_gate_crossing_in_default_permits,
        _test_inference_call_in_default_permits,
        _test_novel_action_excluded,
        _test_extract_response_value_wired,
        _test_root_hex_is_64_chars,
        _test_sigma_anchor_channels_all_pass,
        _test_safe_median_aggregation,
        _test_merkle_root_stable_across_sessions,
    ]
    for fn in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {fn.__name__}: {e}")
    return passed, failed, []


def _test_sensor_constants_in_sigma_anchors():
    from sigma_anchors import (
        MAX_SENSOR_CHANGE_PER_CYCLE,
        MIN_SENSOR_UPDATE_INTERVAL_S,
        SENSOR_STALENESS_THRESHOLD_S,
    )
    assert MAX_SENSOR_CHANGE_PER_CYCLE  == 0.40
    assert MIN_SENSOR_UPDATE_INTERVAL_S == 0.05
    assert SENSOR_STALENESS_THRESHOLD_S == 30.0


def _test_bounded_sensor_gate_internal():
    from bounded_sensor_gate import run_tests as bsg_tests
    p, f, _ = bsg_tests()
    assert f == 0, f"{f} tests failed in bounded_sensor_gate"


def _test_merkle_permit_internal():
    from merkle_permit_set import run_tests as mp_tests
    p, f, _ = mp_tests()
    assert f == 0, f"{f} tests failed in merkle_permit_set"


def _test_gate_crossing_in_default_permits():
    from merkle_permit_set import MerklePermitSet
    ps = MerklePermitSet.labyrinth_default()
    r = ps.check("GATE_CROSSING")
    assert r.permitted, "GATE_CROSSING must be in default permit set"


def _test_inference_call_in_default_permits():
    from merkle_permit_set import MerklePermitSet
    ps = MerklePermitSet.labyrinth_default()
    r = ps.check("INFERENCE_CALL")
    assert r.permitted, "INFERENCE_CALL must be permitted for A010"


def _test_novel_action_excluded():
    from merkle_permit_set import MerklePermitSet, PermitVerdict
    ps = MerklePermitSet.labyrinth_default()
    r = ps.check("NOVEL_UNKNOWN_ATTACK_SURFACE")
    assert not r.permitted
    assert r.verdict == PermitVerdict.NOT_PERMITTED


def _test_extract_response_value_wired():
    """extract_response_value must be importable from api_adapter."""
    from api_adapter import extract_response_value
    # Basic path traversal
    data = {"content": [{"logprob": -0.023}]}
    val = extract_response_value(data, ["content", "0", "logprob"])
    assert val == -0.023


def _test_root_hex_is_64_chars():
    from merkle_permit_set import MerklePermitSet
    ps = MerklePermitSet.labyrinth_default()
    assert len(ps.root) == 64, f"Root must be 64 hex chars, got {len(ps.root)}"


def _test_sigma_anchor_channels_all_pass():
    from bounded_sensor_gate import MultiChannelSensorGate
    gate = MultiChannelSensorGate.for_sigma_anchors()
    results = gate.accept_all({
        "tau": 0.85, "chi": 0.10, "drift": 0.05,
        "betti_1": 0.02, "confidence": 0.91,
    })
    for ch, r in results.items():
        assert r.accepted, f"Channel {ch} rejected: {r.reason}"


def _test_safe_median_aggregation():
    from bounded_sensor_gate import safe_median_float, safe_median_int
    # Float median
    assert safe_median_float([0.80, 0.83, 0.85, 0.90, 0.91]) == 0.85
    # Int overflow-safe median
    assert safe_median_int([1, 2, 3, 4, 5]) == 3
    # Empty
    assert safe_median_float([]) is None
    assert safe_median_int([]) is None


def _test_merkle_root_stable_across_sessions():
    """Same permit set must always produce the same root."""
    from merkle_permit_set import MerklePermitSet
    root1 = MerklePermitSet.labyrinth_default().root
    root2 = MerklePermitSet.labyrinth_default().root
    root3 = MerklePermitSet.labyrinth_default().root
    assert root1 == root2 == root3, "Merkle root must be deterministic"
