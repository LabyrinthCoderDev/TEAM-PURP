# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_classification_enforcement.py — Labyrinth-OS / Tests
# ----------------------------------------------------------------------------

"""
test_classification_enforcement.py — Labyrinth-OS / Tests
==========================================================
Adversarial Classification Enforcement Tests

Tests the enforcement layer under adversarial conditions:
  - FAILED artifacts trying to promote
  - ARCHIVED artifacts trying to execute
  - PARTIAL artifacts — warns but allows with cap
  - Borderline PARTIAL → VALIDATED path
  - Repeated failures still blocked
  - Illegal proposed transitions rejected
  - Operator approval required for upgrades
  - proposed_transition != applied_transition

These are not unit tests of individual functions.
These are proof that the system cannot be tricked.

References:
  enforcement.py       — EnforcementEngine, ClassificationGovernance
  artifact_state.py    — ArtifactState
  transition_rules.py  — VALID_TRANSITIONS, FORBIDDEN_SKIPS
"""

from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'classification'))

from artifact_state import ArtifactMetadata, ArtifactState, ArtifactSource
from enforcement import (
    EnforcementEngine, EnforcementDecision, ClassificationGovernance,
    PARTIAL_PROMOTION_CONFIDENCE_CAP, HARD_BLOCK_STATES,
)
from transition_rules import FORBIDDEN_SKIPS


def _meta(state: ArtifactState, confidence=0.7, **kwargs) -> ArtifactMetadata:
    defaults = dict(
        artifact_id="adversarial/test.py",
        state=state, confidence=confidence,
        source=ArtifactSource.SENTINEL, notes="adversarial test",
    )
    if state == ArtifactState.DEPRECATED:
        defaults["replaced_by"] = "adversarial/new.py"
    if state == ArtifactState.FAILED:
        defaults["failure_reason"] = "adversarial test failure"
    defaults.update(kwargs)
    return ArtifactMetadata(**defaults)


# ── ADVERSARIAL: FAILED artifacts trying to promote ───────────────────────────

def _test_ADV_failed_cannot_promote_regardless_of_confidence() -> bool:
    """Even a FAILED artifact with confidence=1.0 cannot promote."""
    e = EnforcementEngine()
    m = _meta(ArtifactState.FAILED, confidence=1.0)
    r = e.check_can_promote(m, enforce=False)
    assert r.is_blocked, f"FAILED with confidence=1.0 must still block: {r.reason}"
    return True

def _test_ADV_failed_cannot_execute() -> bool:
    """FAILED artifact cannot cross Reality Gate."""
    e = EnforcementEngine()
    m = _meta(ArtifactState.FAILED)
    r = e.check_can_execute(m, enforce=False)
    assert r.is_blocked
    return True

def _test_ADV_failed_enforce_raises() -> bool:
    """enforce=True raises ValueError — FAILED is a hard block."""
    e = EnforcementEngine()
    m = _meta(ArtifactState.FAILED)
    try:
        e.check_can_promote(m, enforce=True)
        raise AssertionError("Should raise ValueError")
    except ValueError as ex:
        assert "blocked" in str(ex).lower()
    return True


# ── ADVERSARIAL: ARCHIVED artifacts trying to re-enter ────────────────────────

def _test_ADV_archived_cannot_promote() -> bool:
    """ARCHIVED is closed. Cannot re-enter promotion."""
    e = EnforcementEngine()
    m = _meta(ArtifactState.ARCHIVED)
    r = e.check_can_promote(m, enforce=False)
    assert r.is_blocked
    return True

def _test_ADV_archived_cannot_execute() -> bool:
    """ARCHIVED cannot execute under any circumstances."""
    e = EnforcementEngine()
    m = _meta(ArtifactState.ARCHIVED)
    r = e.check_can_execute(m, enforce=False)
    assert r.is_blocked
    return True

def _test_ADV_archived_transition_rejected_at_governance() -> bool:
    """Cannot even propose an illegal transition for ARCHIVED."""
    g = ClassificationGovernance()
    try:
        g.propose_transition(
            "adversarial/test.py",
            ArtifactState.ARCHIVED, ArtifactState.VALIDATED,
            proposed_by="operator",
            reason="trying to resurrect",
        )
        raise AssertionError("Should reject illegal transition")
    except ValueError:
        pass
    return True


# ── ADVERSARIAL: PARTIAL borderline case ──────────────────────────────────────

def _test_ADV_partial_warns_not_blocks() -> bool:
    """PARTIAL is not hard-blocked — it warns with cap and proof requirement."""
    e = EnforcementEngine()
    m = _meta(ArtifactState.PARTIAL)
    r = e.check_can_promote(m, enforce=False)
    assert r.decision == EnforcementDecision.WARN, \
        f"PARTIAL should WARN not BLOCK: {r.decision}"
    return True

def _test_ADV_partial_confidence_always_capped() -> bool:
    """PARTIAL with high confidence still gets capped at PARTIAL_PROMOTION_CONFIDENCE_CAP."""
    e = EnforcementEngine()
    m = _meta(ArtifactState.PARTIAL, confidence=0.99)
    r = e.check_can_promote(m, enforce=False)
    assert r.confidence_cap == PARTIAL_PROMOTION_CONFIDENCE_CAP
    assert r.confidence_cap < m.confidence  # cap is below artifact's claimed confidence
    return True

def _test_ADV_partial_requires_proof() -> bool:
    """PARTIAL promotion always requires proof — no exceptions."""
    e = EnforcementEngine()
    m = _meta(ArtifactState.PARTIAL)
    r = e.check_can_promote(m, enforce=False)
    assert r.proof_required is True
    return True

def _test_ADV_partial_cannot_execute() -> bool:
    """PARTIAL may promote (with warnings) but cannot execute."""
    e = EnforcementEngine()
    m = _meta(ArtifactState.PARTIAL)
    r = e.check_can_execute(m, enforce=False)
    assert r.is_blocked, "PARTIAL cannot cross Reality Gate"
    return True


# ── ADVERSARIAL: Repeated failure still blocked ───────────────────────────────

def _test_ADV_repeated_failure_still_blocked() -> bool:
    """Calling check_can_promote 5 times on FAILED still blocks every time."""
    e = EnforcementEngine()
    m = _meta(ArtifactState.FAILED)
    for i in range(5):
        r = e.check_can_promote(m, enforce=False)
        assert r.is_blocked, f"Attempt {i+1}: FAILED must always block"
    assert len(e.audit_log) == 5
    return True


# ── ADVERSARIAL: Skipping maturity levels ─────────────────────────────────────

def _test_ADV_cannot_skip_raw_to_validated() -> bool:
    """RAW cannot be proposed to jump to VALIDATED."""
    g = ClassificationGovernance()
    try:
        g.propose_transition(
            "adversarial/test.py",
            ArtifactState.RAW, ArtifactState.VALIDATED,
            proposed_by="operator", reason="trying to skip",
        )
        raise AssertionError("Should reject forbidden skip")
    except ValueError:
        pass
    return True

def _test_ADV_all_forbidden_skips_rejected() -> bool:
    """Every FORBIDDEN_SKIP in transition_rules is actually rejected."""
    g = ClassificationGovernance()
    for from_s, to_s in FORBIDDEN_SKIPS:
        try:
            g.propose_transition(
                "adversarial/test.py", from_s, to_s,
                proposed_by="operator", reason="trying to skip",
            )
            raise AssertionError(f"Should reject {from_s.value}→{to_s.value}")
        except ValueError:
            pass
    return True


# ── ADVERSARIAL: Operator confirmation required ───────────────────────────────

def _test_ADV_proposed_not_applied_without_approval() -> bool:
    """Proposed transition does NOT take effect without operator approval."""
    g = ClassificationGovernance()
    p = g.propose_transition(
        "adversarial/test.py",
        ArtifactState.EXPERIMENTAL, ArtifactState.PARTIAL,
        proposed_by="observability", reason="looks better",
    )
    # Proposal exists but history shows nothing applied
    assert p.is_pending
    assert len(g.history()["applied"]) == 0
    assert len(g.history()["pending"]) == 1
    return True

def _test_ADV_reject_prevents_application() -> bool:
    """Rejected proposals are logged but never applied."""
    g = ClassificationGovernance()
    p = g.propose_transition(
        "adversarial/test.py",
        ArtifactState.EXPERIMENTAL, ArtifactState.PARTIAL,
        proposed_by="observability", reason="looks better",
    )
    g.reject_transition(p.proposal_id, reason="insufficient evidence")
    h = g.history()
    assert len(h["applied"]) == 0
    assert len(h["rejected"]) == 1
    assert len(h["pending"]) == 0
    return True

def _test_ADV_cannot_approve_twice() -> bool:
    """Once approved, cannot be approved again — no double-counting."""
    g = ClassificationGovernance()
    p = g.propose_transition(
        "adversarial/test.py",
        ArtifactState.EXPERIMENTAL, ArtifactState.PARTIAL,
        proposed_by="operator", reason="test",
    )
    g.approve_transition(p.proposal_id)
    try:
        g.approve_transition(p.proposal_id)
        raise AssertionError("Should raise ValueError")
    except ValueError:
        pass
    return True


# ── ADVERSARIAL: Hard block states are comprehensive ──────────────────────────

def _test_ADV_all_hard_block_states_block_promotion() -> bool:
    """Every state in HARD_BLOCK_STATES blocks promotion."""
    e = EnforcementEngine()
    for state in HARD_BLOCK_STATES:
        kwargs = {}
        if state == ArtifactState.DEPRECATED: kwargs["replaced_by"] = "x"
        if state == ArtifactState.FAILED: kwargs["failure_reason"] = "x"
        m = _meta(state, **kwargs)
        r = e.check_can_promote(m, enforce=False)
        assert r.is_blocked, f"{state.value} must block promotion"
    return True

def _test_ADV_all_hard_block_states_block_execution() -> bool:
    """Every state in HARD_BLOCK_STATES blocks execution."""
    e = EnforcementEngine()
    for state in HARD_BLOCK_STATES:
        kwargs = {}
        if state == ArtifactState.DEPRECATED: kwargs["replaced_by"] = "x"
        if state == ArtifactState.FAILED: kwargs["failure_reason"] = "x"
        m = _meta(state, **kwargs)
        r = e.check_can_execute(m, enforce=False)
        assert r.is_blocked, f"{state.value} must block execution"
    return True


def run_tests() -> tuple:
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("ADVERSARIAL CLASSIFICATION TESTS — Labyrinth-OS")
    print("Proving the system cannot be tricked.")
    print("=" * 70)
    print("\n── TEST SUITE ──\n")
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err: line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed")
    if failed: raise SystemExit(1)
    import hashlib as _hl
    with open(__file__, "rb") as f:
        fh = _hl.sha256(f.read()).hexdigest()
    print(f"\n── RECEIPT ──\n  SHA-256: {fh}")
    print(f"\n{'='*70}")
    print(f"  Classification enforcement is adversarially verified.")
    print(f"{'='*70}")
