# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_registry_and_sync.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
test_registry_and_sync.py — Labyrinth-OS
==========================================
Tests for COMPONENT_REGISTRY.json and scripts/sync_truth.py.
"""
import json, sys, os
root = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(root, 'scripts'))
sys.path.insert(0, os.path.join(root, 'steward'))
sys.path.insert(0, root)


def run_tests():
    passed = failed = 0
    tests = [
        _test_registry_json_valid,
        _test_registry_all_files_exist,
        _test_registry_rust_crates_valid,
        _test_registry_no_unknown_status,
        _test_equivalence_table_complete,
        _test_deferred_have_gates,
        _test_sync_truth_importable,
        _test_sync_truth_passes,
        _test_sync_registry_loads,
        _test_sync_report_loads,
    ]
    for fn in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {fn.__name__}: {e}")
    return passed, failed, []


def _test_registry_json_valid():
    reg = json.loads(open(os.path.join(root, 'COMPONENT_REGISTRY.json')).read())
    assert "components" in reg
    assert "deferred_components" in reg
    assert "python_rust_equivalence" in reg
    assert len(reg["components"]) >= 20


def _test_registry_all_files_exist():
    reg = json.loads(open(os.path.join(root, 'COMPONENT_REGISTRY.json')).read())
    for comp in reg["components"]:
        f = os.path.join(root, comp["file"])
        if not comp["file"].endswith(".toml"):
            assert os.path.exists(f), f"Missing: {comp['file']}"


def _test_registry_rust_crates_valid():
    import pathlib
    reg = json.loads(open(os.path.join(root, 'COMPONENT_REGISTRY.json')).read())
    crates = {p.parent.name for p in pathlib.Path(root).rglob('crates/*/Cargo.toml')
              if 'crates' in str(p)}
    for e in reg["python_rust_equivalence"]:
        if e["rust"]:
            assert e["rust"] in crates, f"Rust crate not found: {e['rust']}"


def _test_registry_no_unknown_status():
    reg = json.loads(open(os.path.join(root, 'COMPONENT_REGISTRY.json')).read())
    valid_statuses = {"wired", "partial", "deferred", "experimental"}
    for comp in reg["components"]:
        assert comp["status"] in valid_statuses, \
            f"{comp['id']} has unknown status: {comp['status']}"


def _test_equivalence_table_complete():
    reg = json.loads(open(os.path.join(root, 'COMPONENT_REGISTRY.json')).read())
    assert len(reg["python_rust_equivalence"]) >= 20


def _test_deferred_have_gates():
    reg = json.loads(open(os.path.join(root, 'COMPONENT_REGISTRY.json')).read())
    # Deferred components with gates should list at least one ACP-1 ID
    for d in reg["deferred_components"]:
        gates = d.get("gates_on", [])
        # gates_on can be empty (e.g., soterion_headers) — that's OK
        if gates:
            assert all(g.startswith("A") for g in gates), \
                f"Deferred {d['id']} has invalid gate: {gates}"


def _test_sync_truth_importable():
    import sync_truth
    assert hasattr(sync_truth, 'run_sync')
    assert hasattr(sync_truth, 'run_tests')


def _test_sync_truth_passes():
    import sync_truth
    p_root = sync_truth._find_root()
    result = sync_truth.run_sync(p_root)
    assert len(result.errors) == 0, f"Sync errors: {result.errors}"


def _test_sync_registry_loads():
    import sync_truth
    p_root = sync_truth._find_root()
    data = sync_truth._load_registry(p_root)
    assert data is not None
    assert len(data["components"]) >= 20


def _test_sync_report_loads():
    import sync_truth
    p_root = sync_truth._find_root()
    data = sync_truth._load_system_report(p_root)
    assert data is not None
    assert data.get("test_status", {}).get("python_pass", 0) >= 1000
