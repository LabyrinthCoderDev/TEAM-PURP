# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_input_provenance.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
test_input_provenance.py — Labyrinth-OS
=========================================
Tests for epistemic/provenance/input_provenance.py
and its wiring into the adversarial suite.
"""
import sys, os
root = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(root, 'epistemic', 'provenance'))
sys.path.insert(0, root)


def run_tests():
    from input_provenance import run_tests as _internal
    passed, failed, _ = _internal()

    extra = [
        _test_polite_lie_detected_via_module,
        _test_declared_chain_passes,
        _test_ignition_entry_has_provenance_fields,
        _test_provenance_in_ignition_to_dict,
        _test_adversarial_suite_still_passes,
        _test_replay_provenance_link,
        _test_model_lineage_hash_in_ignition,
        _test_ic3_doc_exists,
    ]
    for fn in extra:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {fn.__name__}: {e}")
    return passed, failed, []


def _test_polite_lie_detected_via_module():
    from input_provenance import evaluate_provenance
    result = evaluate_provenance("unverified", "abc123def456aabb")
    assert result.is_suspect
    assert any("IC2_UNVERIFIED" in r for r in result.reasons)


def _test_declared_chain_passes():
    from input_provenance import ProvenanceChain, compute_model_fingerprint, evaluate_provenance
    chain = ProvenanceChain()
    chain.add_link("provider", "anthropic")
    chain.add_link("model", "claude-3-5")
    chain.add_link("session", "sess-001")
    fp = compute_model_fingerprint("anthropic", "claude-3-5", "sess-001")
    result = evaluate_provenance(chain.to_json(), fp)
    assert not result.is_suspect, f"Clean chain flagged: {result.reasons}"
    assert result.recommendation == "ALLOW"


def _test_ignition_entry_has_provenance_fields():
    sys.path.insert(0, os.path.join(root, 'runtime'))
    import inspect
    # Check ignition.py defines these fields
    with open(os.path.join(root, 'runtime', 'ignition.py')) as f:
        content = f.read()
    assert 'model_fingerprint' in content
    assert 'provenance_chain' in content
    assert '_provenance_chain' in content   # wired in _run_trial


def _test_provenance_in_ignition_to_dict():
    """model_fingerprint and provenance_chain must appear in to_dict()."""
    with open(os.path.join(root, 'runtime', 'ignition.py')) as f:
        content = f.read()
    # Find to_dict method of IgnitionEntry — use full closing } as end marker
    idx = content.find('def to_dict')
    assert idx > 0
    # Find the closing } of to_dict — look for the return block end
    end_idx = content.find('\n\n\n', idx)
    if end_idx == -1:
        end_idx = idx + 1000  # generous fallback
    to_dict_section = content[idx:end_idx]
    assert 'model_fingerprint' in to_dict_section, \
        "to_dict must include model_fingerprint"
    assert 'provenance_chain' in to_dict_section, \
        "to_dict must include provenance_chain"


def _test_adversarial_suite_still_passes():
    """A020 must still pass after wiring input_provenance."""
    sys.path.insert(0, os.path.join(root, 'execution', 'adversarial'))
    sys.path.insert(0, os.path.join(root, 'execution', 'pre_cgir_gate'))
    for mod in list(sys.modules.keys()):
        if 'adversarial' in mod: del sys.modules[mod]
    import adversarial_load_suite as als
    result = als.run_adversarial_suite(include_clean=True)
    assert result.a020_passed, \
        f"A020 failed after provenance wiring: fp={result.fp_rate:.3f}"
    assert result.fp_rate < 0.05


def _test_replay_provenance_link():
    sys.path.insert(0, os.path.join(root, 'epistemic', 'provenance'))
    from input_provenance import ReplayProvenanceLink, ProvenanceLevel
    import time
    link = ReplayProvenanceLink(
        role="replay",
        identity="sess-001",
        timestamp=time.time(),
        level=ProvenanceLevel.DECLARED,
        replay_from_session="original-sess-001",
        replay_from_seq=42,
        replay_reason="audit",
    )
    d = link.to_dict()
    assert d["is_replay"] is True
    assert d["replay_from_session"] == "original-sess-001"
    assert d["replay_from_seq"] == 42


def _test_model_lineage_hash_in_ignition():
    content = open(os.path.join(root, 'runtime', 'ignition.py')).read()
    assert 'model_lineage_hash' in content
    # Check it's in to_dict
    idx = content.find('def to_dict')
    end = content.find('\n\n\n', idx)
    section = content[idx:end if end > 0 else idx+1000]
    assert 'model_lineage_hash' in section, "model_lineage_hash must be in to_dict"


def _test_ic3_doc_exists():
    doc = os.path.join(root, 'docs', 'INPUT_CONSTITUTION_IC3.md')
    assert os.path.exists(doc), "IC-3 architecture doc must exist"
    content = open(doc).read()
    assert 'ReplayProvenanceLink' in content
    assert 'model_lineage_hash' in content
