# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_vc_export.py — Labyrinth-OS / 777b Integration Tests
# ----------------------------------------------------------------------------

"""
test_vc_export.py — Labyrinth-OS / 777b Integration Tests
==========================================================
Tests for vc_export.py — W3C Verifiable Credential export.
No Z3 dependency. Runs in all environments.

Tests:
  - create_vc produces valid W3C VC structure
  - gate_crossing_to_vc, promotion_receipt_to_vc, failed_proposal_to_vc
  - VC id determinism (same content = same hash)
  - Required fields present
  - labyrinthVersion field present
  - export_vc_to_json writes a file
"""
from __future__ import annotations

import datetime
import hashlib
import json
import os
import sys
import tempfile

# path wiring handled by run_all.py
from vc_export import (
    create_vc,
    export_vc_to_json,
    gate_crossing_to_vc,
    promotion_receipt_to_vc,
    failed_proposal_to_vc,
)

from dataclasses import dataclass

# ── MOCK TYPES ────────────────────────────────────────────────────────────────

@dataclass
class MockGatePassage:
    proposal_id: str = "test-gate-001"
    confidence: float = 0.95
    tau: float = 0.83
    chi: float = 0.11
    drift: float = 0.08
    betti: float = 0.04
    verdict: str = "ALLOW"
    timestamp: str = ""
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()

@dataclass
class MockPromotionReceipt:
    proposal_id: str = "test-promo-001"
    label: str = "TRUTH"
    confidence: float = 0.97
    approved: bool = True
    timestamp: str = ""
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()

@dataclass
class MockFailedProposal:
    proposal_id: str = "test-fail-001"
    reason: str = "TAU_BELOW_FLOOR"
    confidence: float = 0.71
    timestamp: str = ""
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()

_REQUIRED_FIELDS = ['@context', 'id', 'type', 'issuer', 'validFrom', 'credentialSubject']

# ── TESTS ─────────────────────────────────────────────────────────────────────

def _test_gate_crossing_vc_has_required_fields():
    vc = gate_crossing_to_vc(MockGatePassage())
    for field in _REQUIRED_FIELDS:
        assert field in vc, f"Missing field: {field}"

def _test_promotion_receipt_vc_has_required_fields():
    vc = promotion_receipt_to_vc(MockPromotionReceipt())
    for field in _REQUIRED_FIELDS:
        assert field in vc, f"Missing field: {field}"

def _test_failed_proposal_vc_has_required_fields():
    vc = failed_proposal_to_vc(MockFailedProposal())
    for field in _REQUIRED_FIELDS:
        assert field in vc, f"Missing field: {field}"

def _test_vc_type_is_list_with_verifiable_credential():
    vc = gate_crossing_to_vc(MockGatePassage())
    assert isinstance(vc['type'], list)
    assert 'VerifiableCredential' in vc['type']

def _test_vc_id_starts_with_urn():
    vc = gate_crossing_to_vc(MockGatePassage())
    assert vc['id'].startswith('urn:labyrinth:receipt:')

def _test_vc_id_deterministic_same_content():
    p1 = MockGatePassage(proposal_id="det-test", confidence=0.95,
                         tau=0.83, chi=0.11, drift=0.08, betti=0.04,
                         verdict="ALLOW", timestamp="2026-01-01T00:00:00+00:00")
    p2 = MockGatePassage(proposal_id="det-test", confidence=0.95,
                         tau=0.83, chi=0.11, drift=0.08, betti=0.04,
                         verdict="ALLOW", timestamp="2026-01-01T00:00:00+00:00")
    vc1 = gate_crossing_to_vc(p1)
    vc2 = gate_crossing_to_vc(p2)
    assert vc1['id'] == vc2['id'], "Same content must produce same VC id"

def _test_vc_credential_subject_contains_proposal_id():
    passage = MockGatePassage(proposal_id="subj-test-001")
    vc = gate_crossing_to_vc(passage)
    assert vc['credentialSubject']['proposal_id'] == 'subj-test-001'

def _test_vc_contains_labyrinth_version():
    vc = gate_crossing_to_vc(MockGatePassage())
    assert 'labyrinthVersion' in vc['credentialSubject']

def _test_vc_issuer_is_labyrinth_domain():
    vc = gate_crossing_to_vc(MockGatePassage())
    assert 'labyrinth-os.org' in vc['issuer']

def _test_export_vc_to_json_writes_file():
    vc = gate_crossing_to_vc(MockGatePassage())
    with tempfile.TemporaryDirectory() as tmpdir:
        outpath = os.path.join(tmpdir, 'test_vc.json')
        result = export_vc_to_json(vc, outpath)
        assert os.path.exists(outpath)
        with open(outpath) as f:
            loaded = json.load(f)
        assert loaded['id'] == vc['id']

def _test_failed_proposal_vc_type_correct():
    vc = failed_proposal_to_vc(MockFailedProposal())
    assert any('Failed' in t or 'failed' in t.lower() for t in vc['type']) or \
           'LabyrinthOS' in str(vc['type'])

def _test_promotion_receipt_vc_type_correct():
    vc = promotion_receipt_to_vc(MockPromotionReceipt())
    assert any('Promotion' in t or 'promotion' in t.lower() for t in vc['type']) or \
           'LabyrinthOS' in str(vc['type'])

def _test_1000_call_stress_no_errors():
    passage = MockGatePassage()
    for _ in range(1000):
        vc = gate_crossing_to_vc(passage)
        assert '@context' in vc

# ── RUNNER ────────────────────────────────────────────────────────────────────

def run_tests():
    tests = sorted(
        [(name, obj) for name, obj in globals().items()
         if name.startswith('_test_') and callable(obj)],
        key=lambda x: x[0],
    )
    passed, failed = 0, 0
    for name, fn in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []


if __name__ == '__main__':
    p, f, _ = run_tests()
    print(f"vc_export tests: {p} passed, {f} failed")
