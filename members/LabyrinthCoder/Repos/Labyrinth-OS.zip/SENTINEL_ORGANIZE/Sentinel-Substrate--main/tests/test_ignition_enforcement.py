# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_ignition_enforcement.py — Labyrinth-OS / Tests
# ----------------------------------------------------------------------------

"""
test_ignition_enforcement.py — Labyrinth-OS / Tests
=====================================================
Proves Ignition Halts Before Trials When Mandatory Stages Fail

These tests prove the central invariant:
  If violations are printed but trials continue → enforcement is not real.

After this pass: violations HALT execution. Trials do not start.

Tests prove:
  1. archive_ignition() fail → SystemError before trial 1
  2. promote_ignition() fail → SystemError before trial 1
  3. reality_gate_admission() fail → SystemError before trial 1
  4. assert_can_enter_cgir() fail → SystemError before trial 1
  5. All three passing → trials run (positive case)
  6. Missing model → promotion fails → halt
  7. Archive timestamp must precede promotion timestamp

DOCTRINE:
  Visibility without control is not enforcement.
  If trials run while violations exist, the system is not hardened.

References:
  ignition.py           — IgnitionSession.run()
  pipeline_wire.py      — PipelineTrace, assert_can_enter_cgir()
  KNOWN_GAPS.md         — GAP 1 (now closed: wiring complete)
  ARCHITECTURE.md       — mandatory pipeline
"""

from __future__ import annotations

import json
import os
import sys
import time
from unittest.mock import MagicMock, patch

# Path setup
CGIR_DIR  = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
LANE1_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'lane1'))

for d in [CGIR_DIR, LANE1_DIR]:
    if d not in sys.path:
        sys.path.insert(0, d)

from ignition import IgnitionSession
from api_adapter import Provider


def _make_session(provider=Provider.MOCK, model="mock-model-v1", trials=1):
    """Create a minimal IgnitionSession for testing."""
    from api_adapter import make_adapter
    adapter = make_adapter(
        backend=provider.value,
        model=model,
        api_key="mock-key",
    )
    return IgnitionSession(adapter=adapter, n_trials=trials, verbose=False)


# ── TEST 1: archive_ignition failure → halt before trial ─────────────────────

def _test_archive_fail_halts_before_trial() -> bool:
    """
    If archive_ignition() fails, SystemError is raised.
    Trials never start. _entries remains empty.
    """
    session = _make_session()

    # Patch archive to fail
    def bad_archive(self):
        return {"ok": False, "detail": "Simulated archive failure"}

    from ignition import IgnitionSession as IS
    original = IS._archive_ignition
    IS._archive_ignition = bad_archive

    try:
        session.run()
        raise AssertionError("Should have raised SystemError")
    except SystemError as e:
        assert "IGNITION HALTED" in str(e), f"Expected IGNITION HALTED: {e}"
        assert "archive_ignition" in str(e), f"Expected archive_ignition in msg: {e}"
        assert len(session._entries) == 0, \
            f"Trials must not have run. Got {len(session._entries)} entries."
    finally:
        IS._archive_ignition = original

    return True


# ── TEST 2: promote_ignition failure → halt before trial ─────────────────────

def _test_promote_fail_halts_before_trial() -> bool:
    """
    If promote_ignition() fails, SystemError is raised.
    Trials never start.
    """
    session = _make_session()

    def bad_promote(self):
        return {"ok": False, "detail": "Simulated promotion failure"}

    from ignition import IgnitionSession as IS
    original = IS._promote_ignition
    IS._promote_ignition = bad_promote

    try:
        session.run()
        raise AssertionError("Should have raised SystemError")
    except SystemError as e:
        assert "IGNITION HALTED" in str(e)
        assert "promote_ignition" in str(e)
        assert len(session._entries) == 0
    finally:
        IS._promote_ignition = original

    return True


# ── TEST 3: reality_gate_admission failure → halt before trial ───────────────

def _test_gate_fail_halts_before_trial() -> bool:
    """
    If reality_gate_admission() fails, SystemError is raised.
    Trials never start.
    """
    session = _make_session()

    def bad_gate(self):
        return {"ok": False, "detail": "Simulated gate rejection"}

    from ignition import IgnitionSession as IS
    original = IS._reality_gate_admission
    IS._reality_gate_admission = bad_gate

    try:
        session.run()
        raise AssertionError("Should have raised SystemError")
    except SystemError as e:
        assert "IGNITION HALTED" in str(e)
        assert "reality_gate_admission" in str(e)
        assert len(session._entries) == 0
    finally:
        IS._reality_gate_admission = original

    return True


# ── TEST 4: assert_can_enter_cgir failure → halt before trial ────────────────

def _test_assert_can_enter_cgir_fail_halts_before_trial() -> bool:
    """
    If archive/promote/gate pass but assert_can_enter_cgir() still fails
    (e.g. ordering violation), SystemError is raised. Trials never start.
    """
    session = _make_session()

    # Patch archive and promote to pass but inject timestamp ordering violation
    def ok_archive(self):
        return {"ok": True, "detail": "Archive OK"}

    def ok_promote(self):
        return {"ok": True, "detail": "Promote OK"}

    def ok_gate(self):
        return {"ok": True, "detail": "Gate OK"}

    def bad_assert(self):
        raise SystemError("PIPELINE VIOLATION — ordering check failed (test)")

    from ignition import IgnitionSession as IS
    orig_arch  = IS._archive_ignition
    orig_prom  = IS._promote_ignition
    orig_gate  = IS._reality_gate_admission
    orig_assert_method = None

    from pipeline_wire import PipelineTrace
    orig_assert = PipelineTrace.assert_can_enter_cgir

    def failing_assert(self_trace):
        raise SystemError("PIPELINE VIOLATION — injected for test")

    IS._archive_ignition = ok_archive
    IS._promote_ignition = ok_promote
    IS._reality_gate_admission = ok_gate
    PipelineTrace.assert_can_enter_cgir = failing_assert

    try:
        session.run()
        raise AssertionError("Should have raised SystemError")
    except SystemError as e:
        assert "PIPELINE VIOLATION" in str(e)
        assert len(session._entries) == 0
    finally:
        IS._archive_ignition        = orig_arch
        IS._promote_ignition        = orig_prom
        IS._reality_gate_admission  = orig_gate
        PipelineTrace.assert_can_enter_cgir = orig_assert

    return True


# ── TEST 5: All passing → trials run (positive case) ─────────────────────────

def _test_all_stages_passing_trials_run() -> bool:
    """
    When all three stages pass and assert_can_enter_cgir() passes,
    trials run normally.
    """
    session = _make_session(trials=2)
    result = session.run()

    assert result["trials_success"] == 2, \
        f"Expected 2 successful trials, got {result['trials_success']}"
    assert len(session._entries) == 2, \
        f"Expected 2 entries, got {len(session._entries)}"
    assert result.get("option_b_violations") == [], \
        f"Expected empty violations, got {result.get('option_b_violations')}"
    return True


# ── TEST 6: Empty model → promotion fails → halt ─────────────────────────────

def _test_empty_model_promote_fails() -> bool:
    """
    promote_ignition() checks that model is non-empty.
    Test by calling _promote_ignition with a fake adapter that has empty model.
    """
    session = _make_session()

    # Create a fake adapter with empty model
    class FakeAdapter:
        provider = session._adapter.provider
        model    = ""

    # Inject archive_complete so promote can check it
    from pipeline_wire import PipelineTrace, PipelineStage
    session._run_trace = PipelineTrace(input_id="empty_model_test",
                                       labeling_required=False)
    session._run_trace.archive_complete = time.time()

    original_adapter = session._adapter
    session._adapter = FakeAdapter()

    try:
        result = session._promote_ignition()
        assert not result["ok"], f"Should fail with empty model: {result}"
        assert "Model" in result["detail"] or "model" in result["detail"]
    finally:
        session._adapter = original_adapter
    return True


# ── TEST 7: Archive timestamp must precede promotion timestamp ────────────────

def _test_archive_before_promotion_ordering() -> bool:
    """
    reality_gate_admission() checks that archive_complete < promotion_complete.
    If ordering is wrong, gate fails.
    """
    session = _make_session()
    session._run_trace = None  # reset

    from pipeline_wire import PipelineTrace, PipelineStage
    session._run_trace = PipelineTrace(input_id="order_test", labeling_required=False)

    # Set archive_complete AFTER promotion_complete (wrong order)
    session._run_trace.archive_complete    = 10.0
    session._run_trace.promotion_complete  = 5.0   # earlier — wrong

    result = session._reality_gate_admission()
    assert not result["ok"], f"Should fail with wrong ordering: {result}"
    assert "ordering" in result["detail"].lower() or "Timestamp" in result["detail"]
    return True


# ── TEST 8: Trace has no violations after successful run ─────────────────────

def _test_trace_clean_after_successful_run() -> bool:
    """
    After a successful run, option_b_violations is empty.
    The trace has archive, promotion, and gate timestamps set.
    """
    session = _make_session(trials=1)
    result = session.run()

    assert result.get("option_b_violations") == [], \
        f"Expected empty violations after successful run: {result.get('option_b_violations')}"

    trace = session._run_trace
    assert trace is not None
    assert trace.archive_complete is not None,     "archive_complete must be set"
    assert trace.promotion_complete is not None,   "promotion_complete must be set"
    assert trace.reality_gate_pre_cgir is not None,"reality_gate_pre_cgir must be set"

    # Ordering
    assert trace.archive_complete < trace.promotion_complete, \
        "archive must precede promotion"
    assert trace.promotion_complete < trace.reality_gate_pre_cgir, \
        "promotion must precede gate"
    return True


# ── RUNNER ────────────────────────────────────────────────────────────────────


# ── TEST 9: SystemError propagates — not swallowed by run() ──────────────────

def _test_system_error_not_swallowed_by_run() -> bool:
    """
    GPT concern: 'failure is detectable but not guaranteed to prevent execution'
    This test proves SystemError propagates all the way out of run().
    It is not caught, not logged-then-continued, not softened.

    If this test passes: failure is impossible to ignore.
    """
    session = _make_session()

    caught_system_error = False
    ran_any_trials = False

    def bad_archive(self):
        return {"ok": False, "detail": "Forced failure for propagation test"}

    from ignition import IgnitionSession as IS
    orig = IS._archive_ignition
    IS._archive_ignition = bad_archive

    try:
        session.run()
        ran_any_trials = True  # should never reach here
    except SystemError:
        caught_system_error = True
    except Exception as e:
        raise AssertionError(f"Wrong exception type: {type(e).__name__}: {e}")
    finally:
        IS._archive_ignition = orig

    assert caught_system_error, "SystemError must propagate out of run()"
    assert not ran_any_trials, "run() must not return normally on failure"
    assert len(session._entries) == 0, \
        f"No trials must have run. Got {len(session._entries)}"
    return True

def run_tests() -> tuple:
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("IGNITION ENFORCEMENT — Labyrinth-OS")
    print("Proving: if violations exist, trials do not start.")
    print("=" * 70)
    print("\n── TEST SUITE ──\n")
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err: line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed")
    if failed:
        raise SystemExit(1)
    import hashlib as _hl
    with open(__file__, "rb") as f:
        fh = _hl.sha256(f.read()).hexdigest()
    print(f"\n── RECEIPT ──\n  SHA-256: {fh}")
    print(f"\n{'='*70}")
    print(f"  Enforcement proven: violations halt execution.")
    print(f"{'='*70}")
