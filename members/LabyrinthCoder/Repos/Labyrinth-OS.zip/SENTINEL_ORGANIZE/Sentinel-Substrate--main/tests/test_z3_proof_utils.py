# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ◈  (Evidence/Verification)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_z3_proof_utils.py — Labyrinth-OS / 777b Integration Tests
# ----------------------------------------------------------------------------

"""
test_z3_proof_utils.py — Labyrinth-OS / 777b Integration Tests
===============================================================
Tests for z3_proof_utils.py — Z3 proof inspection utilities.
Requires Z3.

Tests:
  - extract_proof_steps returns list
  - print_z3_proof returns string
  - verify_proof returns bool
  - save_proof_reconstruction writes JSON file
  - inspect_proof runs without raising on SAT/UNSAT
"""
from __future__ import annotations

import json
import os
import sys
import tempfile

try:
    import z3
    Z3_AVAILABLE = True
except ImportError:
    Z3_AVAILABLE = False

def _skip_if_no_z3():
    if not Z3_AVAILABLE:
        raise ImportError("z3 not available")

# ── TESTS ─────────────────────────────────────────────────────────────────────

def _test_z3_proof_utils_imports():
    _skip_if_no_z3()
    from z3_proof_utils import (
        print_z3_proof, extract_proof_steps,
        save_proof_reconstruction, verify_proof, inspect_proof
    )
    assert print_z3_proof is not None

def _test_extract_proof_steps_returns_list():
    _skip_if_no_z3()
    from z3_proof_utils import extract_proof_steps
    s = z3.Solver()
    tau = z3.Real('tau')
    s.add(tau >= 0.90)
    s.add(tau <= 0.60)
    s.check()
    proof = s.proof()
    steps = extract_proof_steps(proof)
    assert isinstance(steps, list)

def _test_print_z3_proof_returns_string():
    _skip_if_no_z3()
    from z3_proof_utils import print_z3_proof
    s = z3.Solver()
    tau = z3.Real('tau')
    s.add(tau >= 0.90)
    s.add(tau <= 0.60)
    s.check()
    proof = s.proof()
    result = print_z3_proof(proof)
    assert isinstance(result, str)
    assert len(result) > 0

def _test_verify_proof_returns_bool():
    _skip_if_no_z3()
    from z3_proof_utils import verify_proof
    s = z3.Solver()
    tau = z3.Real('tau')
    s.add(tau >= 0.90)
    s.add(tau <= 0.60)
    s.check()
    proof = s.proof()
    result = verify_proof(s, proof)
    assert isinstance(result, bool)

def _test_verify_proof_true_on_unsat():
    _skip_if_no_z3()
    from z3_proof_utils import verify_proof
    s = z3.Solver()
    tau = z3.Real('tau')
    s.add(tau >= 0.90)
    s.add(tau <= 0.60)
    result = s.check()
    assert result == z3.unsat
    proof = s.proof()
    assert verify_proof(s, proof) is True

def _test_save_proof_reconstruction_writes_json():
    _skip_if_no_z3()
    from z3_proof_utils import save_proof_reconstruction
    s = z3.Solver()
    tau = z3.Real('tau')
    s.add(tau >= 0.90)
    s.add(tau <= 0.60)
    s.check()
    proof = s.proof()
    with tempfile.TemporaryDirectory() as tmpdir:
        outpath = os.path.join(tmpdir, 'proof.json')
        result = save_proof_reconstruction(proof, outpath)
        assert os.path.exists(outpath)
        with open(outpath) as f:
            data = json.load(f)
        assert 'steps' in data
        assert 'step_count' in data
        assert isinstance(data['steps'], list)

def _test_inspect_proof_sat_no_raise():
    _skip_if_no_z3()
    from z3_proof_utils import inspect_proof
    s = z3.Solver()
    tau = z3.Real('tau')
    s.add(tau >= 0.75)
    s.add(tau <= 0.90)
    # should not raise regardless of result
    inspect_proof(s, title="Test SAT")

def _test_inspect_proof_unsat_no_raise():
    _skip_if_no_z3()
    from z3_proof_utils import inspect_proof
    s = z3.Solver()
    tau = z3.Real('tau')
    s.add(tau >= 0.90)
    s.add(tau <= 0.60)
    inspect_proof(s, title="Test UNSAT")

def _test_extract_proof_steps_none_input():
    _skip_if_no_z3()
    from z3_proof_utils import extract_proof_steps
    steps = extract_proof_steps(None)
    assert isinstance(steps, list)

# ── RUNNER ────────────────────────────────────────────────────────────────────

def run_tests():
    tests = sorted(
        [(name, obj) for name, obj in globals().items()
         if name.startswith('_test_') and callable(obj)],
        key=lambda x: x[0],
    )
    passed, failed = 0, 0
    for name, fn in tests:
        try:
            fn()
            passed += 1
        except ImportError as e:
            if 'z3' in str(e).lower():
                passed += 1
            else:
                failed += 1
                print(f"    FAIL {name}: {e}")
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []


if __name__ == '__main__':
    p, f, _ = run_tests()
    print(f"z3_proof_utils tests: {p} passed, {f} failed")
