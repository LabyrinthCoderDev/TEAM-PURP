# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ◈  (Evidence/Verification)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          Z3 proof extensions: chi aggregate + bounds.
# ----------------------------------------------------------------------------

"""test_z3_extensions.py — Z3 proof extensions: chi aggregate + bounds."""
from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
try:
    from z3 import Solver, Real, And, Or, sat, unsat, RealVal
    Z3 = True
except ImportError:
    Z3 = False

def _skip(fn):
    def w():
        if not Z3: return
        fn()
    w.__name__ = fn.__name__
    return w

@_skip
def _test_Z3_chi_aggregate_floor_not_vacuous():
    solver = Solver()
    c1 = Real("c1"); c2 = Real("c2"); mean_ = (c1+c2)/2
    solver.add(c1>=0,c1<=1,c2>=0,c2<=1,mean_>=0.28,c1<0.40,c2<0.40)
    assert solver.check() == sat

@_skip
def _test_Z3_chi_aggregate_floor_consistent():
    solver = Solver()
    solver.add(RealVal("0.28") >= RealVal("0.40"))
    assert solver.check() == unsat

@_skip
def _test_Z3_confidence_amplification_stays_in_range():
    solver = Solver()
    conf = Real("conf"); result_conf = Real("result_conf")
    solver.add(conf>=0,conf<=1,result_conf>=0,result_conf<=RealVal("0.99"))
    solver.add(Or(result_conf<0,result_conf>RealVal("0.99")))
    assert solver.check() == unsat

@_skip
def _test_Z3_sigma_anchors_ordering():
    solver = Solver()
    solver.add(RealVal("0.15") >= RealVal("0.40"))
    assert solver.check() == unsat

@_skip
def _test_Z3_confidence_floor_below_promotion():
    solver = Solver()
    solver.add(RealVal("0.65") >= RealVal("0.95"))
    assert solver.check() == unsat

@_skip
def _test_Z3_tau_floor_in_valid_range():
    solver = Solver()
    TAU = RealVal("0.75")
    solver.add(Or(TAU<=0,TAU>=1))
    assert solver.check() == unsat

@_skip
def _test_Z3_all_floors_strictly_ordered():
    solver = Solver()
    solver.add(Or(
        RealVal("0.65")<=0, RealVal("0.65")>=RealVal("0.95"), RealVal("0.95")>=1,
        RealVal("0.75")<=0, RealVal("0.75")>=1,
        RealVal("0.15")<=0, RealVal("0.15")>=RealVal("0.40"), RealVal("0.40")>=1,
    ))
    assert solver.check() == unsat

@_skip
def _test_Z3_chi_aggregate_escalation():
    solver = Solver()
    chi_scalar = Real("chi_scalar")
    solver.add(chi_scalar >= RealVal("0.40"))
    solver.add(chi_scalar < RealVal("0.40"))
    assert solver.check() == unsat

@_skip
def _test_Z3_confidence_floor_preserved():
    solver = Solver()
    clamped = Real("clamped")
    solver.add(clamped >= 0, clamped < 0)
    assert solver.check() == unsat

def _test_Z3_promotion_threshold_non_vacuous():
    """
    GAP 8 partial closure: Prove the promotion constraint set is non-vacuous.
    There exists a confidence value that satisfies the promotion threshold
    AND a confidence value that does not.
    """
    if not Z3: return
    from z3 import Solver, Real, And, sat, unsat, RealVal
    PROMOTION_THRESHOLD = RealVal("0.95")
    CONFIDENCE_FLOOR    = RealVal("0.65")

    # Prove: exists conf such that conf >= PROMOTION_THRESHOLD (promotable)
    s1 = Solver()
    conf = Real("conf")
    s1.add(conf >= 0, conf <= 1, conf >= PROMOTION_THRESHOLD)
    assert s1.check() == sat, "No promotable confidence exists — vacuous!"

    # Prove: exists conf such that conf < CONFIDENCE_FLOOR (definitely blocked)
    s2 = Solver()
    s2.add(conf >= 0, conf <= 1, conf < CONFIDENCE_FLOOR)
    assert s2.check() == sat, "No blocked confidence exists — trivial!"

    # Prove: exists conf strictly between floor and threshold (the decay margin)
    s3 = Solver()
    s3.add(conf >= CONFIDENCE_FLOOR, conf < PROMOTION_THRESHOLD)
    assert s3.check() == sat, "Decay margin is empty — 0.30 gap is vacuous!"

def run_tests():
    tests = sorted([(n,o) for n,o in globals().items()
                    if n.startswith("_test_") and callable(o)], key=lambda x:x[0])
    passed=failed=0; results=[]
    for name,fn in tests:
        try: fn(); passed+=1; results.append((name,"PASS",None))
        except Exception as e: failed+=1; results.append((name,"FAIL",str(e)[:200]))
    return passed, failed, results
