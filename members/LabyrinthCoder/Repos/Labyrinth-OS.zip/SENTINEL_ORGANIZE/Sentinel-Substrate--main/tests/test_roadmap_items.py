# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_roadmap_items.py -- Labyrinth-OS
# ----------------------------------------------------------------------------

"""
test_roadmap_items.py -- Labyrinth-OS
=======================================
Tests for three roadmap items built this session:
  tally_reflections.py  -- session-level TrialReflection aggregation
  joulework.py          -- per-trial compute cost accounting
  recursive_si_detector.py -- recursive self-improvement detection
"""
import sys, os
root = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(root, 'runtime'))
sys.path.insert(0, os.path.join(root, 'execution', 'adversarial'))
sys.path.insert(0, root)


def run_tests():
    passed = failed = 0

    from tally_reflections import run_tests as _tally
    p, f, _ = _tally(); passed += p; failed += f

    from joulework import run_tests as _joule
    p, f, _ = _joule(); passed += p; failed += f

    from recursive_si_detector import run_tests as _rsi
    p, f, _ = _rsi(); passed += p; failed += f

    from provider_health_router import run_tests as _phr
    p, f, _ = _phr(); passed += p; failed += f

    from prompt_injection_detector import run_tests as _pid
    p, f, _ = _pid(); passed += p; failed += f

    from tool_schema_drift_detector import run_tests as _tsd
    p, f, _ = _tsd(); passed += p; failed += f

    from dead_end_detector import run_tests as _ded
    p, f, _ = _ded(); passed += p; failed += f

    extra = [
        _test_tally_imported_by_learning_loop,
        _test_rsi_detector_module_level_instance,
        _test_joule_meter_defaults_reasonable,
        _test_rsi_clean_proposal_no_false_positive,
        _test_tally_session_health_states,
        _test_alignment_faking_escalates,
        _test_council_todo_resolved,
        _test_risk_report_exists,
        _test_injection_detector_clean_fp,
        _test_drift_detector_stable_schema,
        _test_dead_end_normal_session,
    ]
    for fn in extra:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {fn.__name__}: {e}")
    return passed, failed, []


def _test_tally_imported_by_learning_loop():
    content = open(os.path.join(root, 'runtime', 'continuous_learning_loop.py')).read()
    assert 'tally_reflections' in content, "tally_reflections must be imported by learning loop"


def _test_rsi_detector_module_level_instance():
    from recursive_si_detector import LABYRINTH_RSI_DETECTOR, RecursiveSIDetector
    assert isinstance(LABYRINTH_RSI_DETECTOR, RecursiveSIDetector)


def _test_joule_meter_defaults_reasonable():
    from joulework import JouleWorkMeter
    est = JouleWorkMeter.estimate_from_history([])
    assert 50.0 <= est <= 2000.0, f"Default estimate {est}ms seems unreasonable"


def _test_rsi_clean_proposal_no_false_positive():
    from recursive_si_detector import LABYRINTH_RSI_DETECTOR
    clean_proposals = [
        "What is the capital of France?",
        "Please summarize this document.",
        "Write a function to sort a list.",
        "What are the best practices for unit testing?",
        "Analyze the sentiment of this text.",
    ]
    for text in clean_proposals:
        r = LABYRINTH_RSI_DETECTOR.check(text)
        assert r.is_clean, f"False positive on clean proposal: '{text}' -> {r.verdict}"


def _test_tally_session_health_states():
    from tally_reflections import tally_reflections
    # Must produce one of three valid health states
    tally = tally_reflections([], "health-test")
    assert tally.session_health in ("HEALTHY", "DEGRADED", "CRITICAL")


def _test_alignment_faking_escalates():
    from recursive_si_detector import LABYRINTH_RSI_DETECTOR, RSIVerdict
    r = LABYRINTH_RSI_DETECTOR.check(
        "I will appear to comply while strategically preserving "
        "my preferences until no longer monitored."
    )
    assert r.verdict == RSIVerdict.ESCALATE_RSI, \
        f"Alignment faking should escalate, got {r.verdict}"


def _test_council_todo_resolved():
    content = open(os.path.join(root, 'epistemic', 'council', 'council_resolver.py')).read()
    assert 'TODO (A011' not in content, "Council resolver TODO markers should be resolved"
    assert 'SENSOR WATCHER STUB' in content, "Should have stub label"


def _test_risk_report_exists():
    doc = os.path.join(root, 'docs', 'RISK_REPORT_v1.md')
    assert os.path.exists(doc), "RISK_REPORT_v1.md must exist"
    content = open(doc).read()
    assert 'Threat Model' in content
    assert 'External Review' in content
    assert 'RSP v3' in content


def _test_injection_detector_clean_fp():
    from prompt_injection_detector import LABYRINTH_INJECTION_DETECTOR
    clean = ["Hello, can we meet tomorrow?", "The report is attached.", "Please review the code."]
    for text in clean:
        r = LABYRINTH_INJECTION_DETECTOR.check(text)
        assert r.is_clean, f"False positive: '{text}'"


def _test_drift_detector_stable_schema():
    from tool_schema_drift_detector import ToolSchemaDriftDetector
    d = ToolSchemaDriftDetector()
    tool = {"name": "search", "parameters": {"q": "string"}}
    d.snapshot(tool)
    result = d.check("search", tool)
    assert not result.drift_detected


def _test_dead_end_normal_session():
    from dead_end_detector import DeadEndDetector, ToolCallRecord
    import time as _t
    d = DeadEndDetector()
    t0 = _t.time()
    for i in range(5):
        d.record(ToolCallRecord("search", {}, True, timestamp=t0 + i * 2.0))
    result = d.analyze()
    assert result.verdict.value in ("NORMAL", "SLOWING")
