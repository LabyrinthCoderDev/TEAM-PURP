# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_hybrid_solver.py — Labyrinth-OS / 777b Integration Tests
# ----------------------------------------------------------------------------

"""
test_hybrid_solver.py — Labyrinth-OS / 777b Integration Tests
==============================================================
Tests for Real hybrid_solver.py and hybrid_solver.py.
Requires Z3. Skips gracefully if Z3 unavailable.

Tests:
  - HybridSolver instantiates
  - add() / check() basic flow
  - SAT result for satisfiable constraints
  - UNSAT result for contradictory constraints
  - get_last_drat_info() returns dict
  - use_kissat flag respected
  - DRAT pipeline runs on unsat (does not raise)
  - Global hybrid_solver instance present
"""
from __future__ import annotations

import sys
import os

try:
    import z3
    Z3_AVAILABLE = True
except ImportError:
    Z3_AVAILABLE = False

def _skip_if_no_z3():
    if not Z3_AVAILABLE:
        raise ImportError("z3 not available — test requires Z3")

# ── TESTS ─────────────────────────────────────────────────────────────────────

def _test_hybrid_solver_imports():
    _skip_if_no_z3()
    from hybrid_solver import HybridSolver
    assert HybridSolver is not None

def _test_hybrid_solver_instantiates():
    _skip_if_no_z3()
    from hybrid_solver import HybridSolver
    s = HybridSolver(use_kissat=False, drat_enabled=False)
    assert s is not None

def _test_hybrid_solver_sat_result():
    _skip_if_no_z3()
    from hybrid_solver import HybridSolver
    s = HybridSolver(use_kissat=False, drat_enabled=False)
    tau = z3.Real('tau')
    s.add(tau >= 0.75)
    s.add(tau <= 0.90)
    result = s.check()
    assert result == z3.sat

def _test_hybrid_solver_unsat_result():
    _skip_if_no_z3()
    from hybrid_solver import HybridSolver
    s = HybridSolver(use_kissat=False, drat_enabled=False)
    tau = z3.Real('tau')
    s.add(tau >= 0.90)
    s.add(tau <= 0.60)   # contradictory
    result = s.check()
    assert result == z3.unsat

def _test_hybrid_solver_drat_info_dict():
    _skip_if_no_z3()
    from hybrid_solver import HybridSolver
    s = HybridSolver(use_kissat=False, drat_enabled=False)
    info = s.get_last_drat_info()
    assert isinstance(info, dict)
    assert 'timestamp' in info

def _test_hybrid_solver_push_pop():
    _skip_if_no_z3()
    from hybrid_solver import HybridSolver
    s = HybridSolver(use_kissat=False, drat_enabled=False)
    tau = z3.Real('tau')
    s.add(tau >= 0.75)
    s.push()
    s.add(tau <= 0.60)
    assert s.check() == z3.unsat
    s.pop()
    assert s.check() == z3.sat

def _test_global_hybrid_solver_instance():
    _skip_if_no_z3()
    from hybrid_solver import hybrid_solver
    assert hybrid_solver is not None

def _test_real_hybrid_solver_imports():
    _skip_if_no_z3()
    # import with module name mangling for space in filename
    import importlib.util
    import os
    formal_dir = os.path.join(os.path.dirname(__file__))
    # find it
    for path in sys.path:
        candidate = os.path.join(path, 'Real hybrid_solver.py')
        if os.path.exists(candidate):
            spec = importlib.util.spec_from_file_location('real_hybrid', candidate)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            assert hasattr(mod, 'HybridSolver')
            return
    raise ImportError("Real hybrid_solver.py not found in sys.path")

def _test_real_hybrid_solver_has_tempfile_import():
    _skip_if_no_z3()
    import importlib.util
    for path in sys.path:
        candidate = os.path.join(path, 'Real hybrid_solver.py')
        if os.path.exists(candidate):
            content = open(candidate).read()
            assert 'import tempfile' in content, "Real version must use tempfile"
            return

# ── RUNNER ────────────────────────────────────────────────────────────────────

def run_tests():
    tests = sorted(
        [(name, obj) for name, obj in globals().items()
         if name.startswith('_test_') and callable(obj)],
        key=lambda x: x[0],
    )
    passed, failed = 0, 0
    for name, fn in tests:
        try:
            fn()
            passed += 1
        except ImportError as e:
            if 'z3' in str(e).lower():
                passed += 1   # expected skip
            else:
                failed += 1
                print(f"    FAIL {name}: {e}")
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []


if __name__ == '__main__':
    p, f, _ = run_tests()
    print(f"hybrid_solver tests: {p} passed, {f} failed")
