# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          Standard run_tests() adapter for run_all.py.
# ----------------------------------------------------------------------------

# itv_vectors.py — ITV v1 Test Suite
# Runs the five canonical test vectors and prints byte-level receipts.

from acbf_vm import (
    loadi, move, read, write, cjmp, halt,
    request, validate, commit, assert_eq,
    run_trace, encode_trace_log, trace_log_hash,
    encode_payload, payload_hash,
)


# -----------------------------------------------------------------
# ITV_001 — Linear Execution
# -----------------------------------------------------------------
def itv_001():
    code = b"".join([
        loadi(0, 0x1234),
        move(1, 0),
        halt(),
    ])
    return code, {}, {"name": "ITV_001 linear",   "expect_success": True}


# -----------------------------------------------------------------
# ITV_002 — Conditional Branch
# -----------------------------------------------------------------
def itv_002():
    # 0: LOADI r0, 1
    # 4: CJMP  r0, 16       -> taken
    # 8: LOADI r1, 0xFFFF   (dead)
    # 12: HALT (fail path)  (dead)
    # 16: LOADI r2, 0x42
    # 20: HALT
    code = b"".join([
        loadi(0, 1),
        cjmp(0, 16),
        loadi(1, 0xFFFF),
        halt(),
        loadi(2, 0x42),
        halt(),
    ])
    return code, {}, {"name": "ITV_002 branch",   "expect_success": True}


# -----------------------------------------------------------------
# ITV_003 — Memory IO + ASSERT
# -----------------------------------------------------------------
def itv_003():
    code = b"".join([
        loadi(0, 0x00AB),   # r0 = 0xAB
        write(0, 100),      # heap[100] = 0xAB
        read(1, 100),       # r1 = heap[100]
        loadi(2, 0x00AB),   # r2 = 0xAB
        assert_eq(1, 2),    # r1 == r2?
        halt(),
    ])
    return code, {}, {"name": "ITV_003 memory",   "expect_success": True}


# -----------------------------------------------------------------
# ITV_004 — REQUEST / VALIDATE / COMMIT policy-gated path
# -----------------------------------------------------------------
def itv_004():
    payloads = {
        0: (1, {
            "query":   "SELECT * FROM patients",
            "user_id": 42,
            "purpose": "treatment",
        })
    }
    code = b"".join([
        request(0, 1, 0),   # r0 = hi64(ACBF hash), schema=1, idx=0
        validate(),
        commit(),
        halt(),
    ])
    return code, payloads, {"name": "ITV_004 policy", "expect_success": True}


# -----------------------------------------------------------------
# ITV_005 — Invalid Opcode (fail-closed)
# -----------------------------------------------------------------
def itv_005():
    code = bytes([0xFF, 0x00, 0x00, 0x00])   # undefined opcode
    return code, {}, {"name": "ITV_005 invalid", "expect_success": False}


VECTORS = [itv_001, itv_002, itv_003, itv_004, itv_005]


def run_all() -> int:
    print("=" * 72)
    print(" ITV v1 TEST SUITE — reference Python VM")
    print("=" * 72)
    failures = 0
    for fn in VECTORS:
        code, payloads, meta = fn()
        trace = run_trace(code, payloads)
        log   = encode_trace_log(code, trace)
        lhash = trace_log_hash(log)
        ok    = trace.success == meta["expect_success"] and trace.halted
        status = "PASS" if ok else "FAIL"
        if not ok:
            failures += 1
        print(
            f"[{status}] {meta['name']:<22}  "
            f"steps={len(trace.steps):>2}  "
            f"halted={trace.halted}  "
            f"success={trace.success}  "
            f"(expected={meta['expect_success']})"
        )
        print(f"         initial_hash = {trace.initial_state_hash.hex()}")
        print(f"         final_hash   = {trace.final_state_hash.hex()}")
        print(f"         log_sha256   = {lhash}")
        print(f"         log_bytes    = {len(log)}")
        print("-" * 72)

    print()
    print(f" Vectors run: {len(VECTORS)}   failures: {failures}")
    print("=" * 72)

    # Quick sanity: ACBF v1 canonical hash for vector 1 payload
    h = payload_hash(1, {
        "query": "SELECT * FROM patients",
        "user_id": 42,
        "purpose": "treatment",
    }).hex()
    print(f" ACBF vector 1 payload hash: {h}")
    print(f"   spec expected            : "
          f"4b8f4f55c0d80fa97bf8be89a64685bee8b6e661705f7f916719376c5a1f26b5")
    print(f"   match                    : "
          f"{h == '4b8f4f55c0d80fa97bf8be89a64685bee8b6e661705f7f916719376c5a1f26b5'}")

    return failures


if __name__ == "__main__":
    import sys
    sys.exit(run_all())

def run_tests() -> tuple:
    """Standard run_tests() adapter for run_all.py."""
    passed = failed = 0
    results = []

    for fn in [itv_001, itv_002, itv_003, itv_004, itv_005]:
        name = fn.__name__
        try:
            code, mem, meta = fn()
            from acbf_vm import run_trace, encode_trace_log, encode_payload
            trace = run_trace(code, mem)
            if meta.get("expect_success"):
                assert trace.success, f"{name}: expected success, got failure"
            elif meta.get("expect_fail"):
                assert not trace.success, f"{name}: expected failure, got success"
            passed += 1; results.append((name,'PASS',None))
        except Exception as e:
            failed += 1; results.append((name,'FAIL',str(e)))

    return passed, failed, results
