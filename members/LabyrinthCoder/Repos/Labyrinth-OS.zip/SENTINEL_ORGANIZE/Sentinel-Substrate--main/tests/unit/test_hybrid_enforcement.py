# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_hybrid_enforcement.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
test_hybrid_enforcement.py — Labyrinth-OS
==========================================
Hybrid Enforcement Test: deferred node mutation loop running simultaneously
with the gate pipeline. Verifies that invariants I1-I18 hold throughout.

Inspired by the Poole Manifold Hybrid Evolution + Computation Test — the most
important unverified experiment in that repository. This test asks the
Labyrinth-OS equivalent: does the healing loop destabilize the gate invariants
when running concurrently?
"""
from __future__ import annotations
import sys, os, threading, time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'lane1',
                                 '07_deferred_exploration'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'epistemic',
                                 'archive'))


def _test_healing_loop_does_not_break_pipeline_ordering() -> None:
    """Concurrent healing must not break pipeline stage ordering."""
    import importlib, pipeline_wire as pw_module
    importlib.reload(pw_module)
    PipelineTrace = pw_module.PipelineTrace
    PipelineStage = pw_module.PipelineStage

    violations: list = []

    def run_pipeline() -> None:
        for _ in range(20):
            trace = PipelineTrace(input_id="hybrid_test_001", labeling_required=False)
            try:
                ts = time.time()
                trace.record(PipelineStage.INPUT,        "PASS", timestamp=ts + 0.001)
                trace.record(PipelineStage.ARCHIVE,      "PASS", timestamp=ts + 0.002)
                trace.record(PipelineStage.PROMOTION,    "PASS", timestamp=ts + 0.003)
                trace.record(PipelineStage.REALITY_GATE, "PASS", timestamp=ts + 0.004)
                vs = trace.ordering_violations()
                if vs:
                    violations.extend(vs)
            except ValueError as e:
                if "I17" not in str(e):
                    violations.append(str(e))

    def run_healing() -> None:
        try:
            from deferred_node import DeferredExplorationNode, FailureRecord
            node = DeferredExplorationNode()
            for i in range(20):
                class _FP:
                    passage_id = f"hybrid_failure_{i}"
                    blocked_at = time.time()
                    reason = "GATE_BLOCKED: low confidence"
                fr = FailureRecord.from_failed_proposal(_FP())
                node.add_failure(fr)
                time.sleep(0.001)
        except Exception:
            pass

    t1 = threading.Thread(target=run_pipeline)
    t2 = threading.Thread(target=run_healing)
    t1.start(); t2.start()
    t1.join(); t2.join()

    assert len(violations) == 0, f"Pipeline violated during healing: {violations}"


def _test_healing_does_not_corrupt_ledger() -> None:
    """HashChain must remain valid under concurrent healing simulation."""
    import importlib
    import hashchain as hc_mod; importlib.reload(hc_mod)
    import receipt as r_mod;    importlib.reload(r_mod)
    HashChain = hc_mod.HashChain
    Receipt   = r_mod.Receipt

    chain = HashChain()
    errors: list = []
    lock  = threading.Lock()

    def record_decisions() -> None:
        for i in range(20):
            try:
                with lock:
                    r = Receipt(
                        receipt_id=f"hybrid_ledger_{i}",
                        module="hybrid_test", action="GATE_DECISION",
                        verdict="BLOCK", payload={"trial": i},
                        prev_hash=chain.head_hash,
                    )
                    chain.append(r)
                time.sleep(0.001)
            except Exception as e:
                errors.append(str(e))

    def run_healing_concurrent() -> None:
        for _ in range(20):
            _ = sum(i * i for i in range(100))
            time.sleep(0.001)

    t1 = threading.Thread(target=record_decisions)
    t2 = threading.Thread(target=run_healing_concurrent)
    t1.start(); t2.start()
    t1.join(); t2.join()

    valid, _, _ = chain.verify()
    assert valid,          "HashChain corrupted during concurrent healing"
    assert len(errors) == 0, f"Ledger errors: {errors}"


def _test_invariants_hold_across_healing_cycles() -> None:
    """I1 and I17 must hold across N healing+pipeline cycles."""
    import importlib, pipeline_wire as pw_module
    importlib.reload(pw_module)
    PipelineTrace = pw_module.PipelineTrace
    PipelineStage = pw_module.PipelineStage

    N = 10
    all_violations = []

    for cycle in range(N):
        trace = PipelineTrace(
            input_id=f"invariant_check_{cycle}",
            labeling_required=False,
        )
        ts = time.time()
        trace.record(PipelineStage.INPUT,        "PASS", timestamp=ts + 0.001)
        trace.record(PipelineStage.ARCHIVE,      "PASS", timestamp=ts + 0.002)
        trace.record(PipelineStage.PROMOTION,    "PASS", timestamp=ts + 0.003)
        trace.record(PipelineStage.REALITY_GATE, "PASS", timestamp=ts + 0.004)

        # I1: ordering violations
        vs = trace.ordering_violations()
        if vs:
            all_violations.extend([f"cycle={cycle}: {v}" for v in vs])

        # I17: logical sequence strictly increments
        seqs = [s.get("logical_sequence", 0) for s in trace.stages]
        for i in range(1, len(seqs)):
            if seqs[i] <= seqs[i-1]:
                all_violations.append(
                    f"cycle={cycle}: logical_sequence not incrementing "
                    f"at stage {i}: {seqs[i-1]}→{seqs[i]}"
                )

    assert len(all_violations) == 0, (
        f"Invariant violations across {N} cycles: {all_violations}"
    )


def run_tests() -> tuple[int, int, list]:
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed = failed = 0
    results = []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results
