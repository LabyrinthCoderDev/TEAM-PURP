# pipeline_wire.py

The canonical `pipeline_wire.py` lives at the repo root, not in this directory.
A copy previously existed here and was removed to prevent divergence.
`run_all.py` imports it from the cgir working directory.
