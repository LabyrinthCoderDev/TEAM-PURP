# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          Chronicle JSONL+index dedicated suite.
# ----------------------------------------------------------------------------

"""test_chronicle_dedicated.py — Chronicle JSONL+index dedicated suite."""
from __future__ import annotations
import sys, os, threading, tempfile, json, time
sys.path.insert(0, os.path.dirname(__file__))
from chronicle_query import ChronicleIndex

def _write(path, kind, data):
    with open(path, "a") as f:
        f.write(json.dumps({"kind": kind, "data": data, "ts": time.time()}) + "\n")

def test_chronicle_write_and_read_roundtrip():
    with tempfile.TemporaryDirectory() as td:
        ch = os.path.join(td, "t.jsonl"); db = os.path.join(td, "t.db")
        _write(ch, "GATE_DECISION", {"decision": "BLOCK", "confidence": 0.72})
        idx = ChronicleIndex(ch, db); idx.rebuild()
        events = idx.get_events_since()
        assert len(events) >= 1

def test_chronicle_pipeline_mass_kind_written():
    with tempfile.TemporaryDirectory() as td:
        ch = os.path.join(td, "t.jsonl")
        _write(ch, "PIPELINE_MASS", {"stage": "LABELING", "epistemic_mass": 0.85})
        with open(ch) as f: obj = json.loads(f.read().strip())
        assert obj["kind"] == "PIPELINE_MASS"
        assert obj["data"]["epistemic_mass"] == 0.85

def test_chronicle_entry_ordering():
    with tempfile.TemporaryDirectory() as td:
        ch = os.path.join(td, "t.jsonl"); db = os.path.join(td, "t.db")
        for i in range(5):
            _write(ch, "LABEL", {"seq": i}); time.sleep(0.002)
        idx = ChronicleIndex(ch, db); idx.rebuild()
        assert len(idx.get_events_since()) >= 5

def test_chronicle_verify_chain():
    with tempfile.TemporaryDirectory() as td:
        ch = os.path.join(td, "t.jsonl"); db = os.path.join(td, "t.db")
        for i in range(3): _write(ch, "OUTCOME", {"trial": i})
        idx = ChronicleIndex(ch, db); idx.rebuild()
        result = idx.verify_chain()
        if isinstance(result, dict): assert result.get("valid", True) is not False
        else: assert result is not False

def test_chronicle_concurrent_writes_no_loss():
    with tempfile.TemporaryDirectory() as td:
        ch = os.path.join(td, "c.jsonl")
        errors = []
        def writer(tid):
            for i in range(10):
                try: _write(ch, "LIVE_INFERENCE", {"thread": tid, "seq": i})
                except Exception as e: errors.append(str(e))
        threads = [threading.Thread(target=writer, args=(t,)) for t in range(5)]
        for t in threads: t.start()
        for t in threads: t.join()
        assert not errors
        with open(ch) as f: lines = [l for l in f if l.strip()]
        assert len(lines) >= 50

def test_chronicle_entry_has_timestamp():
    with tempfile.TemporaryDirectory() as td:
        ch = os.path.join(td, "t.jsonl")
        _write(ch, "ANOMALY", {"detail": "test"})
        with open(ch) as f: obj = json.loads(f.read().strip())
        assert "ts" in obj and obj["ts"] > 0

def test_chronicle_survives_restart():
    with tempfile.TemporaryDirectory() as td:
        ch = os.path.join(td, "t.jsonl"); db = os.path.join(td, "t.db")
        _write(ch, "LABEL", {"proposal_id": "persist_test"})
        idx1 = ChronicleIndex(ch, db); idx1.rebuild()
        idx2 = ChronicleIndex(ch, db); idx2.rebuild()
        assert len(idx2.get_events_since()) >= 1

def test_chronicle_large_payload_no_truncation():
    with tempfile.TemporaryDirectory() as td:
        ch = os.path.join(td, "t.jsonl")
        _write(ch, "LIVE_INFERENCE", {"data": "x" * 10_000})
        with open(ch) as f: obj = json.loads(f.read().strip())
        assert len(obj["data"]["data"]) == 10_000

def run_tests():
    tests = sorted([(n,o) for n,o in globals().items()
                    if n.startswith("test_") and callable(o)], key=lambda x:x[0])
    passed=failed=0; results=[]
    for name,fn in tests:
        try: fn(); passed+=1; results.append((name,"PASS",None))
        except Exception as e: failed+=1; results.append((name,"FAIL",str(e)[:200]))
    return passed, failed, results
