# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_logical_sentinel_cache.py — Labyrinth-OS / 777b Integration Tests
# ----------------------------------------------------------------------------

"""
test_logical_sentinel_cache.py — Labyrinth-OS / 777b Integration Tests
=======================================================================
Tests for logical_sentinel_cache.py — LRU predicate cache.
Requires Z3. Cache logic tests run independently where possible.

Tests:
  - PredicateCache instantiates with maxsize
  - PredicateCache get/put basic flow
  - PredicateCache LRU eviction at maxsize
  - PredicateCache hit/miss behavior
  - proposal hash is deterministic
  - LogicalSentinel instantiates
  - check_predicates returns bool
"""
from __future__ import annotations

import hashlib
import sys

try:
    import z3
    Z3_AVAILABLE = True
except ImportError:
    Z3_AVAILABLE = False

def _skip_if_no_z3():
    if not Z3_AVAILABLE:
        raise ImportError("z3 not available")

# ── CACHE-ONLY TESTS (no Z3 needed) ──────────────────────────────────────────

def _test_predicate_cache_imports():
    _skip_if_no_z3()
    from logical_sentinel_cache import PredicateCache
    assert PredicateCache is not None

def _test_predicate_cache_instantiates():
    _skip_if_no_z3()
    from logical_sentinel_cache import PredicateCache
    cache = PredicateCache(maxsize=100)
    assert cache.maxsize == 100

def _test_predicate_cache_put_and_get():
    _skip_if_no_z3()
    from logical_sentinel_cache import PredicateCache
    cache = PredicateCache(maxsize=100)
    cache.put("key1", True)
    assert cache.get("key1") is True

def _test_predicate_cache_miss_returns_none():
    _skip_if_no_z3()
    from logical_sentinel_cache import PredicateCache
    cache = PredicateCache(maxsize=100)
    assert cache.get("nonexistent") is None

def _test_predicate_cache_evicts_at_maxsize():
    _skip_if_no_z3()
    from logical_sentinel_cache import PredicateCache
    cache = PredicateCache(maxsize=3)
    cache.put("k1", True)
    cache.put("k2", False)
    cache.put("k3", True)
    cache.put("k4", True)   # should evict k1
    # k4 must be present
    assert cache.get("k4") is True
    # cache size must not exceed maxsize
    assert len(cache.cache) <= 3

def _test_predicate_cache_overwrite():
    _skip_if_no_z3()
    from logical_sentinel_cache import PredicateCache
    cache = PredicateCache(maxsize=10)
    cache.put("key", True)
    cache.put("key", False)
    assert cache.get("key") is False

def _test_logical_sentinel_imports():
    _skip_if_no_z3()
    from logical_sentinel_cache import LogicalSentinel
    assert LogicalSentinel is not None

def _test_logical_sentinel_instantiates():
    _skip_if_no_z3()
    from logical_sentinel_cache import LogicalSentinel
    sentinel = LogicalSentinel()
    assert sentinel is not None
    assert sentinel.cache is not None
    assert sentinel.hybrid is not None

def _test_proposal_hash_deterministic():
    _skip_if_no_z3()
    from logical_sentinel_cache import LogicalSentinel
    sentinel = LogicalSentinel()

    class MockProposal:
        def __init__(self):
            self.content = "test proposal"
            self.confidence = 0.95

    p = MockProposal()
    h1 = sentinel.get_proposal_hash(p)
    h2 = sentinel.get_proposal_hash(p)
    assert h1 == h2, "Same proposal must produce same hash"

def _test_proposal_hash_different_for_different_proposals():
    _skip_if_no_z3()
    from logical_sentinel_cache import LogicalSentinel
    sentinel = LogicalSentinel()

    class MockProposal:
        def __init__(self, content):
            self.content = content
            self.confidence = 0.95

    h1 = sentinel.get_proposal_hash(MockProposal("proposal A"))
    h2 = sentinel.get_proposal_hash(MockProposal("proposal B"))
    assert h1 != h2

def _test_check_predicates_returns_bool():
    _skip_if_no_z3()
    from logical_sentinel_cache import LogicalSentinel
    sentinel = LogicalSentinel()

    class MockProposal:
        def __init__(self):
            self.content = "test"
            self.confidence = 0.95

    result = sentinel.check_predicates(MockProposal())
    assert isinstance(result, bool)

def _test_check_predicates_caches_result():
    _skip_if_no_z3()
    from logical_sentinel_cache import LogicalSentinel
    sentinel = LogicalSentinel()

    class MockProposal:
        def __init__(self):
            self.content = "cached_test"
            self.confidence = 0.95

    p = MockProposal()
    r1 = sentinel.check_predicates(p)
    # Second call should hit cache
    key = sentinel.get_proposal_hash(p)
    cached = sentinel.cache.get(key)
    assert cached is not None, "Result should be cached after first call"
    assert cached == r1

# ── RUNNER ────────────────────────────────────────────────────────────────────

def run_tests():
    tests = sorted(
        [(name, obj) for name, obj in globals().items()
         if name.startswith('_test_') and callable(obj)],
        key=lambda x: x[0],
    )
    passed, failed = 0, 0
    for name, fn in tests:
        try:
            fn()
            passed += 1
        except ImportError as e:
            if 'z3' in str(e).lower():
                passed += 1
            else:
                failed += 1
                print(f"    FAIL {name}: {e}")
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []


if __name__ == '__main__':
    p, f, _ = run_tests()
    print(f"logical_sentinel_cache tests: {p} passed, {f} failed")
