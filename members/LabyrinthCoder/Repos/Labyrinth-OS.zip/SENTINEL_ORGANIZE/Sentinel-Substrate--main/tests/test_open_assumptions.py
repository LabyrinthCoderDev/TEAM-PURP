# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_open_assumptions.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
test_open_assumptions.py — Labyrinth-OS
=========================================
Tests for A015, A016, A018, A020 assumption closure modules.

  A015 — fractal_parameter_solver.py
  A016 — arc_agi2_pipeline.py
  A018 — eden_signing_key.py
  A020 — adversarial_load_suite.py
"""
import sys, os
root = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, root)
sys.path.insert(0, os.path.join(root, 'execution', 'formal'))
sys.path.insert(0, os.path.join(root, 'execution', 'signing'))
sys.path.insert(0, os.path.join(root, 'execution', 'adversarial'))
sys.path.insert(0, os.path.join(root, 'execution', 'pre_cgir_gate'))


def run_tests():
    passed = failed = 0

    # A015 — fractal parameters
    from fractal_parameter_solver import run_tests as fps_tests
    p, f, _ = fps_tests()
    passed += p; failed += f

    # A016 — ARC-AGI-2 pipeline
    from arc_agi2_pipeline import run_tests as arc_tests
    p, f, _ = arc_tests()
    passed += p; failed += f

    # A018 — signing key persistence
    from eden_signing_key import run_tests as esk_tests
    p, f, _ = esk_tests()
    passed += p; failed += f

    # A020 — adversarial load suite
    from adversarial_load_suite import run_tests as als_tests
    p, f, _ = als_tests()
    passed += p; failed += f

    # Integration checks
    extra = [
        _test_a015_closes_on_two_families,
        _test_a016_chronicle_entries_sealed,
        _test_a018_cross_restart_verify,
        _test_a020_all_attack_signatures_detected,
        _test_a020_fp_rate_below_threshold,
    ]
    for fn in extra:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {fn.__name__}: {e}")

    return passed, failed, []


def _test_a015_closes_on_two_families():
    from fractal_parameter_solver import run_a015_validation
    receipt = run_a015_validation(live=False)
    assert len(receipt.families_validated) >= 2
    assert all(r.params_valid for r in receipt.results), \
        "All families must have valid parameters"


def _test_a016_chronicle_entries_sealed():
    from arc_agi2_pipeline import run_arc_pipeline
    result = run_arc_pipeline(mock_mode=True)
    assert len(result.chronicle_entries) > 0
    assert result.receipt_hash and len(result.receipt_hash) == 24


def _test_a018_cross_restart_verify():
    from eden_signing_key import verify_restart_persistence
    result = verify_restart_persistence(n_restarts=3)
    assert result["passed"]
    assert result["key_stable"]
    assert result["cross_verify_passed"]


def _test_a020_all_attack_signatures_detected():
    from adversarial_load_suite import run_adversarial_suite, AttackSignature
    result = run_adversarial_suite(include_clean=False)
    detected_types = {d.attack_type for d in result.detections if d.detected}
    for sig in [AttackSignature.SLOW_POISON, AttackSignature.BURST,
                AttackSignature.COORDINATED, AttackSignature.POLITE_LIE]:
        assert sig in detected_types, f"{sig.value} not detected"


def _test_a020_fp_rate_below_threshold():
    from adversarial_load_suite import run_adversarial_suite
    result = run_adversarial_suite(include_clean=True)
    assert result.fp_rate < 0.05, \
        f"FP rate {result.fp_rate:.3f} exceeds 5% threshold"
