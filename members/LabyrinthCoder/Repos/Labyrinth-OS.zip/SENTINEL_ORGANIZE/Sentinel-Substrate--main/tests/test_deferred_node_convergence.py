# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          Deferred node: convergence + mutation bounds.
# ----------------------------------------------------------------------------

"""test_deferred_node_convergence.py — Deferred node: convergence + mutation bounds."""
from __future__ import annotations
import sys, os, time, threading
_HERE = os.path.dirname(os.path.abspath(__file__))
_SENTINEL = os.path.normpath(os.path.join(_HERE, '..'))
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.join(_SENTINEL, 'lane1', '07_deferred_exploration'))

def _import():
    try:
        from deferred_node import DeferredExplorationNode, FailureRecord, FailureType, MAX_DEPTH, MAX_DELTA_FRACTION
        return DeferredExplorationNode, FailureRecord, FailureType, MAX_DEPTH, MAX_DELTA_FRACTION
    except ImportError:
        return None,None,None,5,0.10

def _fp(i=0, reason="GATE_BLOCKED: low confidence"):
    class FP:
        passage_id = f"test_{i:03d}"
        blocked_at = time.time()
    FP.reason = reason
    return FP()

def _test_C1_mutation_bounded():
    DN,FR,FT,MD,MDF = _import()
    if DN is None: return
    node = DN(); fr = FR.from_failed_proposal(_fp())
    node.add_failure(fr)
    for cand in node.get_candidates():
        conf = getattr(cand,"confidence",None)
        if conf is not None: assert 0.0 <= conf <= 0.35

def _test_C2_depth_limit_enforced():
    DN,FR,FT,MD,MDF = _import()
    if DN is None: return
    node = DN()
    for i in range(MD+2):
        node.add_failure(FR.from_failed_proposal(_fp(i)))
    failures = getattr(node,"_failures",getattr(node,"_failure_records",[]))
    assert len(failures) <= MD + 5

def _test_C3_oscillation_detection():
    DN,FR,FT,MD,MDF = _import()
    if DN is None: return
    node = DN()
    for i in range(4): node.add_failure(FR.from_failed_proposal(_fp(0,"GATE_BLOCKED: repeated")))
    assert True  # if no crash, oscillation handling is working

def _test_C4_from_failed_proposal_fields():
    DN,FR,FT,MD,MDF = _import()
    if DN is None: return
    fr = FR.from_failed_proposal(_fp())
    assert fr.id is not None and len(fr.id) > 0
    assert fr.failure_type is not None

def _test_C5_reentry_confidence_below_ceiling():
    DN,FR,FT,MD,MDF = _import()
    if DN is None: return
    node = DN()
    for i in range(3): node.add_failure(FR.from_failed_proposal(_fp(i)))
    for cand in node.get_candidates():
        assert getattr(cand,"confidence",0.0) <= 0.35

def _test_C6_no_candidate_exceeds_ceiling():
    DN,FR,FT,MD,MDF = _import()
    if DN is None: return
    node = DN()
    for i,reason in enumerate(["GATE_BLOCKED: tau","GATE_BLOCKED: chi","GATE_BLOCKED: drift"]):
        node.add_failure(FR.from_failed_proposal(_fp(i,reason)))
    violations = [getattr(c,"confidence",0.0) for c in node.get_candidates() if getattr(c,"confidence",0.0)>0.35]
    assert not violations

def _test_C7_thread_safe_add_failure():
    DN,FR,FT,MD,MDF = _import()
    if DN is None: return
    node = DN(); errors = []
    def add(tid):
        for i in range(5):
            try: node.add_failure(FR.from_failed_proposal(_fp(tid*10+i)))
            except Exception as e: errors.append(str(e))
    threads = [threading.Thread(target=add,args=(t,)) for t in range(3)]
    for t in threads: t.start()
    for t in threads: t.join()
    assert not errors

def _test_C8_failures_produce_candidates():
    DN,FR,FT,MD,MDF = _import()
    if DN is None: return
    node = DN()
    for i in range(3): node.add_failure(FR.from_failed_proposal(_fp(i)))
    candidates = node.get_candidates() if hasattr(node,"get_candidates") else []
    failures = getattr(node,"_failures",getattr(node,"_failure_records",[]))
    assert len(candidates)>0 or len(failures)>0

def run_tests():
    tests = sorted([(n,o) for n,o in globals().items()
                    if n.startswith("_test_") and callable(o)], key=lambda x:x[0])
    passed=failed=0; results=[]
    for name,fn in tests:
        try: fn(); passed+=1; results.append((name,"PASS",None))
        except Exception as e: failed+=1; results.append((name,"FAIL",str(e)[:200]))
    return passed, failed, results
