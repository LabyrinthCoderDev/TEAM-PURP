# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_contract_version.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
test_contract_version.py — Labyrinth-OS
=========================================
Tests that LABYRINTH_CONTRACT_VERSION is present and consistent
across all modules that use it.
"""
import sys, os
root = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, root)
sys.path.insert(0, os.path.join(root, 'promotion'))
sys.path.insert(0, os.path.join(root, 'execution', 'ledger'))
sys.path.insert(0, os.path.join(root, 'execution', 'pre_cgir_gate'))
sys.path.insert(0, os.path.join(root, 'runtime'))


def run_tests():
    passed = failed = 0
    tests = [
        _test_sigma_anchors_has_version,
        _test_version_is_string,
        _test_version_format,
        _test_execution_loop_toml_exists,
        _test_execution_loop_has_stages,
        _test_execution_loop_has_21_stages,
        _test_execution_loop_reality_gate_present,
        _test_ledger_entry_to_dict_has_contract_version,
        _test_ledger_entry_to_dict_has_retention,
        _test_promotion_decision_to_dict_has_maturity,
        _test_archive_entry_has_retention_and_version,
    ]
    for fn in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {fn.__name__}: {e}")
    return passed, failed, []


def _test_sigma_anchors_has_version():
    from sigma_anchors import LABYRINTH_CONTRACT_VERSION
    assert LABYRINTH_CONTRACT_VERSION is not None


def _test_version_is_string():
    from sigma_anchors import LABYRINTH_CONTRACT_VERSION
    assert isinstance(LABYRINTH_CONTRACT_VERSION, str)


def _test_version_format():
    from sigma_anchors import LABYRINTH_CONTRACT_VERSION
    parts = LABYRINTH_CONTRACT_VERSION.split(".")
    assert len(parts) == 3, f"Version must be semver: {LABYRINTH_CONTRACT_VERSION}"
    for part in parts:
        assert part.isdigit(), f"Version part must be numeric: {part}"


def _test_execution_loop_toml_exists():
    config = os.path.join(root, "config", "execution_loop.toml")
    assert os.path.exists(config), "config/execution_loop.toml must exist"


def _test_execution_loop_has_stages():
    config = os.path.join(root, "config", "execution_loop.toml")
    content = open(config).read()
    assert "stages" in content
    assert "L09_reality_gate" in content


def _test_execution_loop_has_21_stages():
    config = os.path.join(root, "config", "execution_loop.toml")
    content = open(config).read()
    # Count stage entries: "L00_" through "L20_"
    stages = [l.strip() for l in content.split("\n") 
              if l.strip().startswith('"L') and l.strip().endswith('",')]
    assert len(stages) == 21, f"Expected 21 stages, found {len(stages)}"


def _test_execution_loop_reality_gate_present():
    config = os.path.join(root, "config", "execution_loop.toml")
    content = open(config).read()
    assert "gate_is_mandatory = true" in content
    assert "gate_bypass_is_bug = true" in content


def _test_ledger_entry_to_dict_has_contract_version():
    """LedgerEntry.to_dict() must include contract_version."""
    sys.path.insert(0, os.path.join(root, 'execution', 'ledger'))
    sys.path.insert(0, os.path.join(root, 'execution', 'cgir'))
    from cgir_ledger import LedgerEntry, AEGISPhase
    entry = LedgerEntry(
        phase=AEGISPhase.LOAD,
        graph_hash="abc123",
        session_id="test-session",
        wall_clock=0.0,
    )
    d = entry.to_dict()
    assert "contract_version" in d, "LedgerEntry.to_dict() must include contract_version"
    assert d["contract_version"] == "1.0.0"


def _test_ledger_entry_to_dict_has_retention():
    """LedgerEntry.to_dict() must include retention."""
    sys.path.insert(0, os.path.join(root, 'execution', 'ledger'))
    sys.path.insert(0, os.path.join(root, 'execution', 'cgir'))
    from cgir_ledger import LedgerEntry, AEGISPhase
    entry = LedgerEntry(
        phase=AEGISPhase.LOAD,
        graph_hash="abc123",
        session_id="test-session",
        wall_clock=0.0,
    )
    d = entry.to_dict()
    assert "retention" in d, "LedgerEntry.to_dict() must include retention"


def _test_promotion_decision_to_dict_has_maturity():
    """PromotionDecision.to_dict() must include maturity."""
    sys.path.insert(0, os.path.join(root, 'promotion'))
    from promotion_rules import PromotionDecision, PromotionOutcome
    decision = PromotionDecision(
        label_id="lbl-001",
        outcome=PromotionOutcome.APPROVED,
        confidence=0.96,
        consecutive_runs=3,
    )
    d = decision.to_dict()
    assert "maturity" in d, "PromotionDecision.to_dict() must include maturity"
    assert "contract_version" in d
    assert d["maturity"] == "heuristic_local"
    assert d["contract_version"] == "1.0.0"


def _test_archive_entry_has_retention_and_version():
    """ArchiveEntry must have retention and contract_version fields."""
    sys.path.insert(0, os.path.join(root, 'lane1', '06_archive_memory'))
    sys.path.insert(0, os.path.join(root, 'epistemic', 'labeling'))
    from archive_memory import ArchiveEntry
    from epistemic_types import EpistemicLabel, IdeaNode, InputMode
    node = IdeaNode(
        idea_id="test-001",
        content="test content",
        label=EpistemicLabel.TRUTH,
        mode=InputMode.ANALYTICAL,
    )
    entry = ArchiveEntry(
        idea_id="test-001",
        version=1,
        node=node,
        archived_at=0.0,
        entry_hash="abc123",
    )
    assert hasattr(entry, 'retention'), "ArchiveEntry must have retention field"
    assert hasattr(entry, 'contract_version'), "ArchiveEntry must have contract_version"
    d = entry.to_dict()
    assert "retention" in d
    assert "contract_version" in d
