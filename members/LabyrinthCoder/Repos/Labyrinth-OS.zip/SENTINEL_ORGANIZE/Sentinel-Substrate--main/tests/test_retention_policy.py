# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_retention_policy.py — Labyrinth-OS / Ledger
# ----------------------------------------------------------------------------

"""
test_retention_policy.py — Labyrinth-OS / Ledger
==================================================
Tests for retention_policy.py — RetentionPolicy and SigilSeverity.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'execution', 'ledger'))
from retention_policy import (
    RetentionPolicy, SigilSeverity,
    default_retention, default_severity,
    run_tests as _internal_tests,
)


def run_tests():
    passed, failed, _ = _internal_tests()
    
    extra = [
        _test_all_critical_events_permanent,
        _test_hypothesis_is_ephemeral,
        _test_gate_decisions_are_durable,
    ]
    for fn in extra:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {fn.__name__}: {e}")
    
    return passed, failed, []


def _test_all_critical_events_permanent():
    critical = [
        "LIVE_INFERENCE", "Z3_PROOF_RECEIPT",
        "SOVEREIGNTY_RECEIPT", "A010_CLOSED",
    ]
    for event in critical:
        assert default_retention(event) == RetentionPolicy.PERMANENT, (
            f"{event} should be PERMANENT"
        )


def _test_hypothesis_is_ephemeral():
    assert default_retention("HYPOTHESIS_TEST_RUN") == RetentionPolicy.EPHEMERAL
    assert default_retention("MOCK_DRY_RUN") == RetentionPolicy.EPHEMERAL


def _test_gate_decisions_are_durable():
    for event in ["GATE_ALLOW", "GATE_BLOCK", "GATE_KILL"]:
        assert default_retention(event) == RetentionPolicy.DURABLE
