# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_sync_truth_standalone.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
test_sync_truth_standalone.py — Labyrinth-OS
=============================================
Standalone tests for scripts/sync_truth.py.
"""
import sys, os
root = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(root, 'scripts'))
sys.path.insert(0, root)


def run_tests():
    from sync_truth import run_tests as _internal
    return _internal()
