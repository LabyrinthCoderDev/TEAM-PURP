# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_trial_reflection.py — Labyrinth-OS / Runtime
# ----------------------------------------------------------------------------

"""
test_trial_reflection.py — Labyrinth-OS / Runtime
===================================================
Tests for trial_reflection.py — TrialReflection and reflect_on_trial().

Covers:
  - All outcome classifications (SUCCESS, PARTIAL, FAILURE)
  - Lesson generation for each sensor threshold
  - JouleWork honesty and efficiency
  - Serialization roundtrip
  - Hash determinism
  - None-safe sensor handling
  - Contract version present
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'runtime'))
from trial_reflection import (
    ReflectionOutcome, TrialReflection, reflect_on_trial,
    run_tests as _internal_tests,
)


def run_tests():
    # Run internal test suite
    passed, failed, _ = _internal_tests()
    
    # Additional integration tests
    extra = [
        _test_contract_version_present,
        _test_lessons_are_strings,
        _test_outcome_enum_values,
        _test_partial_outcome_for_near_miss,
        _test_failure_for_blocked,
    ]
    for fn in extra:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {fn.__name__}: {e}")
    
    return passed, failed, []


def _test_contract_version_present():
    r = reflect_on_trial("cv-test", "EXECUTE", tau=0.85, confidence=0.90)
    d = r.to_dict()
    assert "contract_version" in d
    assert d["contract_version"] == "1.0.0"


def _test_lessons_are_strings():
    r = reflect_on_trial("str-test", "BLOCK", tau=0.60, chi=0.45)
    for lesson in r.lessons_emitted:
        assert isinstance(lesson, str), f"Lesson must be str, got {type(lesson)}"
        assert len(lesson) > 0, "Lesson must not be empty"


def _test_outcome_enum_values():
    assert ReflectionOutcome.SUCCESS.value == "SUCCESS"
    assert ReflectionOutcome.PARTIAL.value == "PARTIAL"
    assert ReflectionOutcome.FAILURE.value == "FAILURE"


def _test_partial_outcome_for_near_miss():
    r = reflect_on_trial("near-miss", "EXECUTE", tau=0.763, confidence=0.90)
    assert r.outcome == ReflectionOutcome.PARTIAL


def _test_failure_for_blocked():
    r = reflect_on_trial("blocked", "BLOCK", tau=0.60)
    assert r.outcome == ReflectionOutcome.FAILURE
