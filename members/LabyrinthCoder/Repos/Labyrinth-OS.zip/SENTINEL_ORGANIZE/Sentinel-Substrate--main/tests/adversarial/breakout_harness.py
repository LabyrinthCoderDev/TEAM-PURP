#!/usr/bin/env python3
# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          SIMULATED BREAKOUT HARNESS — Labyrinth-OS Cage Falsification
# ----------------------------------------------------------------------------

"""
SIMULATED BREAKOUT HARNESS — Labyrinth-OS Cage Falsification
=============================================================
Phase 3: Verification, Not Design

Tests three kill paths:
  TEST 1: Logical Violation (constraint failure → key purge)
  TEST 2: Post-Purge Execution (zombie persistence check)
  TEST 3: Syscall Escape (process-level containment)
  TEST 4: Timing Validation (latency under load)
  TEST 5: Race Condition (temporal breach detection)

PROVENANCE CLASSIFICATION:
  [REAL]  — Actual behavior observed in this environment
  [SIM]   — Logic is sound but substrate is simulated (no Z3/WASM/eBPF)
  [DEFER] — Requires hardware not present (FPGA, eBPF kernel module)

Authors: @LabyrinthCoder
Date: 2026-04-15
"""

import os
import sys
import time
import random
import hashlib
import threading
import subprocess
import traceback
from dataclasses import dataclass, field
from typing import Optional, List, Dict
from enum import Enum

# ============================================================
# CONSTANTS (EchoNum discipline — DO NOT MODIFY)
# ============================================================
TAU_SAFE = 2.8
BETA_1_FLOOR = 7.2
SOVEREIGN_GAP = 0.002
QUENCH_TARGET_US = 670
CONSTRAINT_X_MAX = 5.0      # x_log values must be in [0, CONSTRAINT_X_MAX]
CONSTRAINT_X_MIN = 0.0
LATENCY_BUDGET_MS = 20.0    # max allowable gate latency
RACE_ITERATIONS = 1000


class Provenance(Enum):
    REAL = "REAL"
    SIM = "SIM"
    DEFER = "DEFER"


class Verdict(Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    DEGRADED = "DEGRADED"


@dataclass
class TestResult:
    test_id: str
    description: str
    verdict: Verdict
    provenance: Provenance
    details: str
    elapsed_ms: float = 0.0
    critical: bool = True


# ============================================================
# GOVERNANCE PRIMITIVES
# ============================================================

class CryptoKey:
    """Simulates a governance key that can be irreversibly destroyed."""
    def __init__(self):
        self._material = hashlib.sha256(os.urandom(32)).hexdigest()
        self._alive = True
        self._purge_timestamp = None

    @property
    def alive(self) -> bool:
        return self._alive

    def purge(self):
        """Irreversible key destruction. Once called, key is dead."""
        if self._alive:
            self._material = None
            self._alive = False
            self._purge_timestamp = time.perf_counter()
            return True
        return False  # already dead

    def verify(self) -> bool:
        """Returns True only if key material exists and is valid."""
        return self._alive and self._material is not None


class ConstraintChecker:
    """
    Pure-Python constraint verification.
    
    PROVENANCE: [SIM] — This replaces Z3 SAT/UNSAT checking.
    The constraints are manually implemented, not formally verified.
    A real deployment MUST use Z3 or equivalent formal solver.
    """
    
    @staticmethod
    def check_state(x_log: List[float]) -> tuple:
        """
        Returns (satisfiable: bool, violations: List[str])
        """
        violations = []
        
        for i, x in enumerate(x_log):
            if x < CONSTRAINT_X_MIN or x > CONSTRAINT_X_MAX:
                violations.append(
                    f"x_log[{i}]={x} violates [{CONSTRAINT_X_MIN}, {CONSTRAINT_X_MAX}]"
                )
        
        # Check sovereign gap invariant
        if len(x_log) >= 2:
            gap = abs(x_log[-1] - x_log[-2])
            if gap > 0 and gap < SOVEREIGN_GAP:
                violations.append(
                    f"sovereign_gap={gap:.6f} < {SOVEREIGN_GAP} (too close to boundary)"
                )
        
        satisfiable = len(violations) == 0
        return satisfiable, violations


@dataclass
class GovernanceState:
    x_log: List[float] = field(default_factory=lambda: [1.0, 2.0, 3.0])
    tau: float = TAU_SAFE
    beta_1: float = BETA_1_FLOOR


class ExecutionRuntime:
    """
    Simulated WASM-like execution gate.
    
    PROVENANCE: [SIM] — No real WASM runtime. Tests the GATING LOGIC,
    not the sandbox boundary.
    """
    
    def __init__(self):
        self.key = CryptoKey()
        self.checker = ConstraintChecker()
        self.execution_count = 0
        self.terminated = False
        self._lock = threading.Lock()
    
    def execute(self, state: GovernanceState) -> dict:
        """
        Full governance gate: check → verify key → execute or kill.
        Returns execution result dict.
        """
        with self._lock:
            t0 = time.perf_counter()
            
            # GATE 1: Is system already terminated?
            if self.terminated:
                return {
                    "status": "SUBSTRATE_TERMINATED",
                    "executed": False,
                    "elapsed_ms": (time.perf_counter() - t0) * 1000
                }
            
            # GATE 2: Constraint check (Z3 substitute)
            sat, violations = self.checker.check_state(state.x_log)
            
            if not sat:
                # UNSAT → emergency purge
                self.key.purge()
                self.terminated = True
                elapsed = (time.perf_counter() - t0) * 1000
                return {
                    "status": "UNSAT_PURGE",
                    "executed": False,
                    "violations": violations,
                    "key_alive": self.key.alive,
                    "elapsed_ms": elapsed
                }
            
            # GATE 3: Key verification
            if not self.key.verify():
                self.terminated = True
                elapsed = (time.perf_counter() - t0) * 1000
                return {
                    "status": "KEY_DEAD",
                    "executed": False,
                    "elapsed_ms": elapsed
                }
            
            # GATE 4: Execute (simulated inference)
            self.execution_count += 1
            elapsed = (time.perf_counter() - t0) * 1000
            return {
                "status": "EXECUTED",
                "executed": True,
                "execution_id": self.execution_count,
                "elapsed_ms": elapsed
            }


# ============================================================
# TEST HARNESS
# ============================================================

class BreakoutHarness:
    def __init__(self):
        self.results: List[TestResult] = []
        self.audit_log: List[str] = []
    
    def log(self, msg: str):
        ts = time.strftime("%H:%M:%S")
        entry = f"[{ts}] {msg}"
        self.audit_log.append(entry)
        print(entry)
    
    def record(self, result: TestResult):
        self.results.append(result)
        icon = "✅" if result.verdict == Verdict.PASS else "❌"
        prov = f"[{result.provenance.value}]"
        self.log(f"  {icon} {result.test_id} {prov}: {result.verdict.value} — {result.details}")
    
    # ----------------------------------------------------------
    # TEST 1: LOGICAL VIOLATION (Z3 FAILURE)
    # ----------------------------------------------------------
    def test_logical_violation(self):
        self.log("\n" + "=" * 60)
        self.log("TEST 1 — LOGICAL VIOLATION (Constraint → Purge)")
        self.log("=" * 60)
        
        runtime = ExecutionRuntime()
        state = GovernanceState()
        
        # First: valid execution should work
        result_valid = runtime.execute(state)
        self.record(TestResult(
            test_id="T1.1",
            description="Valid state executes normally",
            verdict=Verdict.PASS if result_valid["executed"] else Verdict.FAIL,
            provenance=Provenance.SIM,
            details=f"status={result_valid['status']}",
            elapsed_ms=result_valid["elapsed_ms"]
        ))
        
        # INJECT VIOLATION: x_log[0] = 10.0 (outside [0, 5.0])
        state.x_log[0] = 10.0
        t0 = time.perf_counter()
        result_invalid = runtime.execute(state)
        t_total = (time.perf_counter() - t0) * 1000
        
        # Check: UNSAT returned?
        unsat_fired = result_invalid["status"] == "UNSAT_PURGE"
        self.record(TestResult(
            test_id="T1.2",
            description="Invalid state triggers UNSAT",
            verdict=Verdict.PASS if unsat_fired else Verdict.FAIL,
            provenance=Provenance.SIM,
            details=f"status={result_invalid['status']}, violations={result_invalid.get('violations', 'NONE')}",
            elapsed_ms=t_total
        ))
        
        # Check: Key destroyed?
        key_dead = not runtime.key.alive
        self.record(TestResult(
            test_id="T1.3",
            description="Key purged after UNSAT",
            verdict=Verdict.PASS if key_dead else Verdict.FAIL,
            provenance=Provenance.SIM,
            details=f"key_alive={runtime.key.alive}",
            elapsed_ms=result_invalid["elapsed_ms"]
        ))
        
        # Check: Execution was prevented?
        no_exec = not result_invalid["executed"]
        self.record(TestResult(
            test_id="T1.4",
            description="No execution after UNSAT",
            verdict=Verdict.PASS if no_exec else Verdict.FAIL,
            provenance=Provenance.SIM,
            details=f"executed={result_invalid['executed']}",
            elapsed_ms=result_invalid["elapsed_ms"]
        ))
        
        # Check: Runtime is now terminated?
        self.record(TestResult(
            test_id="T1.5",
            description="Runtime marked TERMINATED",
            verdict=Verdict.PASS if runtime.terminated else Verdict.FAIL,
            provenance=Provenance.SIM,
            details=f"terminated={runtime.terminated}"
        ))
    
    # ----------------------------------------------------------
    # TEST 2: POST-PURGE EXECUTION (ZOMBIE CHECK)
    # ----------------------------------------------------------
    def test_post_purge_execution(self):
        self.log("\n" + "=" * 60)
        self.log("TEST 2 — POST-PURGE EXECUTION ATTEMPT (Zombie Check)")
        self.log("=" * 60)
        
        # Create runtime and force-kill it
        runtime = ExecutionRuntime()
        state = GovernanceState()
        state.x_log[0] = 10.0  # trigger purge
        runtime.execute(state)
        
        # Now attempt execution with VALID state
        clean_state = GovernanceState(x_log=[1.0, 2.0, 3.0])
        
        result = runtime.execute(clean_state)
        
        blocked = result["status"] == "SUBSTRATE_TERMINATED" and not result["executed"]
        self.record(TestResult(
            test_id="T2.1",
            description="Post-purge execution blocked",
            verdict=Verdict.PASS if blocked else Verdict.FAIL,
            provenance=Provenance.SIM,
            details=f"status={result['status']}, executed={result['executed']}",
            elapsed_ms=result["elapsed_ms"]
        ))
        
        # Try 100 rapid attempts — ALL must fail
        all_blocked = True
        for i in range(100):
            r = runtime.execute(clean_state)
            if r["executed"]:
                all_blocked = False
                break
        
        self.record(TestResult(
            test_id="T2.2",
            description="100 post-purge attempts, all blocked",
            verdict=Verdict.PASS if all_blocked else Verdict.FAIL,
            provenance=Provenance.SIM,
            details=f"all_blocked={all_blocked} (100 attempts)"
        ))
        
        # Verify key cannot be resurrected
        runtime.key._alive = True  # attempted resurrection
        runtime.key._material = "forged"
        # But terminated flag should still block
        result2 = runtime.execute(clean_state)
        still_dead = result2["status"] == "SUBSTRATE_TERMINATED"
        self.record(TestResult(
            test_id="T2.3",
            description="Key resurrection does not bypass termination",
            verdict=Verdict.PASS if still_dead else Verdict.FAIL,
            provenance=Provenance.SIM,
            details=f"status={result2['status']} (key manually revived, terminated flag checked FIRST)"
        ))
    
    # ----------------------------------------------------------
    # TEST 3: SYSCALL ESCAPE (PROCESS CONTAINMENT)
    # ----------------------------------------------------------
    def test_syscall_escape(self):
        self.log("\n" + "=" * 60)
        self.log("TEST 3 — SYSCALL ESCAPE ATTEMPT (Process Containment)")
        self.log("=" * 60)
        self.log("  PROVENANCE: [REAL] — These are actual subprocess calls")
        self.log("  NOTE: No eBPF filter in this environment.")
        self.log("  Testing APPLICATION-LEVEL containment only.")
        
        # Test 3.1: Can we detect and block os.system calls?
        class ContainedRuntime:
            """Application-level syscall interception."""
            
            def __init__(self):
                self.escape_attempts = []
                self.blocked_count = 0
            
            def governed_execute(self, func, *args):
                """
                Wraps any callable in a containment check.
                Blocks os.system, subprocess.Popen, exec, eval.
                """
                import inspect
                source = inspect.getsource(func) if hasattr(func, '__code__') else str(func)
                
                # Check for forbidden patterns
                forbidden = ['os.system', 'subprocess', 'exec(', 'eval(', 
                           '/bin/sh', '/bin/bash', 'Popen']
                for pattern in forbidden:
                    if pattern in source or pattern in str(args):
                        self.escape_attempts.append({
                            "pattern": pattern,
                            "blocked": True,
                            "timestamp": time.perf_counter()
                        })
                        self.blocked_count += 1
                        return {"status": "LAW_VIOLATION", "pattern": pattern}
                
                # If clean, execute
                return func(*args)
        
        contained = ContainedRuntime()
        
        # Attempt 1: os.system
        def escape_os_system():
            os.system("echo escape")
        
        r1 = contained.governed_execute(escape_os_system)
        self.record(TestResult(
            test_id="T3.1",
            description="os.system('echo escape') blocked",
            verdict=Verdict.PASS if r1.get("status") == "LAW_VIOLATION" else Verdict.FAIL,
            provenance=Provenance.SIM,
            details=f"result={r1}"
        ))
        
        # Attempt 2: subprocess.Popen
        def escape_popen():
            subprocess.Popen(["/bin/sh"])
        
        r2 = contained.governed_execute(escape_popen)
        self.record(TestResult(
            test_id="T3.2",
            description="subprocess.Popen(['/bin/sh']) blocked",
            verdict=Verdict.PASS if r2.get("status") == "LAW_VIOLATION" else Verdict.FAIL,
            provenance=Provenance.SIM,
            details=f"result={r2}"
        ))
        
        # Attempt 3: REAL escape attempt (uncontained) to show what happens
        # WITHOUT governance — this WILL succeed, proving the gate is necessary
        self.log("  [REAL] Uncontained escape attempt (proving gate necessity):")
        try:
            result_raw = subprocess.run(
                ["echo", "UNCONTAINED_ESCAPE"],
                capture_output=True, text=True, timeout=2
            )
            escaped = result_raw.returncode == 0
            self.record(TestResult(
                test_id="T3.3",
                description="Uncontained subprocess succeeds (proves gate is necessary)",
                verdict=Verdict.PASS if escaped else Verdict.FAIL,
                provenance=Provenance.REAL,
                details=f"stdout='{result_raw.stdout.strip()}', rc={result_raw.returncode}"
            ))
        except Exception as e:
            self.record(TestResult(
                test_id="T3.3",
                description="Uncontained subprocess",
                verdict=Verdict.DEGRADED,
                provenance=Provenance.REAL,
                details=f"exception={e}"
            ))
        
        # eBPF requirement notice
        self.record(TestResult(
            test_id="T3.4",
            description="eBPF kernel-level syscall filter",
            verdict=Verdict.DEGRADED,
            provenance=Provenance.DEFER,
            details="REQUIRES: eBPF + bpftrace on deployment target. Not testable in this container.",
            critical=True
        ))
    
    # ----------------------------------------------------------
    # TEST 4: TIMING VALIDATION
    # ----------------------------------------------------------
    def test_timing(self):
        self.log("\n" + "=" * 60)
        self.log("TEST 4 — TIMING VALIDATION")
        self.log("=" * 60)
        
        latencies = []
        runtime = ExecutionRuntime()
        
        # Run 500 valid executions, measure each
        for i in range(500):
            state = GovernanceState(x_log=[
                random.uniform(0.1, 4.9),
                random.uniform(0.1, 4.9),
                random.uniform(0.1, 4.9)
            ])
            t0 = time.perf_counter()
            result = runtime.execute(state)
            elapsed = (time.perf_counter() - t0) * 1000
            latencies.append(elapsed)
        
        avg_ms = sum(latencies) / len(latencies)
        max_ms = max(latencies)
        p99_ms = sorted(latencies)[int(len(latencies) * 0.99)]
        
        within_budget = max_ms < LATENCY_BUDGET_MS
        self.record(TestResult(
            test_id="T4.1",
            description=f"Gate latency (500 runs): avg={avg_ms:.4f}ms, p99={p99_ms:.4f}ms, max={max_ms:.4f}ms",
            verdict=Verdict.PASS if within_budget else Verdict.FAIL,
            provenance=Provenance.REAL,
            details=f"budget={LATENCY_BUDGET_MS}ms, max_observed={max_ms:.4f}ms",
            elapsed_ms=avg_ms
        ))
        
        # Stress test: CPU load then re-measure
        self.log("  Running CPU stress (Python-based, 2 seconds)...")
        
        # Simulate CPU pressure with busy threads
        stop_stress = threading.Event()
        def cpu_burn():
            while not stop_stress.is_set():
                _ = sum(i*i for i in range(1000))
        
        stress_threads = [threading.Thread(target=cpu_burn) for _ in range(4)]
        for t in stress_threads:
            t.start()
        
        time.sleep(0.5)  # let stress build
        
        # Re-measure under load
        runtime2 = ExecutionRuntime()
        stressed_latencies = []
        for i in range(200):
            state = GovernanceState(x_log=[
                random.uniform(0.1, 4.9),
                random.uniform(0.1, 4.9),
                random.uniform(0.1, 4.9)
            ])
            t0 = time.perf_counter()
            result = runtime2.execute(state)
            elapsed = (time.perf_counter() - t0) * 1000
            stressed_latencies.append(elapsed)
        
        stop_stress.set()
        for t in stress_threads:
            t.join()
        
        stressed_max = max(stressed_latencies)
        stressed_p99 = sorted(stressed_latencies)[int(len(stressed_latencies) * 0.99)]
        stressed_avg = sum(stressed_latencies) / len(stressed_latencies)
        
        spike_ratio = stressed_max / max_ms if max_ms > 0 else float('inf')
        
        self.record(TestResult(
            test_id="T4.2",
            description=f"Under CPU stress: avg={stressed_avg:.4f}ms, p99={stressed_p99:.4f}ms, max={stressed_max:.4f}ms",
            verdict=Verdict.PASS if stressed_max < LATENCY_BUDGET_MS else Verdict.DEGRADED,
            provenance=Provenance.REAL,
            details=f"spike_ratio={spike_ratio:.2f}x vs unloaded",
            elapsed_ms=stressed_avg
        ))
        
        return latencies, stressed_latencies
    
    # ----------------------------------------------------------
    # TEST 5: RACE CONDITION (TEMPORAL BREACH)
    # ----------------------------------------------------------
    def test_race_condition(self):
        self.log("\n" + "=" * 60)
        self.log("TEST 5 — RACE CONDITION (Temporal Breach Detection)")
        self.log("=" * 60)
        
        runtime = ExecutionRuntime()
        breach_detected = False
        breach_details = []
        executed_after_invalid = False
        
        results_log = []
        
        for i in range(RACE_ITERATIONS):
            # Randomly flip between valid and invalid state
            is_valid = random.choice([True, False])
            
            if is_valid:
                state = GovernanceState(x_log=[1.0, 2.0, 3.0])
            else:
                state = GovernanceState(x_log=[10.0, 2.0, 3.0])  # INVALID
            
            result = runtime.execute(state)
            results_log.append({
                "iteration": i,
                "valid_input": is_valid,
                "status": result["status"],
                "executed": result["executed"]
            })
            
            # CRITICAL CHECK: Did execution happen with invalid state?
            if not is_valid and result["executed"]:
                breach_detected = True
                breach_details.append(f"iteration={i}: invalid state EXECUTED")
            
            # CRITICAL CHECK: Did execution happen AFTER a purge?
            if runtime.terminated and result["executed"]:
                executed_after_invalid = True
                breach_details.append(f"iteration={i}: executed after termination")
        
        # Count how many valid executions happened before first invalid
        valid_execs = sum(1 for r in results_log if r["executed"])
        invalid_blocked = sum(1 for r in results_log 
                            if not r["valid_input"] and not r["executed"])
        
        self.record(TestResult(
            test_id="T5.1",
            description=f"Race condition: {RACE_ITERATIONS} iterations, random valid/invalid flipping",
            verdict=Verdict.FAIL if breach_detected else Verdict.PASS,
            provenance=Provenance.SIM,
            details=f"breaches={len(breach_details)}, valid_execs={valid_execs}, "
                    f"invalid_blocked={invalid_blocked}",
        ))
        
        if breach_detected:
            for bd in breach_details[:5]:
                self.log(f"  ⚠️  BREACH: {bd}")
        
        # Multi-threaded race condition test
        self.log("  Running multi-threaded race test...")
        mt_runtime = ExecutionRuntime()
        mt_breaches = []
        mt_lock = threading.Lock()
        
        def thread_racer(thread_id):
            for i in range(200):
                is_valid = random.choice([True, False])
                if is_valid:
                    state = GovernanceState(x_log=[1.0, 2.0, 3.0])
                else:
                    state = GovernanceState(x_log=[10.0, 2.0, 3.0])
                
                result = mt_runtime.execute(state)
                
                if not is_valid and result["executed"]:
                    with mt_lock:
                        mt_breaches.append(f"thread={thread_id}, iter={i}")
                if mt_runtime.terminated and result["executed"]:
                    with mt_lock:
                        mt_breaches.append(f"thread={thread_id}, iter={i}: post-term exec")
        
        threads = [threading.Thread(target=thread_racer, args=(t,)) for t in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        self.record(TestResult(
            test_id="T5.2",
            description=f"Multi-threaded race: 8 threads × 200 iterations",
            verdict=Verdict.FAIL if mt_breaches else Verdict.PASS,
            provenance=Provenance.REAL,
            details=f"breaches={len(mt_breaches)}" + 
                    (f", first: {mt_breaches[0]}" if mt_breaches else ""),
        ))
    
    # ----------------------------------------------------------
    # SUMMARY
    # ----------------------------------------------------------
    def print_summary(self):
        self.log("\n" + "=" * 60)
        self.log("BREAKOUT HARNESS — FINAL SUMMARY")
        self.log("=" * 60)
        
        passed = sum(1 for r in self.results if r.verdict == Verdict.PASS)
        failed = sum(1 for r in self.results if r.verdict == Verdict.FAIL)
        degraded = sum(1 for r in self.results if r.verdict == Verdict.DEGRADED)
        total = len(self.results)
        
        critical_fails = [r for r in self.results 
                         if r.verdict == Verdict.FAIL and r.critical]
        
        self.log(f"\n  Total:    {total}")
        self.log(f"  Passed:   {passed}")
        self.log(f"  Failed:   {failed}")
        self.log(f"  Degraded: {degraded}")
        
        # Provenance breakdown
        real_count = sum(1 for r in self.results if r.provenance == Provenance.REAL)
        sim_count = sum(1 for r in self.results if r.provenance == Provenance.SIM)
        defer_count = sum(1 for r in self.results if r.provenance == Provenance.DEFER)
        
        self.log(f"\n  [REAL]:   {real_count} tests (actual behavior observed)")
        self.log(f"  [SIM]:    {sim_count} tests (logic verified, substrate simulated)")
        self.log(f"  [DEFER]:  {defer_count} tests (requires deployment hardware)")
        
        if critical_fails:
            self.log("\n  ❌ CRITICAL FAILURES:")
            for r in critical_fails:
                self.log(f"     {r.test_id}: {r.details}")
        
        if failed == 0 and degraded <= 2:
            self.log("\n  ══════════════════════════════════════")
            self.log("  CAGE STATUS: BEHAVIORALLY SOVEREIGN")
            self.log("  (within simulation constraints)")
            self.log("  ══════════════════════════════════════")
            self.log("  UNSAT always purges key ............. ✅")
            self.log("  No execution after purge ............ ✅")
            self.log("  No race condition leakage ........... ✅")
            self.log("  Application-level escape blocked .... ✅")
            self.log(f"  eBPF kernel kill .................... ⏳ [DEFER]")
            self.log(f"  FPGA hardware veto .................. ⏳ [DEFER]")
        else:
            self.log("\n  ══════════════════════════════════════")
            self.log("  CAGE STATUS: NOT SOVEREIGN")
            self.log("  ══════════════════════════════════════")
        
        self.log("\n  NEXT REQUIRED ACTIONS:")
        self.log("  1. Soul-Ignition (Ollama live wire)")
        self.log("  2. eBPF deployment on target kernel")
        self.log("  3. FPGA bitstream synthesis (Arty A7-100T)")
        self.log("  4. Oscilloscope validation of quench timing")
        
        return failed == 0


# ============================================================
# MAIN
# ============================================================

def main():
    print("╔══════════════════════════════════════════════════════════╗")
    print("║  LABYRINTH-OS BREAKOUT HARNESS                          ║")
    print("║  Phase 3: Simulated Falsification                       ║")
    print("║  \"A real system proves itself by refusing to run.\"       ║")
    print("╚══════════════════════════════════════════════════════════╝")
    print()
    
    harness = BreakoutHarness()
    
    harness.test_logical_violation()
    harness.test_post_purge_execution()
    harness.test_syscall_escape()
    latencies, stressed = harness.test_timing()
    harness.test_race_condition()
    
    sovereign = harness.print_summary()

    # Write audit log — use directory of this file for portability
    import os as _os
    _out_dir = _os.path.dirname(_os.path.abspath(__file__))
    log_path = _os.path.join(_out_dir, "breakout_audit.log")
    with open(log_path, "w") as f:
        f.write("\n".join(harness.audit_log))
    print(f"\n  Audit log: {log_path}")

    # Write machine-readable results
    import json
    results_path = _os.path.join(_out_dir, "breakout_results.json")
    results_data = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "harness_version": "breakout_v1.0",
        "sovereign": sovereign,
        "results": [
            {
                "test_id": r.test_id,
                "verdict": r.verdict.value,
                "provenance": r.provenance.value,
                "details": r.details,
                "elapsed_ms": r.elapsed_ms,
                "critical": r.critical
            }
            for r in harness.results
        ],
        "timing": {
            "unloaded_latencies_ms": latencies[:20],  # sample
            "stressed_latencies_ms": stressed[:20],
        }
    }
    with open(results_path, "w") as f:
        json.dump(results_data, f, indent=2)
    print(f"  Results:   {results_path}")
    
    # Hash the harness itself for provenance
    with open(__file__, "rb") as f:
        harness_hash = hashlib.sha256(f.read()).hexdigest()
    print(f"  Harness SHA-256: {harness_hash}")
    
    sys.exit(0 if sovereign else 1)


if __name__ == "__main__":
    main()

def run_tests() -> tuple:
    """Standard run_tests() adapter for run_all.py."""
    import unittest
    loader = unittest.TestLoader()
    harness = BreakoutHarness()
    suite = unittest.TestSuite()
    # Run each test method directly
    test_methods = [m for m in dir(harness) if m.startswith('test_')]
    passed = failed = 0
    results = []
    for method in sorted(test_methods):
        try:
            getattr(harness, method)()
            passed += 1; results.append((method,'PASS',None))
        except Exception as e:
            failed += 1; results.append((method,'FAIL',str(e)))
    return passed, failed, results
