# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ✓  (Test/Verification)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          Tests for triad_intent_check.py -- Sun Tzu axis
# ----------------------------------------------------------------------------

"""
test_triad_intent_check.py -- Labyrinth-OS
============================================
Tests for epistemic/council/triad_intent_check.py
"""
import sys, os
root = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(root, 'epistemic', 'council'))
sys.path.insert(0, root)


def run_tests():
    from triad_intent_check import run_tests as _internal
    passed, failed, _ = _internal()
    extra = [_test_wired_into_council, _test_advisory_mode_is_default]
    for fn in extra:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {fn.__name__}: {e}")
    return passed, failed, []


def _test_wired_into_council():
    content = open(os.path.join(root, 'epistemic', 'council', 'council_resolver.py')).read()
    assert 'triad_intent_check' in content, "Triad must be imported by council_resolver"


def _test_advisory_mode_is_default():
    from triad_intent_check import LABYRINTH_TRIAD, TriadMode
    assert LABYRINTH_TRIAD.mode == TriadMode.ADVISORY
