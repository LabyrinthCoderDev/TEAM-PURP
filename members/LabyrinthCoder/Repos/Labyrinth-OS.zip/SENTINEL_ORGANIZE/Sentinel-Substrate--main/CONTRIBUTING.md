# CONTRIBUTING — Labyrinth-OS

## Architecture Compliance

All contributions MUST comply with the architecture defined in ARCHITECTURE.md and INVARIANTS.md.

**Non-negotiable rules:**
1. CGIR is the only semantic substrate.
2. Only AEGIS / CESK may mutate state.
3. Gate is the only decision authority.
4. VECTOR is read-only.
5. Watcher-A and Watcher-B cannot execute.
6. Council emits exactly one SignalNode per decision cycle.
7. Signals annotate. Signals never decide.
8. Ledger is the truth layer.
9. Replay must reconstruct all valid executions.
10. Evolution happens offline only.
11. No hidden execution paths.
12. No bypass flags.
13. No "temporary" code that violates the architecture.

Any contribution that violates these rules will be rejected regardless of functionality.

## Development Setup

```bash
# Install Rust (see rust-toolchain.toml for version)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Build workspace
cargo build --workspace

# Run tests
cargo test --workspace

# Run linter
cargo clippy --workspace

# Run fuzzer (requires nightly)
cargo +nightly fuzz run <target>
```

## Pull Request Requirements

- All PRs must pass CI (test, lint, security scan)
- All PRs must include tests for new functionality
- All PRs must not break existing replay traces
- All PRs must respect the three-stratum architecture

## Crate Guidelines

- Each crate has a single, clearly defined responsibility
- Crates may only depend on crates below them in the layer stack
- No circular dependencies
- No hidden side effects

## Commit Messages

Use conventional commits:
- `feat(crate-name): description`
- `fix(crate-name): description`
- `docs: description`
- `test: description`
- `chore: description`

---

## How to Add a New Invariant

Invariants are the load-bearing properties of Labyrinth-OS. Every new invariant
follows this exact pattern — no shortcuts.

### Step 1: Add to INVARIANTS.md

Document the invariant with:
- **Number** (next available I-number)
- **Statement** (precise, falsifiable)
- **Enforcement location** (full relative path)
- **Evidence** (test name or proof reference)

Example:
```
## I19 — Example Invariant
**Statement:** Every execution must produce exactly one ledger entry.
**Enforced by:** `execution/ledger/hashchain.py` — append() is called once per receipt.
**Evidence:** `test_hybrid_enforcement.py::_test_invariants_hold_across_healing_cycles`
```

### Step 2: Add runtime enforcement

Add a runtime assertion in the appropriate module. The assertion must:
- Raise a specific exception type (ValueError for data errors, SystemError for hard stops)
- Include the invariant number in the error message ("I19 VIOLATION: ...")
- Be fail-closed: on any error, block rather than allow

Example:
```python
# In the relevant module
if not condition:
    raise ValueError(
        f"I19 VIOLATION: every execution must produce exactly one ledger entry. "
        f"Got {count} entries for receipt {receipt_id}."
    )
```

### Step 3: Add a test that proves the invariant holds

Add to the appropriate test file under `tests/`. The test must:
- Prove the invariant holds under normal conditions
- Prove the invariant fires (raises) when violated
- Be named `_test_i{number}_...` so it's findable

Example:
```python
def _test_i19_one_entry_per_execution() -> None:
    """I19: every execution produces exactly one ledger entry."""
    chain = HashChain()
    r = Receipt(receipt_id="test", module="test", action="TEST",
                verdict="EXECUTE", payload={}, prev_hash=chain.head_hash)
    chain.append(r)
    assert chain.count() == 1

def _test_i19_violation_detected() -> None:
    """I19: violation must raise, not silently pass."""
    # Test that the assertion fires correctly
    ...
```

### Step 4: Update KNOWN_GAPS.md if the invariant is not yet enforced

If the invariant is documented but not yet in code (e.g., requires hardware),
add it to KNOWN_GAPS.md with status OPEN and the condition under which it closes.

### Step 5: Run the full test suite

```bash
cd Sentinel-Substrate--main && python3 run_all.py
```

All 1,556+ tests must pass before merging a new invariant.


---

## Architecture Updates — May 2026

The following additions are now part of the core architecture:

**Gate verification is now dual-axis:**
Rule 1: Sigma Anchor channels (tau, chi, drift, betti_1, confidence) — sensor gate.
Rule 2: LogicalSentinel predicate layer (Φ1, Φ2, Φ3) — formal gate.
Both must pass. Any contribution that bypasses either axis violates Rule 12 (no bypass flags).

**Promotion has six rules:**
Rule 0: PROMOTION_RACE check (CLASS-11 TM-001) — in-flight label_id detection.
Rule 0.5: Memory amplification (±0.05 confidence from history).
Rules 1-5: confidence, harness, failure rate, contradiction, consecutive runs.
Rule 6: EBF native polarity check — reasoning_text kwarg must be passed by callers.

**Replay is exact-only:**
EQUIVALENT mode has been removed. chain_entries is mandatory.
Any contribution that weakens this invariant will be rejected.

**Constitutional deadlock has a resolution path:**
circuit_breaker.py provides CLOSED/HALF_OPEN/OPEN states.
DegradationDetector provides HEALTHY/WARNING/ANOMALY states.
These are not yet wired into ignition.py — wiring is a legitimate contribution.

**Epistemic label is a first-class field:**
Every IgnitionEntry now carries epistemic_label and epistemic_conf.
Contributions that add new trial types must carry this field.
