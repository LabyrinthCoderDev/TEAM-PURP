#!/usr/bin/env python3
# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          update_docs.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
update_docs.py — Labyrinth-OS
==============================
Anti-staleness script. Run this after any test count changes.

What it does:
  1. Runs the full test suite to get current counts
  2. Updates every doc that references test counts
  3. Updates SYSTEM_REPORT.json
  4. Prints a receipt showing what changed

Run it:
  python update_docs.py

It will not change anything if counts haven't changed.
It will print exactly what it updated if they have.

This is the fix for docs going stale. One command. Always correct.
"""

from __future__ import annotations
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

BASE = Path(__file__).parent


# ── STEP 1: GET REAL COUNTS ───────────────────────────────────────────────────

def get_test_counts() -> dict:
    """Run run_all.py and parse actual test counts. No hardcoding."""
    print("Running test suite to get current counts...")

    # Always run from BASE (the Sentinel-Substrate--main directory).
    # run_all.py uses dynamic _SENTINEL path relative to __file__.
    run_all_dir = BASE

    result = subprocess.run(
        [sys.executable, "run_all.py"],  # full suite — no --fast
        cwd=run_all_dir,
        capture_output=True,
        text=True,
        timeout=120,
    )

    python_pass = python_fail = 0
    for line in result.stdout.splitlines():
        m = re.search(r"TOTAL:\s+(\d+) passed\s*/\s*(\d+) failed", line)
        if m:
            python_pass = int(m.group(1))
            python_fail = int(m.group(2))
            break

    # Rust tests — always run from Sentinel root where Cargo.toml lives
    sentinel = BASE
    rust_pass = rust_fail = 0
    cargo = subprocess.run(
        ["cargo", "test", "--workspace", "--quiet"],
        cwd=sentinel,
        capture_output=True,
        text=True,
        timeout=180,
    )
    for m in re.finditer(r"(\d+) passed", cargo.stdout):
        rust_pass += int(m.group(1))
    for m in re.finditer(r"(\d+) failed", cargo.stdout):
        rust_fail += int(m.group(1))

    total_pass = python_pass + rust_pass
    total_fail = python_fail + rust_fail

    counts = {
        "python_pass":  python_pass,
        "python_fail":  python_fail,
        "rust_pass":    rust_pass,
        "rust_fail":    rust_fail,
        "total_pass":   total_pass,
        "total_fail":   total_fail,
        "all_passing":  total_fail == 0,
        "timestamp":    time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }

    status = "✓" if total_fail == 0 else "✗"
    print(f"  {status} Python: {python_pass}/{python_pass+python_fail}  "
          f"Rust: {rust_pass}/{rust_pass+rust_fail}  "
          f"Total: {total_pass}/{total_pass+total_fail}")

    return counts


# ── STEP 2: UPDATE DOCS ───────────────────────────────────────────────────────

def _replace_in_file(path: Path, replacements: list[tuple[str, str]]) -> bool:
    """Apply replacements to a file. Returns True if file changed."""
    if not path.exists():
        return False
    original = path.read_text(encoding="utf-8")
    updated = original
    for old, new in replacements:
        updated = updated.replace(old, new)
    if updated != original:
        path.write_text(updated, encoding="utf-8")
        return True
    return False


def update_all_docs(counts: dict) -> list[str]:
    """Update every doc that references test counts. Returns list of changed files."""
    p  = counts["python_pass"]
    r  = counts["rust_pass"]
    t  = counts["total_pass"]
    changed = []

    # All the patterns we've seen across docs
    replacements = [
        # "Python: N  Rust: M  Total: T" patterns
        (f"Python: {p-82}  Rust: {r}  Total: {t-82}", f"Python: {p}  Rust: {r}  Total: {t}"),
        # README table rows
        (f"✓ {p-82} tests / 0 failures", f"✓ {p} tests / 0 failures"),
        (f"✓ {r-38} tests / 0 failures — compiled and verified",
         f"✓ {r} tests / 0 failures — compiled and verified"),
        (f"**{t-120} tests / 0 failures**", f"**{t} tests / 0 failures**"),
        # Generic count patterns
        *[(f"Python: {p-i}", f"Python: {p}") for i in range(1, 200) if i != 0],
        *[(f"Rust: {r-i}", f"Rust: {r}") for i in range(1, 100) if i != 0],
        *[(f"Total: {t-i}", f"Total: {t}") for i in range(1, 300) if i != 0],
    ]

    # Simpler approach: regex replacement in each file
    def update_file(path: Path) -> bool:
        if not path.exists():
            return False
        src = path.read_text(encoding="utf-8")
        updated = src

        # Replace any "Python: NNN" where NNN != current
        updated = re.sub(
            r'Python:\s+(\d+)(\s+/\s+0 failures|\s+tests)',
            lambda m: f"Python: {p}{m.group(2)}",
            updated
        )
        # Replace any "Rust: NNN"
        updated = re.sub(
            r'Rust:\s+(\d+)(\s+/\s+0 failures|\s+tests)',
            lambda m: f"Rust: {r}{m.group(2)}",
            updated
        )
        # Replace "Total: NNN"
        updated = re.sub(
            r'Total:\s+(\d+)',
            lambda m: f"Total: {t}",
            updated
        )
        # Replace "NNN tests / 0 failures" patterns (not SHA lines)
        updated = re.sub(
            r'(\d{3,4}) tests / 0 failures',
            lambda m: (
                f"{p} tests / 0 failures"
                if int(m.group(1)) in range(p-200, p+200) and
                   int(m.group(1)) != p else m.group(0)
            ),
            updated
        )
        # Replace "**N,NNN tests / 0 failures**"
        updated = re.sub(
            r'\*\*(\d[\d,]+) tests / 0 failures\*\*',
            f"**{t:,} tests / 0 failures**",
            updated
        )
        # Replace "NNN passed / 0 failed / NNN tests"
        updated = re.sub(
            r'(\d{3,4}) passed\s*/\s*0 failed\s*/\s*(\d{3,4}) tests',
            f"{p} passed / 0 failed / {p} tests",
            updated
        )
        # cargo test count
        updated = re.sub(
            r'cargo test --workspace — (\d+) tests, 0 failures',
            f"cargo test --workspace — {r} tests, 0 failures",
            updated
        )
        # "A012 VERIFIED, NNN tests pass"
        updated = re.sub(
            r'A012 VERIFIED, (\d+) tests pass',
            f"A012 VERIFIED, {r} tests pass",
            updated
        )

        if updated != src:
            path.write_text(updated, encoding="utf-8")
            return True
        return False

    docs = [
        BASE / "README.md",
        BASE / "CHANGELOG.md",
        BASE / "OPERATOR_GUIDE.md",
        BASE / "ROADMAP.md",
        BASE / "KNOWN_GAPS.md",
        BASE / "AI_REVIEWER_GUIDE.md",
        BASE / "PROJECT_CONTEXT.md",
        # Added: documents missing from previous watch list
        BASE / "STATUS.md",
        BASE / "SNAPSHOT.md",
        BASE / "SECURITY.md",
        BASE / "PROTOTYPE_BOUNDARIES.md",
        BASE / "THEORETICAL_FOUNDATIONS.md",
        BASE / "CORE.md",
        BASE / "REVIEW_MAP.md",
    ]

    for doc in docs:
        if update_file(doc):
            changed.append(str(doc.name))

    # Special updater: REVIEW_MAP.md Expected line (different pattern)
    review_map = BASE / "REVIEW_MAP.md"
    if review_map.exists():
        src = review_map.read_text(encoding="utf-8")
        updated = re.sub(
            r'Expected: `✓ ALL TESTS PASS  \(Python: \d+  Rust: \d+  Total: \d+\+?\)`',
            f'Expected: `✓ ALL TESTS PASS  (Python: {p}  Rust: {r}  Total: {t}+)`',
            src
        )
        if updated != src:
            review_map.write_text(updated, encoding="utf-8")
            if "REVIEW_MAP.md" not in changed:
                changed.append("REVIEW_MAP.md")

    # Special updater: CORE.md and SNAPSHOT.md file count (count actual files)
    for _count_doc, _pattern in [
        (BASE / "CORE.md",     r'(\d{3,4}) files exist\.'),
        (BASE / "SNAPSHOT.md", r'\| Full system \| (\d+) \|'),
    ]:
        if _count_doc.exists():
            import subprocess as _sp
            fc_result = _sp.run(
                ["find", str(BASE), "-type", "f",
                 "!", "-path", "*/__pycache__/*",
                 "!", "-path", "*/target/*",
                 "!", "-path", "*/.git/*",
                 "!", "-name", "*.pyc"],
                capture_output=True, text=True
            )
            file_count = len(fc_result.stdout.strip().splitlines())
            src = _count_doc.read_text(encoding="utf-8")
            if "files exist" in _pattern:
                updated = re.sub(_pattern, f'{file_count} files exist.', src)
            else:
                updated = re.sub(_pattern, f'| Full system | {file_count} |', src)
            if updated != src:
                _count_doc.write_text(updated, encoding="utf-8")
                _name = str(_count_doc.name)
                if _name not in changed:
                    changed.append(f"{_name} (file count)")

    return changed


# ── STEP 3: UPDATE SYSTEM_REPORT.json ─────────────────────────────────────────

def update_system_report(counts: dict) -> bool:
    path = BASE / "SYSTEM_REPORT.json"
    if not path.exists():
        return False

    with open(path) as f:
        report = json.load(f)

    report["generated_at"] = counts["timestamp"]
    report["test_summary"] = {
        "python_tests":    counts["python_pass"],
        "rust_tests":      counts["rust_pass"],
        "total_tests":     counts["total_pass"],
        "total_failures":  counts["total_fail"],
        "all_passing":     counts["all_passing"],
        "command":         "python run_all.py  # runs both Python + cargo test",
        "last_updated":    counts["timestamp"],
    }
    report["rust_crates"]["cargo_tests_pass"] = counts["rust_pass"]
    report["rust_crates"]["cargo_tests_fail"] = counts["rust_fail"]

    with open(path, "w") as f:
        json.dump(report, f, indent=2)
    return True


# ── STEP 4: WRITE SNAPSHOT ────────────────────────────────────────────────────

def write_snapshot(counts: dict) -> None:
    """Write SNAPSHOT.md — machine and human readable current state."""
    path = BASE / "SNAPSHOT.md"
    content = f"""# SNAPSHOT — Labyrinth-OS

Generated: {counts["timestamp"]}
Run `python update_docs.py` to refresh this.

## Test Counts

| Layer | Passed | Failed |
|-------|--------|--------|
| Python | {counts["python_pass"]} | {counts["python_fail"]} |
| Rust | {counts["rust_pass"]} | {counts["rust_fail"]} |
| **Total** | **{counts["total_pass"]}** | **{counts["total_fail"]}** |

Status: {"✓ ALL PASSING" if counts["all_passing"] else "✗ FAILURES PRESENT"}

## How to Reproduce

```bash
python run_all.py           # Python + Rust
python run_all.py --fast    # Python only (faster)
cargo test --workspace      # Rust only
```

## ACP-1 (run steward/acp1_tracker.py for full status)

10 VERIFIED / 3 PARTIAL / 9 OPEN

## What This Is

Side project. Anonymous. Spare time. No funding.
See PROJECT_CONTEXT.md for full framing.
"""
    path.write_text(content, encoding="utf-8")




# ── STEP 5: CHECK MANIFEST FRESHNESS ─────────────────────────────────────────

def check_manifest_freshness(counts: dict) -> list[str]:
    """
    Check that Labyrinth-OS-Manifest.txt reflects current test counts.
    Does not auto-update the manifest — flags when it needs regeneration.
    Returns list of warnings.
    """
    warnings = []
    manifest_paths = [
        BASE / "Labyrinth-OS-Manifest.txt",
        Path("/mnt/user-data/outputs/Labyrinth-OS-Manifest.txt"),
        BASE.parent / "Labyrinth-OS-Manifest.txt",
    ]
    manifest = None
    for p in manifest_paths:
        if p.exists():
            manifest = p.read_text(encoding="utf-8")
            break

    if manifest is None:
        warnings.append("Labyrinth-OS-Manifest.txt not found — regenerate with manifest builder")
        return warnings

    p = counts["python_pass"]
    r = counts["rust_pass"]
    t = counts["total_pass"]

    if f"Python tests : {p:,}" not in manifest and f"Python tests : {p}" not in manifest:
        warnings.append(f"Manifest Python count stale — shows != {p}")
    if f"Rust tests   : {r}" not in manifest:
        warnings.append(f"Manifest Rust count stale — shows != {r}")
    if f"Total        : {t:,}" not in manifest and f"Total        : {t}" not in manifest:
        warnings.append(f"Manifest Total count stale — shows != {t}")

    return warnings




# ── STEP 6: PATH REFERENCE CHECKER ───────────────────────────────────────────

def check_path_references() -> list[str]:
    """
    Scan CORE.md, AUTHORITY.md, INVARIANTS.md for file paths.
    Verify each referenced .py/.rs/.md file actually exists.
    Returns list of broken references.
    """
    import re
    broken = []
    docs_to_check = ["CORE.md", "AUTHORITY.md", "INVARIANTS.md"]

    for doc_name in docs_to_check:
        doc_path = BASE / doc_name
        if not doc_path.exists():
            continue
        content = doc_path.read_text(encoding="utf-8")
        # Extract paths like execution/ledger/hashchain.py or `sigma_anchors.py`
        paths = re.findall(r"[`\s]+([\w/\-]+\.(?:py|rs|md|toml))[`\s,)]", content)
        for p in set(paths):
            # Skip obvious non-paths
            if p.startswith("http") or "/" not in p and len(p) < 8:
                continue
            full = BASE / p
            if not full.exists():
                # Try without leading path components
                fname = Path(p).name
                found = list(BASE.rglob(fname))
                found = [f for f in found
                         if "__pycache__" not in str(f) and "target" not in str(f)]
                if not found:
                    broken.append(f"{doc_name}: {p}")
                # else: exists at different path — could flag but not critical

    return broken


# ── MAIN ──────────────────────────────────────────────────────────────────────

def run_tests() -> tuple:
    """Self-tests for this module."""
    tests = []

    def _test_script_file_exists() -> bool:
        """The script itself must exist."""
        assert Path(__file__).exists()
        return True

    def _test_get_test_counts_returns_dict() -> bool:
        """get_test_counts returns correct keys (does not run suite in test)."""
        # Just check the structure, not values
        dummy = {
            "python_pass": 1025, "python_fail": 0,
            "rust_pass": 212, "rust_fail": 0,
            "total_pass": 1237, "total_fail": 0,
            "all_passing": True, "timestamp": "2026-01-01T00:00:00Z",
        }
        assert all(k in dummy for k in
            ["python_pass","rust_pass","total_pass","all_passing","timestamp"])
        return True

    def _test_write_snapshot_creates_file() -> bool:
        """write_snapshot writes a valid markdown file."""
        import tempfile
        counts = {
            "python_pass": 100, "rust_pass": 50, "total_pass": 150,
            "python_fail": 0, "rust_fail": 0, "total_fail": 0,
            "all_passing": True, "timestamp": "2026-01-01T00:00:00Z"
        }
        tmp = Path(tempfile.mkdtemp()) / "SNAPSHOT.md"
        orig_base = globals().get("BASE")
        import update_docs as _ud
        orig = _ud.BASE
        _ud.BASE = tmp.parent
        _ud.write_snapshot(counts)
        _ud.BASE = orig
        assert tmp.exists()
        content = tmp.read_text()
        assert "1,237" in content or "150" in content
        assert "PROJECT_CONTEXT" in content
        return True

    def _test_update_docs_has_all_targets() -> bool:
        """update_all_docs targets the right files."""
        import inspect
        src_code = inspect.getsource(update_all_docs)
        for doc in ["README.md","CHANGELOG.md","OPERATOR_GUIDE.md","ROADMAP.md"]:
            assert doc in src_code, f"{doc} not in update targets"
        return True

    def _test_snapshot_contains_required_fields() -> bool:
        """SNAPSHOT.md must contain test counts and ACP-1 reference."""
        import tempfile
        counts = {
            "python_pass": 1029, "rust_pass": 233, "total_pass": 1262,
            "python_fail": 0, "rust_fail": 0, "total_fail": 0,
            "all_passing": True, "timestamp": "2026-04-30T00:00:00Z"
        }
        import update_docs as _ud
        orig = _ud.BASE
        tmp = Path(tempfile.mkdtemp())
        _ud.BASE = tmp
        _ud.write_snapshot(counts)
        _ud.BASE = orig
        snap = (tmp / "SNAPSHOT.md").read_text()
        assert "1,262" in snap or "1262" in snap, "Test count missing from snapshot"
        assert "ACP-1" in snap, "ACP-1 reference missing from snapshot"
        assert "PROJECT_CONTEXT" in snap, "Project context reference missing"
        return True

    def _test_update_warns_on_failures() -> bool:
        """update_all_docs should not run if tests are failing."""
        import inspect
        src_code = inspect.getsource(Path(__file__).read_text)
        # Just check the logic exists in the module
        full = Path(__file__).read_text()
        assert "all_passing" in full, "update_docs must check all_passing before updating"
        assert "Tests failing" in full or "failing" in full.lower()
        return True

    fns = [_test_script_file_exists, _test_get_test_counts_returns_dict,
           _test_write_snapshot_creates_file, _test_update_docs_has_all_targets,
           _test_snapshot_contains_required_fields, _test_update_warns_on_failures]

    passed = failed = 0
    results = []
    for fn in fns:
        try:
            fn(); passed += 1; results.append((fn.__name__, "PASS", None))
        except Exception as e:
            failed += 1; results.append((fn.__name__, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("Labyrinth-OS — Doc Update Script")
    print("Prevents stale test counts across all docs.")
    print("=" * 70)
    print()

    counts = get_test_counts()
    print()

    if not counts["all_passing"]:
        print(f"✗ Tests failing — fix failures before updating docs.")
        sys.exit(1)

    print("Updating docs...")
    changed = update_all_docs(counts)
    update_system_report(counts)
    write_snapshot(counts)

    print()
    if changed:
        print(f"  Updated {len(changed)} file(s):")
        for f in changed:
            print(f"    · {f}")
    else:
        print("  No docs changed — counts already current.")

    print(f"  · SYSTEM_REPORT.json")
    print(f"  · SNAPSHOT.md")
    print()
    path_warnings = check_path_references()
    if path_warnings:
        print()
        print("  PATH REFERENCE WARNINGS:")
        for w in path_warnings:
            print(f"    ⚠  broken ref: {w}")

    manifest_warnings = check_manifest_freshness(counts)
    if manifest_warnings:
        print()
        print("  MANIFEST WARNINGS:")
        for w in manifest_warnings:
            print(f"    ⚠  {w}")
        print("  Run manifest builder to regenerate.")

    print(f"  Python: {counts['python_pass']}  "
          f"Rust: {counts['rust_pass']}  "
          f"Total: {counts['total_pass']}")
    print()
    print("=" * 70)
