# Reviewer Guide — Labyrinth-OS

---

## Start Here

Read `PROTOTYPE_BOUNDARIES.md` before anything else.
It defines what "verified" means in this repo. Not all claims are equal:

| Tag | Meaning |
|-----|---------|
| Z3-PROVEN | Machine-checked. Unconditionally true given the model. |
| TEST-VERIFIED | Passes the test suite. True under tested conditions. |
| PROTOTYPE-WIRED | Code exists and runs on mock/stub inputs. Not yet on live data. |
| NOT YET DEMONSTRATED | Designed. Not yet run against real inputs. |

A lot of the strongest-sounding language in the documentation lives in PROTOTYPE-WIRED territory. That is not a defect — it is the honest state of a prototype. But it is the reviewer's job to notice which category a given claim falls into.

---

## What This Is

Labyrinth-OS is a mathematical enforcement substrate for AI systems.

The model proposes. The system enforces. Every proposal passes through a mandatory
pipeline before anything executes. Every execution is logged to an immutable,
hash-chained ledger that can be replayed exactly.

It is a prototype — an experiment in making AI execution structurally auditable
rather than philosophically trusted. The pipeline shape is proven. The live loop
is not closed. The gap between those two things is documented in KNOWN_GAPS.md.

---

## The Core Architecture

Two lanes. One crossing point. No exceptions.

**Lane 1 (Epistemic):** The model generates and proposes. Nothing executes here.

**Lane 2 (Execution):** Validated proposals become deterministic actions. Everything
is logged, replayable, and tamper-evident.

**The Reality Gate (L09):** The only bridge between lanes. Mandatory. Pre-execution.
Fatal if bypassed in production. The mock runtime (ignition.py --backend mock) uses
local stubs for some stages — see GAP 1 in KNOWN_GAPS.md.

---

## Evaluating the Claims

**What is formally verified (Z3-PROVEN):**
- Sigma Anchor threshold constants are internally consistent (A021, z3_sovereignty_spec.py)
- Promotion rules are non-vacuous, sound, deterministic (z3_promotion_proof.py, PR1-PR8)
- Predicate invariants Φ1/Φ2/Φ3 are non-vacuous, independent, consistent (z3_predicate_proof.py, PP1-PP9)

These proofs are real. They prove what they claim. They do not prove the whole system is safe — see PROTOTYPE_BOUNDARIES.md for exactly what each proof covers.

**What is test-verified:**
- Pipeline ordering (I1-I19)
- Hash chain integrity
- Exact replay (EQUIVALENT mode removed — absent chain_entries raises SystemError)
- 11 TM-001 attack classes have detection tests
- 29 Rust crates build and test clean

**What is prototype-wired (not yet on live data):**
- GAP 1: ignition.py stubs for Archive/Promotion/Reality Gate stages
- GAP 7: Semantic replay — structural only, not correctness verification
- Predicate extraction calibration — pattern-based, not calibrated to live LLM outputs

**What is not yet demonstrated:**
- A010: Live inference with real API key
- A014: Hardware enforcement (FPGA + ATECC608B)
- A020: Red-team harness against live system

---

## The Boundary That Matters Most

The gate blocks proposals whose Sigma Anchor readings cross formal thresholds.
It also blocks proposals that fail predicate verification (Φ1/Φ2/Φ3).

What it does NOT do: block a sophisticated adversarial proposal whose sensor
readings stay within thresholds and whose reasoning appears structurally clean.
Such a proposal is logged but not stopped.

This is documented in SECURITY.md as the "Detection vs. Blocking" boundary.
It is not a bug. It is an honest limit. The question for reviewers is whether
the documentation accurately characterizes this limit and its implications.

---

## What Has Been Formally Verified

| Claim | Status | Evidence |
|-------|--------|---------|
| Sigma Anchor thresholds consistent | Z3-PROVEN | z3_sovereignty_spec.py, A021 |
| Promotion rules sound | Z3-PROVEN | z3_promotion_proof.py PR1-PR8 |
| Predicate invariants sound | Z3-PROVEN | z3_predicate_proof.py PP1-PP9 |
| Pipeline ordering enforced | TEST-VERIFIED | I1-I19, PipelineTrace |
| Ledger tamper-evident | TEST-VERIFIED | hashchain.verify(), forced-fail tests |
| Exact replay works | TEST-VERIFIED | replay_validator.py |
| 11 attack classes detectable | TEST-VERIFIED | threat_model.py |
| Rust parity (static) | TEST-VERIFIED | cargo test --workspace |
| Live inference correct | NOT YET DEMONSTRATED | A010 OPEN |
| Adapter calibration accurate | NOT YET DEMONSTRATED | post-A010 |
| Hardware enforcement | NOT YET DEMONSTRATED | A014 OPEN |

10 of 22 ACP-1 assumptions VERIFIED. 3 PARTIAL. 9 OPEN.
Full status with evidence: `steward/acp1_tracker.py`

---

## How to Run It

```bash
python run_all.py     # 1,556 Python + 249 Rust = 1,700+ total
python runtime/ignition.py --backend mock --model mock-model-v1 --trials 5
python runtime/verify_run.py ignition_session_<ts>.json
```

Expected: `✓ ALL TESTS PASS  (Python: 1556  Rust: 249  Total: 1700+)`

---

## Where the Interesting Problems Are

If you want to find something genuinely new, look here:

1. **Predicate extraction calibration** — the five pattern matchers (SOURCE/RISK/VERIFICATION/LOOP/UNCERTAINTY) are heuristic. Are they correctly specified? Can you construct a well-formed adversarial proposal that passes all five?

2. **The operator problem** — software can express the constitution. Hardware makes violation expensive. But who sets the software? A motivated operator with system access can alter thresholds before A014 arrives. Is this boundary stated correctly and completely?

3. **Epistemic label faithfulness** — EpistemicLabeler now runs on every ignition trial. The label is recorded. Does the label correctly represent the model's epistemic state? Is the classification heuristic sound?

4. **Cross-language runtime parity** — GAP R4. The Rust and Python layers share constants and agree on static tests. But there is no test that feeds the same proposal to both and compares runtime decisions. Is this gap characterized correctly?

---

## Token-Efficient Review

`CORE.md` lists the ~20 files that actually matter.
Reading those is sufficient for a structural evaluation.

The full system is 757 files. Most of it is scaffolding, tests, research, and documentation. Do not let volume substitute for signal.

---

Contact: X: @LabyrinthCoder
