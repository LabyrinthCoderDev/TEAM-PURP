#!/bin/bash
# quickstart.sh — Labyrinth-OS
# Single command that builds, tests, and runs a mock ignition.
# Proves the environment is set up correctly.
#
# Usage: bash quickstart.sh

set -e
echo "========================================"
echo "LABYRINTH-OS QUICKSTART"
echo "========================================"

echo ""
echo "Step 1: Checking Python..."
python3 --version || { echo "ERROR: Python 3 required"; exit 1; }

echo ""
echo "Step 2: Checking Rust..."
cargo --version 2>/dev/null || echo "WARNING: Rust not found — Rust tests will be skipped"

echo ""
echo "Step 3: Running full Python test suite..."
cd "$(dirname "$0")/cathedral-os/cgir"
python3 run_all.py --fast
echo "✓ Python tests passed"

echo ""
echo "Step 4: Running Rust tests (if available)..."
cd "$(dirname "$0")/SENTINEL_ORGANIZE/Sentinel-Substrate--main"
cargo test --workspace 2>/dev/null && echo "✓ Rust tests passed" || echo "SKIP: Rust not available"

echo ""
echo "Step 5: Running mock ignition (no API key needed)..."
cd "$(dirname "$0")/SENTINEL_ORGANIZE/Sentinel-Substrate--main"
python3 runtime/ignition.py --backend mock --model mock-model-v1 --trials 3
echo "✓ Mock ignition passed"

echo ""
echo "========================================"
echo "SUCCESS — Labyrinth-OS environment ready"
echo "Next step: export ANTHROPIC_API_KEY=... and run with --backend anthropic"
echo "========================================"
