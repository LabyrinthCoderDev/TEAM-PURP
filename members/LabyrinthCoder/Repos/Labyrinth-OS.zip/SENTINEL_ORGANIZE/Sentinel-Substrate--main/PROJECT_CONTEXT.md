# Labyrinth-OS

**A mathematical enforcement substrate for AI systems.**

> *"This is not alignment-by-training or safety-by-prompting. It is safety-by-structure."*
> — Independent external review, May 2026

> *"A generalized constitutional control substrate for systems that generate proposals
> but must not be allowed to act without structural validation."*
> — Multiple independent AI analyses, May 2026

---

## What Was Built

Every AI system has the same structural problem: the model generates outputs,
and something has to decide whether those outputs become actions. That decision
is usually implicit — a prompt, a guideline, a human in the loop, or nothing at all.

Labyrinth-OS makes that decision **explicit, structural, and auditable**.

This is a **mathematical constitution for AI agents**. The code is the syntax.
The semantics are logic, algebra, and proof theory.

- The gate is a mathematical function: proposal × evidence → {ALLOW, BLOCK}
- The ledger is an algebraic construction: h_n = SHA256(h_{n-1} || entry_n)
- The thresholds are a Z3-proven constraint set — not heuristics, a machine-checked proof
- The invariants are predicates over system state — violations are SystemError, not warnings
- Determinism is a contract: same inputs → same outputs always, everywhere

**The gate doesn't negotiate because math doesn't negotiate.**

---

## The Core Problem This Solves

Most AI safety approaches work inside the model's reasoning space. Experimental
evidence (March 2026, 28 sessions, 72 bootstrap runs) proves the geometric structure
of a latent space cannot distinguish correct reasoning from well-constructed deception.
p=0.948. Indistinguishable from inside.

Labyrinth-OS works **outside** that space. Two independent verification axes:

1. **Sigma Anchor channels** — geometric/sensor: tau_escape, chi, drift, betti_1,
   confidence. Z3-proven internally consistent (A021).
2. **Predicate layer** — logical/formal: five predicates extracted from chain-of-thought,
   three Z3 invariants verified. Independent of sensor readings.

Both must pass. Neither is sufficient alone.

---

## The Core Pattern

**Imagination and execution must be separated by a formal crossing point.**

Lane 1 is the epistemic lane — where the model generates, reasons, and proposes.
Nothing in Lane 1 executes. It is a free space for ideas.

Lane 2 is the execution lane — where validated proposals become deterministic actions.
Nothing enters Lane 2 without crossing the Reality Gate.

The Reality Gate is the only bridge between lanes. It is mandatory, pre-execution,
and fatal if bypassed. This single architectural decision is what makes the system
structurally sound rather than philosophically aspirational.

This pattern — dual lane, single crossing, formal gate, immutable ledger — is not
specific to LLMs. It applies to any system where proposals must be validated before
execution.

---

## What Makes This Unusual

Most safety approaches are layered on top of existing systems.
This is a substrate — the enforcement layer is the foundation, not an addition.

Most audit systems log what happened.
This system enforces what can happen before it happens, then logs it anyway.

Most systems have informal authority.
This system has one authority per decision type, formalized in code.

The assumption tracker (ACP-1) holds 22 specific claims — each with VERIFIED,
PARTIAL, or OPEN status, falsification criteria, and epistemic layer classification
(LAYER_I proven / LAYER_II wired / LAYER_III future). When a parent assumption opens,
all downstream dependents automatically flag AT_RISK. Hidden fragility is made visible.

The gaps are documented in KNOWN_GAPS.md, not hidden. The honest boundary:
the gate is the last formal line of defense at execution time. Pre-execution
contamination (weight poisoning, training data manipulation) is upstream of the gate
and outside current scope — acknowledged explicitly as GAP 13.

---

## Three Independent Convergences

Three researchers arrived at structurally identical conclusions from different starting points:

- **Experimental deception detection** — proved geometry cannot judge, built predicate
  verification + Z3 + kernel enforcement independently. Same architecture, different entry.
- **Discrete cellular physics** — same three-tier decision structure, chi aggregate leak
  fix contributed (three-layer hybrid now running in production).
- **Constitutional governance** — this project. Built from the gate outward.

The convergence is meaningful. The pattern appears constrained by the problem, not by preference.

---

## What a Rebuild Would Look Like

Stripped to the essential pattern, a production version needs five things:

1. **Lane separation** — proposals and executions cannot share state
2. **A single crossing point** — one gate, mandatory, with formal criteria
3. **A typed execution graph** — proposals become formal structures before execution
4. **An immutable ledger** — append-only, hash-chained, exact replay verified
5. **A formal assumption register** — what the system claims, evidence for each claim

Everything else in this prototype is supporting infrastructure for those five things.

---

## Current State

**1,556 Python tests. 249 Rust tests. 1,700+ total. 0 failures.**
29 Rust crates compile and test clean.
10 of 22 architectural assumptions VERIFIED by concrete evidence and tests.
A021 is the only Z3-proven claim. All others are TEST-VERIFIED or PROTOTYPE-WIRED.
See PROTOTYPE_BOUNDARIES.md for the complete taxonomy.

This is a prototype. It demonstrates the pattern. It is not production software.

Full technical detail: `ARCHITECTURE.md`, `THEORETICAL_FOUNDATIONS.md`
Assumption tracking: `steward/acp1_tracker.py` + `steward/acp1_dependency_graph.py`
Contact: X: @LabyrinthCoder

---

## Cross-Domain Applicability

The five Sigma Anchor channels (tau, chi, drift, betti_1, confidence) are abstract
variables any domain can populate through a domain adapter. Same substrate, same gate,
same ledger, same healing loop, same exact replay, same audit trail.

- **AI governance** (current): tau = token escape ratio, chi = contradiction density
- **Industrial automation**: tau = machine health, chi = parameter drift variance
- **Medical decision support**: tau = diagnostic certainty, chi = treatment conflict density
- **Financial systems**: tau = position confidence, chi = portfolio correlation
- **Autonomous vehicles**: tau = trajectory safety margin, chi = sensor agreement density

Same constitutional substrate. Different domain adapters feeding the five channels.
