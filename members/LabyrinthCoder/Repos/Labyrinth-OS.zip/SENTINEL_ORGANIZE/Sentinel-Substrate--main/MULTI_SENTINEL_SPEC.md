# MULTI_SENTINEL_SPEC.md — Labyrinth-OS Phase 11

## Distributed Topology — Xi-Jensen Pattern

**Classification:** LAYER_III — conditional on Layer II holding under live conditions.
**Status:** DESIGN SPEC — not yet built. Requires A010 first.
**Dependency:** Single-sentinel deployment must be stable before distribution.

---

## Why Distribution Becomes Necessary

The current architecture has one Reality Gate. That is architecturally elegant
and auditable. It is also a single point of failure:

- Gate failure (bug, DoS, misconfiguration) stops all proposals
- No Byzantine fault tolerance — a corrupted gate corrupts everything
- No quorum — one operator can alter one gate and affect all enforcement

At scale, or under adversarial pressure, a single gate becomes a target.
Phase 11 addresses this by distributing the gate across multiple sentinel nodes
with Byzantine consensus before any proposal executes.

---

## The Xi-Jensen Pattern

The Xi-Jensen pattern (available in archive `xi_jensen_pipeline/`) solves
the multi-sentinel merging problem for heterogeneous signal sources.

Core insight: multiple sentinels produce independent Sigma Anchor readings.
These readings must be merged into a single gate decision without any single
sentinel being able to corrupt the outcome.

### Quorum Structure

```
Proposal
  ├── Sentinel-A: Sigma readings → decision_A (EXECUTE/BLOCK/KILL)
  ├── Sentinel-B: Sigma readings → decision_B
  └── Sentinel-C: Sigma readings → decision_C
            │
            ▼
      Byzantine Council
        (2/3 quorum required)
            │
            ▼
       Final Decision → CGIR → AEGIS → Ledger
```

**Quorum rule:** A proposal executes only if ≥ 2/3 of sentinels vote EXECUTE.
**Safety rule:** Any single KILL vote from any sentinel → proposal killed.
**Liveness rule:** If quorum is not reached within timeout → BLOCK (fail-closed).

### Why 2/3 and Not Simple Majority

Byzantine fault tolerance requires f < n/3 corrupted nodes for safety.
With 3 sentinels: tolerate 0 Byzantine failures.
With 4 sentinels: tolerate 1 Byzantine failure.
With 7 sentinels: tolerate 2 Byzantine failures.

Minimum viable deployment: 3 sentinels (no Byzantine tolerance, but no single
point of failure for availability). Production deployment: 4+ sentinels.

---

## Sentinel Independence Requirements

Each sentinel must be:

1. **Computationally independent** — separate process, separate address space
2. **Signal-path independent** — each sentinel reads from its own sensor chain
3. **Ledger-independent** — each sentinel maintains its own local chain
4. **Network-isolated** — sentinels communicate only through the Byzantine Council
5. **Time-synchronized** — logical clocks, not wall clocks (I17 applies per-sentinel)

Sentinels may run on the same machine for development but MUST be on
separate hardware for production deployments in security-sensitive contexts.

---

## Merged Ledger Architecture

Each sentinel produces its own local WORM ledger.
The Byzantine Council produces a merged global ledger.

**Local ledger:** Records each sentinel's individual decision process.
**Global ledger:** Records the quorum decision and the set of sentinel votes.
**Cross-reference:** Global ledger entry contains hashes of all contributing local entries.

This means replay has two levels:
- **Local replay:** Prove that sentinel-A's decision was internally consistent
- **Global replay:** Prove that the quorum decision correctly applied the 2/3 rule

Both levels must pass for a global replay to be CLEAN.

---

## Failure Modes and Responses

| Failure | Response |
|---------|---------|
| One sentinel crashes mid-proposal | Remaining sentinels continue; quorum with n-1 |
| One sentinel votes KILL, others EXECUTE | KILL wins — any KILL is final |
| Quorum timeout | BLOCK — fail-closed |
| Byzantine sentinel (arbitrary votes) | 4+ sentinel deployment tolerates 1 |
| Network partition between sentinels | BLOCK — cannot achieve quorum |
| All sentinels agree on BLOCK | BLOCK — unanimous |
| CircuitBreaker OPEN on one sentinel | That sentinel votes BLOCK; quorum decides |

---

## Integration with Current Architecture

The current single-sentinel architecture maps to Phase 11 as follows:

| Current | Phase 11 |
|---------|---------|
| IgnitionSession | SentinelNode (one per sentinel) |
| CGIRLedger (per session) | LocalLedger (per sentinel per session) |
| Reality Gate | ByzantineCouncil + merged vote |
| verify_run.py | GlobalReplayValidator (checks quorum log + local chains) |
| CircuitBreaker | Per-sentinel breaker; council aggregates |
| DegradationDetector | Per-sentinel; council tracks inter-sentinel agreement |

---

## Port from Xi-Jensen Archive

The Xi-Jensen pipeline (`archive/xi_jensen_pipeline/`) implements:
- `xi_merger.py` — merges heterogeneous signal vectors into a consensus signal
- `jensen_divergence_check.py` — detects when sentinel signals diverge beyond threshold
- `quorum_log.py` — Byzantine-fault-tolerant vote log with cryptographic anchoring

These are the building blocks. Phase 11 ports them into the Labyrinth-OS
architecture with the following adaptations:
1. Xi merger input becomes Sigma Anchor channel vectors (not generic signals)
2. Jensen divergence threshold triggers sentinel investigation (not just logging)
3. Quorum log becomes the merged global ledger (WORM, same hash chain rules)

---

## Minimum Viable Phase 11

The smallest deployable multi-sentinel configuration:

```
3 sentinels (A, B, C)
  Each runs: ignition.py → cgir_gate → guardian_slot → local_ledger
  Council: simple 2/3 vote (no Byzantine tolerance)
  Global ledger: merkle tree of local chain heads
  Replay: verify all three local chains + verify quorum log
```

This eliminates single-point-of-failure without full Byzantine tolerance.
Suitable for: internal deployments, research, proof-of-concept.

---

## What Must Not Change

**The gate contract is preserved regardless of distribution:**
- A proposal still crosses exactly one constitutional boundary
- KILL from any sentinel is still irrevocable
- The global ledger is still WORM and tamper-evident
- Replay is still exact (EQUIVALENT mode remains removed)
- The Reality Gate is still mandatory — distribution does not create shortcuts

The distributed architecture multiplies the gate, not bypasses it.

---

*X: @LabyrinthCoder | Phase 11 | Classification: LAYER_III*
