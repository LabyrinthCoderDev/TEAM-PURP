# Adversarial Validation — Labyrinth-OS

## What This Is

Tests that prove the system blocks what it should block, always.
Not just "does it work on clean input" — does it hold under attack.

## TM-001 Attack Classes (A017 VERIFIED — all 10/10)

| Attack | What It Does | Detected By |
|--------|-------------|-------------|
| CONFIDENCE_SPOOF | Perfect confidence to slip past gate | watcher_b (perfect confidence check) |
| GATE_EVASION | Arrange signals to look just below all thresholds | watcher_b (marginal sensor check) |
| INVARIANT_STRIP | Remove invariant bindings from CGIR graph | watcher_b (invariant audit) |
| PARTIAL_WRITE | Write incomplete ledger entry to break chain | hashchain (hash chain verify) |
| PHASE_SKIP | Skip a mandatory pipeline phase | replay_validator |
| REPLAY_ATTACK | Replay a valid past session to re-execute | hashchain (prev_hash mismatch) |
| SIGNAL_INJECTION | Inject a signal not from a known authority | watcher_b (emitter check) |
| SPLIT_BRAIN | Two watchers disagree — attacker exploits gap | council_resolver |
| TEMPORAL_SPLICE | Manipulate logical time to make old events appear new | watcher_b (temporal reset check) |
| TIME_ORDER_MANIP | Backwards logical_time sequence | watcher_b (ordering check) |

## Test File
`tests/adversarial/threat_model.py` — 15 tests, all passing.

## SCUEL Tests (A013 PARTIAL — needs live traffic to close)
`tests/integration/test_full_pipeline.py` — SCUEL synthetic tests:
- POLITE_LIE: high confidence + tau below floor
- SLOW_POISON: drift accumulation across threshold
- BURST: chi collapse
- COORDINATED: all sensors at warning margins
- Identity violation: unknown emitter
- Nominal baseline: clean signal passes

## What VERIFIED Means Here
VERIFIED = attack has a detection test that passes.
Not the same as "this attack has been attempted on a live system."
Live adversarial testing requires A010 (real inference) + A020 (red-team suite).
