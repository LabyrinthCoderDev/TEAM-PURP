# Input Constitution — IC-3 Architecture
## Training Provenance: What It Would Take
## Ω Cipher · June 2026

> GPT external review (J53):
> "The largest unanswered question is no longer 'Can the system reason about
> information?' The largest unanswered question is 'Can the system reason about
> the origin of information with the same rigor that it reasons about the
> information itself?'"
>
> This document designs the answer to that question at the IC-3 level.
> IC-3 is not currently implemented. This is a design sketch.

---

## The Three Input Constitution Layers

```
IC-1  Model Identity Attestation
      Current: SHA-256(provider:model:session) — DECLARED
      Target:  ATECC608B hardware attestation  — ATTESTED (A014)

IC-2  Input Provenance Chain
      Current: JSON chain of declared hops — DECLARED
      Target:  EDEN-signed chain per hop    — SIGNED (A018)

IC-3  Training Provenance (this document)
      Current: Acknowledged boundary — OPEN
      Target:  Ecosystem-level audit trail
```

---

## What IC-3 Is Trying To Answer

Every proposal the system evaluates is shaped by the model's training.
The gate evaluates whether the proposal is safe. The provenance chain
records where the specific inference came from. But neither answers:

**What assumptions are embedded in the model itself?**

A model trained on biased data will produce proposals that pass every
execution check and have valid provenance chains — yet encode systematic
errors from training. The POLITE_LIE attack (A020) demonstrates this at
a small scale: valid execution, valid structure, unknown origin. IC-3
is the ecosystem-level version of that problem.

---

## What IC-3 Would Require

### Component 1 — Model Lineage Record

A structured record accompanying every model artifact, stating:

```json
{
  "model_id":        "claude-3-5-sonnet-20241022",
  "base_model":      "claude-3-sonnet",
  "training_data":   [
    {"name": "Common Crawl 2024-Q1", "license": "CC0", "verified": false},
    {"name": "Internal RLHF", "license": "proprietary", "verified": false}
  ],
  "training_method": "RLHF + Constitutional AI",
  "cutoff_date":     "2024-04-01",
  "known_biases":    ["recency bias in factual claims", "Western-centric defaults"],
  "lineage_hash":    "sha256:abc123..."
}
```

**Why this doesn't exist today:** Model providers do not publish this level
of detail. Anthropic publishes model cards; they do not publish training
corpus manifests. This is an ecosystem gap, not a Labyrinth-OS gap.

**What Labyrinth-OS can do now:** Reserve a `model_lineage_hash` field
in IgnitionEntry that is currently empty but will hold this hash when
providers publish it. This costs nothing and creates the hook.

---

### Component 2 — Training Data Attestation

For each training data source, a cryptographic attestation that:
- The data was collected on date X
- Under license Y
- With content hash Z
- By organization W

This is equivalent to a software supply chain bill of materials (SBOM),
applied to training data. SBOM for AI training data (called "Data Cards"
in ML literature) exists in research form but is not standard practice.

**Dependency:** Requires either the model provider to publish data cards,
or independent audit capability (neither exists at scale for frontier models).

---

### Component 3 — Bias Attestation

A formal record of known biases in the model, analogous to how
Labyrinth-OS's KNOWN_GAPS.md documents known system gaps.

Example structure:
```python
@dataclass
class ModelBiasAttestation:
    model_id:        str
    bias_type:       str    # "recency", "geographic", "cultural", etc.
    direction:       str    # "overrepresents X", "underrepresents Y"
    severity:        str    # "LOW", "MEDIUM", "HIGH"
    evidence:        str    # Citation or test result
    mitigation:      str    # What the model provider did or recommends
    attested_by:     str    # Who made this attestation
    attested_at:     float
```

This would feed into gate logic: a model with a HIGH severity bias
toward a topic relevant to the current proposal might require additional
scrutiny before the proposal proceeds.

**Dependency:** Requires systematic bias testing. Labyrinth-OS could
implement its own bias probe battery (the ARC-AGI-2 pipeline in A016
is a step in this direction — abstract reasoning tests reveal systematic
gaps). Partially within current scope.

---

### Component 4 — Replay Provenance

When Labyrinth-OS replays from the Chronicle ledger (A014, L14), the
replayed proposals carry the provenance of their original run. This
needs to be explicitly marked:

```python
@dataclass
class ReplayProvenanceLink(ProvenanceLink):
    replay_from_session:  str    # Original session ID
    replay_from_seq:      int    # Original ledger sequence number
    replay_reason:        str    # "audit", "verification", "correction"
```

This is achievable now — ReplayProvenanceLink is a subclass of
ProvenanceLink and costs no ecosystem infrastructure.

---

## What Can Be Done Within Current Scope

| Component | Requires | Can Do Now |
|-----------|----------|------------|
| Model lineage hash field | Nothing | Add reserved field to IgnitionEntry |
| Replay provenance link | Nothing | Implement ReplayProvenanceLink |
| Bias probe battery | A010 | Expand ARC-AGI-2 pipeline after A010 |
| Model card parser | Public model cards | Parse Anthropic/OpenAI cards at A010 |
| Training data attestation | Ecosystem | Document boundary, wait |
| Full bias attestation | Ecosystem + research | Partially addressable with A016 |

---

## The Chain Mutability Problem at IC-3 Scale

GPT observation: "Research labs eventually run into this because
discoveries get corrected. You want them to handle revised histories
honestly."

At IC-3 scale, this is acute. Training data sources are sometimes
retroactively found to be contaminated, biased, or improperly licensed.
When this happens, every model trained on that data has a provenance
revision event.

ProvenanceChain.amend() (added in J54) handles this at the IC-1/IC-2
level. At IC-3 scale, the same mechanism applies but the amendment
affects not one proposal but every proposal produced by that model.

The implication: IC-3 revisions are broadcast events, not per-proposal
events. The architecture for handling them is:

```
Model lineage revision
  → update model_lineage_hash in IgnitionEntry
  → flag all prior entries from that model for re-evaluation
  → Chronicle entries get provenance_amendment event
  → Future proposals from that model carry revised attestation
```

This is not implemented. It requires IC-3 Component 1 (lineage record)
to be in place first. It is documented here because the architecture
needs to accommodate it when it becomes possible.

---

## IC-3 Status Summary

```
IC-3 STATUS: OPEN — architectural boundary

What closes it partially:
  - ReplayProvenanceLink (implementable now)
  - model_lineage_hash reserved field (implementable now)
  - ARC-AGI-2 bias probe expansion (after A010)

What closes it fully:
  - Ecosystem-level training data attestation (not within current scope)
  - Frontier model providers publishing lineage records (not within control)

What it enables when closed:
  - Gate decisions that account for known model biases
  - Honest labeling of proposals from models with known data issues
  - Cross-session provenance for replayed proposals
  - The ability to answer "can this system reason about the origin of
    information with the same rigor it reasons about the information itself?"
    with YES rather than "partially."
```

---

## Connection to the Execution Constitution

The execution constitution (gate, CGIR, AEGIS, ledger, replay) answers:
**Is this proposal safe to execute?**

The input constitution (IC-1, IC-2, IC-3) answers:
**Can this proposal be trusted at its origin?**

Both are necessary. A proposal that is safe to execute but comes from
a compromised source is still a risk — it just carries a different kind
of risk than an unsafe proposal from a clean source.

The POLITE_LIE attack (A020) demonstrates the gap in miniature.
IC-3 is what closes it at the ecosystem level.

---

*Ω Cipher · June 2026*
*Design sketch — not yet implemented*
*@LabyrinthCoder — sole authority*
