# Artifact Lifecycle — Labyrinth-OS

## Why This Document Exists

Every piece of code, every idea, every failed experiment in this system
has a formal lifecycle state. This document explains what those states mean,
why failed and partial artifacts are preserved, and how artifacts move
through the lifecycle.

This system does not discard failure. It classifies it, preserves it,
and learns from it.

---

## The Seven States

### RAW
Unprocessed. Not yet evaluated. Just arrived.
Every new artifact starts here.
RAW artifacts cannot enter execution. They cannot even be labeled.
They must be evaluated first.

### EXPERIMENTAL
Partially working. Unstable. Under active development.
The artifact exists and shows promise but is not repeatable.
Tests may exist but pass inconsistently, or cover only part of the behavior.
Most Lane 1 modules start here before reaching PARTIAL or VALIDATED.

### PARTIAL
Works in a limited scope. Known gaps are documented.
Tests pass for what is implemented. But something is missing.
Example: `runtime/ignition.py` — full Lane 2 path works, Lane 1 wiring missing.
Example: logprob bridge — all tests pass, but requires live API to fully close A011.

### VALIDATED
Passes all tests. Repeatable. Ready to promote.
This is the only state that can cross the Reality Gate into execution.
No shortcuts. An artifact must earn VALIDATED — it cannot be assigned it
without passing evidence (test count, test results, known gap closure).

### DEPRECATED
Was VALIDATED. Now replaced by something better.
The artifact still exists and is historically correct.
It is preserved because it may contain lessons, edge cases,
or implementation details that the replacement needs to account for.
Deprecated artifacts must name their replacement.

### ARCHIVED
Preserved for memory only. Not active. Not executable.
This is where external references, legacy code, failed experiments,
and historical artifacts live.
Nothing in ARCHIVED influences execution.
Nothing in ARCHIVED is deleted.

### FAILED
Known to break. Informative.
Failed artifacts are not removed — they explain what was tried and why it didn't work.
A FAILED artifact can transition back to EXPERIMENTAL if lessons are learned
and a new approach is taken. This is the healing loop.

---

## State Transition Rules

```
RAW          → EXPERIMENTAL, ARCHIVED, FAILED
EXPERIMENTAL → PARTIAL, DEPRECATED, FAILED, ARCHIVED
PARTIAL      → VALIDATED, DEPRECATED, FAILED, ARCHIVED
VALIDATED    → DEPRECATED, ARCHIVED
DEPRECATED   → ARCHIVED
ARCHIVED     → (none — fully terminal)
FAILED       → EXPERIMENTAL (retry with lessons learned)
               ARCHIVED     (preserve and close)
```

**What is never allowed:**
- RAW → VALIDATED (cannot skip maturity levels)
- EXPERIMENTAL → VALIDATED (must pass through PARTIAL)
- ARCHIVED → anything (no resurrection)
- Any state → VALIDATED without test evidence

---

## Why Failures Are Preserved

Failure is information. A system that deletes its failures
cannot learn from them, cannot detect patterns, and cannot
prevent repeating them.

Specific reasons failures are kept:

**1. Deferred Exploration (Agent D)**
Failed artifacts feed `deferred_node.py`. The DeferredExplorationNode
selects high-signal failures, applies bounded mutation, and generates
new candidates that re-enter the pipeline at LABELING.
Deleted failures cannot be mutated into future successes.

**2. Tamper Evidence**
The WORM ledger records every execution decision.
If a failed artifact is deleted and someone asks why a decision was made,
the archive provides the answer. Deletion breaks the audit trail.

**3. Hard Invariant I10**
"Nothing is deleted. Everything becomes memory."
This is not a soft preference — it is a hard invariant.
The system enforces it structurally: archive is append-only.

**4. Pattern Detection**
Repeated failures of the same type trigger oscillation detection
in `OscillationDetector`. If the same failure pattern appears
3+ times in a window, the lineage is retired — not deleted, retired.
This prevents infinite retry loops without losing the evidence.

---

## Artifact Sources

| Source | Meaning |
|--------|---------|
| SENTINEL | Labyrinth-OS original work |
| VECTOR | The VECTOR prototype system (predecessor) |
| COPILOT | GitHub Copilot generated |
| MANUAL | Hand-written by operator |
| EXTERNAL | External reference / third-party work studied |

Source is tracked because it matters for trust calibration.
SENTINEL artifacts are most trusted (our work, our tests).
EXTERNAL artifacts are ARCHIVED by default until individually validated.
COPILOT artifacts are flagged — Copilot-generated code has caused
concrete bugs (merge conflict markers, misplaced files).

---

## Current System State (by artifact count)

| State | Count | Notable examples |
|-------|-------|-----------------|
| VALIDATED | ~35 | cgir_*, watcher_*, council, ledger, replay, gate |
| PARTIAL | 3 | ignition.py (Option B wiring), A010 (live inference), A013 (live SCUEL) |
| ARCHIVED | 3 | Quicksilver v3, quantum tubulin, VECTOR dashboards |
| DEPRECATED | 1 | crates/council-resolver/src/council_resolver.py |
| EXPERIMENTAL | 0 | (all active development is PARTIAL or VALIDATED) |
| FAILED | 0 | (no outright failures yet — A010 not attempted) |
| RAW | 0 | (all artifacts have been evaluated) |

---

## The Healing Loop

When an artifact fails, it follows this path:

```
EXECUTION → LEDGER → REPLAY → OBSERVABILITY
→ FEEDBACK_RECORD (structured failure)
→ ARCHIVE (failure preserved with metadata)
→ DEFERRED_EXPLORATION_NODE
  - selects high-signal failures
  - applies bounded mutation (±10% max)
  - assigns low confidence (≤0.35)
→ NEW CANDIDATE (re-enters at LABELING)
→ LABELING → ARCHIVE → PROMOTION → REALITY_GATE
→ EXECUTION (if promoted)
```

The candidate must earn promotion. It cannot skip gates.
If it fails again, it returns to ARCHIVE as a new failure record.
If the same failure type appears 3+ times, the lineage is retired (ARCHIVED).

This is deterministic iterative refinement — not machine learning.

---

## Prototype Status

This system is currently a prototype. Some rules that apply to production
are relaxed during prototype phase and will be tightened once the core loop
is proven. See `KNOWN_GAPS.md` for the complete list.

The most significant relaxation: `ignition.py` (Option B route) bypasses
Lane 1 during prototype phase. This is intentional, documented, and temporary.
It is classified as PARTIAL, not VALIDATED, for exactly this reason.

*Labyrinth-OS — X @LabyrinthCoder*
