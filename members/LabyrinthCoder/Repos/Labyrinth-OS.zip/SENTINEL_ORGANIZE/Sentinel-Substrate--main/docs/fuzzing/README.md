# Fuzzing — Labyrinth-OS

## What Fuzzing Means Here

Not random input generation. Structured adversarial checking:
"Does the gate block what it should block, always, on every input combination?"

## Rust Fuzzer (cgir-fuzzer crate)

`crates/cgir-fuzzer/src/lib.rs` — 6 tests, compiled and passing.

Properties checked:
- P1: confidence always in [0.0, 1.0]
- P2: emitted_by always a known authority (COUNCIL or SIGNAL_ALGEBRA)
- P3: severity_raw has a valid value (0-3, not undefined)

Tracks: checks_run, violations, violation_rate.

## Python Adversarial Tests

`tests/adversarial/threat_model.py` — 15 tests covering all 10 TM-001 attack classes.

`tests/integration/test_full_pipeline.py` — SCUEL tests (POLITE_LIE, SLOW_POISON, BURST, COORDINATED).

`tests/unit/itv_vectors.py` — 5 ITV canonical test vectors for the ACBF reference VM.

## What's Not Yet Done

- `cargo-fuzz` / `proptest` property-based fuzzing (generates truly random inputs)
- Live adversarial load testing (A020 — needs real inference traffic)
- Red-team scenario suite (all 4 attack signatures: SLOW_POISON, BURST, COORDINATED, POLITE_LIE on live traffic)

## Run Fuzzing

```bash
# Python adversarial tests
python run_all.py

# Rust fuzzer
cargo test -p cgir-fuzzer

# Full TM-001
python tests/adversarial/threat_model.py
```
