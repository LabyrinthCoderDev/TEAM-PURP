# Diagrams — Labyrinth-OS

## Pipeline Flow (Text)

```
INPUT
  │
  ▼
LABELING ──────────────────────────────── mandatory (I1)
  │
  ▼
ARCHIVE ───────────────────────────────── immutable append (I10)
  │
  ▼
PROMOTION ─────────────────────────────── criteria: evidence, no contradiction
  │
  ▼
REALITY GATE (L09) ────────────────────── ONLY crossing point between lanes
  │  assert_can_enter_cgir() → SystemError if any stage missing
  ▼
CGIR TRANSLATION ──────────────────────── typed execution graph
  │
  ▼
GATE (Sigma Anchors) ──────────────────── tau, chi, drift, betti check
  │  ALLOW or BLOCK — no middle ground
  ▼
AEGIS/CESK ────────────────────────────── deterministic execution
  │
  ▼
LEDGER (WORM) ─────────────────────────── append-only, hash-chained (I8)
  │
  ▼
REPLAY ────────────────────────────────── exact replay verification (I9)
  │
  ▼
OBSERVABILITY → GOVERNANCE → FEEDBACK → ARCHIVE (closes loop)
```

## Gate Decision Logic

```
tau < 0.75          → CRITICAL → BLOCK
chi >= 0.40         → CRITICAL → BLOCK
chi >= 0.15         → WARNING
drift >= 0.12       → ERROR → BLOCK
betti_1 >= 0.045    → ERROR → BLOCK
confidence < 0.65   → BLOCK

CGIR ALLOW + GuardianSlot EXECUTE → execute
CGIR BLOCK  OR GuardianSlot BLOCK → block (either is sufficient to stop)
```

## ACP-1 Status (April 2026)
```
VERIFIED (10): A001 A005 A006 A007 A008 A009 A012 A017 A019 A021
PARTIAL  (3):  A010 A011 A013
OPEN     (9):  A002 A003 A004 A014 A015 A016 A018 A020 A022
```
