# ARCHITECTURE — 21-Layer Stack

## Overview

Labyrinth-OS implements a **21-layer architecture** from raw sensing to
hardware-anchored execution.  The epistemic side (L3–L9) and the execution
side (L10–L14) are separated by the **Reality Gate** (L10.5).

---

## Full Layer Map

### EPISTEMIC SIDE (L0–L9)

| Layer | Name | Module | Status |
|-------|------|--------|--------|
| L0 | Test Infrastructure | `tests/` | ✓ BUILT |
| L1 | Orchestration | `runtime/ignition.py`, `api_adapter.py` | ✓ BUILT |
| L2 | Control / Safety | `control/` | CONFIRMED |
| L3 | Sensing | `epistemic/vector/`, `epistemic/signal-aggregation/`, `epistemic/logprob-bridge/` | ✓ BUILT |
| L3.5 | **Labeling** | `epistemic/labeling/` | ✓ BUILT |
| L4 | Governance | `epistemic/watcher-a/`, `epistemic/watcher-b/` | ✓ BUILT |
| L5 | Council | `epistemic/council/` | ✓ BUILT |
| L5.5 | **Archive** | `epistemic/archive/` | ✓ BUILT |
| L5.75 | **Observability** | `epistemic/observability/` | ✓ BUILT |
| L6 | World Model | `proposal/world-model/` | TODO |
| L6.5 | **Promotion** | `promotion/` | ✓ BUILT |
| L7 | Planner | `proposal/planner/` | TODO |
| L8 | Shadow Planner | `proposal/shadow-planner/` | TODO |
| L9 | Concept Engine | `proposal/concept-engine/` | TODO |

### BOUNDARY

| Layer | Name | Module | Status |
|-------|------|--------|--------|
| L10.5 | **Reality Gate** | `execution/reality_gate/` | ✓ BUILT |

### EXECUTION SIDE (L10–L19)

| Layer | Name | Module | Status |
|-------|------|--------|--------|
| L10 | CGIR | `execution/cgir/` | ✓ BUILT |
| L11 | Gate | `execution/gate/` | ✓ BUILT |
| L12 | AEGIS / CESK | `execution/aegis/` | ✓ BUILT |
| L13 | Ledger | `execution/ledger/` | ✓ BUILT |
| L14 | Replay / Gnosis | `execution/replay/` | ✓ BUILT |
| L15 | Hardware RoT | `execution/hardware/` | SIMULATION |
| L18 | Formal Specs | `spec/` | ✓ BUILT |
| L19 | Agent Swarms | `proposal/agent-swarms/` | TODO |

---

## Full Flow Diagram

```
Ghost (LLM) proposes
         │
         ▼
L3   Sensing (VECTOR, signal-algebra, logprob-bridge)
         │
         ▼
L3.5 Labeling  ← label_schema, label_validator, confidence_meter
         │
         ▼
L4   Governance (Watcher-A + Watcher-B)
         │
         ▼
L5   Council resolver
         │
         ▼
L5.5 Archive ← MemoryStore, PatternCatalog, ConfidenceRecord
         │  ↑
L5.75 Observability → drift_detector → anomaly_log → feedback_loop
         │
         ▼
L6.5 Promotion ← promotion_rules, test_harness, audit_trail
         │
         ▼
══════ Reality Gate (L10.5) ══════════════════════════════
         │  GateFunction → YES or NO
         │  GateBinding  → 5 rules enforced
         │  GateProof    → cryptographic receipt
         │  GateRejector → log + escalate NO decisions
══════════════════════════════════════════════════════════
         │
         ▼
L10  CGIR (Canonical Graph Intermediate Representation)
         │
         ▼
L11  Gate (pure deterministic gate function)
         │
         ▼
L12  AEGIS / CESK (only state mutator)
         │
         ▼
L13  Ledger (append-only WORM, SHA-256 chained)
         │
         ▼
L14  Replay / Gnosis (replay validator)
```

---

## Signal Authority Chain

```
SensorReadings (L3 VECTOR)
  │
  ├─ signal_algebra ───→ emitted_by="SIGNAL_ALGEBRA"  (raw, unverified)
  │
  ├─ watcher_a ────────┐
  │  (internal audit)  ├──→ council_resolver ──→ emitted_by="COUNCIL"  (I4)
  └─ watcher_b ────────┘
     (adversarial audit)
                │
                ▼
          Labeling (L3.5)  — label + confidence scored
                │
                ▼
          Archive (L5.5)  — sealed, chained record
                │
                ▼
          Promotion (L6.5) — all 5 rules enforced
                │
                ▼
         [ Reality Gate ] — pure YES/NO
                │
                ▼
           CGIR edge binding → Gate → AEGIS → Ledger
```

---

## Epistemic Invariants (I11–I15)

| Inv | Name | Enforcement |
|-----|------|-------------|
| I11 | Labeling Closure | `label_validator.py`, `gate_binding.py` |
| I12 | Archive Integrity | `memory_store.py` (append-only + chain) |
| I13 | Observability Completeness | `MetricsCollector.emit()` at every stage |
| I14 | Promotion Auditability | `audit_trail.py`, `gate_binding.py` |
| I15 | Feedback Loop Closure | `feedback_loop.py` (adjustment always ≤ 0) |

*All original invariants I1–I10 remain unchanged and fully enforced.*
