# Glossary

## A

**AEGIS** — The execution kernel (L12). The only component that may mutate CESK state.

## C

**C2G-RL** — Causal-to-Gate Response Latency. The time from causal event to Gate decision.

**LABYRINTH-OS** — The full system name for this deterministic causally-closed execution substrate.

**CESK** — Control, Environment, Store, Kontinuation. The abstract machine model used by AEGIS.

**CGIR** — Causal Graph Intermediate Representation. The only semantic substrate in the system.

**chi (χ) stability** — A metric for system coherence tracked by VECTOR.

**Confidence** — A float in [0.0, 1.0] indicating the certainty of a SignalNode.

**Council** — The Council Resolver (L5). Merges Watcher-A and Watcher-B into one SignalNode.

## E

**EventEdge** — A CGIR node representing a state transition.

## G

**Gate** — The decision authority (L11). Pure deterministic function.

**GateDecision** — One of: ALLOW, MODIFY, THROTTLE, FALLBACK, HARD_FAIL.

## H

**HardwareBinding** — A CGIR node binding to a hardware register, MMIO address, or RoT latch.

**Hardware RoT** — Hardware Root of Trust (L15).

## I

**InvariantBinding** — A CGIR node binding an invariant rule to a scope with pass/fail status.

## L

**Ledger** — The Ledger/Chronicle (L13). Immutable truth layer.

**LogicalTime** — A monotonically increasing counter representing causal ordering.

## P

**pi-zero (π₀) fallback** — A safe, minimal behavior used under high uncertainty.

**Planner** — The Monte Carlo/formula candidate edge generator (L9).

**Proposal stratum** — The untrusted layer containing world model, concept engine, transfer engine, planner.

## R

**Replay** — The Replay/Gnosis engine (L14). Validates all committed executions.

**RoT** — Root of Trust. See Hardware RoT.

## S

**Severity** — One of: Info, Warning, Error, Critical.

**Shadow/Ghost** — Parallel shadow branch execution for comparison and offline evolution.

**SignalNode** — A CGIR node carrying an annotated severity/confidence signal from Council.

**StateNode** — A CGIR node representing a snapshot of CESK state.

## T

**TimedEdge** — A CGIR node representing a transition with latency constraints.

**TimeRange** — A window [start, end] of LogicalTime during which a signal or edge is valid.

## V

**VECTOR** — The Sensor Fabric (L2). Read-only sensing only.

## W

**Watcher-A** — Internal consistency auditor (L3).

**Watcher-B** — Adversarial auditor (L4).

**WORM** — Write Once Read Many. Property of the Ledger.
