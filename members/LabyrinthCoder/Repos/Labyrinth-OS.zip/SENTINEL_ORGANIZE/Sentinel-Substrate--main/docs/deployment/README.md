# Deployment — Labyrinth-OS

## Current Phase: Phase 1 (Single Node)

One machine. One Sentinel. One LLM backend. Full pipeline enforced.

## Run It

```bash
# Verify everything passes first
python run_all.py

# Mock run (no API key needed — proves pipeline)
python runtime/ignition.py --backend mock --model mock-model-v1 --trials 5
python runtime/verify_run.py ignition_session_<ts>.json
python runtime/a010_monitor.py ignition_session_<ts>.json

# Real run (closes A010)
python runtime/ignition.py --backend anthropic --model claude-sonnet-4-20250514 --trials 5
```

## Backends Supported
- `mock` — no API key, deterministic output, proves pipeline
- `anthropic` — Claude models (needs ANTHROPIC_API_KEY)
- `openai` — GPT models (needs OPENAI_API_KEY)
- `ollama` — local models (needs Ollama running on localhost)

## What Gets Written After Each Run
- `ignition_session_<ts>.json` — full session summary
- `feedback_<ts>.json` — outcome record fed into next session's promotion check

## Phase 2+ (Future — post A010)
See `epistemic/experimental/distributed_topology_ref.md`.
Multi-node requires: Phase 1 proven → multi-sentinel single machine → multi-node.

## Hardware Requirements (Phase 5)
- FPGA (MachXO2 or equivalent) for hardware latch enforcement
- ATECC608B for Root of Trust attestation
- Neither required for Phase 1.
