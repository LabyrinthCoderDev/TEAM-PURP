# EPISTEMIC PIPELINE — Deep Dive

## Why Labeling Matters

The epistemic pipeline is the **intelligence-facing** side of Labyrinth-OS.
It transforms raw sensor signals into classified, scored, archived, and
promoted labels that the execution substrate can act on.

Without rigorous labeling, the system cannot:
- Distinguish high-confidence proposals from uncertain ones.
- Track whether past label profiles led to good or bad outcomes.
- Detect when confidence is drifting and self-correct.
- Prevent bad proposals from reaching the execution substrate.

**The epistemic pipeline is equal in rigor to the execution substrate.**

---

## Pipeline Stages

### Stage 1: Sensing (L3)

Raw sensor readings from VECTOR, signal-algebra, and logprob-bridge.
Produces: `SensorReadings` with τ, χ, drift, D_KL, ΔH.

### Stage 2: Labeling (L3.5)

Classifies sensor output into a `LabelRecord`:
- **Category:** VALID | UNCERTAIN | REJECTED | DEFERRED
- **Confidence:** 0.40 × sensor_agreement + 0.35 × historical_success + 0.25 × temporal_consistency
- **Validation:** schema, confidence floor, TTL, duplicate check

Only `VALID` labels with `confidence ≥ 0.60` pass validation.

### Stage 3: Governance (L4)

Watcher-A (internal consistency) and Watcher-B (adversarial) audit the CGIR
graph independently.  Their findings feed the Council resolver.

### Stage 4: Council (L5)

Merges watcher reports into a single `SignalNode` with `emitted_by="COUNCIL"`.
Only COUNCIL-emitted signals may be bound to CGIR edges (I4).

### Stage 5: Archive (L5.5)

Every sealed label, promotion, and outcome is appended to the `MemoryStore`
(SHA-256 chained, append-only).  The `PatternCatalog` tracks success rates.
The `ConfidenceRecord` measures prediction accuracy over time.

### Stage 6: Observability (L5.75)

Metrics are collected at every stage boundary (`MetricsCollector.emit()`).
`DriftDetector` compares snapshots to the baseline.  Anomalies are logged in
`AnomalyLog`.  `FeedbackLoop` translates anomalies into confidence adjustments
that flow back to the labeling validator.

### Stage 7: Promotion (L6.5)

Five-rule gate:
1. `confidence ≥ 0.95`
2. TestHarness passes all thresholds
3. No archive contradiction
4. `historical_failure_rate ≤ 0.20`
5. `consecutive_runs ≥ 3` (soft — DEFERRED if not met)

Every decision recorded in `AuditTrail` (I14).

### Stage 8: Reality Gate (L10.5)

Pure deterministic decision: **YES** or **NO**.

YES requires:
- `promoted == True`
- `category == "VALID"`
- `confidence ≥ 0.85`
- All 5 GateBinding rules pass

Every YES issues a `GateProof` anchored to the Ledger.
Every NO is logged in `GateRejector`.

---

## How Promotion Works

```
1. Candidate label is created by the labeling layer.
2. LabelValidator checks schema + confidence floor.
3. LabelValidator.validate_for_promotion() checks ≥ 0.85.
4. TestHarness runs candidate through coherence/risk/latency/cost/compliance checks.
5. PromotionRules evaluates all 5 rules → APPROVED | DEFERRED | REJECTED.
6. AuditTrail.record() writes the decision (immutable).
7. If APPROVED: label advances to Reality Gate.
8. Reality Gate issues GateProof and allows CGIR binding.
```

---

## What Archive Remembers

The archive remembers:
- Every label ever created (LABEL entries)
- Every promotion decision (PROMOTION entries)
- Every Reality Gate rejection (REJECTION entries)
- Every observability anomaly (ANOMALY entries)
- Every real-world outcome (OUTCOME entries)

The `RecallProtocol` provides a typed query surface:
```python
recall.similar_patterns("VALID", min_occurrences=2)
  → RecallResult(historical_success=0.92, recommendation="PROMOTE")
```

---

## How Observability Closes the Loop

```
1. MetricsCollector.emit() called at each stage boundary.
2. DriftDetector.check() compares to baseline.
3. If drift detected: DriftAlert created.
4. AnomalyLog.append() records the anomaly.
5. FeedbackLoop.process() computes confidence_adjustment.
6. LabelValidator receives the adjustment suggestion.
7. If demote_flag: label downgraded to UNCERTAIN.
8. If promote_flag still True: label remains eligible.
9. Archive updated with anomaly entry.
```

Anomalies **always reduce confidence** — never increase it (I15).

---

## Integration with Execution Substrate

The epistemic pipeline feeds the execution substrate through the Reality Gate.

```
Reality Gate YES → label_id + confidence + promotion proof → CGIR builder
CGIR edge receives: emitted_by="COUNCIL" SignalNode + Gate proof
CGIR validator checks: proof still valid?
Gate (L11) evaluates: structural validity
AEGIS (L12): commits if Gate allows
Ledger (L13): anchors proof
Replay (L14): can verify at any point
```

The execution substrate is **unmodified** by this epistemic expansion.
