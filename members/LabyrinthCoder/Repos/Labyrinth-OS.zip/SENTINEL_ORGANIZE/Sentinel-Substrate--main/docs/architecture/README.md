# Architecture Documents — Labyrinth-OS

## Primary References

- `ARCHITECTURE.md` (root) — system overview, 21 layers, invariants
- `docs/ARCHITECTURE_21_LAYERS.md` — detailed layer breakdown
- `docs/EPISTEMIC_PIPELINE.md` — Lane 1 epistemic flow
- `docs/ARTIFACT_LIFECYCLE.md` — how artifacts move through states
- `spec/INVARIANTS.tla` — TLA+ formal invariant specification
- `spec/EPISTEMIC.tla` — TLA+ epistemic layer specification
- `spec/CGIR_TEMPORAL.tla` — TLA+ temporal constraint specification

## One-Line Summary

Two lanes. One boundary. Imagination is free. Execution requires proof.

```
LANE 1 (speculative)     LANE 2 (execution)
L00 Boot                 L10 CGIR Translation
L01 Intent               L11 Gate (Sigma Anchors)
L02 Router               L12 AEGIS/CESK
L03 Creative Zone        L13 Ledger (WORM)
L04 Analytical Core      L14 Replay/Gnosis
L05 Epistemic Labeler    L15 Experimental Exec
L06 Archive Memory       L16 Verified Exec
L07 Deferred Node        L17 WORM Chronicle
L08 Promotion Protocol   L18 Replay Audit
        ↓                L19 Observability
   L09 REALITY GATE →    L20 Governance
   (only crossing point)
```

## Key Invariants
See `ARCHITECTURE.md` — I1 through I10.
Most important: I4 (Reality Gate mandatory) and I5 (gate before CGIR).

## Sigma Anchor Constants
Single source: `sigma_anchors.py` (root).
Z3 proven. See `execution/cgir/formal/z3_sovereignty_spec.py`.
