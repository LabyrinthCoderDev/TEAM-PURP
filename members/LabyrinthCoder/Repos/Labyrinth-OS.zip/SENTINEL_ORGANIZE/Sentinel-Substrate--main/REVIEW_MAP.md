# Review Map — Labyrinth-OS

**How to understand this project before evaluating it.**

> *"This is not alignment-by-training or safety-by-prompting. It is safety-by-structure."*

---

## Classification Standard (use when reading any claim)

| Tag | Meaning |
|-----|---------|
| `Z3-PROVEN` | Machine-checked by Z3 SMT solver. Unconditionally true given the model. |
| `TEST-VERIFIED` | Passes the test suite. True under tested conditions. |
| `PROTOTYPE-WIRED` | Code runs; connected to mock/stub inputs, not live data yet. |
| `NOT YET DEMONSTRATED` | Designed and documented. Not yet run against real inputs. |
| `ANALOGY` | Structural parallel to external work — no entailment claimed. |

**Dependency rule:** Layer III collapses if Layer II fails. Layer I stands unconditionally.

---

## The Right Starting Point

Read in this order:

| # | File | What You Learn |
|---|------|----------------|
| 1 | `PROJECT_CONTEXT.md` | What was built, why the pattern matters, three independent convergences |
| 2 | `THEORETICAL_FOUNDATIONS.md` | Three epistemic layers, mathematical grounding, classification standard |
| 3 | `ARCHITECTURE.md` | The 21-layer pipeline and invariants each layer enforces |
| 4 | `AUTHORITY.md` | One job per layer — no ambiguity about who decides what |
| 5 | `steward/acp1_dependency_graph.py` | 22 assumptions + collapse propagation + Layer I/II/III tags |
| 6 | `PROTOTYPE_BOUNDARIES.md` | Exact scope: Z3-proven vs test-verified vs not yet demonstrated |

After these six files you will understand what the system is and whether the architecture is sound.

---

## Run It

```bash
# Everything — Python + Rust
python run_all.py

# Mock inference — no API key needed
python runtime/ignition.py --backend mock --model mock-model-v1 --trials 5
python runtime/verify_run.py ignition_session_<ts>.json

# Rust only
cargo test --workspace
```

Expected: `✓ ALL TESTS PASS  (Python: 1556  Rust: 249  Total: 1700+)`

---

## Core Files Worth Reading

```
Core enforcement (TEST-VERIFIED):
  pipeline_wire.py                           PipelineTrace ordering proofs
  lane1/09_reality_gate/reality_gate.py      Lane crossing gate
  execution/gate/cgir_gate.py                Sigma Anchor gate (ALLOW/BLOCK)
  execution/gate/guardian_slot.py            Final EXECUTE/BLOCK/KILL
  execution/gate/circuit_breaker.py          Constitutional deadlock resolution
  sigma_anchors.py                           Threshold constants (Z3-PROVEN, A021)

Second verification axis — zero-day response (TEST-VERIFIED):
  steward/predicate_extractor.py             LogicalSentinel: Phi1/Phi2/Phi3 via Z3

Core ledger (TEST-VERIFIED):
  execution/ledger/hashchain.py              WORM hash chain, thread-safe (I19)
  execution/replay/replay_validator.py       Exact replay — EQUIVALENT mode removed

Core assumption tracking:
  steward/acp1_dependency_graph.py           Collapse propagation + Layer I/II/III tags
  steward/acp1_tracker.py                    22 assumptions with evidence

Core tests:
  tests/adversarial/threat_model.py          TM-001: 11 attack classes
  tests/unit/test_watcher_council_bounds.py  Watcher influence bounds
  tests/integration/test_feedback_loop_e2e.py  Full feedback loop proof
```

---

## If You Want to Dig Into Limitations

`KNOWN_GAPS.md` — gap summary table with status, collapse rules, and what closes each gap.
`STATUS.md` — current state, dependency rule, what is and is not verified.
`PROTOTYPE_BOUNDARIES.md` — complete taxonomy: Z3-PROVEN / TEST-VERIFIED / PROTOTYPE-WIRED / NOT YET DEMONSTRATED.

The limitations are documented. They are not hidden. The prototype label is honest.

---

## What the System Cannot Currently Do

- Detect a well-crafted deceptive proposal whose Sigma readings stay within thresholds
- Block pre-execution contamination (weight poisoning, training data manipulation) — GAP 13
- Run live inference without an API key — A010 PARTIAL
- Provide hardware enforcement — A014 OPEN (requires FPGA + ATECC608B)

These are documented boundaries, not oversights.

---

Contact: X: @LabyrinthCoder
