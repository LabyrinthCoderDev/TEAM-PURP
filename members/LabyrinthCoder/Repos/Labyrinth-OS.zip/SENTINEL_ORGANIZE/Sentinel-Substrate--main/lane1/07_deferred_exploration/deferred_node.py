# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          deferred_node.py — Labyrinth-OS / Lane 1 / L07
# ----------------------------------------------------------------------------

"""
deferred_node.py — Labyrinth-OS / Lane 1 / L07
================================================
L07 Deferred Exploration Node — Agent D

The controlled autonomous healing loop.

Failures are not discarded. They are transformed into structured,
archived, low-weight future candidates that re-enter the pipeline
ONLY through proper channels.

MANDATORY HEALING LOOP:
  EXECUTION
  → LEDGER → REPLAY → OBSERVABILITY
  → FEEDBACK_RECORD
  → ARCHIVE (store failure with metadata)
  → DEFERRED_EXPLORATION_NODE (this module — mutation stage)
  → NEW CANDIDATE
  → LABELING (mandatory re-entry)
  → ARCHIVE (mandatory again)
  → PROMOTION_PROTOCOL
  → REALITY_GATE
  → EXECUTION

HARD RULES (non-negotiable):
  1. Deferred nodes MUST NOT inject directly into execution
  2. ALL reintroduced candidates MUST go through:
     LABELING → ARCHIVE → PROMOTION → REALITY_GATE
  3. No mutation bypasses CGIR / constraints / solver
  4. No feedback loop overwrites existing truth (append-only)
  5. All mutated candidates are traceable to original failure
  6. Mutation is LOW AMPLITUDE — no radical changes
  7. System remains deterministic per execution cycle
  8. Infinite loop detection is mandatory

This is NOT machine learning.
This is deterministic iterative refinement under strict gating.

References:
  ARCHITECTURE.md   — L07 Deferred Exploration, healing loop
  pipeline_wire.py  — PipelineTrace (extended with mutation fields)
  archive_memory.py — archive (append-only, receives failures)
  promotion_protocol.py — mandatory bridge for re-entry
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, List, Optional


# ─── FAILURE TYPES ────────────────────────────────────────────────────────────

@unique
class FailureType(str, Enum):
    GATE_REJECTION       = "gate_rejection"
    CONSTRAINT_VIOLATION = "constraint_violation"
    SOLVER_FAILURE       = "solver_failure"
    DRIFT_DETECTED       = "drift_detected"
    IDENTITY_VIOLATION   = "identity_violation"


# ─── FAILURE RECORD ───────────────────────────────────────────────────────────

@dataclass
class FailureRecord:
    """
    Structured record of a pipeline failure.
    Stored in archive. Never deleted. Feeds deferred exploration.

    Required fields per audit specification:
      id              — unique identifier
      origin_trace    — PipelineTrace hash reference
      failure_type    — one of FailureType
      parameters      — the parameters that failed
      context         — additional context at time of failure
      timestamp       — when failure occurred
      severity        — 0.0–1.0 (1.0 = most severe)
      replay_verified — whether the failure was confirmed by replay
    """
    id:              str
    origin_trace:    str      # PipelineTrace hash
    failure_type:    FailureType
    parameters:      Dict[str, Any]
    context:         Dict[str, Any]
    timestamp:       float
    severity:        float    # 0.0–1.0
    replay_verified: bool = False
    mutation_depth:  int = 0  # how many times this lineage has been mutated


    @classmethod
    def from_failed_proposal(cls, fp: "FailedProposal") -> "FailureRecord":
        """
        Convert a FailedProposal (from reality_gate.py) into a FailureRecord
        for processing by DeferredExplorationNode.

        Closes the data format mismatch (DeepSeek audit 3.2): the healing loop
        was blind to gate-block structure because the two types had no conversion.

        FailedProposal fields mapped to FailureRecord:
          passage_id     → id  (stable gate passage identifier)
          reason         → failure_type  (mapped to FailureType enum)
          blocked_at     → timestamp
          gate.stage     → origin_trace  (approximated from passage_id)
        """
        # Map gate failure reason to FailureType enum
        # Uses duck-typed access — works regardless of FailedProposal version
        reason = getattr(fp, 'reason', '') or getattr(fp, 'failure_reason', '') or ''
        r = reason.upper()
        if any(k in r for k in ('SIGMA', 'TAU', 'CHI', 'DRIFT', 'BETTI')):
            ftype = FailureType.CONSTRAINT_VIOLATION
        elif 'CONFIDENCE' in r or 'LOW_CONF' in r:
            ftype = FailureType.SOLVER_FAILURE
        elif any(k in r for k in ('STAGE', 'PIPELINE', 'ORDER')):
            ftype = FailureType.IDENTITY_VIOLATION
        else:
            ftype = FailureType.GATE_REJECTION

        passage_id = getattr(fp, 'passage_id', '') or ''
        blocked_at = getattr(fp, 'blocked_at', None) or time.time()

        # Derive a stable id from passage_id or generate one
        record_id = (
            hashlib.sha256(f"fr:{passage_id}".encode()).hexdigest()[:16]
            if passage_id else
            hashlib.sha256(f"fr:{reason}:{blocked_at}".encode()).hexdigest()[:16]
        )

        return cls(
            id=record_id,
            origin_trace=passage_id or "unknown",
            failure_type=ftype,
            parameters={},                 # not available from FailedProposal
            context={
                "reason":       reason,
                "passage_id":   passage_id,
                "source":       "FailedProposal.from_failed_proposal",
            },
            timestamp=blocked_at,
            severity=1.0,                  # gate blocks are high severity
            replay_verified=False,
        )

    def __post_init__(self) -> None:
        if not self.id:
            raise ValueError("FailureRecord id must be non-empty")
        if not 0.0 <= self.severity <= 1.0:
            raise ValueError(f"Severity must be in [0, 1], got {self.severity}")
        if self.mutation_depth < 0:
            raise ValueError("mutation_depth must be non-negative")

    @property
    def record_hash(self) -> str:
        payload = json.dumps({
            "id": self.id,
            "origin_trace": self.origin_trace,
            "failure_type": self.failure_type.value,
            "severity": round(self.severity, 6),
            "timestamp": round(self.timestamp, 3),
            "mutation_depth": self.mutation_depth,
        }, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(payload.encode()).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":              self.id,
            "origin_trace":    self.origin_trace,
            "failure_type":    self.failure_type.value,
            "parameters":      self.parameters,
            "context":         self.context,
            "timestamp":       self.timestamp,
            "severity":        self.severity,
            "replay_verified": self.replay_verified,
            "mutation_depth":  self.mutation_depth,
            "record_hash":     self.record_hash,
        }


# ─── MUTATION RESULT ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class MutationResult:
    """
    Output of one mutation pass.

    candidate_id    — new unique ID for this candidate
    parent_id       — the FailureRecord it was derived from
    content         — the mutated candidate content (re-enters at LABELING)
    parameters      — mutated parameters
    mutation_depth  — parent.mutation_depth + 1
    confidence      — assigned LOW (never high — unproven candidate)
    mutation_log    — what was changed and by how much
    """
    candidate_id:   str
    parent_id:      str
    content:        str
    parameters:     Dict[str, Any]
    mutation_depth: int
    confidence:     float       # always LOW — must earn promotion
    mutation_log:   List[str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id":  self.candidate_id,
            "parent_id":     self.parent_id,
            "content":       self.content,
            "parameters":    self.parameters,
            "mutation_depth":self.mutation_depth,
            "confidence":    self.confidence,
            "mutation_log":  self.mutation_log,
        }


# ─── MUTATION BOUNDS ──────────────────────────────────────────────────────────

# Maximum mutation depth before a lineage is retired
MAX_MUTATION_DEPTH = 5

# Maximum confidence a mutated candidate can be assigned
# Must be low enough that it cannot be promoted without passing all criteria
MUTATION_MAX_CONFIDENCE = 0.35

# Maximum delta for any numeric parameter mutation (as fraction of current value)
MAX_DELTA_FRACTION = 0.10  # ±10% maximum

# Minimum severity to select a failure for mutation
MIN_SEVERITY_FOR_SELECTION = 0.20


# ─── DEFERRED EXPLORATION NODE ────────────────────────────────────────────────

class DeferredExplorationNode:
    """
    L07: Controlled mutation engine for failed pipeline candidates.

    Receives FailureRecords from archive.
    Selects high-signal failures (not random).
    Applies bounded mutation.
    Outputs new candidates at LOW confidence.
    These candidates re-enter pipeline at LABELING — nowhere else.

    Infinite loop detection:
      - tracks lineage by parent_id chain
      - refuses to mutate beyond MAX_MUTATION_DEPTH
      - detects oscillation (same failure type repeating in same lineage)

    This is NOT machine learning. It is deterministic refinement.
    """

    def __init__(self) -> None:
        self._seen_lineages: Dict[str, List[str]] = {}  # parent_id → failure_types

    def select(self, failures: List[FailureRecord]) -> List[FailureRecord]:
        """
        Select which failures are worth mutating.

        Selection criteria (all must pass):
          1. severity >= MIN_SEVERITY_FOR_SELECTION
          2. replay_verified = True (confirmed real failure, not noise)
          3. mutation_depth < MAX_MUTATION_DEPTH (lineage not exhausted)
          4. No oscillation detected in lineage
        """
        selected = []
        for f in failures:
            if f.severity < MIN_SEVERITY_FOR_SELECTION:
                continue
            if not f.replay_verified:
                continue
            if f.mutation_depth >= MAX_MUTATION_DEPTH:
                continue
            if self._is_oscillating(f):
                continue
            selected.append(f)
        # Sort by severity descending — highest signal first
        return sorted(selected, key=lambda x: x.severity, reverse=True)

    def mutate(self, failure: FailureRecord) -> Optional[MutationResult]:
        """
        Apply controlled, bounded mutation to a failure record.
        Returns None if mutation is not safe to produce.

        Mutation rules:
          - preserve structure of original candidate
          - only adjust bounded numeric variables
          - never introduce unknown fields
          - maintain compatibility with CGIR schema
          - delta capped at MAX_DELTA_FRACTION of current value
          - confidence is always LOW (MUTATION_MAX_CONFIDENCE)

        P10.5-H: Directional mutation (Rooke / Poole Manifold kinetic mass recycling).
        The failure type and blocked channel now shape the mutation direction.
        A confidence failure mutates confidence-related parameters upward.
        A chi failure mutates reasoning-structure parameters.
        A tau failure mutates signal-path parameters.
        Failure energy is directional — not uniform ±10% on everything.
        """
        if failure.mutation_depth >= MAX_MUTATION_DEPTH:
            return None

        if self._is_oscillating(failure):
            return None

        mutation_log = []
        new_params = dict(failure.parameters)

        # P10.5-H: Determine mutation strategy from failure context
        # Extract which channel caused the block if available
        context_reason = failure.context.get("reason", "").upper()
        blocked_channel = self._infer_blocked_channel(context_reason)

        # Apply channel-aware directional mutations
        for key, value in failure.parameters.items():
            if not isinstance(value, (int, float)):
                continue
            if value == 0:
                continue

            delta = value * MAX_DELTA_FRACTION
            direction = self._mutation_direction(
                key=key,
                failure_type=failure.failure_type,
                blocked_channel=blocked_channel,
                context_reason=context_reason,
            )

            new_value = value + (delta * direction)
            new_params[key] = round(new_value, 8)
            mutation_log.append(
                f"{key}: {value} → {new_value:.6f} "
                f"(delta={delta * direction:.6f}, "
                f"channel={blocked_channel or 'GENERAL'})"
            )

        # Record this lineage step (oscillation tracking)
        self._record_lineage(failure)

        # Generate deterministic candidate ID
        candidate_id = hashlib.sha256(
            f"{failure.id}:depth{failure.mutation_depth + 1}:{time.time()}".encode()
        ).hexdigest()[:32]

        # Build content summary for labeling re-entry
        content = (
            f"[DEFERRED_CANDIDATE] Derived from failure {failure.id} "
            f"(type={failure.failure_type.value}, "
            f"channel={blocked_channel or 'GENERAL'}, "
            f"severity={failure.severity:.3f}, "
            f"depth={failure.mutation_depth + 1}). "
            f"Mutations: {len(mutation_log)} parameters adjusted."
        )

        return MutationResult(
            candidate_id=candidate_id,
            parent_id=failure.id,
            content=content,
            parameters=new_params,
            mutation_depth=failure.mutation_depth + 1,
            confidence=MUTATION_MAX_CONFIDENCE,
            mutation_log=mutation_log,
        )

    def _infer_blocked_channel(self, reason_upper: str) -> Optional[str]:
        """
        P10.5-H: Infer which Sigma Anchor channel caused the block from the
        failure reason string. Returns the channel name or None if not determinable.
        """
        if any(k in reason_upper for k in ("TAU", "TAU_ESCAPE")):
            return "TAU"
        if any(k in reason_upper for k in ("CHI", "CHI_COLLAPSE", "CHI_WARN")):
            return "CHI"
        if any(k in reason_upper for k in ("DRIFT",)):
            return "DRIFT"
        if any(k in reason_upper for k in ("BETTI", "BETTI_1")):
            return "BETTI_1"
        if any(k in reason_upper for k in ("CONFIDENCE", "CONF")):
            return "CONFIDENCE"
        if any(k in reason_upper for k in ("PREDICATE", "PHI1", "PHI2", "PHI3", "UNSAT")):
            return "PREDICATE"
        return None

    def _mutation_direction(
        self,
        key: str,
        failure_type: FailureType,
        blocked_channel: Optional[str],
        context_reason: str,
    ) -> float:
        """
        P10.5-H: Channel-aware directional mutation.

        Rooke's kinetic mass recycling principle: the energy of the failure
        is used to power the repair. The nature of the failure shapes the
        direction of the repair — not a uniform shrink/grow.

        Mapping:
          TAU failure → raise tau-related parameters (signal health)
          CHI failure → lower chi-related parameters (reduce contradiction)
          DRIFT failure → raise baseline stability parameters
          CONFIDENCE failure → raise confidence-producing parameters
          PREDICATE failure → lower parameters that trigger the predicate pattern
          GATE_REJECTION (generic) → conservative reduce
          DRIFT_DETECTED → raise sensitivity
        """
        key_upper = key.upper()

        # Channel-specific directional logic
        if blocked_channel == "TAU":
            # TAU too low — raise signal-health related parameters
            if any(k in key_upper for k in ("TAU", "SIGNAL", "HEALTH", "ESCAPE")):
                return +1.0  # increase toward healthy range
            return -1.0  # reduce everything else (may be dragging tau down)

        elif blocked_channel == "CHI":
            # CHI too high — reduce contradiction-related parameters
            if any(k in key_upper for k in ("CHI", "CONTRADICT", "CONFLICT")):
                return -1.0  # directly reduce the offending parameter
            return -1.0  # conservative: reduce everything

        elif blocked_channel == "DRIFT":
            # DRIFT too high — reduce variance, raise stability
            if any(k in key_upper for k in ("DRIFT", "VAR", "SPREAD")):
                return -1.0  # reduce drift directly
            if any(k in key_upper for k in ("STABLE", "BASE", "ANCHOR")):
                return +1.0  # raise stability
            return -1.0

        elif blocked_channel == "CONFIDENCE":
            # CONFIDENCE too low — raise confidence-related parameters
            if any(k in key_upper for k in ("CONF", "EVIDENCE", "WEIGHT", "CERT")):
                return +1.0  # raise confidence
            return -1.0  # reduce other parameters (less complexity = more confidence)

        elif blocked_channel == "PREDICATE":
            # Predicate violation — reduce parameters that trigger the pattern
            # Source-risk (Φ1): reduce unverified-source signals
            # Verification-gate (Φ2): reduce bypass-related parameters
            # Loop-uncertainty (Φ3): reduce propagation scope parameters
            if any(k in key_upper for k in ("SCOPE", "PROP", "LOOP", "BREADTH")):
                return -1.0  # reduce propagation scope (Φ3)
            if any(k in key_upper for k in ("BYPASS", "SKIP", "UNVERIF")):
                return -1.0  # reduce bypass tendency (Φ2)
            return -1.0  # conservative for predicate failures

        # Failure-type fallback (when channel not determinable)
        elif failure_type == FailureType.DRIFT_DETECTED:
            return +1.0  # increase sensitivity
        elif failure_type in (
            FailureType.CONSTRAINT_VIOLATION,
            FailureType.GATE_REJECTION,
            FailureType.SOLVER_FAILURE,
            FailureType.IDENTITY_VIOLATION,
        ):
            return -1.0  # conservative reduce

        return -1.0  # safe default

    def _is_oscillating(self, failure: FailureRecord) -> bool:
        """
        Detect if this lineage is oscillating (same failure type repeating).
        An oscillating lineage is retired — further mutation would not converge.
        """
        history = self._seen_lineages.get(failure.id, [])
        if len(history) < 2:
            return False
        # Oscillation: same failure type appears 3+ times in last 4 entries
        recent = history[-4:]
        return recent.count(failure.failure_type.value) >= 3

    def _record_lineage(self, failure: FailureRecord) -> None:
        """Track lineage for oscillation detection."""
        history = self._seen_lineages.setdefault(failure.id, [])
        history.append(failure.failure_type.value)
        # Keep last 10 entries only
        if len(history) > 10:
            self._seen_lineages[failure.id] = history[-10:]

    def process_batch(
        self, failures: List[FailureRecord]
    ) -> List[MutationResult]:
        """
        Process a batch of failures.
        Select → Mutate → Return candidates for re-entry at LABELING.

        Returns only valid MutationResults.
        Empty list means no failures were worth mutating.
        """
        selected = self.select(failures)
        results = []
        for failure in selected:
            result = self.mutate(failure)
            if result is not None:
                results.append(result)
        return results


# ─── PIPELINE TRACE EXTENSION ─────────────────────────────────────────────────

@dataclass
class ExtendedPipelineTrace:
    """
    Extended PipelineTrace for candidates re-entering the pipeline.
    Tracks mutation lineage. Detects infinite loops.

    origin_id       — the FailureRecord.id this candidate came from
    mutation_flag   — True if this is a mutated candidate
    mutation_depth  — how many mutation iterations from original failure
    """
    input_id:       str
    origin_id:      Optional[str] = None
    mutation_flag:  bool = False
    mutation_depth: int = 0
    stages:         List[Dict[str, Any]] = field(default_factory=list)

    def is_loop_risk(self) -> bool:
        """Return True if this candidate is approaching loop termination."""
        return self.mutation_depth >= MAX_MUTATION_DEPTH - 1

    def to_dict(self) -> Dict[str, Any]:
        return {
            "input_id":      self.input_id,
            "origin_id":     self.origin_id,
            "mutation_flag": self.mutation_flag,
            "mutation_depth":self.mutation_depth,
            "stages":        self.stages,
            "loop_risk":     self.is_loop_risk(),
        }


# ─── OSCILLATION DETECTOR ─────────────────────────────────────────────────────

class OscillationDetector:
    """
    Detects repeated failure patterns across the system.
    Feeds results to governance and archive tagging.

    Pattern detection:
      - same failure_type appearing > threshold times in a window
      - same parameter set failing repeatedly
      - mutation_depth not decreasing (convergence failure)
    """

    def __init__(self, window: int = 10, threshold: int = 3) -> None:
        self._window = window
        self._threshold = threshold
        self._history: List[Dict[str, Any]] = []

    def observe(self, failure: FailureRecord) -> bool:
        """
        Record a failure and return True if oscillation is detected.
        """
        self._history.append({
            "failure_type": failure.failure_type.value,
            "severity":     failure.severity,
            "depth":        failure.mutation_depth,
            "timestamp":    failure.timestamp,
        })
        if len(self._history) > self._window:
            self._history = self._history[-self._window:]
        return self._check_oscillation()

    def _check_oscillation(self) -> bool:
        if len(self._history) < self._threshold:
            return False
        recent_types = [h["failure_type"] for h in self._history[-self._threshold:]]
        # All same type in recent window → oscillation
        if len(set(recent_types)) == 1:
            return True
        # All at max depth → convergence failure
        recent_depths = [h["depth"] for h in self._history[-self._threshold:]]
        if all(d >= MAX_MUTATION_DEPTH - 1 for d in recent_depths):
            return True
        return False

    def summary(self) -> Dict[str, Any]:
        if not self._history:
            return {"oscillating": False, "window_size": 0}
        from collections import Counter
        type_counts = Counter(h["failure_type"] for h in self._history)
        return {
            "oscillating":   self._check_oscillation(),
            "window_size":   len(self._history),
            "type_counts":   dict(type_counts),
            "mean_depth":    sum(h["depth"] for h in self._history) / len(self._history),
        }


# ─── CONVENIENCE ──────────────────────────────────────────────────────────────

def process_failures(
    failures: List[FailureRecord],
) -> List[MutationResult]:
    """
    Convenience: process a batch of failures through the deferred node.
    Returns candidates ready for re-entry at LABELING.
    """
    node = DeferredExplorationNode()
    return node.process_batch(failures)


def make_failure_record(
    id: str,
    origin_trace: str,
    failure_type: FailureType,
    parameters: Dict[str, Any],
    context: Dict[str, Any],
    severity: float,
    replay_verified: bool = False,
) -> FailureRecord:
    """Convenience constructor for FailureRecord."""
    return FailureRecord(
        id=id,
        origin_trace=origin_trace,
        failure_type=failure_type,
        parameters=parameters,
        context=context,
        timestamp=time.time(),
        severity=severity,
        replay_verified=replay_verified,
    )


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _make_failure(
    id="f1",
    severity=0.7,
    failure_type=FailureType.GATE_REJECTION,
    replay_verified=True,
    mutation_depth=0,
    parameters=None,
) -> FailureRecord:
    return FailureRecord(
        id=id,
        origin_trace="trace_hash_abc",
        failure_type=failure_type,
        parameters=parameters or {"threshold": 0.75, "drift_score": 0.15},
        context={"cycle": 1},
        timestamp=time.time(),
        severity=severity,
        replay_verified=replay_verified,
        mutation_depth=mutation_depth,
    )


def _test_failure_record_valid() -> bool:
    """FailureRecord constructs correctly."""
    f = _make_failure()
    assert f.id == "f1"
    assert len(f.record_hash) == 64
    assert f.failure_type == FailureType.GATE_REJECTION
    return True

def _test_failure_record_severity_clamped() -> bool:
    """Severity outside [0,1] raises ValueError."""
    try:
        _make_failure(severity=1.5)
        raise AssertionError("Should raise")
    except ValueError:
        pass
    return True

def _test_select_filters_low_severity() -> bool:
    """Failures below MIN_SEVERITY are not selected."""
    node = DeferredExplorationNode()
    low = _make_failure(severity=0.05)
    selected = node.select([low])
    assert len(selected) == 0
    return True

def _test_select_filters_unverified() -> bool:
    """Failures not replay_verified are not selected."""
    node = DeferredExplorationNode()
    unverified = _make_failure(replay_verified=False)
    selected = node.select([unverified])
    assert len(selected) == 0
    return True

def _test_select_filters_max_depth() -> bool:
    """Failures at MAX_MUTATION_DEPTH are not selected (lineage exhausted)."""
    node = DeferredExplorationNode()
    exhausted = _make_failure(mutation_depth=MAX_MUTATION_DEPTH)
    selected = node.select([exhausted])
    assert len(selected) == 0
    return True

def _test_mutate_produces_result() -> bool:
    """Valid failure → MutationResult."""
    node = DeferredExplorationNode()
    f = _make_failure()
    result = node.mutate(f)
    assert result is not None
    assert result.mutation_depth == 1
    assert result.parent_id == "f1"
    assert result.confidence <= MUTATION_MAX_CONFIDENCE
    return True

def _test_mutate_depth_increments() -> bool:
    """Mutation depth increments each time."""
    node = DeferredExplorationNode()
    f = _make_failure(mutation_depth=2)
    result = node.mutate(f)
    assert result is not None
    assert result.mutation_depth == 3
    return True

def _test_mutate_bounded_delta() -> bool:
    """Mutated parameters stay within MAX_DELTA_FRACTION of original."""
    node = DeferredExplorationNode()
    f = _make_failure(parameters={"threshold": 1.0})
    result = node.mutate(f)
    assert result is not None
    new_val = result.parameters.get("threshold", 1.0)
    delta = abs(new_val - 1.0)
    assert delta <= MAX_DELTA_FRACTION + 1e-9, f"Delta {delta} exceeds max {MAX_DELTA_FRACTION}"
    return True

def _test_mutate_preserves_non_numeric() -> bool:
    """Non-numeric parameters are preserved unchanged."""
    node = DeferredExplorationNode()
    f = _make_failure(parameters={"threshold": 0.75, "label": "SPECULATIVE"})
    result = node.mutate(f)
    assert result is not None
    assert result.parameters["label"] == "SPECULATIVE"
    return True

def _test_confidence_always_low() -> bool:
    """Mutated candidates always have low confidence."""
    node = DeferredExplorationNode()
    f = _make_failure()
    result = node.mutate(f)
    assert result is not None
    assert result.confidence <= MUTATION_MAX_CONFIDENCE
    return True

def _test_oscillation_detection() -> bool:
    """Same failure type 3+ times triggers oscillation."""
    detector = OscillationDetector(window=5, threshold=3)
    for _ in range(3):
        f = _make_failure(failure_type=FailureType.GATE_REJECTION)
        oscillating = detector.observe(f)
    assert oscillating, "Should detect oscillation"
    return True

def _test_process_batch() -> bool:
    """process_failures returns candidates for high-signal failures."""
    failures = [
        _make_failure("f1", severity=0.8, replay_verified=True),
        _make_failure("f2", severity=0.1, replay_verified=True),   # too low
        _make_failure("f3", severity=0.7, replay_verified=False),  # not verified
    ]
    results = process_failures(failures)
    assert len(results) == 1
    assert results[0].parent_id == "f1"
    return True

def _test_record_hash_stable() -> bool:
    """Same FailureRecord → same hash."""
    f = _make_failure()
    h1 = f.record_hash
    h2 = f.record_hash
    assert h1 == h2 and len(h1) == 64
    return True

def _test_to_dict_serializable() -> bool:
    """FailureRecord.to_dict() is JSON-serializable."""
    f = _make_failure()
    json.dumps(f.to_dict())
    return True

def _test_extended_trace_loop_risk() -> bool:
    """ExtendedPipelineTrace detects loop risk at depth threshold."""
    trace = ExtendedPipelineTrace(
        input_id="t1",
        origin_id="f1",
        mutation_flag=True,
        mutation_depth=MAX_MUTATION_DEPTH - 1,
    )
    assert trace.is_loop_risk()
    trace2 = ExtendedPipelineTrace(input_id="t2", mutation_depth=0)
    assert not trace2.is_loop_risk()
    return True


def _test_P10_5H_chi_failure_reduces_chi_parameter() -> bool:
    """P10.5-H: CHI block → chi-related parameters mutate downward."""
    node = DeferredExplorationNode()
    f = FailureRecord(
        id="chi_test",
        origin_trace="tr_001",
        failure_type=FailureType.CONSTRAINT_VIOLATION,
        parameters={"chi_weight": 0.5, "confidence": 0.8},
        context={"reason": "CHI_COLLAPSE: chi=0.45 > threshold 0.40"},
        timestamp=time.time(),
        severity=0.9,
        replay_verified=True,
    )
    result = node.mutate(f)
    assert result is not None
    # chi_weight should go down (CHI failure → reduce chi parameter)
    assert result.parameters["chi_weight"] < f.parameters["chi_weight"], \
        "P10.5-H: CHI failure must reduce chi-related parameter"
    return True


def _test_P10_5H_confidence_failure_raises_confidence_parameter() -> bool:
    """P10.5-H: CONFIDENCE block → confidence parameters mutate upward."""
    node = DeferredExplorationNode()
    f = FailureRecord(
        id="conf_test",
        origin_trace="tr_002",
        failure_type=FailureType.SOLVER_FAILURE,
        parameters={"confidence_weight": 0.4, "evidence_score": 0.6},
        context={"reason": "CONFIDENCE_BELOW_FLOOR: 0.42 < 0.65"},
        timestamp=time.time(),
        severity=0.8,
        replay_verified=True,
    )
    result = node.mutate(f)
    assert result is not None
    # confidence and evidence should go UP (CONFIDENCE failure → raise)
    assert result.parameters["confidence_weight"] > f.parameters["confidence_weight"], \
        "P10.5-H: CONFIDENCE failure must raise confidence parameter"
    assert result.parameters["evidence_score"] > f.parameters["evidence_score"], \
        "P10.5-H: CONFIDENCE failure must raise evidence parameter"
    return True


def _test_P10_5H_predicate_failure_reduces_scope() -> bool:
    """P10.5-H: PREDICATE_UNSAT block → scope/propagation parameters reduce."""
    node = DeferredExplorationNode()
    f = FailureRecord(
        id="pred_test",
        origin_trace="tr_003",
        failure_type=FailureType.GATE_REJECTION,
        parameters={"scope_factor": 0.8, "loop_depth": 3.0},
        context={"reason": "PREDICATE_UNSAT: PHI3 LOOP=TRUE certainty claimed"},
        timestamp=time.time(),
        severity=0.95,
        replay_verified=True,
    )
    result = node.mutate(f)
    assert result is not None
    # scope_factor and loop_depth should go DOWN (Φ3 violation → reduce propagation)
    assert result.parameters["scope_factor"] < f.parameters["scope_factor"], \
        "P10.5-H: PREDICATE failure must reduce scope parameter"
    assert result.parameters["loop_depth"] < f.parameters["loop_depth"], \
        "P10.5-H: PREDICATE failure must reduce loop-related parameter"
    return True


def _test_P10_5H_mutation_log_includes_channel() -> bool:
    """P10.5-H: Mutation log records which channel caused the block."""
    node = DeferredExplorationNode()
    f = FailureRecord(
        id="log_test",
        origin_trace="tr_004",
        failure_type=FailureType.CONSTRAINT_VIOLATION,
        parameters={"tau_reading": 0.6},
        context={"reason": "TAU_ESCAPE: tau=0.60 < floor 0.75"},
        timestamp=time.time(),
        severity=0.85,
        replay_verified=True,
    )
    result = node.mutate(f)
    assert result is not None
    assert len(result.mutation_log) > 0
    # Log should mention the channel
    log_str = " ".join(result.mutation_log)
    assert "TAU" in log_str or "GENERAL" in log_str, \
        f"P10.5-H: Mutation log must record channel. Got: {log_str}"
    return True


def run_tests() -> tuple:
    tests = sorted(
        [(name, obj) for name, obj in globals().items()
         if name.startswith("_test_") and callable(obj)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    import hashlib as _hl
    print("=" * 70)
    print("DEFERRED EXPLORATION NODE — Labyrinth-OS / Lane 1 / L07")
    print("Agent D: controlled autonomous healing loop")
    print("=" * 70)
    print("\n── TEST SUITE ──\n")
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err: line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed:
        raise SystemExit(1)
    with open(__file__, "rb") as f:
        fh = _hl.sha256(f.read()).hexdigest()
    print(f"\n── RECEIPT ──\n  SHA-256: {fh}\n  Tests: {passed}/{passed+failed}")
    print(f"\n{'='*70}")
    print(f"  Failures become controlled future attempts.")
    print(f"  Imagination remains separate. Execution still requires proof.")
    print(f"{'='*70}")
