# L04 — Analytical Core

**Status:** STUB — not yet implemented
**Layer:** Lane 1 (structured reasoning, comparison, proof)

## What Goes Here

Structured reasoning on ideas. Comparison. Logical analysis.
Outputs feed into L05 Epistemic Labeling alongside creative outputs.

The analytical core is where SPECULATIVE ideas get evidence attached.
It does not promote ideas — that is L08's job.
It provides the evidence that L08 evaluates.

## Files Needed
- analytical_core.py — evidence gathering, contradiction detection, comparison
- analytical_node.py — IdeaNode with analytical metadata attached

## Current State
Mode router routes ANALYTICAL inputs here.
Epistemic labeler (L05) expects evidence from this layer.
The wiring exists conceptually — the module does not yet exist.
