# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          analytical_core.py — Labyrinth-OS / Lane 1 / L04
# ----------------------------------------------------------------------------

"""
analytical_core.py — Labyrinth-OS / Lane 1 / L04
==================================================
L04 Analytical Core

Structured reasoning on ideas. Evidence gathering. Contradiction detection.
Outputs feed into L05 Epistemic Labeling alongside creative outputs.

The analytical core does NOT promote ideas. That is L08's job.
It does NOT label ideas. That is L05's job.
It provides the evidence that L05 and L08 evaluate.

Three operations:
  analyze(idea)      → AnalysisResult (evidence + contradictions + confidence)
  compare(a, b)      → ComparisonResult (which is better supported)
  find_contradiction(idea, context) → List[str] (known contradictions)

Council uses analytical output but does not replace it.
Council labels signal trust. Analytical core provides the signals.

References:
  ARCHITECTURE.md  — L04 Analytical Core
  epistemic_types.py — IdeaNode, evidence field
  epistemic_labeler.py — uses evidence from this layer
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass(frozen=True)
class AnalysisResult:
    """
    Result of analyzing one idea.

    idea_id         — which idea was analyzed
    evidence        — supporting evidence items found
    contradictions  — known contradictions found
    confidence      — analytical confidence (0.0–1.0)
                      based on evidence count and contradiction count
    has_test_ref    — whether a test reference was found
    analyzed_at     — timestamp
    """
    idea_id:        str
    evidence:       List[str]
    contradictions: List[str]
    confidence:     float
    has_test_ref:   bool
    analyzed_at:    float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "idea_id":        self.idea_id,
            "evidence_count": len(self.evidence),
            "contradiction_count": len(self.contradictions),
            "confidence":     round(self.confidence, 4),
            "has_test_ref":   self.has_test_ref,
            "analyzed_at":    self.analyzed_at,
        }


@dataclass(frozen=True)
class ComparisonResult:
    """Result of comparing two ideas."""
    idea_a:     str
    idea_b:     str
    preferred:  Optional[str]   # idea_id of preferred, or None if equal
    reason:     str
    confidence: float


class AnalyticalCore:
    """
    L04: Evidence gatherer and contradiction detector.

    analyze(content, idea_id) → AnalysisResult
    compare(a_content, b_content) → ComparisonResult
    find_contradictions(content, context) → List[str]

    In prototype: uses simple heuristics.
    In production: calls a structured reasoning pipeline or
    a dedicated analytical LLM with structured output.

    Does NOT modify ideas. Does NOT label. Does NOT promote.
    """

    # Heuristics for evidence detection (prototype)
    EVIDENCE_SIGNALS = [
        "because", "therefore", "since", "given that", "proven",
        "tested", "verified", "confirmed", "evidence shows",
        "data indicates", "research shows", "according to",
    ]

    CONTRADICTION_SIGNALS = [
        "however", "but", "contrary to", "contradicts", "conflicts with",
        "inconsistent", "disproven", "falsified", "refuted",
    ]

    TEST_SIGNALS = [
        "test", "assert", "verify", "check", "prove",
        "reproduce", "run", "execute", "validate",
    ]

    def analyze(
        self,
        content: str,
        idea_id: str,
        context: Optional[List[str]] = None,
    ) -> AnalysisResult:
        """
        Analyze one idea. Returns AnalysisResult with evidence and contradictions.
        """
        context = context or []
        text_lower = content.lower()

        evidence = []
        for signal in self.EVIDENCE_SIGNALS:
            if signal in text_lower:
                evidence.append(f"contains '{signal}' — supporting reasoning present")

        contradictions = self.find_contradictions(content, context)

        has_test = any(s in text_lower for s in self.TEST_SIGNALS)
        if has_test:
            evidence.append("contains test reference")

        # Confidence: scales with evidence, penalized by contradictions
        base = min(1.0, len(evidence) * 0.15)
        penalty = min(base, len(contradictions) * 0.20)
        confidence = max(0.0, base - penalty)

        return AnalysisResult(
            idea_id=idea_id,
            evidence=evidence,
            contradictions=contradictions,
            confidence=round(confidence, 4),
            has_test_ref=has_test,
            analyzed_at=time.time(),
        )

    def find_contradictions(
        self,
        content: str,
        context: List[str],
    ) -> List[str]:
        """
        Find contradictions between content and context items.
        In prototype: keyword-based. In production: semantic comparison.
        """
        contradictions = []
        text_lower = content.lower()

        # Check for explicit contradiction language
        for signal in self.CONTRADICTION_SIGNALS:
            if signal in text_lower:
                contradictions.append(
                    f"contains contradiction signal: '{signal}'"
                )

        # Check context for conflicting claims
        for ctx in context:
            ctx_lower = ctx.lower()
            # Simple heuristic: both contain "not" or "no" for same subject
            if ("not" in text_lower and "not" not in ctx_lower and
                    len(set(text_lower.split()) & set(ctx_lower.split())) > 3):
                contradictions.append(
                    f"possible conflict with context: {ctx[:60]}..."
                )

        return contradictions

    def compare(
        self,
        idea_a_id: str,
        idea_a_content: str,
        idea_b_id: str,
        idea_b_content: str,
    ) -> ComparisonResult:
        """
        Compare two ideas. Returns which is better analytically supported.
        """
        result_a = self.analyze(idea_a_content, idea_a_id)
        result_b = self.analyze(idea_b_content, idea_b_id)

        if result_a.confidence > result_b.confidence + 0.05:
            preferred = idea_a_id
            reason = (
                f"A has higher analytical confidence: "
                f"{result_a.confidence:.2f} vs {result_b.confidence:.2f}"
            )
        elif result_b.confidence > result_a.confidence + 0.05:
            preferred = idea_b_id
            reason = (
                f"B has higher analytical confidence: "
                f"{result_b.confidence:.2f} vs {result_a.confidence:.2f}"
            )
        else:
            preferred = None
            reason = (
                f"Similar confidence: A={result_a.confidence:.2f} "
                f"B={result_b.confidence:.2f}"
            )

        return ComparisonResult(
            idea_a=idea_a_id,
            idea_b=idea_b_id,
            preferred=preferred,
            reason=reason,
            confidence=max(result_a.confidence, result_b.confidence),
        )


# ─── CONVENIENCE ──────────────────────────────────────────────────────────────

_core = AnalyticalCore()

def analyze(content: str, idea_id: str,
            context: Optional[List[str]] = None) -> AnalysisResult:
    return _core.analyze(content, idea_id, context)


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_analyze_returns_result() -> bool:
    r = analyze("This is true because tests confirm it.", "idea_1")
    assert r.idea_id == "idea_1"
    assert isinstance(r.confidence, float)
    assert 0.0 <= r.confidence <= 1.0
    return True

def _test_evidence_detected() -> bool:
    r = analyze("This works because the data indicates it.", "e1")
    assert len(r.evidence) > 0
    return True

def _test_test_ref_detected() -> bool:
    r = analyze("We should test this and verify it works.", "t1")
    assert r.has_test_ref
    assert any("test" in e for e in r.evidence)
    return True

def _test_contradiction_detected() -> bool:
    r = analyze("This is not correct, however it seems true.", "c1")
    assert len(r.contradictions) > 0
    return True

def _test_confidence_penalized_by_contradiction() -> bool:
    no_contradiction = analyze("This is true because tests confirm it.", "n1")
    with_contradiction = analyze(
        "This is true however contradicts everything.", "c1"
    )
    # Contradiction should reduce confidence
    assert with_contradiction.confidence <= no_contradiction.confidence
    return True

def _test_compare_returns_preferred() -> bool:
    core = AnalyticalCore()
    r = core.compare(
        "a1", "This is proven because tests confirm it.",
        "b1", "This might be true.",
    )
    assert r.preferred in ("a1", "b1", None)
    assert r.reason
    return True

def _test_empty_content_analyzed() -> bool:
    r = analyze("", "empty_1")
    assert r.idea_id == "empty_1"
    assert r.confidence == 0.0
    return True

def _test_to_dict_serializable() -> bool:
    import json
    r = analyze("test content because it works", "s1")
    json.dumps(r.to_dict())
    return True


def run_tests() -> tuple:
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("ANALYTICAL CORE — Labyrinth-OS / Lane 1 / L04")
    print("Evidence. Contradiction detection. No labeling. No promotion.")
    print("=" * 70)
    print("\n── TEST SUITE ──\n")
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err: line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed")
    if failed: raise SystemExit(1)
    import hashlib as _hl
    with open(__file__, "rb") as f:
        fh = _hl.sha256(f.read()).hexdigest()
    print(f"\n── RECEIPT ──\n  SHA-256: {fh}")
    print(f"\n{'='*70}\n  ANALYTICAL CORE — COMPLETE\n{'='*70}")
