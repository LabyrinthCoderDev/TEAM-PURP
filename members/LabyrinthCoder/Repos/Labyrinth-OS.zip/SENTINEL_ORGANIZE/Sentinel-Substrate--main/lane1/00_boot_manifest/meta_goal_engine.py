# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          meta_goal_engine.py — Labyrinth-OS / Lane 1 / L00a
# ----------------------------------------------------------------------------

"""
meta_goal_engine.py — Labyrinth-OS / Lane 1 / L00a
====================================================
Meta-Goal Layer — The Driver

The gap this closes:
  Labyrinth-OS governs proposals completely.
  It did not previously decide what proposals should be ABOUT.
  That required a meta-goal layer.

  Without this: system waits for a human prompt.
  With this: system drives itself from system state + memory.

Goal lifecycle (from Quillan emergent goal formation, built natively):
  Formulate → Prioritize → Validate → Revise

Position in pipeline:
  Runs before L00 Boot Manifest in the session lifecycle.
  Produces a GoalDirective that seeds L01 ProposalNode generation.

Design rules:
  1. Meta-goals are formulated from system state + memory archive
  2. Goals are prioritized by novelty and uncertainty reduction
  3. Goals are validated against Labyrinth-OS invariants before use
  4. Goals that fail validation are revised, not silently dropped
  5. Every goal directive is typed, immutable, and archived
  6. Meta-goal layer cannot modify execution. It influences proposals only.
  7. A GoalDirective that has not been validated must not seed L01.

Labyrinth-OS owns this implementation entirely.
Quillan's emergent goal formation paper (File 16) is the reference.
See: archive/external_references/quillan/ASSESSMENT_quillan.md
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, List, Optional, Tuple


# ─── GOAL TYPES ──────────────────────────────────────────────────────────────

@unique
class GoalType(str, Enum):
    EXPLORATION    = "EXPLORATION"    # reduce uncertainty about unknown domain
    CONSOLIDATION  = "CONSOLIDATION"  # strengthen known-good patterns
    REMEDIATION    = "REMEDIATION"    # address known failure pattern
    CALIBRATION    = "CALIBRATION"    # recalibrate confidence or thresholds
    DOMAIN_PROBE   = "DOMAIN_PROBE"   # test domain-specific reasoning


@unique
class GoalStatus(str, Enum):
    FORMULATED = "FORMULATED"
    PRIORITIZED = "PRIORITIZED"
    VALIDATED  = "VALIDATED"
    ACTIVE     = "ACTIVE"
    REVISED    = "REVISED"
    COMPLETED  = "COMPLETED"
    REJECTED   = "REJECTED"


# ─── GOAL DIRECTIVE ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class GoalDirective:
    """
    Immutable typed goal directive.

    Produced by MetaGoalEngine after formulate → prioritize → validate.
    Seeds L01 ProposalNode generation for the session.

    Only a VALIDATED GoalDirective may seed L01.
    """
    goal_id:        str
    goal_type:      GoalType
    status:         GoalStatus
    priority:       float          # 0.0–1.0 (higher = more urgent)
    description:    str            # human-readable goal statement
    domain_hint:    Optional[str]  # domain profile to activate (or None)
    memory_context: List[str]      # archive entries that informed this goal
    constraints:    List[str]      # invariants this goal must respect
    created_at:     float
    validated_at:   Optional[float]
    revision_of:    Optional[str]  # goal_id of prior version if revised
    directive_hash: str            # SHA-256 of goal content

    def is_valid_for_l01(self) -> bool:
        """Only VALIDATED goals may seed L01."""
        return self.status == GoalStatus.VALIDATED

    def to_dict(self) -> Dict[str, Any]:
        return {
            "goal_id":        self.goal_id,
            "goal_type":      self.goal_type.value,
            "status":         self.status.value,
            "priority":       self.priority,
            "description":    self.description,
            "domain_hint":    self.domain_hint,
            "memory_context": self.memory_context,
            "constraints":    self.constraints,
            "created_at":     self.created_at,
            "validated_at":   self.validated_at,
            "revision_of":    self.revision_of,
            "directive_hash": self.directive_hash,
        }

    @staticmethod
    def _compute_hash(
        goal_type: str,
        description: str,
        domain_hint: Optional[str],
        created_at: float,
    ) -> str:
        content = f"{goal_type}|{description}|{domain_hint}|{created_at}"
        return hashlib.sha256(content.encode()).hexdigest()


# ─── VALIDATION RESULT ───────────────────────────────────────────────────────

@dataclass(frozen=True)
class GoalValidationResult:
    """Result of validating a GoalDirective against system invariants."""
    passed:   bool
    failures: List[str]
    warnings: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "passed":   self.passed,
            "failures": self.failures,
            "warnings": self.warnings,
        }


# ─── META-GOAL ENGINE ────────────────────────────────────────────────────────

class MetaGoalEngine:
    """
    Drives the system by formulating, prioritizing, validating,
    and revising goals before each session.

    Lifecycle per session:
      1. formulate()  — generate candidate goals from state + memory
      2. prioritize() — rank candidates by novelty + urgency
      3. validate()   — check against invariants
      4. revise()     — if validation fails, revise and re-validate
      5. directive()  — return the top VALIDATED GoalDirective for L01
    """

    # Invariant constraints every goal must respect
    SYSTEM_CONSTRAINTS = [
        "goal must not modify execution directly",
        "goal must not bypass the Reality Gate",
        "goal must not promote its own output",
        "goal must not suppress failure records",
        "goal must be archivable and replayable",
    ]

    def __init__(
        self,
        failure_history: Optional[List[Dict[str, Any]]] = None,
        domain_context: Optional[str] = None,
        session_id: Optional[str] = None,
    ):
        self._failure_history = failure_history or []
        self._domain_context  = domain_context
        self._session_id      = session_id or f"session_{time.time()}"
        self._candidates:  List[GoalDirective] = []
        self._active_goal: Optional[GoalDirective] = None

    # ── STEP 1: FORMULATE ────────────────────────────────────────────────────

    def formulate(self) -> List[GoalDirective]:
        """
        Generate candidate goals from failure history and domain context.

        Candidates are formulated, not yet validated.
        Returns list sorted by preliminary priority (desc).
        """
        candidates = []
        now = time.time()

        # If there are recent failures, remediation has highest priority
        valid_failures = [f for f in self._failure_history
                          if isinstance(f, dict)]
        if valid_failures:
            failure_types = [f.get("failure_type", "unknown")
                             for f in valid_failures[-5:]]
            desc = (f"Address recent failure pattern: "
                    f"{', '.join(set(failure_types))}")
            cue_context = [f.get("id", "unknown")
                           for f in valid_failures[-3:]]
            goal_id = self._make_id("remediation")
            h = GoalDirective._compute_hash("REMEDIATION", desc,
                                            self._domain_context, now)
            candidates.append(GoalDirective(
                goal_id        = goal_id,
                goal_type      = GoalType.REMEDIATION,
                status         = GoalStatus.FORMULATED,
                priority       = 0.90,
                description    = desc,
                domain_hint    = self._domain_context,
                memory_context = cue_context,
                constraints    = self.SYSTEM_CONSTRAINTS,
                created_at     = now,
                validated_at   = None,
                revision_of    = None,
                directive_hash = h,
            ))

        # Domain probe if domain context is set
        if self._domain_context:
            desc = f"Probe domain '{self._domain_context}' to test reasoning"
            goal_id = self._make_id("domain_probe")
            h = GoalDirective._compute_hash("DOMAIN_PROBE", desc,
                                            self._domain_context, now + 0.001)
            candidates.append(GoalDirective(
                goal_id        = goal_id,
                goal_type      = GoalType.DOMAIN_PROBE,
                status         = GoalStatus.FORMULATED,
                priority       = 0.70,
                description    = desc,
                domain_hint    = self._domain_context,
                memory_context = [],
                constraints    = self.SYSTEM_CONSTRAINTS,
                created_at     = now + 0.001,
                validated_at   = None,
                revision_of    = None,
                directive_hash = h,
            ))

        # Default: exploration (always available)
        desc = "Explore novel proposal space to reduce epistemic uncertainty"
        goal_id = self._make_id("exploration")
        h = GoalDirective._compute_hash("EXPLORATION", desc,
                                        self._domain_context, now + 0.002)
        candidates.append(GoalDirective(
            goal_id        = goal_id,
            goal_type      = GoalType.EXPLORATION,
            status         = GoalStatus.FORMULATED,
            priority       = 0.50,
            description    = desc,
            domain_hint    = self._domain_context,
            memory_context = [],
            constraints    = self.SYSTEM_CONSTRAINTS,
            created_at     = now + 0.002,
            validated_at   = None,
            revision_of    = None,
            directive_hash = h,
        ))

        self._candidates = sorted(candidates,
                                  key=lambda g: g.priority, reverse=True)
        return self._candidates

    # ── STEP 2: PRIORITIZE ───────────────────────────────────────────────────

    def prioritize(self) -> List[GoalDirective]:
        """
        Re-rank candidates after formulation.
        Currently returns formulated list sorted by priority.
        Extended by domain profiles or memory signals when available.
        """
        if not self._candidates:
            self.formulate()
        return sorted(self._candidates, key=lambda g: g.priority, reverse=True)

    # ── STEP 3: VALIDATE ─────────────────────────────────────────────────────

    def validate(self, goal: GoalDirective) -> GoalValidationResult:
        """
        Validate a GoalDirective against system invariants.

        A goal that modifies execution, bypasses the gate, or promotes
        its own output fails validation and must be revised.
        """
        failures = []
        warnings = []

        # Must have a description
        if not goal.description or len(goal.description.strip()) < 10:
            failures.append("description too short or empty")

        # Must have a valid goal type
        if goal.goal_type not in GoalType:
            failures.append(f"unknown goal_type: {goal.goal_type}")

        # Priority must be in range
        if not 0.0 <= goal.priority <= 1.0:
            failures.append(f"priority out of range: {goal.priority}")

        # Must carry system constraints
        for constraint in self.SYSTEM_CONSTRAINTS:
            if constraint not in goal.constraints:
                failures.append(f"missing constraint: {constraint}")

        # Domain hint must be a string if provided
        if goal.domain_hint is not None and not isinstance(goal.domain_hint, str):
            failures.append("domain_hint must be string or None")

        # Warn if no memory context and history exists
        valid_failures = [f for f in self._failure_history if isinstance(f, dict)]
        if not goal.memory_context and valid_failures:
            warnings.append("goal has no memory context despite failure history")

        # Hash must be present and correct length
        if not goal.directive_hash or len(goal.directive_hash) != 64:
            failures.append("directive_hash missing or malformed")

        return GoalValidationResult(
            passed   = len(failures) == 0,
            failures = failures,
            warnings = warnings,
        )

    # ── STEP 4: REVISE ───────────────────────────────────────────────────────

    def revise(
        self,
        goal: GoalDirective,
        validation: GoalValidationResult,
    ) -> Optional[GoalDirective]:
        """
        Attempt to revise a failed goal.

        Returns revised GoalDirective if revision is possible.
        Returns None if goal cannot be salvaged.
        """
        if validation.passed:
            return goal  # No revision needed

        # If description is the only issue, patch it
        if (validation.failures == ["description too short or empty"] and
                goal.description):
            now = time.time()
            new_desc = f"[revised] {goal.description} — auto-expanded for validity"
            h = GoalDirective._compute_hash(
                goal.goal_type.value, new_desc, goal.domain_hint, now
            )
            return GoalDirective(
                goal_id        = self._make_id("revised"),
                goal_type      = goal.goal_type,
                status         = GoalStatus.REVISED,
                priority       = max(0.0, goal.priority - 0.05),
                description    = new_desc,
                domain_hint    = goal.domain_hint,
                memory_context = goal.memory_context,
                constraints    = self.SYSTEM_CONSTRAINTS,
                created_at     = now,
                validated_at   = None,
                revision_of    = goal.goal_id,
                directive_hash = h,
            )

        # Other failures: cannot safely revise
        return None

    # ── STEP 5: GET ACTIVE DIRECTIVE ─────────────────────────────────────────

    def get_directive(self) -> Optional[GoalDirective]:
        """
        Run the full lifecycle and return the top VALIDATED GoalDirective.

        Returns None if no valid goal can be produced.
        This is the method called by IgnitionSession before L01.
        """
        candidates = self.prioritize()

        for candidate in candidates:
            validation = self.validate(candidate)

            if validation.passed:
                # Stamp as validated
                now = time.time()
                validated = GoalDirective(
                    goal_id        = candidate.goal_id,
                    goal_type      = candidate.goal_type,
                    status         = GoalStatus.VALIDATED,
                    priority       = candidate.priority,
                    description    = candidate.description,
                    domain_hint    = candidate.domain_hint,
                    memory_context = candidate.memory_context,
                    constraints    = candidate.constraints,
                    created_at     = candidate.created_at,
                    validated_at   = now,
                    revision_of    = candidate.revision_of,
                    directive_hash = candidate.directive_hash,
                )
                self._active_goal = validated
                return validated

            # Try revision
            revised = self.revise(candidate, validation)
            if revised is not None:
                rev_validation = self.validate(revised)
                if rev_validation.passed:
                    now = time.time()
                    validated = GoalDirective(
                        goal_id        = revised.goal_id,
                        goal_type      = revised.goal_type,
                        status         = GoalStatus.VALIDATED,
                        priority       = revised.priority,
                        description    = revised.description,
                        domain_hint    = revised.domain_hint,
                        memory_context = revised.memory_context,
                        constraints    = revised.constraints,
                        created_at     = revised.created_at,
                        validated_at   = now,
                        revision_of    = revised.revision_of,
                        directive_hash = revised.directive_hash,
                    )
                    self._active_goal = validated
                    return validated

        # No valid goal produced
        return None

    # ── HELPERS ──────────────────────────────────────────────────────────────

    def _make_id(self, prefix: str) -> str:
        ts = str(time.time()).replace(".", "")
        return f"goal_{prefix}_{self._session_id}_{ts}"


# ─── TESTS ───────────────────────────────────────────────────────────────────

def run_tests() -> tuple:
    passed = failed = 0
    results = []

    def t(name, fn):
        nonlocal passed, failed
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))

    def test_engine_formulates_candidates():
        engine = MetaGoalEngine()
        candidates = engine.formulate()
        assert len(candidates) >= 1
    t("test_engine_formulates_candidates", test_engine_formulates_candidates)

    def test_remediation_goal_when_failures_present():
        engine = MetaGoalEngine(failure_history=[
            {"failure_type": "GATE_REJECTION", "id": "f1"},
        ])
        candidates = engine.formulate()
        types = [c.goal_type for c in candidates]
        assert GoalType.REMEDIATION in types
    t("test_remediation_goal_when_failures_present",
      test_remediation_goal_when_failures_present)

    def test_remediation_has_highest_priority():
        engine = MetaGoalEngine(failure_history=[
            {"failure_type": "SIGMA_BLOCKED", "id": "f2"},
        ])
        candidates = engine.formulate()
        assert candidates[0].goal_type == GoalType.REMEDIATION
    t("test_remediation_has_highest_priority",
      test_remediation_has_highest_priority)

    def test_domain_probe_added_with_domain_context():
        engine = MetaGoalEngine(domain_context="medical")
        candidates = engine.formulate()
        types = [c.goal_type for c in candidates]
        assert GoalType.DOMAIN_PROBE in types
    t("test_domain_probe_added_with_domain_context",
      test_domain_probe_added_with_domain_context)

    def test_exploration_always_present():
        engine = MetaGoalEngine()
        candidates = engine.formulate()
        types = [c.goal_type for c in candidates]
        assert GoalType.EXPLORATION in types
    t("test_exploration_always_present", test_exploration_always_present)

    def test_validation_passes_for_valid_goal():
        engine = MetaGoalEngine()
        candidates = engine.formulate()
        result = engine.validate(candidates[0])
        assert result.passed, f"Failures: {result.failures}"
    t("test_validation_passes_for_valid_goal",
      test_validation_passes_for_valid_goal)

    def test_validation_fails_empty_description():
        engine = MetaGoalEngine()
        candidates = engine.formulate()
        bad_goal = GoalDirective(
            goal_id="bad", goal_type=GoalType.EXPLORATION,
            status=GoalStatus.FORMULATED, priority=0.5,
            description="", domain_hint=None, memory_context=[],
            constraints=MetaGoalEngine.SYSTEM_CONSTRAINTS,
            created_at=time.time(), validated_at=None, revision_of=None,
            directive_hash="a" * 64,
        )
        result = engine.validate(bad_goal)
        assert not result.passed
        assert any("description" in f for f in result.failures)
    t("test_validation_fails_empty_description",
      test_validation_fails_empty_description)

    def test_get_directive_returns_validated_goal():
        engine = MetaGoalEngine()
        directive = engine.get_directive()
        assert directive is not None
        assert directive.status == GoalStatus.VALIDATED
        assert directive.validated_at is not None
    t("test_get_directive_returns_validated_goal",
      test_get_directive_returns_validated_goal)

    def test_validated_goal_passes_l01_check():
        engine = MetaGoalEngine()
        directive = engine.get_directive()
        assert directive.is_valid_for_l01()
    t("test_validated_goal_passes_l01_check",
      test_validated_goal_passes_l01_check)

    def test_goal_directive_is_immutable():
        engine = MetaGoalEngine()
        directive = engine.get_directive()
        try:
            directive.priority = 0.0
            raise AssertionError("Should be immutable")
        except Exception as e:
            assert "frozen" in str(e).lower() or "can't" in str(e).lower() or "FrozenInstanceError" in type(e).__name__
    t("test_goal_directive_is_immutable", test_goal_directive_is_immutable)

    def test_goal_directive_to_dict_serializable():
        engine = MetaGoalEngine()
        directive = engine.get_directive()
        json.dumps(directive.to_dict())
    t("test_goal_directive_to_dict_serializable",
      test_goal_directive_to_dict_serializable)

    def test_directive_hash_is_64_chars():
        engine = MetaGoalEngine()
        directive = engine.get_directive()
        assert len(directive.directive_hash) == 64
    t("test_directive_hash_is_64_chars", test_directive_hash_is_64_chars)

    def test_revision_tracks_origin():
        engine = MetaGoalEngine()
        candidates = engine.formulate()
        # Force a revision scenario by making validation fail
        short_goal = GoalDirective(
            goal_id="short", goal_type=GoalType.EXPLORATION,
            status=GoalStatus.FORMULATED, priority=0.5,
            description="short",
            domain_hint=None, memory_context=[],
            constraints=MetaGoalEngine.SYSTEM_CONSTRAINTS,
            created_at=time.time(), validated_at=None, revision_of=None,
            directive_hash="b" * 64,
        )
        validation = engine.validate(short_goal)
        if not validation.passed:
            revised = engine.revise(short_goal, validation)
            if revised is not None:
                assert revised.revision_of == "short"
    t("test_revision_tracks_origin", test_revision_tracks_origin)

    def test_prioritize_returns_sorted_by_priority():
        engine = MetaGoalEngine(
            failure_history=[{"failure_type": "GATE_REJECTION", "id": "f3"}],
            domain_context="industrial"
        )
        ranked = engine.prioritize()
        priorities = [g.priority for g in ranked]
        assert priorities == sorted(priorities, reverse=True)
    t("test_prioritize_returns_sorted_by_priority",
      test_prioritize_returns_sorted_by_priority)

    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("Labyrinth-OS — Meta-Goal Engine")
    print("The driver half. Closes the autonomous operation gap.")
    print("=" * 70)
    print()
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err:
            line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed")
    if failed:
        raise SystemExit(1)
    print("\n  Meta-Goal Engine — COMPLETE")
    print("=" * 70)
