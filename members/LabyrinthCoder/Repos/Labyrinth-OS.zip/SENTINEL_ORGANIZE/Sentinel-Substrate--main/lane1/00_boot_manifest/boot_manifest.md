# L00 — Boot Manifest

**Status:** STUB — not yet implemented
**Layer:** Pre-Lane (system bootstrap before dual-lane split begins)

## What Goes Here

The Boot Manifest is the system's self-description on startup.
It loads and validates:
- System configuration (Sigma Anchor constants)
- Hardware availability (FPGA latch, guardian slot)
- Lane 1 + Lane 2 module presence
- ACP-1 assumption register state

## When This Runs

Before any input arrives. Before any lane is active.
L00 → L01 → L02 → (Lane 1 or Lane 2)

## Implementation Notes

Currently handled implicitly by ignition.py startup checks.
Formal L00 module needed when system runs as a daemon (eden_daemon.py).

## Files Needed
- boot_manifest.py — loads config, validates hardware, checks modules
- boot_receipt.py  — immutable record of each boot (feeds L13 Ledger)
