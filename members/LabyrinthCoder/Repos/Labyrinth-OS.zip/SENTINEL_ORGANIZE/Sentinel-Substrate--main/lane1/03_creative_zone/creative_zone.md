# L03 — Creative Zone

**Status:** STUB — not yet implemented
**Layer:** Lane 1 (unbounded generation — no suppression)

## What Goes Here

The creative zone is where ideas are generated without constraint.
Hallucination is allowed here. Speculation is allowed here.
Nothing from this zone executes directly. Ever.

Output feeds into L05 Epistemic Labeling — everything gets labeled.

## Core Rule
Ideas generated here are UNKNOWN until labeled.
They cannot skip L05. They cannot cross the Reality Gate (L09) without
passing through L06 Archive, L07 Deferred, L08 Promotion first.

## Files Needed
- creative_zone.py — idea generation, prompt construction, output capture
- creative_node.py — IdeaNode factory for creative outputs

## Current State
Mode router (lane1/02_mode_router/mode_router.py) routes CREATIVE
inputs to this layer. The routing exists. The processing stub does not.
