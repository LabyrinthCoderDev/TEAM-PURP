# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          creative_zone.py — Labyrinth-OS / Lane 1 / L03
# ----------------------------------------------------------------------------

"""
creative_zone.py — Labyrinth-OS / Lane 1 / L03
================================================
L03 Creative Zone

Unbounded idea generation. No suppression. Hallucination allowed.
Nothing from this zone executes directly. Ever.

Output feeds into L05 Epistemic Labeling — everything gets labeled.
Ideas that come out are UNKNOWN until labeled.

This zone does not evaluate ideas. It generates them.
Evaluation is L04 (Analytical Core) and L05 (Epistemic Labeling).

Core rule: the creative zone has no authority over what is true.
It has authority over what is proposed.

References:
  ARCHITECTURE.md — L03 Creative Zone
  epistemic_types.py — IdeaNode, EpistemicLabel.UNKNOWN
  mode_router.py — routes CREATIVE inputs here
"""

from __future__ import annotations

import hashlib
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class CreativeOutput:
    """
    Output of one creative generation pass.

    idea_id     — stable unique identifier
    content     — the generated idea (text, structured, anything)
    prompt      — the input that triggered this idea
    generated_at — when it was generated
    session_id  — which session

    Label is NOT set here. Label is always UNKNOWN until L05 assigns it.
    The creative zone does not label its own output.
    """
    idea_id:      str
    content:      str
    prompt:       str
    generated_at: float
    session_id:   Optional[str] = None
    parent_id:    Optional[str] = None  # if derived from another idea

    @property
    def content_hash(self) -> str:
        return hashlib.sha256(self.content.encode()).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "idea_id":      self.idea_id,
            "content_hash": self.content_hash,
            "prompt":       self.prompt,
            "generated_at": self.generated_at,
            "session_id":   self.session_id,
            "parent_id":    self.parent_id,
            "label":        "UNKNOWN",  # always UNKNOWN at this stage
        }


class CreativeZone:
    """
    L03: Idea generator. No suppression. No evaluation.

    generate(prompt) → CreativeOutput
    generate_batch(prompts) → List[CreativeOutput]

    The creative zone is the pressure source — it continuously
    generates candidates that feed the epistemic pipeline.
    High volume, low authority. All ideas are UNKNOWN until proven.
    """

    def generate(
        self,
        prompt: str,
        session_id: Optional[str] = None,
        parent_id: Optional[str] = None,
    ) -> CreativeOutput:
        """
        Generate one creative output from a prompt.
        Never suppresses. Never evaluates.
        Returns CreativeOutput with label=UNKNOWN (implicit).
        """
        # In prototype: content mirrors the prompt with a creative framing.
        # In production: this calls the LLM API (Lane 1 side only).
        # The output never reaches execution directly — it must pass
        # through L05 labeling, L06 archive, L08 promotion, L09 gate.
        content = self._frame(prompt)
        return CreativeOutput(
            idea_id=str(uuid.uuid4()),
            content=content,
            prompt=prompt,
            generated_at=time.time(),
            session_id=session_id,
            parent_id=parent_id,
        )

    def generate_batch(
        self,
        prompts: List[str],
        session_id: Optional[str] = None,
    ) -> List[CreativeOutput]:
        """Generate one output per prompt. All outputs are UNKNOWN."""
        return [self.generate(p, session_id=session_id) for p in prompts]

    def _frame(self, prompt: str) -> str:
        """
        Minimal creative framing. Marks output as a proposal, not a fact.
        In production this is replaced by an LLM call.
        """
        if not prompt.strip():
            return "[CREATIVE] Empty prompt — no idea generated."
        return f"[CREATIVE PROPOSAL] {prompt.strip()}"


# ─── CONVENIENCE ──────────────────────────────────────────────────────────────

_zone = CreativeZone()

def generate(prompt: str, session_id: Optional[str] = None) -> CreativeOutput:
    return _zone.generate(prompt, session_id=session_id)


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_generate_returns_output() -> bool:
    out = generate("what if we redesigned the gate?")
    assert out.idea_id and out.content and out.prompt
    assert out.generated_at > 0
    return True

def _test_label_always_unknown() -> bool:
    """Creative output always reports UNKNOWN label."""
    out = generate("any idea")
    assert out.to_dict()["label"] == "UNKNOWN"
    return True

def _test_ids_unique() -> bool:
    o1 = generate("same prompt")
    o2 = generate("same prompt")
    assert o1.idea_id != o2.idea_id
    return True

def _test_content_hash_stable() -> bool:
    out = generate("test")
    assert out.content_hash == out.content_hash
    assert len(out.content_hash) == 64
    return True

def _test_empty_prompt_handled() -> bool:
    out = generate("")
    assert out.idea_id  # still produces output
    assert "Empty" in out.content
    return True

def _test_batch_generate() -> bool:
    prompts = ["idea 1", "idea 2", "idea 3"]
    outputs = _zone.generate_batch(prompts)
    assert len(outputs) == 3
    ids = {o.idea_id for o in outputs}
    assert len(ids) == 3  # all unique
    return True

def _test_parent_id_preserved() -> bool:
    out = _zone.generate("derived idea", parent_id="parent_001")
    assert out.parent_id == "parent_001"
    return True

def _test_to_dict_serializable() -> bool:
    import json
    out = generate("test", session_id="s1")
    json.dumps(out.to_dict())
    return True


def run_tests() -> tuple:
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("CREATIVE ZONE — Labyrinth-OS / Lane 1 / L03")
    print("Unbounded. No suppression. All output is UNKNOWN.")
    print("=" * 70)
    print("\n── TEST SUITE ──\n")
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err: line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed")
    if failed: raise SystemExit(1)
    import hashlib as _hl
    with open(__file__, "rb") as f:
        fh = _hl.sha256(f.read()).hexdigest()
    print(f"\n── RECEIPT ──\n  SHA-256: {fh}")
    print(f"\n{'='*70}\n  CREATIVE ZONE — COMPLETE\n{'='*70}")
