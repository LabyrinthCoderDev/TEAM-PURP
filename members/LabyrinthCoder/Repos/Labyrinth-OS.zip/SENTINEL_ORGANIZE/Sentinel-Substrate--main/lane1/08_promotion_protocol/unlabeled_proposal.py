# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          unlabeled_proposal.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
unlabeled_proposal.py — Labyrinth-OS
=======================================
Typed artifact for Option B (labeling_required=False) proposals.

When labeling is skipped, the proposal is wrapped as an UnlabeledProposal.
CGIR entry explicitly rejects UnlabeledProposal unless it carries an
exception token — making the bypass visible and traceable, not silent.

This closes GPT audit Issue 2: labeling_required=False should produce
a different artifact type, not silently propagate as if labeled.

Without this:
  PipelineTrace(labeling_required=False) → passes silently → relies on discipline

With this:
  PipelineTrace(labeling_required=False) → produces UnlabeledProposal
  → CGIR entry checks type → sees UnlabeledProposal → logs EXCEPTION_PATH
  → prototype: warn; post-prototype: block

PROTOTYPE NOTE: UnlabeledProposal is accepted with WARNING in prototype phase.
ROADMAP (post-prototype): UnlabeledProposal must be rejected at CGIR entry.
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class ExceptionToken:
    """
    Required to pass an UnlabeledProposal into CGIR.
    Must be explicitly constructed — cannot be accidentally included.
    
    In prototype phase: token carries a warning.
    Post-prototype: CGIR entry should require a hardware-signed token.
    """
    reason:     str
    authorized_by: str
    timestamp:  float
    token_hash: str

    @classmethod
    def prototype(cls, reason: str) -> "ExceptionToken":
        """Prototype-phase exception token. Not hardware-signed."""
        ts = time.time()
        token_hash = hashlib.sha256(
            f"PROTOTYPE_EXCEPTION:{reason}:{ts}".encode()
        ).hexdigest()
        return cls(
            reason=reason,
            authorized_by="PROTOTYPE_STUB",
            timestamp=ts,
            token_hash=token_hash,
        )


@dataclass(frozen=True)  
class UnlabeledProposal:
    """
    A proposal that explicitly bypassed labeling (Option B).
    
    Carries the reason and exception token.
    CGIR entry must check for this type and handle accordingly.
    
    This makes the bypass explicit and typed — not a silent flag.
    """
    idea_id:         str
    content_hash:    str
    exception_token: ExceptionToken
    timestamp:       float
    is_prototype_path: bool = True

    @classmethod
    def create(cls, idea_id: str, content: str,
               reason: str = "Option B — prototype path") -> "UnlabeledProposal":
        content_hash = hashlib.sha256(content.encode()).hexdigest()
        return cls(
            idea_id=idea_id,
            content_hash=content_hash,
            exception_token=ExceptionToken.prototype(reason),
            timestamp=time.time(),
            is_prototype_path=True,
        )

    def exception_log_entry(self) -> dict:
        """Returns a log entry describing this exception — for the ledger."""
        return {
            "type":           "LABELING_SKIPPED",
            "idea_id":        self.idea_id,
            "reason":         self.exception_token.reason,
            "authorized_by":  self.exception_token.authorized_by,
            "prototype_path": self.is_prototype_path,
            "timestamp":      self.timestamp,
            "token_hash":     self.exception_token.token_hash,
            "note": (
                "PROTOTYPE: accepted with WARNING. "
                "Post-prototype: CGIR entry must reject UnlabeledProposal."
            ),
        }


# ── TEST SUITE ─────────────────────────────────────────────────────────────────

def _test_unlabeled_proposal_creates_cleanly() -> bool:
    p = UnlabeledProposal.create("idea-001", "proposal content here")
    assert p.idea_id == "idea-001"
    assert p.is_prototype_path
    assert p.exception_token is not None
    return True

def _test_exception_token_has_hash() -> bool:
    tok = ExceptionToken.prototype("test reason")
    assert len(tok.token_hash) == 64
    assert tok.authorized_by == "PROTOTYPE_STUB"
    return True

def _test_log_entry_has_required_fields() -> bool:
    p = UnlabeledProposal.create("idea-002", "content")
    entry = p.exception_log_entry()
    for field in ["type","idea_id","reason","prototype_path","timestamp","token_hash"]:
        assert field in entry, f"Missing field: {field}"
    assert entry["type"] == "LABELING_SKIPPED"
    return True

def _test_different_content_different_hash() -> bool:
    p1 = UnlabeledProposal.create("idea-001", "content A")
    p2 = UnlabeledProposal.create("idea-001", "content B")
    assert p1.content_hash != p2.content_hash
    return True

def _test_frozen_immutable() -> bool:
    p = UnlabeledProposal.create("idea-001", "content")
    try:
        p.idea_id = "tampered"  # type: ignore
        return False
    except Exception:
        return True

def _test_prototype_note_in_log_entry() -> bool:
    """Post-prototype rejection note must be in the log."""
    p = UnlabeledProposal.create("idea-001", "content")
    entry = p.exception_log_entry()
    assert "Post-prototype" in entry["note"] or "post-prototype" in entry["note"].lower()
    return True


def run_tests() -> tuple:
    tests = sorted([(n, o) for n, o in globals().items()
                    if n.startswith("_test_") and callable(o)])
    passed = failed = 0
    results = []
    for name, fn in tests:
        try:
            fn(); passed += 1; results.append((name, "PASS", None))
        except Exception as e:
            failed += 1; results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    p, f, results = run_tests()
    for name, status, err in results:
        print(f"  {'✓' if status=='PASS' else '✗'} {name}" +
              (f": {err}" if err else ""))
    print(f"\n  {p}/{p+f} passed")
    if f: raise SystemExit(1)
