# L01 — User Intent

**Status:** STUB — not yet implemented
**Layer:** Pre-Lane (raw input capture before routing)

## What Goes Here

Every input to the system arrives here first.
L01 normalizes it into a standard IntentRecord before L02 routes it.

No classification happens here. No labeling. Just capture and normalize.

## IntentRecord (planned schema)
- intent_id   — unique ID generated at arrival
- raw_input   — unmodified input text
- source      — API provider, user, sensor, or daemon
- arrived_at  — timestamp
- session_id  — which session this belongs to

## Files Needed
- user_intent.py — IntentRecord dataclass, normalization, ID generation

## Note
Currently ignition.py handles this implicitly.
Formal L01 needed when system processes multi-source input streams.
