# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          user_intent.py — Labyrinth-OS / Lane 1 / L01
# ----------------------------------------------------------------------------

"""
user_intent.py — Labyrinth-OS / Lane 1 / L01
=============================================
L01 User Intent

Every input to the system arrives here first.
L01 normalizes it into a standard IntentRecord.
No classification. No labeling. Just capture and normalize.

The IntentRecord is what L02 (Mode Router) receives.
It contains the raw input unchanged plus metadata.

Sources of input:
  API       — from ignition.py / live inference
  OPERATOR  — direct operator input
  DAEMON    — from background system process
  MUTATION  — re-entry from deferred_node (healing loop)
  TEST      — synthetic test input

References:
  ARCHITECTURE.md — L01 User Intent
  mode_router.py  — receives IntentRecord from L01
"""

from __future__ import annotations

import hashlib
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, Optional


@unique
class IntentSource(str, Enum):
    API      = "API"       # from live inference path
    OPERATOR = "OPERATOR"  # direct operator input
    DAEMON   = "DAEMON"    # background system process
    MUTATION = "MUTATION"  # re-entry from deferred_node
    TEST     = "TEST"      # synthetic test input


@dataclass
class IntentRecord:
    """
    Normalized input record. Created once per input. Never modified.

    intent_id   — stable unique identifier (UUID4)
    raw_input   — unmodified input text (preserved exactly)
    source      — where this input came from
    arrived_at  — wall clock timestamp of arrival
    session_id  — which session this belongs to (optional)
    parent_id   — if MUTATION: the failure record this derives from
    content_hash — SHA-256 of raw_input (for deduplication)
    """
    intent_id:    str
    raw_input:    str
    source:       IntentSource
    arrived_at:   float
    session_id:   Optional[str] = None
    parent_id:    Optional[str] = None  # set for MUTATION source

    def __post_init__(self) -> None:
        if not self.intent_id:
            raise ValueError("intent_id must be non-empty")
        if self.raw_input is None:
            raise ValueError("raw_input must not be None")
        if self.source == IntentSource.MUTATION and not self.parent_id:
            raise ValueError("MUTATION source requires parent_id")

    @property
    def content_hash(self) -> str:
        return hashlib.sha256(self.raw_input.encode()).hexdigest()

    @property
    def is_empty(self) -> bool:
        return not self.raw_input.strip()

    @property
    def is_mutation(self) -> bool:
        return self.source == IntentSource.MUTATION

    def to_dict(self) -> Dict[str, Any]:
        return {
            "intent_id":    self.intent_id,
            "content_hash": self.content_hash,
            "source":       self.source.value,
            "arrived_at":   self.arrived_at,
            "session_id":   self.session_id,
            "parent_id":    self.parent_id,
            "is_empty":     self.is_empty,
            "is_mutation":  self.is_mutation,
        }


class UserIntent:
    """
    L01: Normalizes raw input into IntentRecord.

    capture(raw, source, session_id, parent_id) → IntentRecord

    Always succeeds — even empty input is captured.
    Empty input is flagged (is_empty=True) and routed to
    ANALYTICAL mode by L02 with zero confidence.
    """

    def capture(
        self,
        raw_input: str,
        source: IntentSource = IntentSource.API,
        session_id: Optional[str] = None,
        parent_id: Optional[str] = None,
    ) -> IntentRecord:
        """
        Capture one input. Returns IntentRecord.
        Never raises — even malformed input is recorded.
        """
        intent_id = str(uuid.uuid4())
        return IntentRecord(
            intent_id=intent_id,
            raw_input=str(raw_input) if raw_input is not None else "",
            source=source,
            arrived_at=time.time(),
            session_id=session_id,
            parent_id=parent_id,
        )

    def capture_mutation(
        self,
        candidate_content: str,
        parent_id: str,
        session_id: Optional[str] = None,
    ) -> IntentRecord:
        """
        Capture a mutation re-entry from deferred_node.
        Source is always MUTATION. parent_id is required.
        """
        return self.capture(
            raw_input=candidate_content,
            source=IntentSource.MUTATION,
            session_id=session_id,
            parent_id=parent_id,
        )


# ─── CONVENIENCE ──────────────────────────────────────────────────────────────

_intent = UserIntent()

def capture(raw_input: str, source: IntentSource = IntentSource.API,
            session_id: Optional[str] = None,
            parent_id: Optional[str] = None) -> IntentRecord:
    return _intent.capture(raw_input, source, session_id, parent_id)


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_capture_returns_record() -> bool:
    r = capture("hello world")
    assert r.intent_id and r.raw_input == "hello world"
    assert r.source == IntentSource.API
    assert r.arrived_at > 0
    return True

def _test_content_hash_stable() -> bool:
    r1 = capture("same text")
    r2 = capture("same text")
    assert r1.content_hash == r2.content_hash
    assert len(r1.content_hash) == 64
    return True

def _test_intent_ids_unique() -> bool:
    r1 = capture("text")
    r2 = capture("text")
    assert r1.intent_id != r2.intent_id
    return True

def _test_empty_input_captured() -> bool:
    r = capture("")
    assert r.is_empty
    assert r.intent_id  # still has an ID
    return True

def _test_mutation_requires_parent_id() -> bool:
    pass  # pytest not needed
    try:
        IntentRecord(
            intent_id="x", raw_input="y",
            source=IntentSource.MUTATION,
            arrived_at=1.0,
            parent_id=None,
        )
        raise AssertionError("Should require parent_id")
    except ValueError:
        pass
    return True

def _test_mutation_capture() -> bool:
    ui = UserIntent()
    r = ui.capture_mutation("mutated candidate", parent_id="failure_001")
    assert r.is_mutation
    assert r.parent_id == "failure_001"
    assert r.source == IntentSource.MUTATION
    return True

def _test_to_dict_serializable() -> bool:
    import json
    r = capture("test", IntentSource.OPERATOR, session_id="s1")
    json.dumps(r.to_dict())
    return True

def _test_sources_all_valid() -> bool:
    for source in IntentSource:
        parent = "p1" if source == IntentSource.MUTATION else None
        r = capture("text", source, parent_id=parent)
        assert r.source == source
    return True


def run_tests() -> tuple:
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("USER INTENT — Labyrinth-OS / Lane 1 / L01")
    print("=" * 70)
    print("\n── TEST SUITE ──\n")
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err: line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed")
    if failed: raise SystemExit(1)
    import hashlib as _hl
    with open(__file__, "rb") as f:
        fh = _hl.sha256(f.read()).hexdigest()
    print(f"\n── RECEIPT ──\n  SHA-256: {fh}")
    print(f"\n{'='*70}\n  USER INTENT — COMPLETE\n{'='*70}")
