//! # cgir-validator
//! Labyrinth-OS — CGIR graph validation pipeline.
//!
//! Validates a CGIR graph before it reaches the gate.
//! Fail-closed: any validation failure stops the pipeline.
//! All checks must pass or the graph is rejected.

/// Reasons a graph can be rejected.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ValidationError {
    EmptyGraph,
    UnknownEmitter(String),
    InvalidConfidence(String),
    InvalidSeverity(String),
    TemporalOrderViolation { node: String, time: i64 },
    MissingInvariantBinding,
    DuplicateNodeId(String),
}

impl std::fmt::Display for ValidationError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::EmptyGraph => write!(f, "Graph is empty"),
            Self::UnknownEmitter(e) => write!(f, "Unknown emitter: {e}"),
            Self::InvalidConfidence(n) => write!(f, "Invalid confidence in node {n}"),
            Self::InvalidSeverity(n) => write!(f, "Invalid severity in node {n}"),
            Self::TemporalOrderViolation { node, time } =>
                write!(f, "Temporal violation at {node}: time={time}"),
            Self::MissingInvariantBinding => write!(f, "No invariant binding present"),
            Self::DuplicateNodeId(id) => write!(f, "Duplicate node id: {id}"),
        }
    }
}

/// A node description for validation (minimal — avoids circular deps).
#[derive(Debug, Clone)]
pub struct NodeDesc {
    pub id:          String,
    pub emitted_by:  String,
    pub confidence:  f64,
    pub severity:    String,
    pub logical_time: i64,
    pub has_invariant: bool,
}

const KNOWN_EMITTERS: &[&str] = &["COUNCIL", "SIGNAL_ALGEBRA"];
const KNOWN_SEVERITIES: &[&str] = &["INFO", "WARNING", "ERROR", "CRITICAL"];

/// Run all validation checks on a list of nodes.
pub fn validate(nodes: &[NodeDesc]) -> Result<(), Vec<ValidationError>> {
    let mut errors = Vec::new();

    if nodes.is_empty() {
        errors.push(ValidationError::EmptyGraph);
        return Err(errors);
    }

    let mut seen_ids = std::collections::HashSet::new();
    let mut last_time = i64::MIN;
    let mut has_invariant = false;

    for node in nodes {
        // Duplicate IDs
        if !seen_ids.insert(&node.id) {
            errors.push(ValidationError::DuplicateNodeId(node.id.clone()));
        }
        // Known emitter
        if !KNOWN_EMITTERS.contains(&node.emitted_by.as_str()) {
            errors.push(ValidationError::UnknownEmitter(node.emitted_by.clone()));
        }
        // Confidence range
        if !(0.0..=1.0).contains(&node.confidence) {
            errors.push(ValidationError::InvalidConfidence(node.id.clone()));
        }
        // Known severity
        if !KNOWN_SEVERITIES.contains(&node.severity.as_str()) {
            errors.push(ValidationError::InvalidSeverity(node.id.clone()));
        }
        // Temporal ordering
        if node.logical_time < last_time {
            errors.push(ValidationError::TemporalOrderViolation {
                node: node.id.clone(),
                time: node.logical_time,
            });
        }
        last_time = node.logical_time;
        if node.has_invariant { has_invariant = true; }
    }

    if !has_invariant {
        errors.push(ValidationError::MissingInvariantBinding);
    }

    if errors.is_empty() { Ok(()) } else { Err(errors) }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn good_node(id: &str, time: i64) -> NodeDesc {
        NodeDesc {
            id: id.to_string(), emitted_by: "COUNCIL".to_string(),
            confidence: 0.85, severity: "INFO".to_string(),
            logical_time: time, has_invariant: true,
        }
    }

    #[test] fn valid_single_node_passes() {
        assert!(validate(&[good_node("n1", 1)]).is_ok());
    }
    #[test] fn empty_graph_rejected() {
        let errs = validate(&[]).unwrap_err();
        assert!(errs.contains(&ValidationError::EmptyGraph));
    }
    #[test] fn unknown_emitter_rejected() {
        let mut n = good_node("n1", 1);
        n.emitted_by = "HACKER".to_string();
        let errs = validate(&[n]).unwrap_err();
        assert!(errs.iter().any(|e| matches!(e, ValidationError::UnknownEmitter(_))));
    }
    #[test] fn invalid_confidence_rejected() {
        let mut n = good_node("n1", 1);
        n.confidence = 1.5;
        let errs = validate(&[n]).unwrap_err();
        assert!(errs.iter().any(|e| matches!(e, ValidationError::InvalidConfidence(_))));
    }
    #[test] fn temporal_violation_detected() {
        let errs = validate(&[good_node("n1",10), good_node("n2",5)]).unwrap_err();
        assert!(errs.iter().any(|e| matches!(e,
            ValidationError::TemporalOrderViolation{..})));
    }
    #[test] fn duplicate_id_detected() {
        let errs = validate(&[good_node("n1",1), good_node("n1",2)]).unwrap_err();
        assert!(errs.iter().any(|e| matches!(e, ValidationError::DuplicateNodeId(_))));
    }
    #[test] fn missing_invariant_rejected() {
        let mut n = good_node("n1", 1);
        n.has_invariant = false;
        let errs = validate(&[n]).unwrap_err();
        assert!(errs.contains(&ValidationError::MissingInvariantBinding));
    }
    #[test] fn multiple_valid_nodes_ordered() {
        assert!(validate(&[good_node("n1",1), good_node("n2",2), good_node("n3",3)]).is_ok());
    }
}
