# cgir-validator

Rejects invalid CGIR before Gate.

## Responsibility

Validates CGIR graphs before they are passed to Gate. Any invalid CGIR must be
rejected — never silently accepted (Invariant I10: Fail Closed).

## Validation Passes

| Pass | Checks |
|------|--------|
| Structural | No orphan nodes, no duplicate IDs, no invalid cycles |
| Temporal | Monotonic logical time, valid time ranges, no expired signals |
| Signal | Exactly one SignalNode per event cycle (Invariant I4) |
| Invariant | All required InvariantBindings present and valid |
| Hardware | HardwareBindings point to valid addresses |

## TODO

- [ ] Implement ValidationError enum
- [ ] Implement structural pass
- [ ] Implement temporal pass
- [ ] Implement signal pass
- [ ] Implement invariant pass
- [ ] Implement hardware pass
- [ ] Compose full validator pipeline
- [ ] Add property-based tests

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
