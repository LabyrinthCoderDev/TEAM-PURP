//! # cgir-codegen
//! Labyrinth-OS — CGIR → deterministic bytecode code generation.
//!
//! Takes a validated CGIR graph and emits deterministic bytecode.
//! Same inputs always produce same output (Invariant I2).
//! Codegen never modifies the graph — read-only pass.

/// A bytecode instruction emitted from a CGIR node.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Instruction {
    /// Load a value from a named binding
    Load { binding: String },
    /// Store result under a binding
    Store { binding: String },
    /// Check an invariant by name — halts if violated
    CheckInvariant { name: String },
    /// Emit a signal with given severity
    EmitSignal { severity: String },
    /// Halt execution — used on gate BLOCK
    Halt { reason: String },
    /// No-op marker for tracing
    Trace { label: String },
}

impl Instruction {
    pub fn opcode(&self) -> &'static str {
        match self {
            Self::Load { .. }           => "LOAD",
            Self::Store { .. }          => "STORE",
            Self::CheckInvariant { .. } => "CHECK_INV",
            Self::EmitSignal { .. }     => "EMIT_SIG",
            Self::Halt { .. }           => "HALT",
            Self::Trace { .. }          => "TRACE",
        }
    }
    pub fn is_terminal(&self) -> bool {
        matches!(self, Self::Halt { .. })
    }
}

/// A compiled bytecode program — sequence of instructions.
#[derive(Debug, Default, Clone)]
pub struct Bytecode {
    pub instructions: Vec<Instruction>,
    pub source_id: String,
}

impl Bytecode {
    pub fn new(source_id: impl Into<String>) -> Self {
        Self { instructions: Vec::new(), source_id: source_id.into() }
    }
    pub fn push(&mut self, instr: Instruction) {
        self.instructions.push(instr);
    }
    pub fn len(&self) -> usize { self.instructions.len() }
    pub fn is_empty(&self) -> bool { self.instructions.is_empty() }
    pub fn is_deterministic(&self) -> bool {
        // Deterministic: no randomness instructions, at most one HALT
        let halts = self.instructions.iter().filter(|i| i.is_terminal()).count();
        halts <= 1
    }
}

/// CGIR node descriptor for codegen (avoids circular dependency).
#[derive(Debug, Clone)]
pub struct NodeDesc {
    pub id:       String,
    pub severity: String,
    pub binding:  String,
}

/// Generate bytecode from a sequence of CGIR node descriptors.
/// Fail-closed: unknown severity → HALT.
pub fn generate(nodes: &[NodeDesc]) -> Result<Bytecode, String> {
    let mut bc = Bytecode::new("cgir-codegen");
    for node in nodes {
        bc.push(Instruction::Trace { label: node.id.clone() });
        bc.push(Instruction::Load { binding: node.binding.clone() });
        match node.severity.as_str() {
            "INFO" | "WARNING" => {
                bc.push(Instruction::CheckInvariant { name: "I2".to_string() });
                bc.push(Instruction::EmitSignal { severity: node.severity.clone() });
                bc.push(Instruction::Store { binding: node.binding.clone() });
            }
            "ERROR" | "CRITICAL" => {
                bc.push(Instruction::EmitSignal { severity: node.severity.clone() });
                bc.push(Instruction::Halt {
                    reason: format!("{} severity halts execution", node.severity)
                });
                return Ok(bc); // HALT terminates codegen
            }
            other => return Err(format!("Unknown severity: {other}")),
        }
    }
    Ok(bc)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn node(id: &str, sev: &str) -> NodeDesc {
        NodeDesc { id: id.to_string(), severity: sev.to_string(),
                   binding: format!("binding_{id}") }
    }

    #[test] fn empty_nodes_produces_empty_bytecode() {
        let bc = generate(&[]).unwrap();
        assert!(bc.is_empty());
    }
    #[test] fn info_node_emits_check_and_signal() {
        let bc = generate(&[node("n1","INFO")]).unwrap();
        let opcodes: Vec<_> = bc.instructions.iter().map(|i| i.opcode()).collect();
        assert!(opcodes.contains(&"CHECK_INV"));
        assert!(opcodes.contains(&"EMIT_SIG"));
    }
    #[test] fn critical_node_halts() {
        let bc = generate(&[node("n1","CRITICAL")]).unwrap();
        assert!(bc.instructions.iter().any(|i| i.is_terminal()));
    }
    #[test] fn unknown_severity_is_error() {
        assert!(generate(&[node("n1","UNKNOWN")]).is_err());
    }
    #[test] fn deterministic_single_halt() {
        let bc = generate(&[node("n1","INFO"), node("n2","CRITICAL")]).unwrap();
        assert!(bc.is_deterministic());
    }
    #[test] fn instruction_opcodes_correct() {
        assert_eq!(Instruction::Halt { reason: "x".into() }.opcode(), "HALT");
        assert_eq!(Instruction::Load { binding: "b".into() }.opcode(), "LOAD");
    }
    #[test] fn halt_is_terminal() {
        assert!(Instruction::Halt { reason: "x".into() }.is_terminal());
        assert!(!Instruction::Load { binding: "b".into() }.is_terminal());
    }
    #[test] fn same_input_same_output() {
        let nodes = vec![node("n1","INFO"), node("n2","WARNING")];
        let b1 = generate(&nodes).unwrap();
        let b2 = generate(&nodes).unwrap();
        assert_eq!(b1.instructions.len(), b2.instructions.len());
        for (a, b) in b1.instructions.iter().zip(b2.instructions.iter()) {
            assert_eq!(a.opcode(), b.opcode());
        }
    }
}
