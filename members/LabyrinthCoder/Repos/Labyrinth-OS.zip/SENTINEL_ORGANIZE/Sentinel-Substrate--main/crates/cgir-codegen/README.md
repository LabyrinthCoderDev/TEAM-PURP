# cgir-codegen

Emit Rust, CBOR/JSON, Kani harnesses, and test fixtures from CGIR.

## Responsibility

Code generation from validated CGIR graphs.

## Outputs

| Output | Description |
|--------|-------------|
| Rust | Type-safe execution stubs |
| CBOR/JSON | Serialized CGIR bundles |
| Kani harnesses | Formal verification harnesses |
| Test fixtures | Replay and validation test data |

## TODO

- [ ] Rust code emitter
- [ ] CBOR/JSON bundle emitter
- [ ] Kani harness emitter
- [ ] Test fixture emitter

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
