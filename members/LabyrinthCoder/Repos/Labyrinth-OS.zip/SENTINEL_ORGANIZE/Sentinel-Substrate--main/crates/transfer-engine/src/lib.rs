//! # transfer-engine
//! Labyrinth-OS — Knowledge transfer between sessions.
//!
//! When a session ends, validated knowledge can be transferred
//! to the next session's starting state. Only VALIDATED artifacts transfer.
//! FAILED, EXPERIMENTAL, PARTIAL artifacts are not transferred.

/// The status of a knowledge item for transfer eligibility.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TransferEligibility {
    Eligible,          // VALIDATED — can transfer
    NotEligible(Reason),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Reason {
    NotValidated,  // not yet VALIDATED
    Deprecated,    // replaced
    Failed,        // known failure — archived, not transferred
}

/// A knowledge item eligible for transfer.
#[derive(Debug, Clone)]
pub struct KnowledgeItem {
    pub item_id:     String,
    pub content:     String,
    pub confidence:  f64,
    pub source_session: String,
}

/// Transfer package — everything moving to next session.
#[derive(Debug, Default)]
pub struct TransferPackage {
    items: Vec<KnowledgeItem>,
}

impl TransferPackage {
    pub fn new() -> Self { Self::default() }

    pub fn add(&mut self, item: KnowledgeItem, eligibility: TransferEligibility)
        -> Result<(), Reason>
    {
        match eligibility {
            TransferEligibility::Eligible => { self.items.push(item); Ok(()) }
            TransferEligibility::NotEligible(r) => Err(r),
        }
    }

    pub fn item_count(&self) -> usize { self.items.len() }
    pub fn is_empty(&self)  -> bool   { self.items.is_empty() }
    pub fn items(&self)     -> &[KnowledgeItem] { &self.items }

    pub fn total_confidence(&self) -> f64 {
        if self.items.is_empty() { return 0.0; }
        self.items.iter().map(|i| i.confidence).sum::<f64>() / self.items.len() as f64
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn eligible_item_added() {
        let mut pkg = TransferPackage::new();
        let item = KnowledgeItem { item_id:"k1".into(), content:"c".into(),
                                    confidence:0.9, source_session:"s1".into() };
        assert!(pkg.add(item, TransferEligibility::Eligible).is_ok());
        assert_eq!(pkg.item_count(), 1);
    }
    #[test] fn ineligible_item_rejected() {
        let mut pkg = TransferPackage::new();
        let item = KnowledgeItem { item_id:"k1".into(), content:"c".into(),
                                    confidence:0.5, source_session:"s1".into() };
        assert!(pkg.add(item, TransferEligibility::NotEligible(Reason::NotValidated)).is_err());
        assert_eq!(pkg.item_count(), 0);
    }
    #[test] fn failed_items_not_transferred() {
        let mut pkg = TransferPackage::new();
        let item = KnowledgeItem { item_id:"k1".into(), content:"c".into(),
                                    confidence:0.0, source_session:"s1".into() };
        let result = pkg.add(item, TransferEligibility::NotEligible(Reason::Failed));
        assert_eq!(result, Err(Reason::Failed));
    }
    #[test] fn average_confidence_computed() {
        let mut pkg = TransferPackage::new();
        for (id, conf) in [("k1", 0.8), ("k2", 0.6)] {
            pkg.add(KnowledgeItem { item_id:id.into(), content:"c".into(),
                                     confidence:conf, source_session:"s".into() },
                    TransferEligibility::Eligible).unwrap();
        }
        assert!((pkg.total_confidence() - 0.7).abs() < 1e-9);
    }
    #[test] fn empty_package_zero_confidence() {
        let pkg = TransferPackage::new();
        assert_eq!(pkg.total_confidence(), 0.0);
    }
    #[test] fn items_accessible() {
        let mut pkg = TransferPackage::new();
        pkg.add(KnowledgeItem { item_id:"k1".into(), content:"hello".into(),
                                  confidence:0.9, source_session:"s".into() },
                TransferEligibility::Eligible).unwrap();
        assert_eq!(pkg.items()[0].content, "hello");
    }
}
