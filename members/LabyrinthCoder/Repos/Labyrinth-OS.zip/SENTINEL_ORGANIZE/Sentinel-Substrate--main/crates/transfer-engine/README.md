# transfer-engine

Cross-domain transfer tests — the AGI-pressure layer (L8).

## Responsibility

Tests whether concepts formed by the concept-engine transfer across domains.
This is the primary measurement layer for AGI-level generalization.

## TODO

- [ ] TransferTest type
- [ ] Cross-domain transfer measurement
- [ ] Transfer scoring

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
