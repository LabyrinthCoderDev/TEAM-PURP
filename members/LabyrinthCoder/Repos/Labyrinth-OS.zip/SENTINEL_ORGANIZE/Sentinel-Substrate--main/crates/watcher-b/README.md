# watcher-b

Adversarial auditor.

## Responsibility

Watcher-B (L4) independently audits proposals AND audits Watcher-A for bias
drift, audit corruption, silent failure, and false confidence.

## Non-Negotiable

Watcher-B CANNOT execute. Watcher-B CANNOT mutate state.

## TODO

- [ ] Adversarial evidence audit
- [ ] Watcher-A bias detection
- [ ] Audit corruption detection
- [ ] Silent failure detection
- [ ] False confidence detection

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
