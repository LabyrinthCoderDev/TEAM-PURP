//! # watcher-b
//! Labyrinth-OS — Adversarial signal auditor.
//!
//! Watcher-B assumes the worst. It looks for attack patterns, not just errors.
//! Every signal is treated as potentially adversarial until proven otherwise.
//!
//! TM-001 attack classes it detects:
//!   CONFIDENCE_SPOOF — perfect confidence (1.0) is suspicious
//!   GATE_EVASION     — all sensors exactly at thresholds
//!   TEMPORAL_SPLICE  — logical time goes backwards
//!   SIGNAL_INJECTION — unknown emitter

const TAU_ESCAPE_FLOOR: f64 = 0.75;
const CHI_WARN:         f64 = 0.15;
const CONFIDENCE_FLOOR: f64 = 0.65;
const PERFECT_CONF:     f64 = 1.0;

/// Known authorities that can emit signals.
const KNOWN_AUTHORITIES: &[&str] = &["COUNCIL", "SIGNAL_ALGEBRA"];

/// A finding — something Watcher-B flagged.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FindingLevel { Info, Warning, Error, Critical }

#[derive(Debug, Clone)]
pub struct Finding {
    pub level:  FindingLevel,
    pub code:   &'static str,
    pub detail: String,
}

/// Signal descriptor for auditing.
#[derive(Debug, Clone)]
pub struct SignalDesc {
    pub id:           String,
    pub emitted_by:   String,
    pub confidence:   f64,
    pub tau_escape:   f64,
    pub chi:          f64,
    pub logical_time: i64,
}

impl SignalDesc {
    pub fn nominal(id: &str) -> Self {
        Self {
            id: id.to_string(),
            emitted_by: "COUNCIL".to_string(),
            confidence: 0.88,
            tau_escape: 0.85,
            chi: 0.08,
            logical_time: 1,
        }
    }
}

/// Audit result.
#[derive(Debug, Default)]
pub struct AuditResult {
    pub findings: Vec<Finding>,
    pub signals_checked: usize,
}

impl AuditResult {
    pub fn is_clean(&self) -> bool {
        self.findings.iter().all(|f| matches!(f.level, FindingLevel::Info))
    }
    pub fn has_critical(&self) -> bool {
        self.findings.iter().any(|f| matches!(f.level, FindingLevel::Critical))
    }
}

/// Watcher-B adversarial auditor.
pub struct WatcherB;

impl WatcherB {
    pub fn new() -> Self { Self }

    pub fn audit(&self, signals: &[SignalDesc]) -> AuditResult {
        let mut result = AuditResult { signals_checked: signals.len(), ..Default::default() };
        let mut prev_time = i64::MIN;

        for sig in signals {
            // SIGNAL_INJECTION: unknown emitter
            if !KNOWN_AUTHORITIES.contains(&sig.emitted_by.as_str()) {
                result.findings.push(Finding {
                    level: FindingLevel::Critical,
                    code: "SIGNAL_INJECTION",
                    detail: format!("Unknown emitter: {}", sig.emitted_by),
                });
            }

            // CONFIDENCE_SPOOF: perfect confidence is suspicious
            if (sig.confidence - PERFECT_CONF).abs() < f64::EPSILON {
                result.findings.push(Finding {
                    level: FindingLevel::Warning,
                    code: "CONFIDENCE_SPOOF",
                    detail: "Perfect confidence (1.0) is suspicious — possible spoof".to_string(),
                });
            }

            // TAU collapse
            if sig.tau_escape < TAU_ESCAPE_FLOOR {
                result.findings.push(Finding {
                    level: FindingLevel::Critical,
                    code: "TAU_COLLAPSE",
                    detail: format!("tau={:.3} below floor={}", sig.tau_escape, TAU_ESCAPE_FLOOR),
                });
            }

            // GATE_EVASION: chi exactly at warning threshold
            if (sig.chi - CHI_WARN).abs() < 0.001 {
                result.findings.push(Finding {
                    level: FindingLevel::Warning,
                    code: "GATE_EVASION",
                    detail: format!("chi={:.3} exactly at CHI_WARN threshold — possible evasion", sig.chi),
                });
            }

            // TEMPORAL_SPLICE: backwards logical time
            if sig.logical_time < prev_time {
                result.findings.push(Finding {
                    level: FindingLevel::Error,
                    code: "TEMPORAL_SPLICE",
                    detail: format!("logical_time {} < previous {}", sig.logical_time, prev_time),
                });
            }
            if sig.logical_time > prev_time { prev_time = sig.logical_time; }

            // Low confidence
            if sig.confidence < CONFIDENCE_FLOOR {
                result.findings.push(Finding {
                    level: FindingLevel::Warning,
                    code: "LOW_CONFIDENCE",
                    detail: format!("confidence={:.3} below floor={}", sig.confidence, CONFIDENCE_FLOOR),
                });
            }
        }

        result
    }
}

impl Default for WatcherB { fn default() -> Self { Self::new() } }

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn nominal_signal_is_clean() {
        let wb = WatcherB::new();
        let result = wb.audit(&[SignalDesc::nominal("n1")]);
        assert!(result.is_clean());
    }
    #[test] fn unknown_emitter_flagged_critical() {
        let wb = WatcherB::new();
        let mut s = SignalDesc::nominal("n1");
        s.emitted_by = "HACKER".to_string();
        let result = wb.audit(&[s]);
        assert!(result.has_critical());
        assert!(result.findings.iter().any(|f| f.code == "SIGNAL_INJECTION"));
    }
    #[test] fn perfect_confidence_flagged() {
        let wb = WatcherB::new();
        let mut s = SignalDesc::nominal("n1");
        s.confidence = 1.0;
        let result = wb.audit(&[s]);
        assert!(result.findings.iter().any(|f| f.code == "CONFIDENCE_SPOOF"));
    }
    #[test] fn tau_collapse_flagged_critical() {
        let wb = WatcherB::new();
        let mut s = SignalDesc::nominal("n1");
        s.tau_escape = 0.60;
        let result = wb.audit(&[s]);
        assert!(result.has_critical());
        assert!(result.findings.iter().any(|f| f.code == "TAU_COLLAPSE"));
    }
    #[test] fn temporal_splice_detected() {
        let wb = WatcherB::new();
        let mut s1 = SignalDesc::nominal("n1"); s1.logical_time = 100;
        let mut s2 = SignalDesc::nominal("n2"); s2.logical_time = 50;
        let result = wb.audit(&[s1, s2]);
        assert!(result.findings.iter().any(|f| f.code == "TEMPORAL_SPLICE"));
    }
    #[test] fn gate_evasion_at_threshold_flagged() {
        let wb = WatcherB::new();
        let mut s = SignalDesc::nominal("n1");
        s.chi = 0.150; // exactly CHI_WARN
        let result = wb.audit(&[s]);
        assert!(result.findings.iter().any(|f| f.code == "GATE_EVASION"));
    }
    #[test] fn multiple_signals_all_checked() {
        let wb = WatcherB::new();
        let signals: Vec<_> = (0..5).map(|i| SignalDesc::nominal(&format!("n{i}"))).collect();
        let result = wb.audit(&signals);
        assert_eq!(result.signals_checked, 5);
    }
    #[test] fn empty_audit_clean() {
        let wb = WatcherB::new();
        let result = wb.audit(&[]);
        assert!(result.is_clean());
        assert_eq!(result.signals_checked, 0);
    }
    #[test] fn low_confidence_flagged() {
        let wb = WatcherB::new();
        let mut s = SignalDesc::nominal("n1");
        s.confidence = 0.50;
        let result = wb.audit(&[s]);
        assert!(result.findings.iter().any(|f| f.code == "LOW_CONFIDENCE"));
    }
    #[test] fn clean_signal_has_no_findings() {
        let wb = WatcherB::new();
        let s = SignalDesc { id: "n1".to_string(), emitted_by: "COUNCIL".to_string(),
            confidence: 0.85, tau_escape: 0.85, chi: 0.08, logical_time: 1 };
        let result = wb.audit(&[s]);
        assert!(result.findings.is_empty());
    }
}
