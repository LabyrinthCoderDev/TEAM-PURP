//! # cgir-temporal
//! Labyrinth-OS — Temporal constraint checking for CGIR nodes
//!
//! Mirrors Labyrinth-OS architecture. All invariants apply.
//! Council = labeling authority only. No direct CGIR bypass.

/// A logical clock value. Monotonically increasing.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct LogicalTime(u64);

impl LogicalTime {
    pub fn new(t: u64) -> Self { Self(t) }
    pub fn value(self) -> u64 { self.0 }
    pub fn zero() -> Self { Self(0) }
    pub fn advance(&self) -> Self { Self(self.0 + 1) }
}

/// Temporal constraint: a node must be processed within a window.
#[derive(Debug, Clone)]
pub struct TemporalConstraint {
    pub min_time: LogicalTime,
    pub max_time: Option<LogicalTime>,
}

impl TemporalConstraint {
    pub fn at_or_after(min: u64) -> Self {
        Self { min_time: LogicalTime::new(min), max_time: None }
    }

    pub fn window(min: u64, max: u64) -> Result<Self, &'static str> {
        if max < min { return Err("max must be >= min"); }
        Ok(Self {
            min_time: LogicalTime::new(min),
            max_time: Some(LogicalTime::new(max)),
        })
    }

    pub fn is_satisfied(&self, t: LogicalTime) -> bool {
        if t < self.min_time { return false; }
        if let Some(max) = self.max_time {
            if t > max { return false; }
        }
        true
    }
}

/// A deadline — execution must complete before logical_time reaches this.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Deadline(u64);

impl Deadline {
    pub fn new(t: u64) -> Self { Self(t) }
    pub fn value(self) -> u64 { self.0 }
    pub fn is_exceeded_by(self, current: LogicalTime) -> bool {
        current.value() >= self.0
    }
    pub fn remaining(self, current: LogicalTime) -> Option<u64> {
        self.0.checked_sub(current.value())
    }
}

/// A temporal window — valid between min and max logical time.
#[derive(Debug, Clone)]
pub struct TemporalWindow {
    pub open:    LogicalTime,
    pub close:   Deadline,
}

impl TemporalWindow {
    pub fn new(open: u64, close: u64) -> Result<Self, &'static str> {
        if close <= open { return Err("close must be > open"); }
        Ok(Self { open: LogicalTime::new(open), close: Deadline::new(close) })
    }
    pub fn is_active(&self, t: LogicalTime) -> bool {
        t >= self.open && !self.close.is_exceeded_by(t)
    }
}

#[test] fn deadline_exceeded_detection() {
    let d = Deadline::new(10);
    assert!(d.is_exceeded_by(LogicalTime::new(10)));
    assert!(!d.is_exceeded_by(LogicalTime::new(9)));
}
#[test] fn deadline_remaining() {
    let d = Deadline::new(10);
    assert_eq!(d.remaining(LogicalTime::new(7)), Some(3));
    assert_eq!(d.remaining(LogicalTime::new(10)), Some(0));
}
#[test] fn window_active_within_range() {
    let w = TemporalWindow::new(5, 15).unwrap();
    assert!(w.is_active(LogicalTime::new(10)));
    assert!(!w.is_active(LogicalTime::new(3)));
    assert!(!w.is_active(LogicalTime::new(15)));
}
#[test] fn invalid_window_rejected() {
    assert!(TemporalWindow::new(10, 5).is_err());
    assert!(TemporalWindow::new(5, 5).is_err());
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn logical_time_advances() {
        let t = LogicalTime::new(5);
        assert_eq!(t.advance().value(), 6);
    }
    #[test] fn constraint_satisfied_in_window() {
        let c = TemporalConstraint::window(3, 7).unwrap();
        assert!(c.is_satisfied(LogicalTime::new(5)));
    }
    #[test] fn constraint_before_min_fails() {
        let c = TemporalConstraint::at_or_after(5);
        assert!(!c.is_satisfied(LogicalTime::new(3)));
    }
    #[test] fn constraint_after_max_fails() {
        let c = TemporalConstraint::window(1, 5).unwrap();
        assert!(!c.is_satisfied(LogicalTime::new(6)));
    }
    #[test] fn invalid_window_rejected() {
        assert!(TemporalConstraint::window(10, 5).is_err());
    }
    #[test] fn open_ended_constraint_always_passes_min() {
        let c = TemporalConstraint::at_or_after(3);
        assert!(c.is_satisfied(LogicalTime::new(1000)));
    }
}
