# cgir-temporal

Latency bounds, monotonic time, and C2G-RL checks.

## Responsibility

Validates all temporal properties of a CGIR graph.

## Checks

| Check | Description |
|-------|-------------|
| Monotonic time | Logical time never decreases |
| Latency bounds | expected_latency <= max_latency |
| Negative latency | Rejected outright |
| Overflow latency | Rejected outright |
| Signal expiry | Signals must be valid for current logical time |
| C2G-RL bounds | Causal-to-Gate Response Latency limits |

## TODO

- [ ] Implement all temporal checks
- [ ] Add property-based fuzz tests

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
