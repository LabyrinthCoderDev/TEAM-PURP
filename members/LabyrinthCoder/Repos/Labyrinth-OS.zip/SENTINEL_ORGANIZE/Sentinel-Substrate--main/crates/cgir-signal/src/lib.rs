//! # cgir-signal
//! Labyrinth-OS — Signal routing between CGIR layers.
//!
//! Routes signals from the sensor layer to the gate.
//! Validates signal provenance before forwarding.
//! Fail-closed: unknown source = drop the signal.

const KNOWN_SOURCES: &[&str] = &["WATCHER_A", "WATCHER_B", "COUNCIL", "SIGNAL_ALGEBRA"];

/// The severity of a routed signal.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum SignalSeverity { Info, Warning, Error, Critical }

impl SignalSeverity {
    pub fn from_str(s: &str) -> Option<Self> {
        match s {
            "INFO"     => Some(Self::Info),
            "WARNING"  => Some(Self::Warning),
            "ERROR"    => Some(Self::Error),
            "CRITICAL" => Some(Self::Critical),
            _          => None,
        }
    }
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Info     => "INFO",
            Self::Warning  => "WARNING",
            Self::Error    => "ERROR",
            Self::Critical => "CRITICAL",
        }
    }
}

/// A signal before routing — may be dropped.
#[derive(Debug, Clone)]
pub struct RawSignal {
    pub id:       String,
    pub source:   String,
    pub severity: String,
    pub payload:  String,
}

/// A signal after routing — provenance verified.
#[derive(Debug, Clone)]
pub struct RoutedSignal {
    pub id:       String,
    pub source:   String,
    pub severity: SignalSeverity,
    pub payload:  String,
}

/// Why a signal was dropped.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DropReason { UnknownSource, InvalidSeverity }

/// Route a raw signal. Fail-closed on unknown source or invalid severity.
pub fn route(raw: RawSignal) -> Result<RoutedSignal, DropReason> {
    if !KNOWN_SOURCES.contains(&raw.source.as_str()) {
        return Err(DropReason::UnknownSource);
    }
    let severity = SignalSeverity::from_str(&raw.severity)
        .ok_or(DropReason::InvalidSeverity)?;
    Ok(RoutedSignal { id: raw.id, source: raw.source, severity, payload: raw.payload })
}

/// Route multiple signals. Silently drops invalid ones, returns (routed, dropped).
pub fn route_batch(signals: Vec<RawSignal>) -> (Vec<RoutedSignal>, Vec<(RawSignal, DropReason)>) {
    let mut routed = Vec::new();
    let mut dropped = Vec::new();
    for sig in signals {
        match route(sig.clone()) {
            Ok(r) => routed.push(r),
            Err(e) => dropped.push((sig, e)),
        }
    }
    (routed, dropped)
}

fn raw(source: &str, severity: &str) -> RawSignal {
    RawSignal { id: "s1".to_string(), source: source.to_string(),
                severity: severity.to_string(), payload: "p".to_string() }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn known_source_routes() {
        assert!(route(raw("COUNCIL", "INFO")).is_ok());
    }
    #[test] fn unknown_source_dropped() {
        assert_eq!(route(raw("HACKER", "INFO")).unwrap_err(), DropReason::UnknownSource);
    }
    #[test] fn invalid_severity_dropped() {
        assert_eq!(route(raw("COUNCIL", "EXTREME")).unwrap_err(), DropReason::InvalidSeverity);
    }
    #[test] fn all_known_sources_accepted() {
        for src in &["WATCHER_A","WATCHER_B","COUNCIL","SIGNAL_ALGEBRA"] {
            assert!(route(raw(src, "INFO")).is_ok());
        }
    }
    #[test] fn all_severities_parsed() {
        for sev in &["INFO","WARNING","ERROR","CRITICAL"] {
            assert!(route(raw("COUNCIL", sev)).is_ok());
        }
    }
    #[test] fn batch_route_separates_valid_invalid() {
        let signals = vec![raw("COUNCIL","INFO"), raw("HACKER","INFO"), raw("COUNCIL","BAD")];
        let (routed, dropped) = route_batch(signals);
        assert_eq!(routed.len(), 1);
        assert_eq!(dropped.len(), 2);
    }
    #[test] fn severity_ordering() {
        assert!(SignalSeverity::Critical > SignalSeverity::Error);
        assert!(SignalSeverity::Error > SignalSeverity::Warning);
    }
    #[test] fn severity_round_trip() {
        for s in &["INFO","WARNING","ERROR","CRITICAL"] {
            assert_eq!(SignalSeverity::from_str(s).unwrap().as_str(), *s);
        }
    }
    #[test] fn empty_batch_returns_empty() {
        let (routed, dropped) = route_batch(vec![]);
        assert!(routed.is_empty() && dropped.is_empty());
    }
    #[test] fn routed_signal_preserves_id() {
        let r = route(raw("COUNCIL", "WARNING")).unwrap();
        assert_eq!(r.id, "s1");
    }
}
