# cgir-signal

SignalNode binding, time validity, and orphan signal detection.

## Responsibility

Validates that SignalNodes in a CGIR graph are correctly bound, temporally valid,
and non-orphaned. Enforces Invariant I4: exactly one SignalNode per event cycle.

## TODO

- [ ] SignalNode binding verification
- [ ] Time validity checking
- [ ] Orphan signal detection
- [ ] Duplicate signal detection
- [ ] Self-referential signal detection

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
