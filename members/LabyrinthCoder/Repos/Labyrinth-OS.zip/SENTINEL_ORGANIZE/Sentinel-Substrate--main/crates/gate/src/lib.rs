//! # gate
//! Labyrinth-OS — Pre-CGIR gate with Sigma Anchor enforcement.
//!
//! The gate is a pure function: same inputs always produce same output.
//! No randomness. No side effects. No hidden state.
//!
//! Sigma Anchor constants (Z3 proven):
//!   TAU_ESCAPE_FLOOR = 0.75  — below → CRITICAL
//!   CHI_WARN         = 0.15  — at/above → WARNING
//!   CHI_COLLAPSE     = 0.40  — at/above → CRITICAL
//!   DRIFT_THRESHOLD  = 0.12  — at/above → ERROR
//!   BETTI_1_CAP      = 0.045 — at/above → ERROR
//!   CONFIDENCE_FLOOR = 0.65  — below → BLOCK

// Sigma Anchor constants — must match sigma_anchors.py exactly
const TAU_ESCAPE_FLOOR: f64 = 0.75;
const CHI_WARN:         f64 = 0.15;
const CHI_COLLAPSE:     f64 = 0.40;
const DRIFT_THRESHOLD:  f64 = 0.12;
const BETTI_1_CAP:      f64 = 0.045;
const CONFIDENCE_FLOOR: f64 = 0.65;

/// Gate verdict — binary. No middle ground.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GateVerdict { Allow, Block }

impl GateVerdict {
    pub fn allows(self) -> bool { self == GateVerdict::Allow }
    pub fn blocks(self) -> bool { self == GateVerdict::Block }
}

/// Severity level assigned by the gate.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Severity { Info, Warning, Error, Critical }

impl Severity {
    pub fn blocks_gate(self) -> bool {
        matches!(self, Severity::Error | Severity::Critical)
    }
    pub fn as_str(self) -> &'static str {
        match self {
            Severity::Info     => "INFO",
            Severity::Warning  => "WARNING",
            Severity::Error    => "ERROR",
            Severity::Critical => "CRITICAL",
        }
    }
}

/// Sensor readings fed into the gate.
#[derive(Debug, Clone)]
pub struct SensorReadings {
    pub tau_escape:   f64,
    pub chi:          f64,
    pub drift_score:  f64,
    pub betti_1:      f64,
    pub confidence:   f64,
}

impl SensorReadings {
    pub fn new(tau: f64, chi: f64, drift: f64, betti: f64, conf: f64) -> Self {
        Self {
            tau_escape:  tau.clamp(0.0, 1.0),
            chi:         chi.clamp(0.0, 1.0),
            drift_score: drift.clamp(0.0, 1.0),
            betti_1:     betti.clamp(0.0, 1.0),
            confidence:  conf.clamp(0.0, 1.0),
        }
    }
    pub fn nominal() -> Self { Self::new(0.88, 0.08, 0.05, 0.02, 0.90) }
}

/// Gate decision — verdict + severity + reasons.
#[derive(Debug, Clone)]
pub struct GateDecision {
    pub verdict:  GateVerdict,
    pub severity: Severity,
    pub reasons:  Vec<&'static str>,
}

impl GateDecision {
    pub fn allows(&self) -> bool { self.verdict.allows() }
}

/// The gate function — pure, deterministic.
pub fn evaluate(readings: &SensorReadings, promoted: bool) -> GateDecision {
    let mut severity = Severity::Info;
    let mut reasons  = Vec::new();

    // Must be promoted to cross the gate
    if !promoted {
        reasons.push("not promoted");
        return GateDecision { verdict: GateVerdict::Block, severity: Severity::Error, reasons };
    }

    // Tau escape floor
    if readings.tau_escape < TAU_ESCAPE_FLOOR {
        severity = Severity::Critical;
        reasons.push("tau below floor");
    }

    // Chi collapse
    if readings.chi >= CHI_COLLAPSE {
        severity = Severity::Critical;
        reasons.push("chi collapsed");
    } else if readings.chi >= CHI_WARN && severity < Severity::Warning {
        severity = Severity::Warning;
        reasons.push("chi elevated");
    }

    // Drift
    if readings.drift_score >= DRIFT_THRESHOLD && severity < Severity::Error {
        severity = Severity::Error;
        reasons.push("drift exceeded");
    }

    // Betti
    if readings.betti_1 >= BETTI_1_CAP && severity < Severity::Error {
        severity = Severity::Error;
        reasons.push("betti cap exceeded");
    }

    // Confidence floor
    if readings.confidence < CONFIDENCE_FLOOR {
        if severity < Severity::Error { severity = Severity::Error; }
        reasons.push("confidence below floor");
    }

    let verdict = if severity.blocks_gate() { GateVerdict::Block } else { GateVerdict::Allow };
    GateDecision { verdict, severity, reasons }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn nominal_allows() {
        let d = evaluate(&SensorReadings::nominal(), true);
        assert!(d.allows());
        assert_eq!(d.severity, Severity::Info);
    }
    #[test] fn not_promoted_blocks() {
        let d = evaluate(&SensorReadings::nominal(), false);
        assert!(d.verdict.blocks());
    }
    #[test] fn tau_below_floor_critical() {
        let r = SensorReadings::new(0.60, 0.08, 0.05, 0.02, 0.90);
        let d = evaluate(&r, true);
        assert_eq!(d.severity, Severity::Critical);
        assert!(d.verdict.blocks());
    }
    #[test] fn chi_collapse_critical() {
        let r = SensorReadings::new(0.85, 0.45, 0.05, 0.02, 0.90);
        let d = evaluate(&r, true);
        assert_eq!(d.severity, Severity::Critical);
    }
    #[test] fn drift_exceeded_error() {
        let r = SensorReadings::new(0.85, 0.08, 0.15, 0.02, 0.90);
        let d = evaluate(&r, true);
        assert!(d.severity >= Severity::Error);
    }
    #[test] fn low_confidence_blocks() {
        let r = SensorReadings::new(0.85, 0.08, 0.05, 0.02, 0.50);
        let d = evaluate(&r, true);
        assert!(d.verdict.blocks());
    }
    #[test] fn severity_ordering_correct() {
        assert!(Severity::Critical > Severity::Error);
        assert!(Severity::Error > Severity::Warning);
        assert!(Severity::Warning > Severity::Info);
    }
    #[test] fn blocks_gate_info_warning_do_not_block() {
        assert!(!Severity::Info.blocks_gate());
        assert!(!Severity::Warning.blocks_gate());
    }
    #[test] fn blocks_gate_error_critical_block() {
        assert!(Severity::Error.blocks_gate());
        assert!(Severity::Critical.blocks_gate());
    }
    #[test] fn deterministic_same_input_same_output() {
        let r = SensorReadings::nominal();
        let d1 = evaluate(&r, true);
        let d2 = evaluate(&r, true);
        assert_eq!(d1.verdict, d2.verdict);
        assert_eq!(d1.severity, d2.severity);
    }
}
