# gate

Pure deterministic Gate function — the only decision authority.

## Responsibility

Implements the Gate function: the sole decision authority for whether a CGIR
graph may proceed to execution.

## Invariant: I2 Gate Determinism

```
Gate(CGIR, SignalNode, Contract) → ALLOW | MODIFY | THROTTLE | FALLBACK | HARD_FAIL
```

Same inputs always produce same output. No randomness. No side effects. No I/O.

## Decision Priority

1. Ledger violation → HARD_FAIL
2. Critical SignalNode → HARD_FAIL
3. Temporal / hardware violation → HARD_FAIL or FALLBACK
4. Contract violation → THROTTLE or FALLBACK
5. VECTOR risk score → THROTTLE or MODIFY
6. Planner proposal quality → MODIFY or ALLOW

## TODO

- [ ] Implement GateDecision enum
- [ ] Implement GateInput struct
- [ ] Implement gate() pure function
- [ ] Implement all priority checks
- [ ] Property-based tests: same input → same output
- [ ] Verify no mutable state, no I/O, no randomness

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
