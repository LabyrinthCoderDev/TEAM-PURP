# cgir-fuzzer

Generates syntactically valid but semantically hostile CGIR graphs.

## Responsibility

Creates hostile CGIR inputs to stress-test the validator and Gate. All generated
graphs must be shrinkable to a minimal failing example.

## Attack Categories

- **Structural**: orphan nodes, duplicate IDs, cycles, self-loops, disconnected components
- **Temporal**: negative latency, overflow, non-monotonic time, expired signals
- **Signal**: conflicting severities, missing council resolution, orphan signals
- **Invariant**: χ violations, contradictory flags, missing masks
- **Binding**: missing states, wrong targets, hardware mismatches
- **Composite**: individually valid edges combining into invalid behavior

## CI Requirements

CI must fail on:
- False negatives (invalid graph accepted)
- False positives (valid graph rejected)
- Nondeterministic validator output
- Panic or crash

## TODO

- [ ] All attack category generators
- [ ] Shrink-to-minimal implementation
- [ ] CI integration

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
