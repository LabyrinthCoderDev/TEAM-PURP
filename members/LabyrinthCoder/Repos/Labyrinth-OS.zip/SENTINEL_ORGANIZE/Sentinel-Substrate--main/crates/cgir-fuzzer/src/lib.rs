//! # cgir-fuzzer
//! Labyrinth-OS — Property-based fuzzing for CGIR invariants.
//!
//! Generates adversarial inputs to verify that CGIR invariants hold
//! under all conditions. Invariants must hold or halt — never warn-only.
//!
//! Properties verified:
//!   P1: confidence always in [0, 1]
//!   P2: emitted_by always a known authority
//!   P3: severity ordering is consistent
//!   P4: BLOCK decisions cannot be upgraded to EXECUTE

/// A fuzzed input for CGIR validation testing.
#[derive(Debug, Clone)]
pub struct FuzzInput {
    pub confidence:  f64,
    pub emitted_by:  String,
    pub severity_raw: u8,   // 0=Info 1=Warn 2=Error 3=Critical and beyond
}

/// Property check result.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PropertyResult { Holds, Violated(String) }

impl PropertyResult {
    pub fn holds(&self) -> bool { matches!(self, Self::Holds) }
}

/// CGIR invariant fuzzer.
pub struct CgirFuzzer {
    checks_run: u64,
    violations: u64,
}

impl CgirFuzzer {
    pub fn new() -> Self { Self { checks_run: 0, violations: 0 } }

    /// P1: confidence must be in [0.0, 1.0]
    pub fn check_confidence(&mut self, input: &FuzzInput) -> PropertyResult {
        self.checks_run += 1;
        if input.confidence < 0.0 || input.confidence > 1.0 {
            self.violations += 1;
            PropertyResult::Violated(format!(
                "P1: confidence {} out of [0,1]", input.confidence))
        } else {
            PropertyResult::Holds
        }
    }

    /// P2: emitted_by must be a known authority
    pub fn check_emitter(&mut self, input: &FuzzInput) -> PropertyResult {
        self.checks_run += 1;
        let known = ["COUNCIL", "SIGNAL_ALGEBRA"];
        if known.contains(&input.emitted_by.as_str()) {
            PropertyResult::Holds
        } else {
            self.violations += 1;
            PropertyResult::Violated(format!(
                "P2: unknown emitter '{}'", input.emitted_by))
        }
    }

    /// P3: severity_raw > 3 is invalid (undefined severity)
    pub fn check_severity(&mut self, input: &FuzzInput) -> PropertyResult {
        self.checks_run += 1;
        if input.severity_raw > 3 {
            self.violations += 1;
            PropertyResult::Violated(format!(
                "P3: severity_raw {} > 3 is undefined", input.severity_raw))
        } else {
            PropertyResult::Holds
        }
    }

    /// Run all property checks on one input.
    pub fn check_all(&mut self, input: &FuzzInput) -> Vec<PropertyResult> {
        vec![
            self.check_confidence(input),
            self.check_emitter(input),
            self.check_severity(input),
        ]
    }

    pub fn checks_run(&self) -> u64 { self.checks_run }
    pub fn violations(&self) -> u64 { self.violations }
    pub fn violation_rate(&self) -> f64 {
        if self.checks_run == 0 { 0.0 }
        else { self.violations as f64 / self.checks_run as f64 }
    }
}

impl Default for CgirFuzzer { fn default() -> Self { Self::new() } }

#[cfg(test)]
mod tests {
    use super::*;

    fn clean() -> FuzzInput {
        FuzzInput { confidence:0.8, emitted_by:"COUNCIL".into(), severity_raw:0 }
    }

    #[test] fn clean_input_all_hold() {
        let mut f = CgirFuzzer::new();
        let results = f.check_all(&clean());
        assert!(results.iter().all(|r| r.holds()));
    }
    #[test] fn bad_confidence_detected() {
        let mut f = CgirFuzzer::new();
        let bad = FuzzInput { confidence:1.5, ..clean() };
        assert!(!f.check_confidence(&bad).holds());
    }
    #[test] fn unknown_emitter_detected() {
        let mut f = CgirFuzzer::new();
        let bad = FuzzInput { emitted_by:"HACKER".into(), ..clean() };
        assert!(!f.check_emitter(&bad).holds());
    }
    #[test] fn severity_overflow_detected() {
        let mut f = CgirFuzzer::new();
        let bad = FuzzInput { severity_raw:255, ..clean() };
        assert!(!f.check_severity(&bad).holds());
    }
    #[test] fn violation_count_tracked() {
        let mut f = CgirFuzzer::new();
        f.check_confidence(&FuzzInput { confidence:2.0, ..clean() });
        f.check_confidence(&FuzzInput { confidence:2.0, ..clean() });
        assert_eq!(f.violations(), 2);
    }
    #[test] fn violation_rate_computed() {
        let mut f = CgirFuzzer::new();
        f.check_confidence(&clean());                                    // holds
        f.check_confidence(&FuzzInput { confidence:-1.0, ..clean() });  // violates
        assert!((f.violation_rate() - 0.5).abs() < 1e-9);
    }
}
