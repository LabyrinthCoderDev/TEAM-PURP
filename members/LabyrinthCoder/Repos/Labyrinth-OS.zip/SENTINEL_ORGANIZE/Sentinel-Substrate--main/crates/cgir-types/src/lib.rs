//! # cgir-types
//!
//! Strongly-typed primitives for the CGIR system.
//! Rust port of `execution/cgir/cgir_types.py`.
//!
//! Key difference: Python validates at runtime. Rust enforces at compile time.
//! Invalid states cannot be constructed — they fail to compile.

use std::fmt;

// ── Sigma Anchor Constants ──────────────────────────────────────────────────
pub mod constants {
    pub const TAU_ESCAPE_FLOOR: f64 = 0.75;
    pub const DRIFT_THRESHOLD:  f64 = 0.12;
    pub const CHI_WARN:         f64 = 0.15;
    pub const CHI_COLLAPSE:     f64 = 0.40;
    pub const BETTI_1_CAP:      f64 = 0.045;
    pub const TAU_MARGINAL:     f64 = 0.85;
}

// ── NodeId ──────────────────────────────────────────────────────────────────
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct NodeId(String);
impl NodeId {
    pub fn new(id: impl Into<String>) -> Option<Self> {
        let s = id.into();
        if s.is_empty() { None } else { Some(NodeId(s)) }
    }
    pub fn from_str_unchecked(id: impl Into<String>) -> Self { NodeId(id.into()) }
    pub fn as_str(&self) -> &str { &self.0 }
}
impl fmt::Display for NodeId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result { write!(f, "{}", self.0) }
}

// ── EdgeId ──────────────────────────────────────────────────────────────────
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct EdgeId(String);
impl EdgeId {
    pub fn new(id: impl Into<String>) -> Option<Self> {
        let s = id.into();
        if s.is_empty() { None } else { Some(EdgeId(s)) }
    }
    pub fn from_str_unchecked(id: impl Into<String>) -> Self { EdgeId(id.into()) }
    pub fn as_str(&self) -> &str { &self.0 }
}
impl fmt::Display for EdgeId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result { write!(f, "{}", self.0) }
}

// ── LogicalTime ─────────────────────────────────────────────────────────────
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct LogicalTime(u64);
impl LogicalTime {
    pub fn new(t: u64) -> Self { LogicalTime(t) }
    pub fn zero() -> Self { LogicalTime(0) }
    pub fn value(&self) -> u64 { self.0 }
    pub fn next(&self) -> Self { LogicalTime(self.0.saturating_add(1)) }
}
impl fmt::Display for LogicalTime {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result { write!(f, "t={}", self.0) }
}

// ── Hash ────────────────────────────────────────────────────────────────────
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct Hash([u8; 32]);
impl Hash {
    pub fn from_bytes(bytes: [u8; 32]) -> Self { Hash(bytes) }
    pub fn from_hex(hex: &str) -> Option<Self> {
        if hex.len() != 64 { return None; }
        let mut bytes = [0u8; 32];
        for (i, chunk) in hex.as_bytes().chunks(2).enumerate() {
            let s = std::str::from_utf8(chunk).ok()?;
            bytes[i] = u8::from_str_radix(s, 16).ok()?;
        }
        Some(Hash(bytes))
    }
    pub fn to_hex(&self) -> String { self.0.iter().map(|b| format!("{:02x}", b)).collect() }
    pub fn as_bytes(&self) -> &[u8; 32] { &self.0 }
    pub fn zero() -> Self { Hash([0u8; 32]) }
}
impl fmt::Display for Hash {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}…", &self.to_hex()[..12])
    }
}

// ── Severity ────────────────────────────────────────────────────────────────
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Severity { Info = 0, Warning = 1, Error = 2, Critical = 3 }
impl Severity {
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_uppercase().as_str() {
            "INFO"     => Some(Severity::Info),
            "WARNING"  => Some(Severity::Warning),
            "ERROR"    => Some(Severity::Error),
            "CRITICAL" => Some(Severity::Critical),
            _          => None,
        }
    }
    pub fn as_str(&self) -> &'static str {
        match self {
            Severity::Info     => "INFO",
            Severity::Warning  => "WARNING",
            Severity::Error    => "ERROR",
            Severity::Critical => "CRITICAL",
        }
    }
    /// True if this severity causes CGIR Gate to BLOCK (Invariant I5).
    pub fn blocks_gate(&self) -> bool {
        matches!(self, Severity::Error | Severity::Critical)
    }
}
impl fmt::Display for Severity {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result { write!(f, "{}", self.as_str()) }
}

// ── Confidence ──────────────────────────────────────────────────────────────
#[derive(Debug, Clone, Copy, PartialEq, PartialOrd)]
pub struct Confidence(f64);
impl Confidence {
    pub fn new(v: f64) -> Self { Confidence(v.clamp(0.0, 1.0)) }
    pub fn zero() -> Self { Confidence(0.0) }
    pub fn one()  -> Self { Confidence(1.0) }
    pub fn value(&self) -> f64 { self.0 }
    pub fn capped(&self, cap: f64) -> Self { Confidence(self.0.min(cap).max(0.0)) }
}
impl fmt::Display for Confidence {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result { write!(f, "{:.4}", self.0) }
}

// ── TimeRange ───────────────────────────────────────────────────────────────
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TimeRange { pub start_time: LogicalTime, pub end_time: LogicalTime }
impl TimeRange {
    pub fn new(start: LogicalTime, end: LogicalTime) -> Option<Self> {
        if start <= end { Some(TimeRange { start_time: start, end_time: end }) } else { None }
    }
    pub fn contains(&self, t: LogicalTime) -> bool {
        t >= self.start_time && t <= self.end_time
    }
    pub fn duration(&self) -> u64 { self.end_time.value() - self.start_time.value() }
}

// ── NodeType ────────────────────────────────────────────────────────────────
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum NodeType { State, EventEdge, Signal, TimedEdge, Invariant, Hardware }
impl NodeType {
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_uppercase().as_str() {
            "STATE"      => Some(NodeType::State),
            "EVENT_EDGE" => Some(NodeType::EventEdge),
            "SIGNAL"     => Some(NodeType::Signal),
            "TIMED_EDGE" => Some(NodeType::TimedEdge),
            "INVARIANT"  => Some(NodeType::Invariant),
            "HARDWARE"   => Some(NodeType::Hardware),
            _            => None,
        }
    }
    pub fn as_str(&self) -> &'static str {
        match self {
            NodeType::State      => "STATE",
            NodeType::EventEdge  => "EVENT_EDGE",
            NodeType::Signal     => "SIGNAL",
            NodeType::TimedEdge  => "TIMED_EDGE",
            NodeType::Invariant  => "INVARIANT",
            NodeType::Hardware   => "HARDWARE",
        }
    }
}

// ── GateDecision ────────────────────────────────────────────────────────────
/// Binary gate decision. Invariant I5: BLOCK overrides GuardianSlot.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GateDecision { Allow, Block }
impl GateDecision {
    pub fn as_str(&self) -> &'static str {
        match self { GateDecision::Allow => "ALLOW", GateDecision::Block => "BLOCK" }
    }
    pub fn is_allow(&self) -> bool { matches!(self, GateDecision::Allow) }
    pub fn is_block(&self) -> bool { matches!(self, GateDecision::Block) }
}
impl fmt::Display for GateDecision {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result { write!(f, "{}", self.as_str()) }
}

// ── GateResult ──────────────────────────────────────────────────────────────
#[derive(Debug, Clone)]
pub struct GateResult { pub decision: GateDecision, pub reason: String }
impl GateResult {
    pub fn allow(reason: impl Into<String>) -> Self {
        GateResult { decision: GateDecision::Allow, reason: reason.into() }
    }
    pub fn block(reason: impl Into<String>) -> Self {
        GateResult { decision: GateDecision::Block, reason: reason.into() }
    }
}

// ── ValidationError / Result ─────────────────────────────────────────────────
#[derive(Debug, Clone)]
pub struct ValidationError {
    pub error_type: String,
    pub message:    String,
    pub node_id:    Option<NodeId>,
    pub edge_id:    Option<EdgeId>,
}
#[derive(Debug, Clone)]
pub struct ValidationResult { pub valid: bool, pub errors: Vec<ValidationError> }
impl ValidationResult {
    pub fn ok() -> Self { ValidationResult { valid: true, errors: Vec::new() } }
    pub fn fail(errors: Vec<ValidationError>) -> Self {
        ValidationResult { valid: false, errors }
    }
}

// ── Tests ────────────────────────────────────────────────────────────────────
#[cfg(test)]
mod tests {
    use super::*;
    use super::constants::*;

    #[test] fn node_id_rejects_empty() { assert!(NodeId::new("").is_none()); }
    #[test] fn node_id_accepts_nonempty() { assert!(NodeId::new("n0").is_some()); }
    #[test] fn edge_id_rejects_empty() { assert!(EdgeId::new("").is_none()); }

    #[test] fn logical_time_monotonic() {
        let t = LogicalTime::new(5);
        assert_eq!(t.next().value(), 6);
        assert!(t < t.next());
    }
    #[test] fn logical_time_saturates() {
        let t = LogicalTime::new(u64::MAX);
        assert_eq!(t.next().value(), u64::MAX);
    }

    #[test] fn hash_wrong_length_none() {
        assert!(Hash::from_hex("abc").is_none());
        assert!(Hash::from_hex(&"a".repeat(63)).is_none());
    }
    #[test] fn hash_roundtrip() {
        let hex = "deadbeef".repeat(8);
        let h = Hash::from_hex(&hex).unwrap();
        assert_eq!(h.to_hex(), hex);
    }

    #[test] fn severity_ordering() {
        assert!(Severity::Info < Severity::Warning);
        assert!(Severity::Warning < Severity::Error);
        assert!(Severity::Error < Severity::Critical);
    }
    #[test] fn severity_blocks_gate() {
        assert!(!Severity::Info.blocks_gate());
        assert!(!Severity::Warning.blocks_gate());
        assert!(Severity::Error.blocks_gate());
        assert!(Severity::Critical.blocks_gate());
    }
    #[test] fn severity_roundtrip() {
        for s in ["INFO","WARNING","ERROR","CRITICAL"] {
            assert_eq!(Severity::from_str(s).unwrap().as_str(), s);
        }
    }

    #[test] fn confidence_clamps() {
        assert_eq!(Confidence::new(-1.0).value(), 0.0);
        assert_eq!(Confidence::new(2.0).value(),  1.0);
        assert_eq!(Confidence::new(0.5).value(),  0.5);
    }
    #[test] fn confidence_cap() {
        let c = Confidence::new(0.9);
        assert_eq!(c.capped(0.6).value(), 0.6);
    }

    #[test] fn time_range_rejects_inverted() {
        assert!(TimeRange::new(LogicalTime::new(5), LogicalTime::new(3)).is_none());
    }
    #[test] fn time_range_contains() {
        let r = TimeRange::new(LogicalTime::new(2), LogicalTime::new(8)).unwrap();
        assert!(r.contains(LogicalTime::new(5)));
        assert!(!r.contains(LogicalTime::new(9)));
    }

    #[test] fn sigma_anchor_values() {
        assert_eq!(TAU_ESCAPE_FLOOR, 0.75);
        assert_eq!(CHI_COLLAPSE,     0.40);
        assert!(CHI_WARN < CHI_COLLAPSE);
        assert!(TAU_ESCAPE_FLOOR < TAU_MARGINAL);
    }

    #[test] fn gate_decision_i5() {
        assert!(GateDecision::Allow.is_allow());
        assert!(GateDecision::Block.is_block());
        assert!(!GateDecision::Allow.is_block());
    }

    #[test] fn node_type_roundtrip() {
        for s in ["STATE","EVENT_EDGE","SIGNAL","TIMED_EDGE","INVARIANT","HARDWARE"] {
            assert_eq!(NodeType::from_str(s).unwrap().as_str(), s);
        }
    }
}
