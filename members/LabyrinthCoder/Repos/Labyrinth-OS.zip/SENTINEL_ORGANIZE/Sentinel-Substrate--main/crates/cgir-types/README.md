# cgir-types

Strongly-typed primitives for the CGIR system.

## Responsibility

Defines all shared primitive types used across CGIR crates.
These types enforce type safety at the Rust type system level.

## Types

| Type | Description |
|------|-------------|
| `NodeId` | Unique node identifier (UUID-backed) |
| `EdgeId` | Unique edge identifier (UUID-backed) |
| `LogicalTime` | Monotonic logical clock (u64) |
| `Hash` | SHA-256 content hash |
| `Signature` | Cryptographic signature bytes |
| `Severity` | Signal severity: Info, Warning, Error, Critical |
| `Confidence` | Signal confidence score [0.0, 1.0] |
| `TimeRange` | Valid time window (start, end LogicalTime) |

## TODO

- [ ] Implement all primitive types
- [ ] Add serde derive for all types
- [ ] Add Display/Debug implementations
- [ ] Add builder patterns where appropriate
- [ ] Add validation methods

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
