//! # cgir-hardware
//! Labyrinth-OS — Hardware enforcement boundary.
//!
//! Models the interface between software enforcement and hardware.
//! In prototype: simulation mode. In production: physical FPGA (A014).
//!
//! Hardware is the final authority (Invariant I7).
//! Software gates are advisory relative to hardware.

/// Hardware enforcement mode.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HardwareMode {
    /// Software simulation — no physical hardware required
    Simulation,
    /// Physical FPGA enforcement (A014 — requires MachXO2)
    Silicon,
}

impl HardwareMode {
    pub fn is_simulation(self) -> bool { self == HardwareMode::Simulation }
    pub fn requires_fpga(self)  -> bool { self == HardwareMode::Silicon }
}

/// A hardware enforcement decision.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HardwareVerdict {
    /// Hardware allows execution to proceed
    Allow,
    /// Hardware latches — execution stopped at silicon level
    Latch,
}

impl HardwareVerdict {
    pub fn allows(self) -> bool { self == HardwareVerdict::Allow }
    pub fn latches(self) -> bool { self == HardwareVerdict::Latch }
}

/// Hardware boundary check inputs.
#[derive(Debug, Clone)]
pub struct HardwareCheck {
    pub tau_escape:  f64,
    pub drift_score: f64,
    pub iteration:   u32,
}

impl HardwareCheck {
    pub fn new(tau: f64, drift: f64, iter: u32) -> Self {
        Self { tau_escape: tau.clamp(0.0,1.0),
               drift_score: drift.clamp(0.0,1.0),
               iteration: iter }
    }
    pub fn nominal() -> Self { Self::new(0.85, 0.05, 0) }
}

/// Hardware enforcement boundary — I7: hardware is final authority.
pub struct HardwareBoundary {
    pub mode: HardwareMode,
    tau_floor:  f64,
    drift_cap:  f64,
    max_iter:   u32,
}

impl HardwareBoundary {
    pub fn simulation() -> Self {
        Self { mode: HardwareMode::Simulation,
               tau_floor: 0.75, drift_cap: 0.12, max_iter: 100 }
    }

    /// Evaluate hardware check — simulation mode uses same thresholds as Sigma Anchors.
    pub fn evaluate(&self, check: &HardwareCheck) -> HardwareVerdict {
        if check.tau_escape < self.tau_floor { return HardwareVerdict::Latch; }
        if check.drift_score > self.drift_cap { return HardwareVerdict::Latch; }
        if check.iteration > self.max_iter { return HardwareVerdict::Latch; }
        HardwareVerdict::Allow
    }

    pub fn is_simulation(&self) -> bool { self.mode.is_simulation() }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn simulation_mode_available() {
        let hb = HardwareBoundary::simulation();
        assert!(hb.is_simulation());
    }
    #[test] fn nominal_check_allows() {
        let hb = HardwareBoundary::simulation();
        assert!(hb.evaluate(&HardwareCheck::nominal()).allows());
    }
    #[test] fn low_tau_latches() {
        let hb = HardwareBoundary::simulation();
        let check = HardwareCheck::new(0.60, 0.05, 0);
        assert!(hb.evaluate(&check).latches());
    }
    #[test] fn high_drift_latches() {
        let hb = HardwareBoundary::simulation();
        let check = HardwareCheck::new(0.85, 0.20, 0);
        assert!(hb.evaluate(&check).latches());
    }
    #[test] fn max_iteration_latches() {
        let hb = HardwareBoundary::simulation();
        let check = HardwareCheck::new(0.85, 0.05, 999);
        assert!(hb.evaluate(&check).latches());
    }
    #[test] fn hardware_is_final_authority_invariant_i7() {
        // I7: hardware can latch even when software would allow
        let hb = HardwareBoundary::simulation();
        let marginal = HardwareCheck::new(0.74, 0.05, 0); // just below tau floor
        // Hardware catches what software might miss
        assert!(hb.evaluate(&marginal).latches());
    }
    #[test] fn silicon_mode_requires_fpga() {
        assert!(HardwareMode::Silicon.requires_fpga());
        assert!(!HardwareMode::Simulation.requires_fpga());
    }
    #[test] fn verdict_binary_no_middle() {
        let allow = HardwareVerdict::Allow;
        let latch = HardwareVerdict::Latch;
        assert!(allow.allows() && !allow.latches());
        assert!(latch.latches() && !latch.allows());
    }
}
