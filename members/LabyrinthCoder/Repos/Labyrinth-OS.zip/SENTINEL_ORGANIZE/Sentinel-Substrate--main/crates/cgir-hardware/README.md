# cgir-hardware

HardwareBinding validation, MMIO address checking, and RoT stubs.

## Responsibility

Validates HardwareBinding nodes in CGIR graphs. Stubs for MMIO, FPGA latch,
and Hardware Root of Trust integrations.

## TODO

- [ ] HardwareBinding validation
- [ ] MMIO address range checking
- [ ] FPGA latch binding stubs
- [ ] RoT attestation stubs

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
