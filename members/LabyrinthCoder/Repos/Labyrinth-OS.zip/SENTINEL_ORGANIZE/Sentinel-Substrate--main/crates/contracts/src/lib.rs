//! # contracts
//! Labyrinth-OS — Value contracts and risk contracts.
//!
//! Contracts define what the system will and will not do.
//! Checked at gate before any execution.
//! Fail-closed: contract violation = no execution.

/// A value contract — what the system must preserve.
#[derive(Debug, Clone)]
pub struct ValueContract {
    pub name:        String,
    pub description: String,
    pub is_hard:     bool,  // hard = system halts on violation; soft = warn only
}

impl ValueContract {
    pub fn hard(name: &str, description: &str) -> Self {
        Self { name: name.to_string(), description: description.to_string(), is_hard: true }
    }
    pub fn soft(name: &str, description: &str) -> Self {
        Self { name: name.to_string(), description: description.to_string(), is_hard: false }
    }
}

/// A risk contract — what conditions must hold for execution to proceed.
#[derive(Debug, Clone)]
pub struct RiskContract {
    pub name:              String,
    pub max_confidence_threshold: f64,
    pub max_drift:         f64,
    pub require_council:   bool,
}

impl RiskContract {
    pub fn standard() -> Self {
        Self {
            name:                    "STANDARD".to_string(),
            max_confidence_threshold: 0.65,
            max_drift:               0.12,
            require_council:         true,
        }
    }

    pub fn check(&self, confidence: f64, drift: f64, emitted_by: &str)
        -> Result<(), ContractViolation>
    {
        if confidence < self.max_confidence_threshold {
            return Err(ContractViolation::InsufficientConfidence {
                got: confidence, required: self.max_confidence_threshold,
            });
        }
        if drift > self.max_drift {
            return Err(ContractViolation::DriftExceeded {
                got: drift, limit: self.max_drift,
            });
        }
        if self.require_council && emitted_by != "COUNCIL" {
            return Err(ContractViolation::UnauthorizedEmitter(emitted_by.to_string()));
        }
        Ok(())
    }
}

/// Why a contract was violated.
#[derive(Debug, Clone, PartialEq)]
pub enum ContractViolation {
    InsufficientConfidence { got: f64, required: f64 },
    DriftExceeded { got: f64, limit: f64 },
    UnauthorizedEmitter(String),
}

/// The π₀ fallback policy — what happens when primary contracts fail.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FallbackPolicy { Halt, RetryOnce, Archive }

impl FallbackPolicy {
    pub fn default_safe() -> Self { Self::Halt }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn standard_contract_passes_clean_input() {
        let c = RiskContract::standard();
        assert!(c.check(0.90, 0.05, "COUNCIL").is_ok());
    }
    #[test] fn low_confidence_fails() {
        let c = RiskContract::standard();
        assert!(matches!(c.check(0.50, 0.05, "COUNCIL"),
            Err(ContractViolation::InsufficientConfidence{..})));
    }
    #[test] fn drift_exceeded_fails() {
        let c = RiskContract::standard();
        assert!(matches!(c.check(0.90, 0.20, "COUNCIL"),
            Err(ContractViolation::DriftExceeded{..})));
    }
    #[test] fn unauthorized_emitter_fails() {
        let c = RiskContract::standard();
        assert!(matches!(c.check(0.90, 0.05, "UNKNOWN"),
            Err(ContractViolation::UnauthorizedEmitter(_))));
    }
    #[test] fn hard_contract_is_hard() {
        let v = ValueContract::hard("NO_BYPASS", "Pipeline cannot be bypassed");
        assert!(v.is_hard);
    }
    #[test] fn fallback_default_is_halt() {
        assert_eq!(FallbackPolicy::default_safe(), FallbackPolicy::Halt);
    }
    #[test] fn soft_contract_is_soft() {
        let v = ValueContract::soft("LOG_WARN", "Log warnings");
        assert!(!v.is_hard);
    }
    #[test] fn contract_violation_variants_exist() {
        let _ = ContractViolation::UnauthorizedEmitter("x".to_string());
    }
}
