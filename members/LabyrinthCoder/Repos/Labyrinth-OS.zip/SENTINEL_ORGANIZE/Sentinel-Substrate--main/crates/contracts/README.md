# contracts

Value contracts, risk contracts, and π₀ fallback policies.

## Responsibility

Defines and evaluates contracts that Gate uses when making decisions.

## Contract Types

| Type | Description |
|------|-------------|
| ValueContract | Defines acceptable execution outcomes |
| RiskContract | Defines risk tolerance thresholds |
| Pi0FallbackPolicy | Fallback behavior for high-uncertainty states |

## TODO

- [ ] Implement ValueContract
- [ ] Implement RiskContract
- [ ] Implement Pi0FallbackPolicy
- [ ] Implement ContractViolation error
- [ ] Implement evaluation logic

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
