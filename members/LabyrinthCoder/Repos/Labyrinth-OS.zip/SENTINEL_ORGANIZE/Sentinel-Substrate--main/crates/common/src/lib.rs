//! # common
//! Labyrinth-OS — Shared types used across all crates.
//!
//! Single source of truth for types that appear everywhere.
//! No business logic here. Pure type definitions.

/// A content hash (SHA-256 hex string). Enforced 64 hex chars.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct ContentHash(String);

impl ContentHash {
    pub fn new(s: impl Into<String>) -> Result<Self, &'static str> {
        let s = s.into();
        if s.len() == 64 && s.chars().all(|c| c.is_ascii_hexdigit()) {
            Ok(Self(s))
        } else {
            Err("ContentHash must be exactly 64 hex chars")
        }
    }
    pub fn as_str(&self) -> &str { &self.0 }
    pub fn zeroed() -> Self { Self("0".repeat(64)) }
}

/// Session ID — non-empty string identifier.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct SessionId(String);

impl SessionId {
    pub fn new(s: impl Into<String>) -> Result<Self, &'static str> {
        let s = s.into();
        if s.is_empty() { Err("SessionId must be non-empty") }
        else { Ok(Self(s)) }
    }
    pub fn as_str(&self) -> &str { &self.0 }
}

/// Node ID — non-empty string, valid identifier chars.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct NodeId(String);

impl NodeId {
    pub fn new(s: impl Into<String>) -> Result<Self, &'static str> {
        let s = s.into();
        if s.is_empty() { return Err("NodeId must be non-empty"); }
        if !s.chars().all(|c| c.is_alphanumeric() || c == '_' || c == '-') {
            return Err("NodeId must be alphanumeric with _ or -");
        }
        Ok(Self(s))
    }
    pub fn as_str(&self) -> &str { &self.0 }
}

/// Lane designation. Only two lanes exist.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Lane { Creative, Execution }

impl Lane {
    /// The only valid crossing point between lanes.
    pub const BRIDGE: &'static str = "PROMOTION_PROTOCOL → REALITY_GATE";

    pub fn is_creative(self)   -> bool { self == Lane::Creative }
    pub fn is_execution(self)  -> bool { self == Lane::Execution }
}

/// Decision — binary. No middle ground.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Decision { Allow, Block }

impl Decision {
    pub fn allows(self) -> bool { self == Decision::Allow }
    pub fn blocks(self) -> bool { self == Decision::Block }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn content_hash_valid_64_hex() {
        assert!(ContentHash::new("a".repeat(64)).is_ok());
    }
    #[test] fn content_hash_wrong_length_rejected() {
        assert!(ContentHash::new("abc").is_err());
    }
    #[test] fn content_hash_non_hex_rejected() {
        assert!(ContentHash::new("g".repeat(64)).is_err());
    }
    #[test] fn session_id_empty_rejected() {
        assert!(SessionId::new("").is_err());
    }
    #[test] fn session_id_valid() {
        assert!(SessionId::new("session_001").is_ok());
    }
    #[test] fn node_id_invalid_chars_rejected() {
        assert!(NodeId::new("bad node!").is_err());
    }
    #[test] fn node_id_valid() {
        assert!(NodeId::new("node_001").is_ok());
    }
    #[test] fn lanes_distinct() {
        assert_ne!(Lane::Creative, Lane::Execution);
        assert!(Lane::Creative.is_creative());
        assert!(Lane::Execution.is_execution());
    }
    #[test] fn bridge_references_reality_gate() {
        assert!(Lane::BRIDGE.contains("REALITY_GATE"));
    }
    #[test] fn decision_binary() {
        assert!(Decision::Allow.allows());
        assert!(Decision::Block.blocks());
        assert!(!Decision::Allow.blocks());
    }
}
