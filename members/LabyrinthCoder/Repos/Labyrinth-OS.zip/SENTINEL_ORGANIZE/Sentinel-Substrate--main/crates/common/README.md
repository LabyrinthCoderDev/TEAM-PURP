# common

Shared utilities for the Labyrinth-OS execution substrate.

## Responsibility

Provides shared error types, result type aliases, utility traits,
and serialization helpers used across all crates.

## Non-Negotiable Rule

This crate MUST NOT contain any hidden execution logic.
All contents must be pure utilities with no side effects.

## TODO

- [ ] Add shared error types
- [ ] Add shared result type aliases
- [ ] Add shared utility traits
- [ ] Add serialization helpers

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
