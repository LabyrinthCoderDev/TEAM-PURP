//! # cgir-logical
//! Labyrinth-OS — Logical inference over CGIR graphs.
//!
//! Evaluates logical propositions about CGIR nodes.
//! Used by the gate to check invariant conditions before execution.
//! Pure functions only. No side effects.

/// A logical proposition about a CGIR node or system state.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Proposition {
    /// Node's severity matches the given string
    HasSeverity(String),
    /// Node was emitted by the named authority
    EmittedBy(String),
    /// Confidence is at or above the threshold (stored as thousandths)
    ConfidenceAbove(u32),
    /// Both propositions hold
    And(Box<Proposition>, Box<Proposition>),
    /// At least one holds
    Or(Box<Proposition>, Box<Proposition>),
    /// Proposition does not hold
    Not(Box<Proposition>),
    /// Always true
    True,
    /// Always false
    False,
}

/// Context for evaluating a proposition.
#[derive(Debug, Clone)]
pub struct EvalContext {
    pub severity:    String,
    pub emitted_by:  String,
    pub confidence:  f64,
}

impl EvalContext {
    pub fn new(severity: &str, emitted_by: &str, confidence: f64) -> Self {
        Self {
            severity:   severity.to_string(),
            emitted_by: emitted_by.to_string(),
            confidence: confidence.clamp(0.0, 1.0),
        }
    }
}

/// Evaluate a proposition against a context. Pure function.
pub fn evaluate(prop: &Proposition, ctx: &EvalContext) -> bool {
    match prop {
        Proposition::True  => true,
        Proposition::False => false,
        Proposition::HasSeverity(s)     => &ctx.severity == s,
        Proposition::EmittedBy(e)       => &ctx.emitted_by == e,
        Proposition::ConfidenceAbove(t) => ctx.confidence >= (*t as f64 / 1000.0),
        Proposition::And(a, b) => evaluate(a, ctx) && evaluate(b, ctx),
        Proposition::Or(a, b)  => evaluate(a, ctx) || evaluate(b, ctx),
        Proposition::Not(p)    => !evaluate(p, ctx),
    }
}

/// Convenience: build the standard "safe to execute" proposition.
/// COUNCIL-emitted, INFO severity, confidence >= 0.65
pub fn safe_to_execute() -> Proposition {
    Proposition::And(
        Box::new(Proposition::EmittedBy("COUNCIL".to_string())),
        Box::new(Proposition::And(
            Box::new(Proposition::HasSeverity("INFO".to_string())),
            Box::new(Proposition::ConfidenceAbove(650)),
        )),
    )
}

/// Check if a proposition is a tautology (always true regardless of context).
pub fn is_tautology(prop: &Proposition) -> bool {
    matches!(prop, Proposition::True)
}

/// Check if a proposition is a contradiction (always false).
pub fn is_contradiction(prop: &Proposition) -> bool {
    matches!(prop, Proposition::False)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn nominal() -> EvalContext {
        EvalContext::new("INFO", "COUNCIL", 0.90)
    }
    fn critical() -> EvalContext {
        EvalContext::new("CRITICAL", "COUNCIL", 0.90)
    }

    #[test] fn true_always_holds() {
        assert!(evaluate(&Proposition::True, &nominal()));
    }
    #[test] fn false_never_holds() {
        assert!(!evaluate(&Proposition::False, &nominal()));
    }
    #[test] fn severity_match() {
        let p = Proposition::HasSeverity("INFO".to_string());
        assert!(evaluate(&p, &nominal()));
        assert!(!evaluate(&p, &critical()));
    }
    #[test] fn emitted_by_match() {
        let p = Proposition::EmittedBy("COUNCIL".to_string());
        assert!(evaluate(&p, &nominal()));
        assert!(!evaluate(&p, &EvalContext::new("INFO","UNKNOWN",0.9)));
    }
    #[test] fn confidence_threshold() {
        let p = Proposition::ConfidenceAbove(650); // 0.65
        assert!(evaluate(&p, &EvalContext::new("INFO","COUNCIL",0.80)));
        assert!(!evaluate(&p, &EvalContext::new("INFO","COUNCIL",0.50)));
    }
    #[test] fn and_requires_both() {
        let p = Proposition::And(
            Box::new(Proposition::HasSeverity("INFO".to_string())),
            Box::new(Proposition::EmittedBy("COUNCIL".to_string())),
        );
        assert!(evaluate(&p, &nominal()));
        assert!(!evaluate(&p, &critical()));
    }
    #[test] fn or_requires_one() {
        let p = Proposition::Or(
            Box::new(Proposition::HasSeverity("INFO".to_string())),
            Box::new(Proposition::HasSeverity("CRITICAL".to_string())),
        );
        assert!(evaluate(&p, &nominal()));
        assert!(evaluate(&p, &critical()));
    }
    #[test] fn not_inverts() {
        let p = Proposition::Not(Box::new(Proposition::HasSeverity("CRITICAL".to_string())));
        assert!(evaluate(&p, &nominal()));
        assert!(!evaluate(&p, &critical()));
    }
    #[test] fn safe_to_execute_nominal_passes() {
        assert!(evaluate(&safe_to_execute(), &nominal()));
    }
    #[test] fn safe_to_execute_critical_fails() {
        assert!(!evaluate(&safe_to_execute(), &critical()));
    }
}
