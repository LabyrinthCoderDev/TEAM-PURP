# cgir-logical

CESK correctness, invariant coverage, and logical ordering checks.

## Responsibility

Validates the logical properties of a CGIR graph: CESK state machine
correctness, invariant mask coverage, causal ordering, and contradiction detection.

## TODO

- [ ] CESK correctness checks
- [ ] Invariant mask coverage
- [ ] Logical ordering verification
- [ ] Contradiction detection

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
