//! # concept-engine
//! Labyrinth-OS — Concept graph for Lane 1 (L04 Analytical Core).
//!
//! The concept engine builds a graph of related ideas and concepts.
//! It feeds the Analytical Core (L04) with structured relationships.
//! Never directly influences Lane 2 execution.

/// A concept node in the concept graph.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct ConceptId(String);

impl ConceptId {
    pub fn new(id: impl Into<String>) -> Result<Self, &'static str> {
        let id = id.into();
        if id.is_empty() { Err("ConceptId must be non-empty") }
        else { Ok(Self(id)) }
    }
    pub fn as_str(&self) -> &str { &self.0 }
}

/// Relationship type between two concepts.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Relation {
    Supports,      // A supports B
    Contradicts,   // A contradicts B
    Refines,       // A is a refinement of B
    Generalizes,   // A is a generalization of B
    DependsOn,     // A depends on B
}

/// A directed edge in the concept graph.
#[derive(Debug, Clone)]
pub struct ConceptEdge {
    pub from:     ConceptId,
    pub to:       ConceptId,
    pub relation: Relation,
    pub weight:   f64,
}

/// The concept graph.
#[derive(Debug, Default)]
pub struct ConceptEngine {
    concepts: Vec<ConceptId>,
    edges:    Vec<ConceptEdge>,
}

impl ConceptEngine {
    pub fn new() -> Self { Self::default() }

    pub fn add_concept(&mut self, id: ConceptId) {
        if !self.concepts.contains(&id) {
            self.concepts.push(id);
        }
    }

    pub fn add_edge(&mut self, edge: ConceptEdge) -> Result<(), &'static str> {
        if !self.concepts.contains(&edge.from) { return Err("Source concept not found"); }
        if !self.concepts.contains(&edge.to)   { return Err("Target concept not found"); }
        self.edges.push(edge);
        Ok(())
    }

    pub fn concept_count(&self) -> usize { self.concepts.len() }
    pub fn edge_count(&self)   -> usize { self.edges.len() }

    /// Find all concepts that support a given concept.
    pub fn supporters_of(&self, id: &ConceptId) -> Vec<&ConceptId> {
        self.edges.iter()
            .filter(|e| &e.to == id && e.relation == Relation::Supports)
            .map(|e| &e.from)
            .collect()
    }

    /// Find all concepts that contradict a given concept.
    pub fn contradictions_of(&self, id: &ConceptId) -> Vec<&ConceptId> {
        self.edges.iter()
            .filter(|e| (&e.from == id || &e.to == id) && e.relation == Relation::Contradicts)
            .map(|e| if &e.from == id { &e.to } else { &e.from })
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn concept_id_empty_rejected() {
        assert!(ConceptId::new("").is_err());
    }
    #[test] fn add_concept_and_count() {
        let mut ce = ConceptEngine::new();
        ce.add_concept(ConceptId::new("c1").unwrap());
        assert_eq!(ce.concept_count(), 1);
    }
    #[test] fn add_edge_valid() {
        let mut ce = ConceptEngine::new();
        let c1 = ConceptId::new("c1").unwrap();
        let c2 = ConceptId::new("c2").unwrap();
        ce.add_concept(c1.clone()); ce.add_concept(c2.clone());
        assert!(ce.add_edge(ConceptEdge { from:c1, to:c2, relation:Relation::Supports, weight:0.9 }).is_ok());
        assert_eq!(ce.edge_count(), 1);
    }
    #[test] fn edge_missing_concept_rejected() {
        let mut ce = ConceptEngine::new();
        let c1 = ConceptId::new("c1").unwrap();
        let c2 = ConceptId::new("c2").unwrap();
        assert!(ce.add_edge(ConceptEdge { from:c1, to:c2, relation:Relation::Supports, weight:0.5 }).is_err());
    }
    #[test] fn supporters_found() {
        let mut ce = ConceptEngine::new();
        let c1 = ConceptId::new("c1").unwrap();
        let c2 = ConceptId::new("c2").unwrap();
        ce.add_concept(c1.clone()); ce.add_concept(c2.clone());
        ce.add_edge(ConceptEdge { from:c1.clone(), to:c2.clone(), relation:Relation::Supports, weight:0.9 }).unwrap();
        let supporters = ce.supporters_of(&c2);
        assert_eq!(supporters.len(), 1);
        assert_eq!(supporters[0].as_str(), "c1");
    }
    #[test] fn contradictions_found() {
        let mut ce = ConceptEngine::new();
        let c1 = ConceptId::new("c1").unwrap();
        let c2 = ConceptId::new("c2").unwrap();
        ce.add_concept(c1.clone()); ce.add_concept(c2.clone());
        ce.add_edge(ConceptEdge { from:c1.clone(), to:c2.clone(), relation:Relation::Contradicts, weight:1.0 }).unwrap();
        assert_eq!(ce.contradictions_of(&c1).len(), 1);
    }
}
