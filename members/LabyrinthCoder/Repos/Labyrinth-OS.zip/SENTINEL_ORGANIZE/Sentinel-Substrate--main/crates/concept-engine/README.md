# concept-engine

Falsifiable abstraction formation layer (L7).

## Responsibility

Forms falsifiable abstractions from ledger records and replay traces.
All formed concepts are proposals — invalid until validated.

## TODO

- [ ] FalsifiableConcept type
- [ ] Abstraction formation from ledger
- [ ] Abstraction formation from replay traces
- [ ] Concept validation

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
