//! # signal-algebra
//! Labyrinth-OS — Sigma Anchor signal algebra.
//!
//! Mirrors Python: cgir_signal_algebra.py
//! chi = risk (high = bad). tau = coherence (low = bad).

pub const TAU_ESCAPE_FLOOR: f64 = 0.75;
pub const CHI_WARN: f64         = 0.15;
pub const CHI_COLLAPSE: f64     = 0.40;
pub const DRIFT_THRESHOLD: f64  = 0.12;
pub const BETTI_1_CAP: f64      = 0.045;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Severity { Info, Warning, Error, Critical }

#[derive(Debug, Clone)]
pub struct SignalNode {
    pub severity:    Severity,
    pub confidence:  f64,
    pub tau_escape:  f64,
    pub chi:         f64,
    pub drift:       f64,
    pub betti_1:     f64,
    pub emitted_by:  &'static str,
}

pub fn evaluate(tau: f64, chi: f64, drift: f64, betti: f64, conf: f64) -> SignalNode {
    let severity = if tau < TAU_ESCAPE_FLOOR || chi >= CHI_COLLAPSE {
        Severity::Critical
    } else if drift >= DRIFT_THRESHOLD || betti >= BETTI_1_CAP {
        Severity::Error
    } else if chi >= CHI_WARN {
        Severity::Warning
    } else {
        Severity::Info
    };
    SignalNode {
        severity, confidence: conf,
        tau_escape: tau, chi, drift, betti_1: betti,
        emitted_by: "SIGNAL_ALGEBRA",
    }
}

/// Severity merge: when combining multiple signals, take the highest.
pub fn merge_severity(a: Severity, b: Severity) -> Severity {
    if a >= b { a } else { b }
}

/// Confidence merge: take the minimum (most conservative).
pub fn merge_confidence(a: f64, b: f64) -> f64 {
    a.min(b).clamp(0.0, 1.0)
}

/// Merge a list of (severity, confidence) pairs.
/// Returns (worst_severity, min_confidence).
pub fn merge_signals(signals: &[(Severity, f64)]) -> Option<(Severity, f64)> {
    if signals.is_empty() { return None; }
    let sev = signals.iter().map(|(s,_)| *s).max().unwrap();
    let conf = signals.iter().map(|(_,c)| *c)
        .fold(f64::INFINITY, f64::min).clamp(0.0, 1.0);
    Some((sev, conf))
}

#[test] fn merge_severity_takes_higher() {
    assert_eq!(merge_severity(Severity::Info, Severity::Critical), Severity::Critical);
    assert_eq!(merge_severity(Severity::Warning, Severity::Error), Severity::Error);
}
#[test] fn merge_confidence_takes_lower() {
    assert!((merge_confidence(0.9, 0.6) - 0.6).abs() < 1e-9);
}
#[test] fn merge_signals_empty_returns_none() {
    assert!(merge_signals(&[]).is_none());
}
#[test] fn merge_signals_worst_case() {
    let result = merge_signals(&[
        (Severity::Info, 0.9),
        (Severity::Critical, 0.7),
        (Severity::Warning, 0.8),
    ]).unwrap();
    assert_eq!(result.0, Severity::Critical);
    assert!((result.1 - 0.7).abs() < 1e-9);
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn low_tau_critical() {
        let s = evaluate(0.5, 0.1, 0.0, 0.0, 0.9);
        assert_eq!(s.severity, Severity::Critical);
    }
    #[test] fn high_chi_critical() {
        let s = evaluate(0.9, 0.5, 0.0, 0.0, 0.9);
        assert_eq!(s.severity, Severity::Critical);
    }
    #[test] fn high_drift_error() {
        let s = evaluate(0.9, 0.1, 0.15, 0.0, 0.9);
        assert_eq!(s.severity, Severity::Error);
    }
    #[test] fn chi_warn_warning() {
        let s = evaluate(0.9, 0.2, 0.0, 0.0, 0.9);
        assert_eq!(s.severity, Severity::Warning);
    }
    #[test] fn clean_signal_info() {
        let s = evaluate(0.9, 0.05, 0.05, 0.01, 0.9);
        assert_eq!(s.severity, Severity::Info);
    }
    #[test] fn emitted_by_signal_algebra() {
        let s = evaluate(0.9, 0.05, 0.0, 0.0, 0.9);
        assert_eq!(s.emitted_by, "SIGNAL_ALGEBRA");
    }
}
