# signal-algebra

Severity, confidence, aggregation, decay, and escalation rules.

## Responsibility

Implements the algebra for combining, escalating, and decaying signal
severity and confidence values. All operations must be deterministic.

## Operations

| Operation | Description |
|-----------|-------------|
| Severity ordering | Info < Warning < Error < Critical |
| Confidence aggregation | Deterministic merge of confidence values |
| Severity escalation | Rules for severity escalation |
| Signal decay | Confidence decay over logical time |

## TODO

- [ ] Severity ordering
- [ ] Confidence aggregation
- [ ] Escalation rules
- [ ] Decay function

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
