# Labyrinth-OS Rust Substrate — Known Gaps

This file documents the gap between the current Rust prototype
and the intended production implementation. Mirrors KNOWN_GAPS.md
in the Python layer.

---

## GAP R1 — Prototype Signing (HIGH)

**Current:** `chancery-core` AuditRecord uses FNV-1a 64-bit deterministic hash (not cryptographically secure) deterministic hash
as a prototype signature. Same inputs → same signature (I9 satisfied),
but not cryptographically secure.

**Intended:** ML-DSA (NIST FIPS 204) post-quantum signatures via the
`fips204` crate. Each AuditRecord signed with a hardware-backed key.

**Closes when:** Hardware HSM or TPM available. `fips204` crate
integrated. Key provisioning workflow defined.

**Risk if unclosed:** Audit records can be forged by anyone who knows
the proposal_id, payload_hash, and timestamp. In current prototype
context (offline, controlled) this is acceptable. In production: not.

---

## GAP R2 — ExecutionValidity Always UNVERIFIED (MEDIUM)

**Current:** The Python layer sets ExecutionValidity::Verified only
after full enforcement ran. The Rust AuditRecord always starts as
Unverified and is never promoted to Verified in the Rust layer.

**Intended:** Rust AuditRecord should be marked Verified only after
the Python enforcement pipeline confirms the crossing was legitimate.
Requires cross-language signal from Python → Rust.

**Closes when:** Cross-language verification protocol defined.
Python enforcement result propagated into Rust ledger entry.

---

## GAP R3 — No Rust-side Chain Verification (LOW)

**Current:** Hash chain verification lives entirely in Python
(hash_ledger.py, hashchain.py). The Rust workspace has no equivalent
chain integrity check.

**Intended:** `ledger-chronicle` crate should expose a verify()
function that mirrors Python hash_ledger.py verify(). Independent
verification from both layers.

**Closes when:** ledger-chronicle implements chain verification
with the same algorithm as Python layer.

---

X: @LabyrinthCoder

This file is documentation only — no executable code.
