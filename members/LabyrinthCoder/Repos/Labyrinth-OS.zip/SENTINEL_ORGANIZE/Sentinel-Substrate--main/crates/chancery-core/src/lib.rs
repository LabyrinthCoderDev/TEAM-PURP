//! # chancery-core
//! Labyrinth-OS — Verification harness for language-agent tool calls.
//!
//! Provides:
//!   - Capability types for tool call verification
//!   - Structured rule identity
//!   - Signed audit records (prototype: SHA-256; post-prototype: ML-DSA FIPS 204)
//!
//! Every tool call that crosses the Reality Gate produces an AuditRecord
//! that can be verified independently of the runtime.
//!
//! Invariant alignment:
//!   I8: All execution logged — AuditRecord is the per-tool-call ledger entry
//!   I9: All execution replayable — signed record enables independent verification
//!   I3: Nothing bypasses PROMOTION — CapabilityType enforces per-capability rules

use serde::{Deserialize, Serialize};

/// Capability types — what kind of action a tool call performs.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum CapabilityType {
    /// Read-only — no gate or promotion required
    Read,
    /// Write — requires promotion receipt
    Write,
    /// Execute external process — requires gate approval
    Execute,
    /// Network access — full pipeline required
    Network,
    /// Internal state mutation — maps to AEGIS/CESK
    StateMutation,
}

impl CapabilityType {
    /// Whether this capability requires a Reality Gate crossing.
    pub fn requires_gate(&self) -> bool {
        matches!(self, Self::Execute | Self::Network | Self::StateMutation)
    }
    /// Whether this capability requires a PromotionReceipt.
    pub fn requires_promotion(&self) -> bool {
        matches!(self, Self::Write | Self::Execute | Self::Network | Self::StateMutation)
    }
}

/// Structured rule identity — which rule authorizes this tool call.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuleId {
    pub namespace: String,
    pub name:      String,
    pub version:   u32,
    pub rule_hash: String,
}

impl RuleId {
    pub fn new(namespace: &str, name: &str, version: u32, rule_hash: &str) -> Self {
        Self {
            namespace:  namespace.to_string(),
            name:       name.to_string(),
            version,
            rule_hash:  rule_hash.to_string(),
        }
    }
    pub fn qualified_name(&self) -> String {
        format!("{}::{}@v{}", self.namespace, self.name, self.version)
    }
}

/// Execution validity — mirrors Python receipt.py ExecutionValidity.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ExecutionValidity {
    Verified,
    Unverified,
    MockPath,
}

/// Audit record for a single tool call — signed, immutable, replayable.
///
/// Prototype: SHA-256 placeholder signature.
/// Post-prototype: ML-DSA (NIST FIPS 204) via `fips204` crate.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuditRecord {
    pub tool_call_id:       String,
    pub capability:         CapabilityType,
    pub rule_id:            RuleId,
    pub payload_hash:       String,
    pub timestamp_ns:       u64,
    pub execution_validity: ExecutionValidity,
    /// Prototype: hex string of a deterministic hash of record fields.
    /// Post-prototype: ML-DSA-65 detached signature bytes (base64).
    pub signature:          String,
}

impl AuditRecord {
    pub fn new_prototype(
        tool_call_id: String,
        capability: CapabilityType,
        rule_id: RuleId,
        payload_hash: String,
        timestamp_ns: u64,
    ) -> Self {
        // Deterministic prototype signature — same inputs → same signature (I9)
        let sig_input = format!(
            "LABYRINTH:{}:{}:{}:{}",
            tool_call_id, payload_hash, timestamp_ns,
            rule_id.qualified_name()
        );
        // Simple deterministic hash — stdlib only (no external crypto crate needed here)
        let mut h: u64 = 0xcbf29ce484222325;
        for b in sig_input.bytes() {
            h ^= b as u64;
            h = h.wrapping_mul(0x100000001b3);
        }
        let signature = format!("{:016x}", h);
        Self {
            tool_call_id,
            capability,
            rule_id,
            payload_hash,
            timestamp_ns,
            execution_validity: ExecutionValidity::Unverified,
            signature,
        }
    }
    pub fn is_gate_required(&self)      -> bool { self.capability.requires_gate() }
    pub fn is_promotion_required(&self) -> bool { self.capability.requires_promotion() }
    pub fn is_prototype_signature(&self) -> bool {
        // Prototype signatures are exactly 16 hex chars (FNV-64)
        self.signature.len() == 16 && self.signature.chars().all(|c| c.is_ascii_hexdigit())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn rule() -> RuleId { RuleId::new("labyrinth.gate", "allow_read", 1, &"a".repeat(64)) }

    #[test] fn read_no_gate()              { assert!(!CapabilityType::Read.requires_gate()); }
    #[test] fn execute_requires_gate()     { assert!(CapabilityType::Execute.requires_gate()); }
    #[test] fn network_requires_promotion(){ assert!(CapabilityType::Network.requires_promotion()); }
    #[test] fn read_no_promotion()         { assert!(!CapabilityType::Read.requires_promotion()); }
    #[test] fn rule_qualified_name() {
        assert_eq!(rule().qualified_name(), "labyrinth.gate::allow_read@v1");
    }
    #[test] fn audit_record_creates_cleanly() {
        let r = AuditRecord::new_prototype(
            "tc-001".into(), CapabilityType::Read, rule(), "a".repeat(64), 1_000_000,
        );
        assert_eq!(r.tool_call_id, "tc-001");
        assert!(r.is_prototype_signature());
    }
    #[test] fn default_validity_unverified() {
        let r = AuditRecord::new_prototype(
            "tc-002".into(), CapabilityType::Write, rule(), "b".repeat(64), 2_000_000,
        );
        assert_eq!(r.execution_validity, ExecutionValidity::Unverified);
    }
    #[test] fn same_inputs_same_signature() {
        let r1 = AuditRecord::new_prototype(
            "tc-x".into(), CapabilityType::Execute, rule(), "c".repeat(64), 999,
        );
        let r2 = AuditRecord::new_prototype(
            "tc-x".into(), CapabilityType::Execute, rule(), "c".repeat(64), 999,
        );
        assert_eq!(r1.signature, r2.signature);
    }
}
