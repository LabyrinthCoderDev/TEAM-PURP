//! # cgir-compiler
//! Labyrinth-OS — Full CGIR compilation pipeline.
//!
//! Orchestrates: validate → gate → codegen → program
//! Each stage must pass before the next runs.
//! Fail-closed: any validation failure stops compilation.

/// Compilation stage result.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StageResult { Pass, Fail(String) }

impl StageResult {
    pub fn passed(&self) -> bool { matches!(self, Self::Pass) }
}

/// Full compilation result.
#[derive(Debug)]
pub struct CompileResult {
    pub node_id:         String,
    pub stages:          Vec<(&'static str, StageResult)>,
    pub compiled:        bool,
    pub instruction_count: usize,
}

impl CompileResult {
    pub fn failed_stages(&self) -> Vec<&str> {
        self.stages.iter()
            .filter(|(_, r)| !r.passed())
            .map(|(s, _)| *s)
            .collect()
    }
}

/// CGIR compiler — fail-closed multi-stage compilation.
pub struct CgirCompiler {
    confidence_floor: f64,
}

impl CgirCompiler {
    pub fn new(confidence_floor: f64) -> Self { Self { confidence_floor } }

    pub fn compile(&self, node_id: &str, severity: &str,
                   confidence: f64, emitted_by: &str) -> CompileResult
    {
        let mut stages = Vec::new();

        // Stage 1: Validate emitter
        let s1 = if ["COUNCIL","SIGNAL_ALGEBRA"].contains(&emitted_by) {
            StageResult::Pass
        } else {
            StageResult::Fail(format!("Unknown emitter: {emitted_by}"))
        };
        stages.push(("validate_emitter", s1.clone()));
        if !s1.passed() {
            return CompileResult { node_id:node_id.into(), stages, compiled:false, instruction_count:0 };
        }

        // Stage 2: Gate check
        let s2 = if matches!(severity, "ERROR"|"CRITICAL") || confidence < self.confidence_floor {
            StageResult::Fail(format!("Blocked: severity={severity} confidence={confidence:.2}"))
        } else {
            StageResult::Pass
        };
        stages.push(("gate_check", s2.clone()));

        // Stage 3: Codegen (only if gate passed)
        let (compiled, count) = if s2.passed() {
            // 4 instructions: Load + Verify + Gate + Emit
            (true, 4)
        } else {
            // 3 instructions: Load + Verify + Halt
            (false, 3)
        };
        stages.push(("codegen", if compiled { StageResult::Pass } else { StageResult::Fail("Halted".into()) }));

        CompileResult { node_id:node_id.into(), stages, compiled, instruction_count:count }
    }
}

impl Default for CgirCompiler { fn default() -> Self { Self::new(0.5) } }

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn clean_compiles() {
        let c = CgirCompiler::new(0.5);
        let r = c.compile("n1", "INFO", 0.9, "COUNCIL");
        assert!(r.compiled);
        assert!(r.failed_stages().is_empty());
    }
    #[test] fn unknown_emitter_fails_stage1() {
        let c = CgirCompiler::new(0.5);
        let r = c.compile("n1", "INFO", 0.9, "UNKNOWN");
        assert!(!r.compiled);
        assert!(r.failed_stages().contains(&"validate_emitter"));
    }
    #[test] fn critical_fails_gate() {
        let c = CgirCompiler::new(0.5);
        let r = c.compile("n1", "CRITICAL", 0.9, "COUNCIL");
        assert!(!r.compiled);
        assert!(r.failed_stages().contains(&"gate_check"));
    }
    #[test] fn low_confidence_fails_gate() {
        let c = CgirCompiler::new(0.8);
        let r = c.compile("n1", "INFO", 0.3, "COUNCIL");
        assert!(!r.compiled);
    }
    #[test] fn instruction_count_nonzero() {
        let c = CgirCompiler::default();
        let r = c.compile("n1", "INFO", 0.9, "COUNCIL");
        assert!(r.instruction_count > 0);
    }
    #[test] fn fail_closed_no_partial_compile() {
        let c = CgirCompiler::default();
        let r = c.compile("n1", "CRITICAL", 0.9, "COUNCIL");
        assert!(!r.compiled);
        // Even though emitter is valid, critical severity means no compiled output
        assert!(r.instruction_count > 0);  // instructions exist but not compiled
    }
}
