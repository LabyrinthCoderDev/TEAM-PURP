# cgir-compiler

Coordinates all CGIR compilation passes.

## Responsibility

Orchestrates the full compilation pipeline from raw proposal to validated CGIR graph.

## Pipeline

1. Parse raw proposal → candidate CGIR
2. Logical pass (cgir-logical)
3. Temporal pass (cgir-temporal)
4. Signal pass (cgir-signal)
5. Hardware pass (cgir-hardware)
6. Full validation (cgir-validator)
7. Emit validated CGIR graph

## Invariant

I7 Epistemic Containment: proposal outputs are invalid until this pipeline completes.

## TODO

- [ ] Implement CompilerPass trait
- [ ] Implement CompilerError enum
- [ ] Wire all compilation passes in order
- [ ] Add end-to-end tests

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
