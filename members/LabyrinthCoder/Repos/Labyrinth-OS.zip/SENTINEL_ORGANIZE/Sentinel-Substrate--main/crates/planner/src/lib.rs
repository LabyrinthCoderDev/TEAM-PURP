//! # planner
//! Labyrinth-OS — Execution plan builder.
//!
//! Builds an ordered execution plan from a set of CGIR nodes,
//! respecting dependencies and invariant constraints.
//! Plan is validated before any execution begins.
//! Fail-closed: circular dependency → error.

/// A single step in an execution plan.
#[derive(Debug, Clone)]
pub struct PlanStep {
    pub step_id:    String,
    pub depends_on: Vec<String>,
    pub label:      String,
}

impl PlanStep {
    pub fn new(id: &str, label: &str) -> Self {
        Self { step_id: id.to_string(), depends_on: vec![], label: label.to_string() }
    }
    pub fn with_dep(mut self, dep: &str) -> Self {
        self.depends_on.push(dep.to_string()); self
    }
}

/// A validated execution plan.
#[derive(Debug, Clone)]
pub struct ExecutionPlan {
    pub steps:     Vec<PlanStep>,
    pub validated: bool,
}

/// Why plan validation failed.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PlanError {
    EmptyPlan,
    UnknownDependency { step: String, dep: String },
    CircularDependency { step: String },
    DuplicateStepId(String),
}

/// Build and validate an execution plan from a list of steps.
pub fn build_plan(steps: Vec<PlanStep>) -> Result<ExecutionPlan, PlanError> {
    if steps.is_empty() { return Err(PlanError::EmptyPlan); }

    // Check for duplicate IDs
    let mut seen = std::collections::HashSet::new();
    for s in &steps {
        if !seen.insert(&s.step_id) {
            return Err(PlanError::DuplicateStepId(s.step_id.clone()));
        }
    }

    // Check all dependencies exist
    let ids: std::collections::HashSet<_> = steps.iter().map(|s| &s.step_id).collect();
    for step in &steps {
        for dep in &step.depends_on {
            if !ids.contains(dep) {
                return Err(PlanError::UnknownDependency {
                    step: step.step_id.clone(), dep: dep.clone(),
                });
            }
        }
    }

    // Check for circular dependencies (topological sort)
    let mut order: Vec<String> = Vec::new();
    let mut resolved: std::collections::HashSet<String> = std::collections::HashSet::new();
    let mut remaining: Vec<&PlanStep> = steps.iter().collect();
    let mut stalled = false;

    while !remaining.is_empty() {
        let prev_len = remaining.len();
        remaining.retain(|s| {
            if s.depends_on.iter().all(|d| resolved.contains(d)) {
                order.push(s.step_id.clone());
                resolved.insert(s.step_id.clone());
                false
            } else { true }
        });
        if remaining.len() == prev_len {
            stalled = true; break;
        }
    }

    if stalled {
        return Err(PlanError::CircularDependency {
            step: remaining[0].step_id.clone()
        });
    }

    // Reorder steps by resolved order
    let mut ordered_steps: Vec<PlanStep> = Vec::new();
    for id in &order {
        if let Some(s) = steps.iter().find(|s| &s.step_id == id) {
            ordered_steps.push(s.clone());
        }
    }

    Ok(ExecutionPlan { steps: ordered_steps, validated: true })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn empty_plan_rejected() {
        assert!(matches!(build_plan(vec![]), Err(PlanError::EmptyPlan)));
    }
    #[test] fn single_step_plan_valid() {
        let plan = build_plan(vec![PlanStep::new("s1","label")]).unwrap();
        assert!(plan.validated);
        assert_eq!(plan.steps.len(), 1);
    }
    #[test] fn dependency_ordering_resolved() {
        let steps = vec![
            PlanStep::new("s2","step2").with_dep("s1"),
            PlanStep::new("s1","step1"),
        ];
        let plan = build_plan(steps).unwrap();
        assert_eq!(plan.steps[0].step_id, "s1");
        assert_eq!(plan.steps[1].step_id, "s2");
    }
    #[test] fn unknown_dependency_rejected() {
        let steps = vec![PlanStep::new("s1","x").with_dep("nonexistent")];
        assert!(matches!(build_plan(steps), Err(PlanError::UnknownDependency{..})));
    }
    #[test] fn circular_dependency_detected() {
        let steps = vec![
            PlanStep::new("s1","a").with_dep("s2"),
            PlanStep::new("s2","b").with_dep("s1"),
        ];
        assert!(matches!(build_plan(steps), Err(PlanError::CircularDependency{..})));
    }
    #[test] fn duplicate_step_id_rejected() {
        let steps = vec![PlanStep::new("s1","x"), PlanStep::new("s1","y")];
        assert!(matches!(build_plan(steps), Err(PlanError::DuplicateStepId(_))));
    }
    #[test] fn three_step_chain_ordered() {
        let steps = vec![
            PlanStep::new("c","C").with_dep("b"),
            PlanStep::new("b","B").with_dep("a"),
            PlanStep::new("a","A"),
        ];
        let plan = build_plan(steps).unwrap();
        let ids: Vec<_> = plan.steps.iter().map(|s| s.step_id.as_str()).collect();
        assert_eq!(ids, vec!["a","b","c"]);
    }
    #[test] fn validated_flag_is_true() {
        let plan = build_plan(vec![PlanStep::new("s1","x")]).unwrap();
        assert!(plan.validated);
    }
}
