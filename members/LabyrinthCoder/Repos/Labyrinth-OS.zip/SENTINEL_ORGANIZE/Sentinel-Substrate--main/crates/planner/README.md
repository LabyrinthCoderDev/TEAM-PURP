# planner

Monte Carlo and formula-based candidate CGIR edge generator (L9).

## Responsibility

Generates ranked candidate CGIR edges for consideration.

## Non-Negotiable

The planner NEVER executes. All outputs are proposals only.

## TODO

- [ ] Monte Carlo candidate generator
- [ ] Formula-based candidate generator
- [ ] Candidate ranking
- [ ] Verify: no execution

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
