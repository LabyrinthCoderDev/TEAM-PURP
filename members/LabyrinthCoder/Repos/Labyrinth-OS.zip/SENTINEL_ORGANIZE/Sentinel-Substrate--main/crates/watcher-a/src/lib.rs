//! # watcher-a
//! Labyrinth-OS — Internal consistency auditor.
//!
//! Mirrors Python: watcher_a.py
//! Role: AUDIT ONLY. Cannot execute. Cannot promote. Cannot modify PipelineTrace.

/// A single finding from Watcher-A.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FindingLevel { Pass, Warn, Fail }

#[derive(Debug, Clone)]
pub struct Finding {
    pub level:   FindingLevel,
    pub check:   String,
    pub detail:  String,
}

impl Finding {
    pub fn pass(check: impl Into<String>) -> Self {
        Self { level: FindingLevel::Pass, check: check.into(), detail: String::new() }
    }
    pub fn warn(check: impl Into<String>, detail: impl Into<String>) -> Self {
        Self { level: FindingLevel::Warn, check: check.into(), detail: detail.into() }
    }
    pub fn fail(check: impl Into<String>, detail: impl Into<String>) -> Self {
        Self { level: FindingLevel::Fail, check: check.into(), detail: detail.into() }
    }
    pub fn is_fail(&self) -> bool { self.level == FindingLevel::Fail }
}

/// Watcher-A result set.
#[derive(Debug, Default)]
pub struct WatcherAResult {
    pub findings: Vec<Finding>,
}

impl WatcherAResult {
    pub fn has_failures(&self) -> bool { self.findings.iter().any(|f| f.is_fail()) }
    pub fn failure_count(&self) -> usize { self.findings.iter().filter(|f| f.is_fail()).count() }
}

/// Watcher-A: checks internal consistency of a signal set.
pub struct WatcherA;

impl WatcherA {
    /// Audit a confidence value. Must be in [0, 1].
    pub fn check_confidence(&self, confidence: f64) -> Finding {
        if !(0.0..=1.0).contains(&confidence) {
            Finding::fail("confidence_range",
                format!("Confidence {confidence:.3} out of [0,1]"))
        } else {
            Finding::pass("confidence_range")
        }
    }

    /// Audit that emitted_by is COUNCIL (Invariant I4).
    pub fn check_emitter(&self, emitted_by: &str) -> Finding {
        if emitted_by == "COUNCIL" {
            Finding::pass("emitter_authority")
        } else {
            Finding::fail("emitter_authority",
                format!("Expected COUNCIL, got '{emitted_by}'"))
        }
    }

    /// Audit logical time is non-zero.
    pub fn check_logical_time(&self, t: u64) -> Finding {
        if t == 0 {
            Finding::warn("logical_time", "Logical time is 0 — may indicate uninitialized signal")
        } else {
            Finding::pass("logical_time")
        }
    }

    /// Run all checks and return combined result.
    pub fn audit(&self, confidence: f64, emitted_by: &str, logical_time: u64) -> WatcherAResult {
        WatcherAResult {
            findings: vec![
                self.check_confidence(confidence),
                self.check_emitter(emitted_by),
                self.check_logical_time(logical_time),
            ],
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn confidence_out_of_range_fails() {
        let w = WatcherA;
        assert!(w.check_confidence(1.5).is_fail());
        assert!(w.check_confidence(-0.1).is_fail());
    }
    #[test] fn confidence_valid_passes() {
        let w = WatcherA;
        assert!(!w.check_confidence(0.75).is_fail());
    }
    #[test] fn wrong_emitter_fails() {
        let w = WatcherA;
        assert!(w.check_emitter("SIGNAL_ALGEBRA").is_fail());
    }
    #[test] fn council_emitter_passes() {
        let w = WatcherA;
        assert!(!w.check_emitter("COUNCIL").is_fail());
    }
    #[test] fn zero_logical_time_warns() {
        let w = WatcherA;
        let f = w.check_logical_time(0);
        assert_eq!(f.level, FindingLevel::Warn);
    }
    #[test] fn full_audit_bad_confidence() {
        let w = WatcherA;
        let r = w.audit(1.5, "COUNCIL", 1);
        assert!(r.has_failures());
        assert_eq!(r.failure_count(), 1);
    }
    #[test] fn full_audit_clean() {
        let w = WatcherA;
        let r = w.audit(0.8, "COUNCIL", 42);
        assert!(!r.has_failures());
    }
}
