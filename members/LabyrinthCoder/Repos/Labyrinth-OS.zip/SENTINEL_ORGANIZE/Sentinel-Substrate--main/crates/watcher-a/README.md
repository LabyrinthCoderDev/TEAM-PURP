# watcher-a

Internal consistency auditor.

## Responsibility

Watcher-A (L3) checks invariants, expected behavior, system sanity,
and replay assumptions. It produces audit signals only.

## Non-Negotiable

Watcher-A CANNOT execute. Watcher-A CANNOT mutate state.
It CANNOT trigger execution or bypass Gate.

## TODO

- [ ] Implement invariant checking
- [ ] Implement expected behavior verification
- [ ] Implement system sanity checks
- [ ] Implement replay assumption checks
- [ ] Verify: no execution, no mutation

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
