//! # offline-evolution
//! Labyrinth-OS — Offline evolution engine.
//!
//! Evolution runs OFFLINE — never in real-time during execution.
//! Takes archived failures → produces mutation candidates.
//! Mirrors deferred_node.py in Python.
//! All mutation candidates re-enter at LABELING. No shortcuts.

/// A failure record available for evolution.
#[derive(Debug, Clone)]
pub struct FailureRecord {
    pub failure_id:   String,
    pub failure_type: FailureType,
    pub severity:     f64,
    pub parameters:   Vec<(String, f64)>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FailureType {
    GateRejection,
    ConstraintViolation,
    SolverFailure,
    DriftDetected,
    IdentityViolation,
}

/// A mutation candidate produced by offline evolution.
#[derive(Debug, Clone)]
pub struct MutationCandidate {
    pub candidate_id:    String,
    pub parent_id:       String,
    pub mutation_depth:  u32,
    pub mutated_params:  Vec<(String, f64)>,
    pub entry_point:     EntryPoint,
}

/// All mutation candidates re-enter at LABELING. No other entry point.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EntryPoint { Labeling }

impl MutationCandidate {
    pub fn entry_point(&self) -> EntryPoint { EntryPoint::Labeling }
    pub fn must_pass_full_pipeline(&self) -> bool { true }
}

/// The offline evolution engine.
pub struct OfflineEvolution {
    max_depth: u32,
    mutation_count: u64,
}

impl OfflineEvolution {
    pub fn new(max_depth: u32) -> Self {
        Self { max_depth, mutation_count: 0 }
    }

    pub fn evolve(&mut self, failure: &FailureRecord) -> Option<MutationCandidate> {
        if failure.severity < 0.3 { return None; }
        self.mutation_count += 1;
        let mutated = failure.parameters.iter()
            .map(|(k, v)| (k.clone(), (v * 0.95).max(0.0).min(1.0)))
            .collect();
        Some(MutationCandidate {
            candidate_id:   format!("mut_{:08}", self.mutation_count),
            parent_id:      failure.failure_id.clone(),
            mutation_depth: 1,
            mutated_params: mutated,
            entry_point:    EntryPoint::Labeling,
        })
    }

    pub fn mutation_count(&self) -> u64 { self.mutation_count }
}

impl Default for OfflineEvolution {
    fn default() -> Self { Self::new(5) }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn high_severity_produces_candidate() {
        let mut oe = OfflineEvolution::new(5);
        let f = FailureRecord { failure_id:"f1".into(), failure_type:FailureType::GateRejection,
                                 severity:0.8, parameters:vec![("tau".into(), 0.7)] };
        assert!(oe.evolve(&f).is_some());
    }
    #[test] fn low_severity_skipped() {
        let mut oe = OfflineEvolution::new(5);
        let f = FailureRecord { failure_id:"f1".into(), failure_type:FailureType::GateRejection,
                                 severity:0.1, parameters:vec![] };
        assert!(oe.evolve(&f).is_none());
    }
    #[test] fn candidate_enters_at_labeling() {
        let mut oe = OfflineEvolution::new(5);
        let f = FailureRecord { failure_id:"f1".into(), failure_type:FailureType::DriftDetected,
                                 severity:0.9, parameters:vec![] };
        let c = oe.evolve(&f).unwrap();
        assert_eq!(c.entry_point(), EntryPoint::Labeling);
        assert!(c.must_pass_full_pipeline());
    }
    #[test] fn mutation_count_increments() {
        let mut oe = OfflineEvolution::new(5);
        let f = FailureRecord { failure_id:"f1".into(), failure_type:FailureType::GateRejection,
                                 severity:0.8, parameters:vec![] };
        oe.evolve(&f); oe.evolve(&f);
        assert_eq!(oe.mutation_count(), 2);
    }
    #[test] fn parent_id_preserved() {
        let mut oe = OfflineEvolution::new(5);
        let f = FailureRecord { failure_id:"failure_001".into(),
                                 failure_type:FailureType::SolverFailure,
                                 severity:0.7, parameters:vec![] };
        let c = oe.evolve(&f).unwrap();
        assert_eq!(c.parent_id, "failure_001");
    }
    #[test] fn params_are_mutated() {
        let mut oe = OfflineEvolution::new(5);
        let f = FailureRecord { failure_id:"f1".into(), failure_type:FailureType::GateRejection,
                                 severity:0.8, parameters:vec![("threshold".into(), 0.8)] };
        let c = oe.evolve(&f).unwrap();
        let new_val = c.mutated_params[0].1;
        assert!(new_val < 0.8);  // mutated downward
    }
}
