# offline-evolution

Replay-driven promotion proposals — offline only.

## Responsibility

Implements the offline evolution pipeline:
Shadow → Replay → Value Contract → Gate Promotion

## Non-Negotiable

Evolution happens OFFLINE ONLY. No live self-modification.

## TODO

- [ ] EvolutionProposal type
- [ ] Shadow → Replay evaluation
- [ ] Value Contract evaluation
- [ ] Gate Promotion proposal generation

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
