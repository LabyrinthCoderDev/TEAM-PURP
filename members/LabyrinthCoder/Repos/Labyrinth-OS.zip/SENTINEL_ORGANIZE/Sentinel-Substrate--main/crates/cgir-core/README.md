# cgir-core

Core CGIR graph model.

## Responsibility

Defines the core data structures for the Causal Graph Intermediate Representation (CGIR).

## Node Types

| Type | Description |
|------|-------------|
| `StateNode` | Snapshot of CESK state |
| `EventEdge` | State transition with invariant mask and signal binding |
| `SignalNode` | Annotated severity/confidence signal from Council |
| `TimedEdge` | Transition with latency constraints |
| `InvariantBinding` | Bound invariant rule with pass/fail/partial status |
| `HardwareBinding` | Hardware register, MMIO address, or RoT latch |

## BaseNode Fields

All nodes share: `id`, `schema_version`, `logical_time`, `timestamp_ms`, `hash`, `prev_hash`

## TODO

- [ ] Implement BaseNode
- [ ] Implement all node types
- [ ] Implement CGIRNode enum
- [ ] Implement CGIRGraph collection
- [ ] Add graph traversal utilities
- [ ] Add hash verification

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
