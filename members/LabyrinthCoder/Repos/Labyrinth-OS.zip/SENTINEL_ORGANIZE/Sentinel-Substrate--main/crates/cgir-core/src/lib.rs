//! # cgir-core
//! Labyrinth-OS — Causal Graph IR core graph model.
//!
//! Mirrors Python: cgir_core.py
//! Invariant I1: Only valid CGIR edges can mutate CESK state.

use std::collections::HashMap;

/// Unique node identifier. Non-empty, no whitespace.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct NodeId(String);

impl NodeId {
    pub fn new(id: impl Into<String>) -> Result<Self, &'static str> {
        let id = id.into();
        if id.is_empty() || id.contains(char::is_whitespace) {
            return Err("NodeId must be non-empty with no whitespace");
        }
        Ok(Self(id))
    }
    pub fn as_str(&self) -> &str { &self.0 }
}

/// Unique edge identifier.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct EdgeId(String);

impl EdgeId {
    pub fn new(id: impl Into<String>) -> Result<Self, &'static str> {
        let id = id.into();
        if id.is_empty() { return Err("EdgeId must be non-empty"); }
        Ok(Self(id))
    }
}

/// Signal severity levels. Mirrors Python Severity enum.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Severity { Info, Warning, Error, Critical }

impl Severity {
    /// Returns true if this severity level blocks gate execution.
    pub fn blocks_gate(self) -> bool {
        matches!(self, Severity::Error | Severity::Critical)
    }
}

/// Confidence in [0.0, 1.0]. Enforced at construction.
#[derive(Debug, Clone, Copy, PartialEq, PartialOrd)]
pub struct Confidence(f64);

impl Confidence {
    pub fn new(v: f64) -> Result<Self, &'static str> {
        if !(0.0..=1.0).contains(&v) {
            return Err("Confidence must be in [0.0, 1.0]");
        }
        Ok(Self(v))
    }
    pub fn value(self) -> f64 { self.0 }
    pub fn zero() -> Self { Self(0.0) }
    pub fn one() -> Self { Self(1.0) }
}

/// A node in the Causal Graph IR.
#[derive(Debug, Clone)]
pub struct CgirNode {
    pub id:           NodeId,
    pub severity:     Severity,
    pub confidence:   Confidence,
    pub emitted_by:   String,
    pub logical_time: u64,
}

/// An edge in the Causal Graph IR.
#[derive(Debug, Clone)]
pub struct CgirEdge {
    pub id:      EdgeId,
    pub from:    NodeId,
    pub to:      NodeId,
    pub label:   String,
}

/// The CGIR graph container.
#[derive(Debug, Default)]
pub struct CgirGraph {
    nodes: HashMap<String, CgirNode>,
    edges: Vec<CgirEdge>,
}

impl CgirGraph {
    pub fn new() -> Self { Self::default() }

    pub fn add_node(&mut self, node: CgirNode) {
        self.nodes.insert(node.id.as_str().to_string(), node);
    }

    pub fn add_edge(&mut self, edge: CgirEdge) -> Result<(), &'static str> {
        if !self.nodes.contains_key(edge.from.as_str()) {
            return Err("Edge source node not found");
        }
        if !self.nodes.contains_key(edge.to.as_str()) {
            return Err("Edge target node not found");
        }
        self.edges.push(edge);
        Ok(())
    }

    pub fn node_count(&self) -> usize { self.nodes.len() }
    pub fn edge_count(&self) -> usize { self.edges.len() }

    /// Check if graph has at least one node with the given severity.
    pub fn has_severity(&self, sev: Severity) -> bool {
        self.nodes.values().any(|n| n.severity == sev)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn node_id_rejects_empty() {
        assert!(NodeId::new("").is_err());
    }
    #[test] fn node_id_rejects_whitespace() {
        assert!(NodeId::new("bad id").is_err());
    }
    #[test] fn node_id_accepts_valid() {
        assert!(NodeId::new("node_001").is_ok());
    }
    #[test] fn confidence_rejects_out_of_range() {
        assert!(Confidence::new(1.5).is_err());
        assert!(Confidence::new(-0.1).is_err());
    }
    #[test] fn confidence_accepts_valid() {
        assert!(Confidence::new(0.75).is_ok());
    }
    #[test] fn severity_blocks_gate_error_critical() {
        assert!(Severity::Error.blocks_gate());
        assert!(Severity::Critical.blocks_gate());
        assert!(!Severity::Info.blocks_gate());
        assert!(!Severity::Warning.blocks_gate());
    }
    #[test] fn graph_add_node_and_edge() {
        let mut g = CgirGraph::new();
        let n1 = CgirNode {
            id: NodeId::new("n1").unwrap(),
            severity: Severity::Info,
            confidence: Confidence::new(0.9).unwrap(),
            emitted_by: "COUNCIL".into(),
            logical_time: 1,
        };
        let n2 = CgirNode {
            id: NodeId::new("n2").unwrap(),
            severity: Severity::Warning,
            confidence: Confidence::new(0.7).unwrap(),
            emitted_by: "COUNCIL".into(),
            logical_time: 2,
        };
        g.add_node(n1);
        g.add_node(n2);
        let e = CgirEdge {
            id: EdgeId::new("e1").unwrap(),
            from: NodeId::new("n1").unwrap(),
            to: NodeId::new("n2").unwrap(),
            label: "transition".into(),
        };
        assert!(g.add_edge(e).is_ok());
        assert_eq!(g.node_count(), 2);
        assert_eq!(g.edge_count(), 1);
    }
    #[test] fn graph_rejects_edge_with_missing_node() {
        let mut g = CgirGraph::new();
        let e = CgirEdge {
            id: EdgeId::new("e1").unwrap(),
            from: NodeId::new("missing").unwrap(),
            to: NodeId::new("also_missing").unwrap(),
            label: "bad".into(),
        };
        assert!(g.add_edge(e).is_err());
    }
    #[test] fn has_severity_correct() {
        let mut g = CgirGraph::new();
        let n = CgirNode {
            id: NodeId::new("n1").unwrap(),
            severity: Severity::Critical,
            confidence: Confidence::one(),
            emitted_by: "COUNCIL".into(),
            logical_time: 0,
        };
        g.add_node(n);
        assert!(g.has_severity(Severity::Critical));
        assert!(!g.has_severity(Severity::Info));
    }
}
