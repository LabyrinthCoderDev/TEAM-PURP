//! # ledger-chronicle
//! Labyrinth-OS — WORM append-only ledger with hash chaining.
//!
//! Write Once Read Many. Nothing is ever deleted or modified.
//! Every entry is cryptographically linked to the previous one.
//! Tampering with any entry breaks all subsequent hashes.
//!
//! Invariant I8: All execution is logged.
//! Invariant I9: All execution is replayable.
//! Invariant I10: All failures archived, never deleted.

use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};

/// An entry type in the ledger.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EntryType {
    Execute,
    Block,
    Kill,
    Failure,
    Replay,
    Audit,
}

impl EntryType {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Execute => "EXECUTE",
            Self::Block   => "BLOCK",
            Self::Kill    => "KILL",
            Self::Failure => "FAILURE",
            Self::Replay  => "REPLAY",
            Self::Audit   => "AUDIT",
        }
    }
}

/// A single ledger entry.
#[derive(Debug, Clone)]
pub struct LedgerEntry {
    pub entry_id:    u64,
    pub entry_type:  EntryType,
    pub session_id:  String,
    pub payload:     String,
    pub prev_hash:   u64,
    pub entry_hash:  u64,
    pub logical_time: u64,
}

fn compute_hash(entry_id: u64, entry_type: &str, payload: &str,
                prev_hash: u64, logical_time: u64) -> u64 {
    let mut h = DefaultHasher::new();
    entry_id.hash(&mut h);
    entry_type.hash(&mut h);
    payload.hash(&mut h);
    prev_hash.hash(&mut h);
    logical_time.hash(&mut h);
    h.finish()
}

/// The WORM ledger. Append-only. No delete. No modify.
#[derive(Debug, Default)]
pub struct LedgerChronicle {
    entries:      Vec<LedgerEntry>,
    head_hash:    u64,
    logical_time: u64,
}

impl LedgerChronicle {
    pub fn new() -> Self { Self::default() }

    pub fn append(&mut self, session_id: &str, entry_type: EntryType,
                  payload: &str) -> u64
    {
        self.logical_time += 1;
        let entry_id = self.entries.len() as u64 + 1;
        let entry_hash = compute_hash(
            entry_id, entry_type.as_str(), payload,
            self.head_hash, self.logical_time,
        );
        let entry = LedgerEntry {
            entry_id,
            entry_type,
            session_id: session_id.to_string(),
            payload: payload.to_string(),
            prev_hash: self.head_hash,
            entry_hash,
            logical_time: self.logical_time,
        };
        self.head_hash = entry_hash;
        self.entries.push(entry);
        entry_id
    }

    pub fn verify(&self) -> (bool, Option<u64>) {
        let mut prev = 0u64;
        for entry in &self.entries {
            if entry.prev_hash != prev { return (false, Some(entry.entry_id)); }
            let expected = compute_hash(
                entry.entry_id, entry.entry_type.as_str(),
                &entry.payload, entry.prev_hash, entry.logical_time,
            );
            if entry.entry_hash != expected { return (false, Some(entry.entry_id)); }
            prev = entry.entry_hash;
        }
        (true, None)
    }

    pub fn len(&self) -> usize { self.entries.len() }
    pub fn is_empty(&self) -> bool { self.entries.is_empty() }
    pub fn head_hash(&self) -> u64 { self.head_hash }
    pub fn entries(&self) -> &[LedgerEntry] { &self.entries }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn empty_ledger_verifies() {
        let l = LedgerChronicle::new();
        assert!(l.verify().0);
        assert_eq!(l.len(), 0);
    }
    #[test] fn append_increments_len() {
        let mut l = LedgerChronicle::new();
        l.append("s1", EntryType::Execute, "payload");
        assert_eq!(l.len(), 1);
    }
    #[test] fn chain_verifies_after_appends() {
        let mut l = LedgerChronicle::new();
        for i in 0..5 { l.append("s1", EntryType::Execute, &format!("p{i}")); }
        assert!(l.verify().0);
    }
    #[test] fn tamper_breaks_chain() {
        let mut l = LedgerChronicle::new();
        l.append("s1", EntryType::Execute, "original");
        l.append("s1", EntryType::Execute, "second");
        l.entries[0].entry_hash = 0xdeadbeef;
        let (valid, broken) = l.verify();
        assert!(!valid);
        assert!(broken.is_some());
    }
    #[test] fn no_delete_method_exists() {
        // Compile-time proof: LedgerChronicle has no delete method
        // If this test compiles, delete doesn't exist in the public API
        let l = LedgerChronicle::new();
        let _ = l.len();
        true;
    }
    #[test] fn head_hash_changes_on_append() {
        let mut l = LedgerChronicle::new();
        let h0 = l.head_hash();
        l.append("s1", EntryType::Execute, "p1");
        assert_ne!(l.head_hash(), h0);
    }
    #[test] fn failure_entries_accepted() {
        let mut l = LedgerChronicle::new();
        l.append("s1", EntryType::Failure, "pipeline violation");
        assert_eq!(l.len(), 1);
        assert_eq!(l.entries()[0].entry_type, EntryType::Failure);
    }
    #[test] fn logical_time_monotonic() {
        let mut l = LedgerChronicle::new();
        l.append("s1", EntryType::Execute, "p1");
        l.append("s1", EntryType::Execute, "p2");
        assert!(l.entries()[1].logical_time > l.entries()[0].logical_time);
    }
}
