# ledger-chronicle

Append-only immutable truth layer.

## Responsibility

Implements the immutable, append-only WORM ledger that records all executions.
The ledger is canonical history; no entry may ever be modified or deleted.

## Ledger Entry

Each entry records:
- `state_before` — StateNode hash before execution
- `proposal` — CGIR edge hash
- `signals` — bound SignalNodes
- `gate_decision` — Gate output
- `contracts` — Contract hashes
- `timing` — timestamps and latency
- `state_after` — StateNode hash after execution
- `hash` — entry content hash (chained)
- `receipt` — Hardware RoT signature

## TODO

- [ ] Implement LedgerEntry
- [ ] Implement append-only store
- [ ] Implement hash chaining
- [ ] Implement entry verification
- [ ] Stub Hardware RoT receipt signing

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
