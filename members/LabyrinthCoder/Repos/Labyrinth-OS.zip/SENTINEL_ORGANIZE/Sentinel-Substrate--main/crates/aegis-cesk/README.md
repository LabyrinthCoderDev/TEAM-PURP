# aegis-cesk

The AEGIS execution kernel — the only state mutator in the system.

## Responsibility

Implements the CESK machine that executes Gate-approved CGIR edges.
This is the ONLY component that may mutate CESK state (Invariant I1).

## Execution Phases

```
LOAD → PROPOSE → CHECK → COMMIT → PROVE
```

| Phase | Description |
|-------|-------------|
| LOAD | Load current CESK state from ledger |
| PROPOSE | Accept Gate-approved CGIR edge |
| CHECK | Verify all pre-conditions |
| COMMIT | Mutate state (only here) and write to ledger |
| PROVE | Generate cryptographic proof of execution |

## TODO

- [ ] Implement CESKState
- [ ] Implement all execution phases
- [ ] Implement AegisError enum
- [ ] Verify state mutation occurs ONLY in COMMIT phase
- [ ] Integration tests with Gate and Ledger

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
