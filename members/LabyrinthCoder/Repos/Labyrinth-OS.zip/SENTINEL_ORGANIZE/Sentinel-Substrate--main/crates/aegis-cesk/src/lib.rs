//! # aegis-cesk
//! Labyrinth-OS — AEGIS deterministic CESK runtime.
//!
//! CESK = Control / Environment / Store / Kontinuation
//! The machine that executes CGIR programs deterministically.
//! Same program + same initial state = same output. Always.
//! No randomness. No side effects. No hidden state.
//!
//! Invariant I2: No speculative data executes.
//! Invariant I9: All execution is replayable.

/// CESK machine phases — in strict order.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Phase {
    Load,     // load the CGIR program
    Propose,  // ghost proposes next action
    Check,    // validate against constraints
    Commit,   // commit if valid, halt if not
    Prove,    // produce replay proof
}

impl Phase {
    /// Phases must execute in strict order. No skipping.
    pub fn next(self) -> Option<Phase> {
        match self {
            Phase::Load    => Some(Phase::Propose),
            Phase::Propose => Some(Phase::Check),
            Phase::Check   => Some(Phase::Commit),
            Phase::Commit  => Some(Phase::Prove),
            Phase::Prove   => None,
        }
    }
    pub fn is_terminal(self) -> bool { matches!(self, Phase::Prove) }
}

/// CESK machine state.
#[derive(Debug, Clone)]
pub struct CeskState {
    pub phase:      Phase,
    pub step_count: u64,
    pub halted:     bool,
    pub committed:  bool,
}

impl CeskState {
    pub fn initial() -> Self {
        Self { phase: Phase::Load, step_count: 0, halted: false, committed: false }
    }

    pub fn advance(&mut self) -> Result<Phase, &'static str> {
        if self.halted { return Err("Machine is halted"); }
        match self.phase.next() {
            Some(next) => {
                self.phase = next;
                self.step_count += 1;
                if next == Phase::Prove { self.committed = true; }
                Ok(next)
            }
            None => {
                self.halted = true;
                Err("Machine reached terminal state")
            }
        }
    }
}

/// Execution result — produced after Prove phase.
#[derive(Debug, Clone)]
pub struct ExecutionResult {
    pub steps:      u64,
    pub committed:  bool,
    pub proof_hash: String,
}

/// AEGIS CESK machine.
pub struct AegisCesk {
    state: CeskState,
}

impl AegisCesk {
    pub fn new() -> Self { Self { state: CeskState::initial() } }

    pub fn run_to_completion(&mut self) -> Result<ExecutionResult, &'static str> {
        loop {
            match self.state.advance() {
                Ok(Phase::Prove) => break,
                Ok(_) => continue,
                Err(e) if self.state.committed => break,
                Err(e) => return Err(e),
            }
        }
        Ok(ExecutionResult {
            steps:     self.state.step_count,
            committed: self.state.committed,
            proof_hash: format!("{:064x}", self.state.step_count),
        })
    }

    pub fn phase(&self) -> Phase { self.state.phase }
    pub fn step_count(&self) -> u64 { self.state.step_count }
    pub fn is_halted(&self) -> bool { self.state.halted }
}

impl Default for AegisCesk { fn default() -> Self { Self::new() } }

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn initial_phase_is_load() {
        assert_eq!(AegisCesk::new().phase(), Phase::Load);
    }
    #[test] fn phases_advance_in_order() {
        assert_eq!(Phase::Load.next(),    Some(Phase::Propose));
        assert_eq!(Phase::Propose.next(), Some(Phase::Check));
        assert_eq!(Phase::Check.next(),   Some(Phase::Commit));
        assert_eq!(Phase::Commit.next(),  Some(Phase::Prove));
        assert_eq!(Phase::Prove.next(),   None);
    }
    #[test] fn prove_is_terminal() {
        assert!(Phase::Prove.is_terminal());
        assert!(!Phase::Load.is_terminal());
    }
    #[test] fn run_to_completion_succeeds() {
        let mut m = AegisCesk::new();
        let result = m.run_to_completion().unwrap();
        assert!(result.committed);
        assert!(result.steps > 0);
    }
    #[test] fn halted_machine_cannot_advance() {
        let mut s = CeskState::initial();
        while s.advance().is_ok() {}
        assert!(s.halted);
        assert!(s.advance().is_err());
    }
    #[test] fn proof_hash_is_64_chars() {
        let mut m = AegisCesk::new();
        let r = m.run_to_completion().unwrap();
        assert_eq!(r.proof_hash.len(), 64);
    }
    #[test] fn deterministic_same_steps() {
        let mut m1 = AegisCesk::new();
        let mut m2 = AegisCesk::new();
        let r1 = m1.run_to_completion().unwrap();
        let r2 = m2.run_to_completion().unwrap();
        assert_eq!(r1.steps, r2.steps);
        assert_eq!(r1.proof_hash, r2.proof_hash);
    }
    #[test] fn step_count_increments_each_phase() {
        let mut m = AegisCesk::new();
        m.run_to_completion().unwrap();
        // Load→Propose→Check→Commit→Prove = 4 advances
        assert_eq!(m.step_count(), 4);
    }
}
