//! # vector-sensors
//! Labyrinth-OS — Sensor observation layer.
//!
//! Collects raw measurements from the LLM output (logprobs, token stats)
//! and packages them into structured SensorReadings for the signal algebra.
//!
//! This is the interface between raw LLM output and the epistemic pipeline.
//! It does not interpret. It measures and packages.

/// Raw logprob reading from a single token.
#[derive(Debug, Clone)]
pub struct LogprobReading {
    pub token:   String,
    pub logprob: f64,  // log probability — always <= 0.0
}

impl LogprobReading {
    pub fn new(token: impl Into<String>, logprob: f64) -> Result<Self, &'static str> {
        if logprob > 0.0 { return Err("logprob must be <= 0.0"); }
        Ok(Self { token: token.into(), logprob })
    }
    /// Convert logprob to probability (0.0-1.0)
    pub fn probability(&self) -> f64 { self.logprob.exp().clamp(0.0, 1.0) }
}

/// Aggregated sensor readings from one inference call.
#[derive(Debug, Clone)]
pub struct SensorBundle {
    pub session_id:    String,
    pub readings:      Vec<LogprobReading>,
    pub token_count:   usize,
    pub model_id:      String,
    pub available:     bool,  // false if logprobs not available from provider
}

impl SensorBundle {
    pub fn new(session_id: &str, model_id: &str, readings: Vec<LogprobReading>) -> Self {
        let available = !readings.is_empty();
        let token_count = readings.len();
        Self { session_id: session_id.to_string(), model_id: model_id.to_string(),
               readings, token_count, available }
    }

    /// Mean log probability (proxy for confidence)
    pub fn mean_logprob(&self) -> Option<f64> {
        if self.readings.is_empty() { return None; }
        let sum: f64 = self.readings.iter().map(|r| r.logprob).sum();
        Some(sum / self.readings.len() as f64)
    }

    /// Convert to confidence score (0.0-1.0)
    pub fn confidence(&self) -> f64 {
        match self.mean_logprob() {
            None => 0.5, // no logprobs → uncertain
            Some(mean_lp) => {
                // mean_lp is <= 0. Map [-inf, 0] → [0, 1]
                // We use a simple clamp: very negative = low conf, near 0 = high conf
                let normalized = (mean_lp / -10.0).clamp(0.0, 1.0);
                1.0 - normalized
            }
        }
    }

    /// Variance of logprobs (proxy for drift/uncertainty)
    pub fn logprob_variance(&self) -> f64 {
        if self.readings.len() < 2 { return 0.0; }
        let mean = self.mean_logprob().unwrap_or(0.0);
        let variance = self.readings.iter()
            .map(|r| (r.logprob - mean).powi(2))
            .sum::<f64>() / self.readings.len() as f64;
        variance
    }

    /// Unavailable bundle — logprobs not provided by this model/provider.
    pub fn unavailable(session_id: &str, model_id: &str) -> Self {
        Self::new(session_id, model_id, vec![])
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn logprob_must_be_nonpositive() {
        assert!(LogprobReading::new("tok", 0.1).is_err());
        assert!(LogprobReading::new("tok", 0.0).is_ok());
        assert!(LogprobReading::new("tok", -2.3).is_ok());
    }
    #[test] fn probability_from_logprob() {
        let r = LogprobReading::new("tok", 0.0).unwrap();
        assert!((r.probability() - 1.0).abs() < 1e-9); // e^0 = 1.0
        let r2 = LogprobReading::new("tok", -100.0).unwrap();
        assert!(r2.probability() < 0.001);
    }
    #[test] fn empty_bundle_unavailable() {
        let b = SensorBundle::unavailable("s1", "model");
        assert!(!b.available);
        assert_eq!(b.token_count, 0);
        assert!(b.mean_logprob().is_none());
    }
    #[test] fn mean_logprob_correct() {
        let readings = vec![
            LogprobReading::new("a", -1.0).unwrap(),
            LogprobReading::new("b", -3.0).unwrap(),
        ];
        let b = SensorBundle::new("s1", "model", readings);
        assert!((b.mean_logprob().unwrap() - (-2.0)).abs() < 1e-9);
    }
    #[test] fn confidence_in_range() {
        let readings = vec![LogprobReading::new("tok", -1.5).unwrap()];
        let b = SensorBundle::new("s1", "model", readings);
        assert!(b.confidence() >= 0.0 && b.confidence() <= 1.0);
    }
    #[test] fn unavailable_bundle_returns_uncertain_confidence() {
        let b = SensorBundle::unavailable("s1", "model");
        assert!((b.confidence() - 0.5).abs() < 1e-9);
    }
    #[test] fn variance_zero_for_single_reading() {
        let readings = vec![LogprobReading::new("tok", -2.0).unwrap()];
        let b = SensorBundle::new("s1", "model", readings);
        assert!(b.logprob_variance() < 1e-9);
    }
    #[test] fn high_logprob_gives_high_confidence() {
        let readings = vec![LogprobReading::new("tok", -0.01).unwrap()];
        let b = SensorBundle::new("s1", "model", readings);
        assert!(b.confidence() > 0.9);
    }
    #[test] fn session_id_preserved() {
        let b = SensorBundle::unavailable("my-session-001", "model");
        assert_eq!(b.session_id, "my-session-001");
    }
    #[test] fn token_count_matches_readings() {
        let readings: Vec<_> = (0..7)
            .map(|i| LogprobReading::new(format!("t{i}"), -1.0).unwrap())
            .collect();
        let b = SensorBundle::new("s1", "model", readings);
        assert_eq!(b.token_count, 7);
    }
}
