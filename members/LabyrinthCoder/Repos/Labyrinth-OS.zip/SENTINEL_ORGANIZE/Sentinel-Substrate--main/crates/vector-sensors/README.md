# vector-sensors

VECTOR Sensor Fabric — read-only sensing only.

## Responsibility

Implements the VECTOR sensing layer (L2). VECTOR observes the system and
produces raw observations. It has NO write access to any state (Invariant I3).

## Sensed Metrics

| Metric | Description |
|--------|-------------|
| Drift | Behavioral drift from expected patterns |
| Entropy | System entropy level |
| Contradictions | Detected contradictions in proposals |
| Uncertainty | Uncertainty level of proposals |
| χ stability | Chi stability metric |
| Latency | Observed execution latency |
| Bias pressure | Detected bias in intelligence outputs |
| Failure patterns | Observed failure mode patterns |

## Non-Negotiable

This crate MUST NOT have any write methods. VECTOR is read-only.

## TODO

- [ ] Implement VectorObservation (read-only)
- [ ] Implement all sensing metrics
- [ ] Verify: no write methods anywhere in crate

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
