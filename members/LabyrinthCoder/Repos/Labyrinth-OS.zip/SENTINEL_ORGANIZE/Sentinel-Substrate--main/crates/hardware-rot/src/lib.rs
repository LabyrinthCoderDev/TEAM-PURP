//! # hardware-rot
//! Labyrinth-OS — Hardware Root of Trust interface.
//!
//! Models the Root of Trust attestation layer.
//! In prototype: simulation with deterministic key derivation.
//! In production: ATECC608B secure element (A003).
//!
//! The Root of Trust provides:
//!   1. Hardware-bound identity (cannot be cloned in software)
//!   2. Signed attestations that execution happened on verified hardware
//!   3. Session key generation tied to physical device

use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};

/// Root of Trust mode.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RotMode {
    /// Software simulation — deterministic, not hardware-bound
    Simulation,
    /// Physical ATECC608B (A003 — hardware required)
    Silicon,
}

/// A Root of Trust attestation — proof that a session ran on verified hardware.
#[derive(Debug, Clone)]
pub struct Attestation {
    pub session_id:    String,
    pub device_serial: String,
    pub signature:     String,
    pub mode:          RotMode,
}

impl Attestation {
    pub fn is_hardware_bound(&self) -> bool {
        self.mode == RotMode::Silicon
    }
}

/// Root of Trust interface.
pub struct RootOfTrust {
    pub mode:   RotMode,
    serial:     String,
}

impl RootOfTrust {
    pub fn simulation() -> Self {
        Self { mode: RotMode::Simulation, serial: "SIM-00000000".to_string() }
    }

    /// Produce a deterministic simulation attestation.
    /// Not hardware-bound — for prototype use only.
    pub fn attest(&self, session_id: &str) -> Attestation {
        let mut h = DefaultHasher::new();
        session_id.hash(&mut h);
        self.serial.hash(&mut h);
        let sig = format!("{:016x}", h.finish());
        Attestation {
            session_id: session_id.to_string(),
            device_serial: self.serial.clone(),
            signature: sig,
            mode: self.mode,
        }
    }

    /// Verify a simulation attestation — checks signature matches expected.
    pub fn verify(&self, attestation: &Attestation) -> bool {
        let expected = self.attest(&attestation.session_id);
        expected.signature == attestation.signature
            && expected.device_serial == attestation.device_serial
    }

    pub fn serial(&self) -> &str { &self.serial }
    pub fn is_simulation(&self) -> bool { self.mode == RotMode::Simulation }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn simulation_available() {
        let rot = RootOfTrust::simulation();
        assert!(rot.is_simulation());
    }
    #[test] fn attest_produces_signature() {
        let rot = RootOfTrust::simulation();
        let att = rot.attest("session-001");
        assert!(!att.signature.is_empty());
        assert_eq!(att.session_id, "session-001");
    }
    #[test] fn verify_valid_attestation() {
        let rot = RootOfTrust::simulation();
        let att = rot.attest("session-001");
        assert!(rot.verify(&att));
    }
    #[test] fn verify_rejects_tampered_session() {
        let rot = RootOfTrust::simulation();
        let mut att = rot.attest("session-001");
        att.session_id = "session-TAMPERED".to_string();
        assert!(!rot.verify(&att));
    }
    #[test] fn simulation_not_hardware_bound() {
        let rot = RootOfTrust::simulation();
        let att = rot.attest("s1");
        assert!(!att.is_hardware_bound());
    }
    #[test] fn deterministic_same_session_same_sig() {
        let rot = RootOfTrust::simulation();
        let a1 = rot.attest("session-xyz");
        let a2 = rot.attest("session-xyz");
        assert_eq!(a1.signature, a2.signature);
    }
    #[test] fn different_sessions_different_sigs() {
        let rot = RootOfTrust::simulation();
        let a1 = rot.attest("session-001");
        let a2 = rot.attest("session-002");
        assert_ne!(a1.signature, a2.signature);
    }
    #[test] fn silicon_mode_requires_hardware() {
        assert_eq!(RotMode::Silicon, RotMode::Silicon);
        assert_ne!(RotMode::Simulation, RotMode::Silicon);
    }
}
