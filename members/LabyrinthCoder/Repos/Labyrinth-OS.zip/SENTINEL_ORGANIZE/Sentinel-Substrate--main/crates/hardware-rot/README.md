# hardware-rot

Hardware Root of Trust (L15).

## Responsibility

Provides signing, TEE attestation, FPGA latch control, timestamp attestation,
and fail-closed kill-switch stubs.

## TODO

- [ ] RoT signing stubs
- [ ] TEE attestation stubs
- [ ] FPGA latch stubs
- [ ] Timestamp attestation stubs
- [ ] Fail-closed kill-switch

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
