//! # replay-gnosis
//! Labyrinth-OS — Exact chain replay and audit.
//!
//! Mirrors Python: replay_validator.py
//! Hard Invariant I9: All execution must be replayable.
//! Replay mode: EXACT (from exported chain entries, not reconstruction).

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ReplayStatus { Clean, Tampered, Incomplete }

#[derive(Debug, Clone)]
pub struct ReplayEntry {
    pub index:      u64,
    pub data:       String,
    pub entry_hash: String,
    pub prev_hash:  String,
}

#[derive(Debug)]
pub struct ReplayResult {
    pub status:        ReplayStatus,
    pub entries_checked: usize,
    pub first_violation: Option<usize>,
}

/// Exact chain replay validator.
pub struct ReplayGnosis;

impl ReplayGnosis {
    /// Replay a chain of entries. Returns ReplayResult.
    /// EXACT mode: validates hash linkage across all entries.
    pub fn replay_exact(&self, entries: &[ReplayEntry]) -> ReplayResult {
        if entries.is_empty() {
            return ReplayResult {
                status: ReplayStatus::Incomplete,
                entries_checked: 0,
                first_violation: None,
            };
        }
        for i in 1..entries.len() {
            if entries[i].prev_hash != entries[i-1].entry_hash {
                return ReplayResult {
                    status: ReplayStatus::Tampered,
                    entries_checked: i,
                    first_violation: Some(i),
                };
            }
        }
        ReplayResult {
            status: ReplayStatus::Clean,
            entries_checked: entries.len(),
            first_violation: None,
        }
    }
}

/// Why a replay failed.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ReplayFailure {
    HashMismatch { entry: u64, expected: u64, got: u64 },
    OrderingViolation { entry: u64 },
    EmptyReplay,
}

/// Verify a sequence of (entry_id, hash, prev_hash) tuples.
pub fn verify_chain(entries: &[(u64, u64, u64)]) -> Result<(), ReplayFailure> {
    if entries.is_empty() { return Err(ReplayFailure::EmptyReplay); }
    let mut prev = 0u64;
    for &(id, hash, entry_prev) in entries {
        if entry_prev != prev {
            return Err(ReplayFailure::HashMismatch {
                entry: id, expected: prev, got: entry_prev,
            });
        }
        if id == 0 {
            return Err(ReplayFailure::OrderingViolation { entry: id });
        }
        prev = hash;
    }
    Ok(())
}

#[test] fn valid_chain_passes() {
    // (id, hash, prev_hash)
    assert!(verify_chain(&[(1, 100, 0), (2, 200, 100), (3, 300, 200)]).is_ok());
}
#[test] fn broken_chain_detected() {
    assert!(verify_chain(&[(1, 100, 0), (2, 200, 999)]).is_err());
}
#[test] fn empty_replay_fails() {
    assert_eq!(verify_chain(&[]), Err(ReplayFailure::EmptyReplay));
}
#[test] fn zero_id_ordering_violation() {
    assert!(matches!(verify_chain(&[(0, 100, 0)]),
        Err(ReplayFailure::OrderingViolation{..})));
}

#[cfg(test)]
mod tests {
    use super::*;
    fn make_chain(n: usize) -> Vec<ReplayEntry> {
        let mut entries = Vec::new();
        let mut prev = "0000000000000000".to_string();
        for i in 0..n {
            let hash = format!("{:016x}", i + 1);
            entries.push(ReplayEntry {
                index: i as u64,
                data: format!("entry_{i}"),
                entry_hash: hash.clone(),
                prev_hash: prev.clone(),
            });
            prev = hash;
        }
        entries
    }
    #[test] fn clean_chain_is_clean() {
        let chain = make_chain(5);
        let r = ReplayGnosis.replay_exact(&chain);
        assert_eq!(r.status, ReplayStatus::Clean);
        assert_eq!(r.entries_checked, 5);
    }
    #[test] fn tampered_chain_detected() {
        let mut chain = make_chain(5);
        chain[2].entry_hash = "tampered000".to_string();
        let r = ReplayGnosis.replay_exact(&chain);
        assert_eq!(r.status, ReplayStatus::Tampered);
        assert_eq!(r.first_violation, Some(3));
    }
    #[test] fn empty_chain_incomplete() {
        let r = ReplayGnosis.replay_exact(&[]);
        assert_eq!(r.status, ReplayStatus::Incomplete);
    }
    #[test] fn single_entry_clean() {
        let chain = make_chain(1);
        let r = ReplayGnosis.replay_exact(&chain);
        assert_eq!(r.status, ReplayStatus::Clean);
    }
}
