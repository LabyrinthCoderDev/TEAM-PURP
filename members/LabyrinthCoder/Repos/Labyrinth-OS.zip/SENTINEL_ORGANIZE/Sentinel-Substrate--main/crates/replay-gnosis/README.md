# replay-gnosis

Replay validator and root-cause analysis.

## Responsibility

Replays committed executions from the ledger and validates that all
invariants hold. Provides causal tracing and root-cause analysis.

## Capabilities

| Capability | Description |
|-----------|-------------|
| Replay | Reconstruct all committed executions from ledger |
| Causal tracing | Trace causal chain of any event |
| Root-cause analysis | Find root cause of any failure |
| Invariant verification | Verify all invariants over replay trace |
| Divergence detection | Detect when replay diverges from expected |

## TODO

- [ ] Implement replay engine
- [ ] Implement causal trace builder
- [ ] Implement RCA engine
- [ ] Implement divergence detection

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
