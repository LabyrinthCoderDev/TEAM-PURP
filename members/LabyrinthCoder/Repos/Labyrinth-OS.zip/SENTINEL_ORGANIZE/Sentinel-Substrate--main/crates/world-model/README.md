# world-model

Untrusted simulation scaffold (L6).

## Responsibility

Produces predicted outcomes and uncertainty estimates. All outputs are
PROPOSALS ONLY — invalid until compiled into CGIR.

## Uncertainty Routing

| Uncertainty | Action |
|-------------|--------|
| Low | Full simulation |
| Medium | Constrained simulation |
| High | π₀ fallback |

## TODO

- [ ] Uncertainty routing
- [ ] Simulation scaffold
- [ ] Constrained simulation
- [ ] π₀ fallback

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
