//! # world-model
//! Labyrinth-OS — World model state for Lane 1.
//!
//! Lane 1 maintains a world model — beliefs about the environment.
//! These beliefs are SPECULATIVE until promoted through the pipeline.
//! The world model never directly influences Lane 2 execution.

/// A belief entry in the world model.
#[derive(Debug, Clone)]
pub struct Belief {
    pub belief_id:  String,
    pub claim:      String,
    pub confidence: f64,
    pub source:     String,
    pub verified:   bool,
}

impl Belief {
    pub fn new(id: &str, claim: &str, confidence: f64, source: &str) -> Self {
        Self {
            belief_id:  id.to_string(),
            claim:      claim.to_string(),
            confidence: confidence.clamp(0.0, 1.0),
            source:     source.to_string(),
            verified:   false,
        }
    }

    /// Beliefs are never verified by default — they must pass the pipeline.
    pub fn is_speculative(&self) -> bool { !self.verified }
}

/// World model — collection of beliefs about the environment.
/// All beliefs are speculative until explicitly verified through promotion.
#[derive(Debug, Default)]
pub struct WorldModel {
    beliefs: Vec<Belief>,
}

impl WorldModel {
    pub fn new() -> Self { Self::default() }

    pub fn assert_belief(&mut self, belief: Belief) {
        self.beliefs.push(belief);
    }

    pub fn retract(&mut self, belief_id: &str) {
        self.beliefs.retain(|b| b.belief_id != belief_id);
    }

    pub fn beliefs(&self) -> &[Belief] { &self.beliefs }

    pub fn speculative_count(&self) -> usize {
        self.beliefs.iter().filter(|b| b.is_speculative()).count()
    }

    pub fn verified_count(&self) -> usize {
        self.beliefs.iter().filter(|b| b.verified).count()
    }

    /// High-confidence speculative beliefs are candidates for promotion.
    pub fn promotion_candidates(&self, threshold: f64) -> Vec<&Belief> {
        self.beliefs.iter()
            .filter(|b| b.is_speculative() && b.confidence >= threshold)
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn belief_constructs_speculative() {
        let b = Belief::new("b1", "sky is blue", 0.9, "observation");
        assert!(b.is_speculative());
    }
    #[test] fn world_model_stores_beliefs() {
        let mut wm = WorldModel::new();
        wm.assert_belief(Belief::new("b1", "claim", 0.8, "test"));
        assert_eq!(wm.beliefs().len(), 1);
    }
    #[test] fn retract_removes_belief() {
        let mut wm = WorldModel::new();
        wm.assert_belief(Belief::new("b1", "claim", 0.8, "test"));
        wm.retract("b1");
        assert_eq!(wm.beliefs().len(), 0);
    }
    #[test] fn speculative_count_correct() {
        let mut wm = WorldModel::new();
        wm.assert_belief(Belief::new("b1", "c1", 0.9, "t"));
        wm.assert_belief(Belief::new("b2", "c2", 0.7, "t"));
        assert_eq!(wm.speculative_count(), 2);
        assert_eq!(wm.verified_count(), 0);
    }
    #[test] fn promotion_candidates_filtered_by_threshold() {
        let mut wm = WorldModel::new();
        wm.assert_belief(Belief::new("b1", "c1", 0.9, "t"));
        wm.assert_belief(Belief::new("b2", "c2", 0.3, "t"));
        let candidates = wm.promotion_candidates(0.7);
        assert_eq!(candidates.len(), 1);
        assert_eq!(candidates[0].belief_id, "b1");
    }
    #[test] fn confidence_clamped_at_construction() {
        let b = Belief::new("b1", "c", 1.5, "t");
        assert!(b.confidence <= 1.0);
    }
}
