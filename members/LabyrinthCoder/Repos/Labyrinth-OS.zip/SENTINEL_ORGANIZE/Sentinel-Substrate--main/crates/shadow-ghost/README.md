# shadow-ghost

Parallel shadow branch execution and comparison.

## Responsibility

Runs N shadow branches in parallel for every real execution and compares
their results. Shadow results feed into offline evolution only.

## Non-Negotiable

Shadow branches NEVER modify live state. Live self-modification is NEVER allowed.

## Comparison Metrics

- Coherence
- Causal lift
- Risk
- Latency
- Cost
- Contract compliance
- Failure rate

## Promotion Path

Shadow → Replay → Value Contract → Gate Promotion

## TODO

- [ ] Implement ShadowBranch
- [ ] Implement shadow execution (read-only)
- [ ] Implement comparison metrics
- [ ] Verify: no live state mutation

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
