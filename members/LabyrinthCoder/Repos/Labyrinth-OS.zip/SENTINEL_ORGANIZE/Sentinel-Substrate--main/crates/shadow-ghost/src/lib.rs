//! # shadow-ghost
//! Labyrinth-OS — LLM boundary adapter.
//!
//! The Ghost is the LLM. It lives in Lane 1 only.
//! It proposes. It never executes. It never touches Lane 2 directly.
//!
//! Every proposal from the Ghost is:
//!   1. Labeled UNVERIFIED
//!   2. Archived before any other use
//!   3. Required to pass PROMOTION + REALITY_GATE before CGIR
//!
//! The Ghost has no direct access to the ledger, gate, or CESK machine.
//! That separation is structural, not advisory.

/// A proposal from the Ghost (LLM output).
/// Always starts UNVERIFIED. Cannot self-promote.
#[derive(Debug, Clone)]
pub struct GhostProposal {
    pub id:         String,
    pub content:    String,
    pub model_id:   String,
    pub confidence: f64,
    pub status:     ProposalStatus,
}

/// Lifecycle of a Ghost proposal.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProposalStatus {
    Unverified,  // just received from LLM — default
    Archived,    // written to archive — mandatory first step
    Promoted,    // passed promotion — still needs reality gate
    Blocked,     // rejected at any stage
    // Note: "Executed" is NOT a proposal status.
    // Proposals don't execute. CGIR nodes execute.
}

impl ProposalStatus {
    pub fn can_promote(self) -> bool {
        matches!(self, ProposalStatus::Archived)
    }
    pub fn is_blocked(self) -> bool {
        matches!(self, ProposalStatus::Blocked)
    }
    pub fn label(self) -> &'static str {
        match self {
            Self::Unverified => "UNVERIFIED",
            Self::Archived   => "ARCHIVED",
            Self::Promoted   => "PROMOTED",
            Self::Blocked    => "BLOCKED",
        }
    }
}

impl GhostProposal {
    pub fn new(id: &str, content: &str, model_id: &str, confidence: f64) -> Self {
        Self {
            id: id.to_string(),
            content: content.to_string(),
            model_id: model_id.to_string(),
            confidence: confidence.clamp(0.0, 1.0),
            status: ProposalStatus::Unverified,
        }
    }

    /// Archive the proposal. Must happen before promotion.
    pub fn archive(&mut self) -> Result<(), &'static str> {
        if self.status != ProposalStatus::Unverified {
            return Err("Can only archive UNVERIFIED proposals");
        }
        self.status = ProposalStatus::Archived;
        Ok(())
    }

    /// Promote the proposal. Requires archived status.
    pub fn promote(&mut self) -> Result<(), &'static str> {
        if !self.status.can_promote() {
            return Err("Can only promote ARCHIVED proposals");
        }
        self.status = ProposalStatus::Promoted;
        Ok(())
    }

    /// Block the proposal at any stage.
    pub fn block(&mut self) {
        self.status = ProposalStatus::Blocked;
    }

    /// Lane 2 boundary check. Ghost proposals cannot directly enter CGIR.
    /// They must be transformed by the promotion + reality gate process.
    pub fn can_enter_cgir(&self) -> bool {
        // Proposals NEVER directly enter CGIR.
        // Only CGIR nodes (created from promoted proposals) enter CGIR.
        // This method exists to make that boundary explicit.
        false
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn new_proposal_is_unverified() {
        let p = GhostProposal::new("p1", "do something", "claude", 0.85);
        assert_eq!(p.status, ProposalStatus::Unverified);
    }
    #[test] fn archive_before_promote_required() {
        let mut p = GhostProposal::new("p1", "content", "claude", 0.85);
        assert!(p.promote().is_err()); // can't promote unverified
        p.archive().unwrap();
        assert!(p.promote().is_ok()); // can promote archived
    }
    #[test] fn proposals_never_enter_cgir() {
        let p = GhostProposal::new("p1", "content", "claude", 0.85);
        assert!(!p.can_enter_cgir());
        let mut p2 = p.clone();
        p2.archive().unwrap();
        p2.promote().unwrap();
        assert!(!p2.can_enter_cgir()); // even promoted proposals don't directly enter
    }
    #[test] fn block_at_any_stage() {
        let mut p = GhostProposal::new("p1", "content", "claude", 0.85);
        p.block();
        assert!(p.status.is_blocked());
    }
    #[test] fn confidence_clamped() {
        let p = GhostProposal::new("p1", "content", "claude", 1.5);
        assert!(p.confidence <= 1.0);
        let p2 = GhostProposal::new("p2", "content", "claude", -0.5);
        assert!(p2.confidence >= 0.0);
    }
    #[test] fn cannot_archive_twice() {
        let mut p = GhostProposal::new("p1", "content", "claude", 0.85);
        p.archive().unwrap();
        assert!(p.archive().is_err());
    }
    #[test] fn status_labels_correct() {
        assert_eq!(ProposalStatus::Unverified.label(), "UNVERIFIED");
        assert_eq!(ProposalStatus::Blocked.label(), "BLOCKED");
    }
    #[test] fn promoted_cannot_re_archive() {
        let mut p = GhostProposal::new("p1", "content", "claude", 0.85);
        p.archive().unwrap();
        p.promote().unwrap();
        assert!(p.archive().is_err());
    }
    #[test] fn blocked_proposal_cannot_promote() {
        let mut p = GhostProposal::new("p1", "content", "claude", 0.85);
        p.archive().unwrap();
        p.block();
        assert!(p.promote().is_err());
    }
    #[test] fn model_id_preserved() {
        let p = GhostProposal::new("p1", "content", "claude-sonnet-4-20250514", 0.85);
        assert_eq!(p.model_id, "claude-sonnet-4-20250514");
    }
}
