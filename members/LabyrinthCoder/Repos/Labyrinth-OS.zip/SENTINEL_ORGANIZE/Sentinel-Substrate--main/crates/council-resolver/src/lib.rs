//! # council-resolver
//! Labyrinth-OS — Merge multiple watcher outputs into a single Council decision.
//!
//! The Council is the LABELING AUTHORITY only.
//! It merges watcher findings and produces a single label + confidence.
//! It CANNOT: promote, modify PipelineTrace, bypass stages, influence execution.
//!
//! Merge rules:
//!   - Severity: take the worst (highest)
//!   - Confidence: take the minimum (most conservative)
//!   - If any watcher reports CRITICAL: Council output is CRITICAL

/// Severity levels — in ascending order of severity.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Severity { Info, Warning, Error, Critical }

impl Severity {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Info     => "INFO",
            Self::Warning  => "WARNING",
            Self::Error    => "ERROR",
            Self::Critical => "CRITICAL",
        }
    }
}

/// Input from a single watcher.
#[derive(Debug, Clone)]
pub struct WatcherInput {
    pub watcher_id:  String,
    pub severity:    Severity,
    pub confidence:  f64,
    pub label:       String,
}

/// Council decision — merged from all watchers.
#[derive(Debug, Clone)]
pub struct CouncilDecision {
    pub severity:    Severity,
    pub confidence:  f64,
    pub label:       String,
    pub watcher_count: usize,
    pub dissent:     bool,  // true if watchers disagreed on severity
}

impl CouncilDecision {
    pub fn blocks_promotion(&self) -> bool {
        matches!(self.severity, Severity::Critical | Severity::Error)
    }
}

/// Merge watcher inputs into a single Council decision.
pub fn resolve(inputs: &[WatcherInput]) -> Result<CouncilDecision, &'static str> {
    if inputs.is_empty() {
        return Err("Council requires at least one watcher input");
    }

    let severity = inputs.iter().map(|i| i.severity).max().unwrap();
    let confidence = inputs.iter()
        .map(|i| i.confidence)
        .fold(f64::INFINITY, f64::min)
        .clamp(0.0, 1.0);

    // Check for dissent — did all watchers agree?
    let all_same = inputs.iter().all(|i| i.severity == inputs[0].severity);
    let dissent = !all_same;

    // Label from the most severe watcher
    let label = inputs.iter()
        .max_by_key(|i| i.severity)
        .map(|i| i.label.clone())
        .unwrap_or_else(|| "UNKNOWN".to_string());

    Ok(CouncilDecision {
        severity, confidence, label,
        watcher_count: inputs.len(),
        dissent,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn input(id: &str, sev: Severity, conf: f64) -> WatcherInput {
        WatcherInput { watcher_id: id.to_string(), severity: sev,
                       confidence: conf, label: sev.as_str().to_string() }
    }

    #[test] fn empty_inputs_error() {
        assert!(resolve(&[]).is_err());
    }
    #[test] fn single_watcher_passes_through() {
        let d = resolve(&[input("wa", Severity::Info, 0.90)]).unwrap();
        assert_eq!(d.severity, Severity::Info);
        assert!((d.confidence - 0.90).abs() < 1e-9);
    }
    #[test] fn worst_severity_wins() {
        let d = resolve(&[
            input("wa", Severity::Info, 0.90),
            input("wb", Severity::Critical, 0.85),
        ]).unwrap();
        assert_eq!(d.severity, Severity::Critical);
    }
    #[test] fn minimum_confidence_wins() {
        let d = resolve(&[
            input("wa", Severity::Info, 0.90),
            input("wb", Severity::Info, 0.60),
        ]).unwrap();
        assert!((d.confidence - 0.60).abs() < 1e-9);
    }
    #[test] fn dissent_detected_when_watchers_disagree() {
        let d = resolve(&[
            input("wa", Severity::Info, 0.90),
            input("wb", Severity::Critical, 0.85),
        ]).unwrap();
        assert!(d.dissent);
    }
    #[test] fn no_dissent_when_all_agree() {
        let d = resolve(&[
            input("wa", Severity::Warning, 0.85),
            input("wb", Severity::Warning, 0.80),
        ]).unwrap();
        assert!(!d.dissent);
    }
    #[test] fn critical_blocks_promotion() {
        let d = resolve(&[input("wa", Severity::Critical, 0.90)]).unwrap();
        assert!(d.blocks_promotion());
    }
    #[test] fn info_does_not_block_promotion() {
        let d = resolve(&[input("wa", Severity::Info, 0.90)]).unwrap();
        assert!(!d.blocks_promotion());
    }
    #[test] fn watcher_count_recorded() {
        let d = resolve(&[
            input("wa", Severity::Info, 0.90),
            input("wb", Severity::Info, 0.85),
            input("wc", Severity::Info, 0.80),
        ]).unwrap();
        assert_eq!(d.watcher_count, 3);
    }
    #[test] fn severity_ordering_correct() {
        assert!(Severity::Critical > Severity::Error);
        assert!(Severity::Error > Severity::Warning);
        assert!(Severity::Warning > Severity::Info);
    }
}
