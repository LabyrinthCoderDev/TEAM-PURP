# council-resolver

Merges Watcher-A and Watcher-B into exactly one SignalNode.

## Responsibility

The Council Resolver (L5) combines the outputs of Watcher-A and Watcher-B
into exactly one normalized SignalNode per decision cycle (Invariant I4).

## Resolution Logic

| Condition | Result |
|-----------|--------|
| Agreement | Reinforced confidence |
| Disagreement | Escalated severity, reduced confidence |
| Critical disagreement | CRITICAL SignalNode |

## Invariants Enforced

- I4: Exactly one SignalNode per cycle
- I8: Same inputs always produce same output

## TODO

- [ ] Implement resolution logic
- [ ] Implement agreement/disagreement detection
- [ ] Verify: exactly one output per call
- [ ] Verify: deterministic

## Depth Status

This is a **prototype**.
Implementations are functional and tested but not exhaustive.
See `PROJECT_CONTEXT.md` at repo root for full context.
