# 16 — Dual Use Risk Register

Each row in this table identifies a capability, its legitimate use,
its potential for misuse, the safeguards in place, and what additional
controls would be required for deployment.

---

## Risk Register

| # | Capability | Legitimate Use | Potential Misuse | Current Safeguard | Deployment Restriction |
|---|-----------|----------------|------------------|-------------------|----------------------|
| 1 | Mandatory gate crossing | Ensures every AI proposal is reviewed before execution | Could be used to create a false sense of security if gate thresholds are maliciously calibrated | Thresholds Z3-proven; single source of truth | Independent review of thresholds before production |
| 2 | WORM hash-chained ledger | Tamper-evident audit trail for all gate decisions | Could be used to create an irrefutable false record if initial entries are fraudulent | Hash chain detects post-hoc tampering; not pre-hoc fraud | Hardware-backed signing (A014) needed for pre-hoc protection |
| 3 | Structural replay | Allows independent verification of any execution | Could be used to reconstruct sensitive information from ledger if content is logged | Content not logged by default; structural metadata only | Content logging policy must be reviewed per deployment |
| 4 | Domain adapter pattern | Enables constitutional enforcement in any domain | Could be used to embed enforcement substrate in infrastructure systems for misuse | No live domain adapters exist; specification only | Independent review required per domain before implementation |
| 5 | Healing loop / mutation engine | Allows blocked proposals to be revised and resubmitted | Could be used to iterate toward gate-bypassing proposals through adversarial mutation | Confidence ceiling at 0.35 on re-entry; MAX_DEPTH=5; oscillation detection | Mutation rate and depth limits must be reviewed per deployment |
| 6 | Persistent episodic memory | Learns from past failures to improve future proposals | Could accumulate exploitable knowledge about gate behavior over time | SQLite; local only; no network; bounded scope | Data retention policy required; purge schedule |
| 7 | Chi aggregate detection | Catches distributed contradiction signals that individually fall below threshold | Could be used to understand gate response surface for adversarial calibration | Fix documented (Rooke Poole); thresholds not public in live deployment | Threshold values should not be exposed in API responses in production |
| 8 | Multi-channel gate evaluation | Five independent channels provide defense-in-depth | Partial channel spoofing could exploit channels with weaker enforcement | All five channels independently checked; KILL irrevocable | Ensure all channels are actively computed, not stubbed |
| 9 | Adversarial threat model (TM-001) | Documents known attack classes; enables red-team testing | Provides adversary with a structured attack taxonomy | 11 classes tested; detection verified (A017); tests are public | Accept as tradeoff: public red-team documentation is less dangerous than undocumented attacks |
| 10 | Human override logging | Ensures all overrides are auditable | Could be used to build a record of when human authority was exercised (inference about operational tempo) | Overrides logged but override content is operator-controlled | Operational security review for any deployment with sensitive override patterns |
| 11 | Session isolation | Prevents cross-session contamination | Creates discrete attack windows per session | Per-session subdirectory; session ID in all entries | Ensure session boundaries are enforced in production |
| 12 | Offline/local operation | Can operate without network connectivity | Reduces logging and audit trail visibility if network is used for audit export | Ledger is local-first; network connectivity is optional | Audit export to external system required for high-stakes deployment |

---

## Summary Assessment

**Capabilities with highest legitimate value:**
1. Mandatory gate crossing — the core constitutional primitive
2. WORM ledger — the accountability foundation
3. Structural replay — the verifiability mechanism

**Capabilities with highest misuse concern:**
1. Domain adapter pattern — the infrastructure connection risk
2. Persistent memory — the knowledge accumulation risk
3. Healing loop — the adversarial iteration risk

**Net assessment:** The legitimate use cases significantly outweigh the
misuse concerns at the current prototype stage, given that no live
connections exist. The misuse concerns are real for future deployments
and must be managed through the deployment restrictions in File 10 and
the escalation triggers in File 17.
