# 12 — Glossary for Non-Technical Reviewers

Terms used in this folder and the project, explained for policy,
legal, and security reviewers without deep software engineering background.

---

**Agentic AI system**
An AI system that takes actions, not just produces text. It may call tools,
browse the web, execute code, or control other systems. The key difference
from a chatbot is autonomy: it does things, not just says things.

**Append-only ledger (WORM)**
A record-keeping system where entries can be added but never changed or deleted.
Like a bound ledger book where each page is numbered and glued. If someone tears
out a page, the gap is immediately visible. WORM stands for Write Once Read Many.

**Assumption register (ACP-1)**
A list of every claim the system makes about itself, each marked as either
VERIFIED (proved), PARTIAL (some evidence), or OPEN (not yet proved). This is
unusual — most systems don't publish what they haven't proved. This one does.

**Constitutional substrate**
An enforcement layer that operates by structure rather than by instruction.
A nuclear reactor safety interlock is constitutional: it doesn't ask the control
software to want to stay safe, it physically prevents certain outcomes. This
system tries to apply that principle to AI governance.

**Crossing point / Reality Gate**
The single mandatory checkpoint every proposal must pass before it can become
an action. Nothing in the proposal lane can affect the world without crossing
this point. Think of it as a customs checkpoint: every traveler (proposal) must
pass through, no exceptions.

**Domain adapter**
The translation layer that converts measurements from a specific field (medicine,
manufacturing, finance) into the five standard channels the gate evaluates.
The gate itself doesn't know which domain it's operating in — it only sees the
five numbers. The adapter does the translation.

**Dual-lane separation**
The architectural divide between "thinking" (Lane 1, where the AI proposes)
and "doing" (Lane 2, where actions take effect). Nothing in Lane 1 can directly
cause something to happen in Lane 2. Every transition requires an explicit,
logged crossing.

**Fail-closed**
A safety posture where any malfunction results in blocking rather than allowing.
If the security guard faints, the door locks — it doesn't open. The gate in
this system is fail-closed: any error during evaluation produces BLOCK, not EXECUTE.

**Gate (Reality Gate)**
The component that evaluates every proposal against a set of threshold constants
(the Sigma Anchors) and produces one of three decisions: EXECUTE (safe), BLOCK
(soft violation, review needed), or KILL (hard violation, irrevocable this cycle).

**Hash chain / Hash-chained ledger**
A ledger where each entry is mathematically linked to the previous entry, so
that if any entry is changed, every subsequent entry breaks. Like a blockchain,
but simpler and single-node. Provides tamper-evidence: you can't change history
without leaving a detectable trace.

**Healing loop**
The mechanism that processes blocked proposals — doesn't discard them, but sends
them back for revision with lower confidence, requiring them to re-earn promotion.
Like an appellate process: a rejected proposal can try again, but must meet higher
evidence standards.

**Invariant**
A property that must always be true, enforced in code. Not a guideline or a goal
— an invariant is a constraint the system checks and enforces with an error if
violated. Examples: "every input must pass through the labeling stage" (I1),
"the ledger is append-only" (I6), "the gate precedes execution" (I5).

**KILL decision**
The most severe gate outcome. When triggered (tau below floor, chi at collapse
level, or betti_1 cap exceeded), the decision is irrevocable within the current
cycle. It cannot be upgraded to EXECUTE without starting a new cycle from scratch.

**Lane 1 / Lane 2**
Lane 1: where the AI model reasons, proposes, and labels — the "thinking" space.
Lane 2: where validated proposals become actions — the "doing" space. The system's
central architectural principle is that these two lanes must never mix.

**Persistent memory / Episodic memory**
The system's record of past proposals and their outcomes, stored in a database.
Used to learn from history: proposals similar to past failures receive lower
confidence, proposals similar to past successes receive higher confidence.

**Procedural sovereignty**
Governance by process rather than by authority. A constitutionally-governed
system doesn't rely on the trustworthiness of any individual actor — it relies
on the structure of the process every actor must follow. The phrase captures what
this system is actually trying to achieve.

**Promotion / Promotion receipt**
The explicit approval that a proposal requires before it can attempt to cross
the gate. Promotion requires evidence — it cannot be granted silently or without
a cryptographic record. The receipt is a typed artifact that the gate checks.

**Proposal**
An AI-generated suggested action. In Lane 1 (where thinking happens), proposals
are free to be speculative, uncertain, even wrong. They only become dangerous
if they cross into Lane 2. The system's job is to control what crosses.

**Replay / Structural replay**
The ability to reconstruct what happened from the ledger record, deterministically,
after the fact. If a dispute arises about what the system did, the ledger and
replay system allow independent reconstruction — not from memory or testimony,
but from the mathematical record.

**Sigma Anchors**
The five threshold constants that the gate evaluates: tau (escape ratio),
chi (contradiction density), drift (baseline deviation), betti_1 (complexity),
and confidence (evidence weight). These constants are formally verified to be
internally consistent and non-vacuous.

**WORM**
Write Once Read Many. A storage paradigm where data can be added but never
modified or deleted. The WORM ledger in this system ensures that the record
of what happened cannot be altered after the fact.

**Z3 / SMT solver**
A formal mathematical verification tool (developed by Microsoft Research) that
can prove or disprove mathematical claims about the relationships between numbers.
Used here to formally verify that the Sigma Anchor threshold constants are
consistent, non-vacuous, and correctly ordered. The proof is machine-checkable.
