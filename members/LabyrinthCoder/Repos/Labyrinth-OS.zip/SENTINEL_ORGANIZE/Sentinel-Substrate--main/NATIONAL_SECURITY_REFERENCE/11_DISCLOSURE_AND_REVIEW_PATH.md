# 11 — Disclosure and Review Path

---

## The Disclosure Philosophy

This project is publicly documented by design. The same openness required
for independent audit, reproducibility, and external verification also creates
an adversarial study surface. We accept this tradeoff because:

1. Hidden governance systems are more dangerous than transparent ones.
   They cannot be audited, contested, or corrected by external parties.

2. Public review enables red-teaming. The security improvements made as
   a result of external review (including the chi aggregate fix from Rooke
   Poole, May 2026) demonstrate the value of this openness.

3. Reproducibility is necessary for trust. A governance system that cannot
   be independently verified is not a governance system. It is a claim.

4. The pattern is more important than any specific implementation. Publishing
   the architecture enables the field to improve on it, find its failure modes,
   and build better versions.

Transparency does not mean recklessness. It means being explicit about what
has been proved, what has not, what is dangerous, and what the limits are.

---

## Who Should Review This Project

| Reviewer Type | What They Should Read |
|--------------|----------------------|
| Technical security researcher | `PROTOTYPE_BOUNDARIES.md`, `threat_model.py`, `KNOWN_GAPS.md`, File 18 |
| AI safety researcher | `acp1_tracker.py`, `INVARIANTS.md`, `z3_sovereignty_spec.py`, Files 02, 03 |
| Policy researcher / regulator | Files 01, 02, 10, 12 (glossary), then ask questions |
| Critical infrastructure security | Files 06, 07, 08, 09, 04 |
| National security / defense | All files in this folder, in order |
| Academic computer science | `THEORY_AND_METAPHOR.md`, `ARCHITECTURE.md`, the Rust crates, `z3_sovereignty_spec.py` |

---

## The Review Path

If you are a government body, regulatory agency, or defense organization
and you want to understand the security implications of this architecture
class:

**Step 1:** Read this folder (00–20) in order.

**Step 2:** Read `PROTOTYPE_BOUNDARIES.md` and `KNOWN_GAPS.md` in the
project root. These are the most honest documents in the repository.

**Step 3:** Run the test suite (`python run_all.py` in the project root).
The tests demonstrate what is actually enforced versus what is aspirational.

**Step 4:** Ask the questions you have. The builder can be contacted via
the `@LabyrinthCoder` handle.

---

## What the Builder Is Prepared to Discuss

- Architecture decisions and their rationale
- Known gaps and their honest status
- Threat model completeness and gaps
- Domain adapter design for specific use cases
- The relationship between this architecture and existing AI safety frameworks
- The national security implications of systems in this class at scale

---

## What the Builder Is Not Claiming

- That this system is ready for any production deployment
- That this system solves the alignment problem
- That this system eliminates the risk of AI systems causing harm
- That this system cannot be misused
- That the builders have complete expertise in all relevant domains

---

## Responsible Disclosure Protocol

If a security researcher discovers a vulnerability in this system:

1. Document the vulnerability with a proof of concept
2. Contact the builder via `@LabyrinthCoder` before public disclosure
3. Allow a reasonable time period for the builder to understand and respond
4. If no response within a reasonable period, proceed with responsible
   public disclosure

The builder commits to:
- Acknowledging receipt of vulnerability reports
- Assessing the severity honestly and publicly
- Crediting the researcher in the changelog (as was done for the
  chi aggregate fix)
- Not taking legal action against good-faith security research

---

## The Record of External Reviews

External reviews conducted and archived to date:

| Reviewer | Format | Date | Key Findings |
|----------|--------|------|--------------|
| Technical reviewer (anonymous) | Written analysis | May 2026 | "Governance is geometry not advice" |
| Philosophical reviewer (anonymous) | Written analysis | May 2026 | "Ledger makes time solid" |
| DeepSeek | AI analysis | May 2026 | "Governance is irreversible commitment" |
| Rooke Poole | Code contribution | May 2026 | Chi aggregate leak — identified and fixed |
| GPT-4 (security analysis, documents 5–10) | Security analysis | May 2026 | National security framing (this folder) |

All findings are archived in `archive/THEORY_AND_METAPHOR.md` and
incorporated into the codebase or documentation.
