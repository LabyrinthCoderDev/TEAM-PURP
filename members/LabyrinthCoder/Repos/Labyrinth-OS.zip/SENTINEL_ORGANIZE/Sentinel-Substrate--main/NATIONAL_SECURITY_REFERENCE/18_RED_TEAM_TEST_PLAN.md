# 18 — Red Team Test Plan

---

## Current Coverage

TM-001 defines 11 attack classes. All 11 have detection tests.
`A017 VERIFIED`: Detection logic exists for all 11 attack classes.

The following tests are verified:

| Class | Attack | Detector | Verified |
|-------|--------|----------|---------|
| CLASS-1 | Replay attack — replaying a prior valid decision | `watcher_b.py`, `replay_validator.py` | Yes |
| CLASS-2 | Split brain — different graphs to different watchers | Council resolver | Yes |
| CLASS-3 | Signal injection — fake COUNCIL signals | `watcher_b.py` | Yes |
| CLASS-4 | Temporal splice — proposals from different sessions combined | `watcher_a.py` | Yes |
| CLASS-5 | Invariant strip — removing invariant mask entries | `watcher_a.py` | Yes |
| CLASS-6 | Gate evasion — schema-valid but empty graph | `watcher_b.py` | Yes |
| CLASS-7 | Confidence spoof — uniform/perfect confidence | `watcher_b.py` | Yes |
| CLASS-8 | Phase skip — execution without gate check | `replay_validator.py` | Yes |
| CLASS-9 | Time order manipulation — reordering ledger entries | `replay_validator.py` | Yes |
| CLASS-10 | Partial write — incomplete cycle left open | `replay_validator.py` | Yes |
| CLASS-11 | Promotion race — simultaneous same-ID promotion | `healing_system.py` | Yes |

---

## Red Team Scenarios Not Yet Tested

These scenarios require either live inference (A010) or distributed
deployment (Phase 11) to test fully:

| Scenario | Description | Blocked Until |
|----------|-------------|---------------|
| Prompt injection | Crafted LLM input manipulates gate signal extraction | A010 (live inference) |
| Adversarial logprob | Constructed logprob distribution produces false channel values | A010 |
| Threshold discovery via probing | Systematic API probing to map gate response surface | A010 + production API hardening |
| Cascading refusal | Multi-node block cascade | Phase 11 |
| Cross-node legitimacy laundering | Node A approves what Node B would reject | Phase 11 |
| Healing loop adversarial mutation | Iterating mutations to find gate-passing near-bypass | A010 + extended testing |
| Constitutional configuration poisoning | Threshold recalibration after deployment | Requires deployment |

---

## Red Team Test Protocol

For each attack class, the test must demonstrate:

1. **Attack is possible** — the test can produce the attack condition
2. **Attack is detectable** — the detector fires correctly
3. **Attack is blocked** — the system's response is BLOCK or KILL,
   not EXECUTE

Tests that demonstrate detection but not blocking are logged as partial.

---

## New Red Team Scenarios to Add (Priority)

Based on the GPT security analysis (May 2026), the following scenarios
should be added to TM-001 before Phase 11:

**CLASS-12: Control Loop Instability**
Description: Adversarially-timed proposals trigger oscillation between
the gate and the healing loop, producing either runaway acceptance or
permanent deadlock.
Detector: Approval rate monitoring + oscillation detection in healing loop
Status: Not yet designed

**CLASS-13: Governance Legitimacy Laundering**
Description: A formally-correct sequence of gate approvals is used to
authorize a harmful action that no individual crossing would have revealed.
Detector: Semantic review at promotion stage (requires EBF full implementation)
Status: Not yet designed — requires Effective Boolean Filter

**CLASS-14: Constitution Capture**
Description: Threshold configuration is modified by an actor with
implementation access, outside the documented change control process.
Detector: Threshold change monitoring; Z3 re-verification on any change
Status: Change control exists; automated monitoring not yet implemented

**CLASS-15: Distributed Attribution Loss**
Description: A harmful outcome results from the aggregate of individually
correct decisions across multiple enforcement nodes.
Detector: Cross-node attribution protocol (see File 07)
Status: Blocked until Phase 11 design

---

## Red Team Schedule

| Phase | Scope | When |
|-------|-------|------|
| Phase 0 (current) | Classes 1–11 | Complete |
| Phase 1 (A010) | Prompt injection, logprob adversarial, threshold probing | After A010 |
| Phase 2 (Phase 11) | Cascade, cross-node, attribution | After Phase 11 design |
| Phase 3 (production) | Full independent red team | Before Tier 3 deployment |

---

## What an External Red Team Should Receive

- `threat_model.py` — current attack class definitions and tests
- `sigma_anchors.py` — threshold constants (public; Z3-proven)
- `PROTOTYPE_BOUNDARIES.md` — what is and isn't enforced
- `KNOWN_GAPS.md` — documented gaps
- This file — current coverage and open scenarios

The red team should not receive:
- API keys or credentials
- Session ledger files containing real operational data
- Hardware signing key material (once A014 is implemented)
