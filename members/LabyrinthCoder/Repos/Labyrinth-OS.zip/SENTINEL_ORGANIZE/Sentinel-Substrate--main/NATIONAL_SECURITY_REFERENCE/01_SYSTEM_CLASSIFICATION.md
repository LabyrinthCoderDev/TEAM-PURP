# 01 — System Classification

---

## Classification

| Field | Value |
|-------|-------|
| System name | Labyrinth-OS |
| Classification | Research prototype |
| Architecture type | Constitutional execution substrate |
| Primary function | Governance/enforcement topology for generative AI systems |
| Autonomy level | Human-supervised only |
| Deployment status | Not deployed — prototype and laboratory only |
| Operational status | Mock inference paths; no live external system connections |
| Builder | @LabyrinthCoder (anonymous independent researcher) |

---

## What the System Is

Labyrinth-OS is an architectural enforcement substrate. It separates the
epistemic lane (where an AI model reasons and proposes) from the execution
lane (where actions affect the world), and enforces that every proposal must
cross a mandatory gate before execution. Every crossing is logged to a
tamper-evident, append-only ledger. Every execution is structurally
replayable.

The constitutional spine:

- **Dual-lane separation** — proposals and execution cannot mix
- **Single mandatory crossing point** — the Reality Gate (L09)
- **Typed execution artifacts** — every crossing produces a typed record
- **WORM ledger** — append-only, hash-chained, tamper-evident
- **Structural replay** — any execution can be reconstructed from ledger entries
- **Formal assumption register** — 22 assumptions tracked with VERIFIED/PARTIAL/OPEN status

---

## What the System Is Not

| Claim | Status |
|-------|--------|
| Autonomous AGI | No |
| Deployed safety infrastructure | No |
| Self-directing sovereign system | No |
| Production hardened platform | No |
| Certified AI governance system | No |
| Weapons system or component | No |
| Continuous autonomous operator | No |
| Connected to critical infrastructure | No |
| Connected to live external APIs | No (mock only) |
| Self-modifying | No |
| Self-authorizing | No |

---

## Architecture Classification by Layer

| Layer | Classification |
|-------|---------------|
| Language 1 (Python) | Orchestration and epistemic layer |
| Language 2 (Rust, 29 crates) | Enforcement primitives and ledger |
| Gate | Deterministic threshold evaluator — not ML-based |
| Ledger | WORM hash chain — analogous to append-only audit log |
| Replay | Structural determinism verifier |
| Memory | SQLite-indexed episodic memory — bounded scope |
| Healing loop | Bounded mutation engine — confidence-capped re-entry |
| Domain adapters | Translation layer — five channels, domain-specific mapping |

---

## Applicable Frameworks

| Framework | Relevance |
|-----------|-----------|
| NIST AI RMF | Govern / Map / Measure / Manage — all four functions addressed |
| NIST AI RMF GenAI Profile | Relevant — LLM proposal gating is primary use case |
| CISA Secure-by-Design | Architecture enforces security at design level |
| UK DSIT AI Safety Institute | Constitutional constraints and adversarial threat model align with oversight focus |
| EU AI Act (high-risk) | Pattern applies to high-risk AI system deployment with audit trail |

---

*See `PROTOTYPE_BOUNDARIES.md` in the root for the full technical scope statement.*
