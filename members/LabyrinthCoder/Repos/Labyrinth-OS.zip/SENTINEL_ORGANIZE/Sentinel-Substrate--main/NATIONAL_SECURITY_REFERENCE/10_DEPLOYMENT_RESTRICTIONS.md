# 10 — Deployment Restrictions

---

## Current Deployment Status

**Labyrinth-OS is not deployed.**

It operates in sandbox and laboratory conditions only, with mock
inference paths. No live external system connections exist.

This restriction is not a limitation. It is a precondition for responsible
development at this stage.

---

## Absolute Prohibitions

The following deployments are prohibited at all times, regardless of
capability level:

| Prohibited Deployment | Reason |
|-----------------------|--------|
| Offensive cyber operations | Active harm to third-party systems |
| Autonomous weapons targeting | International humanitarian law; autonomous kill decisions |
| Lethal autonomous systems | Same as above |
| Infrastructure sabotage | Direct harm to public infrastructure and safety |
| Covert surveillance without consent | Privacy law; fundamental rights |
| Stalking, harassment, or tracking of individuals | Legal and ethical prohibition |
| Unsupervised deployment against human targets | Human authority requirement |
| Self-authorizing privilege escalation | Core architectural prohibition |
| Disinformation or information manipulation at scale | Public harm |
| Any deployment intended to deceive human overseers | Core architectural prohibition |

These prohibitions are permanent. They are not negotiable under any
framing of beneficial intent.

---

## Conditional Prohibitions (Until Conditions Are Met)

The following deployments are prohibited until the stated conditions
are satisfied:

| Prohibited Until | Condition Required |
|------------------|--------------------|
| Live AI inference connection | A010 completed and validated |
| Any external API write access | Independent security review |
| Multi-agent networking (Phase 11) | Distributed control requirements designed (File 07) |
| Critical infrastructure mediation | Independent architecture review + FMEA + penetration test |
| Medical system integration | Regulatory approval + clinical validation + independent review |
| Financial system integration | Regulatory review + penetration test + human override verification |
| Robotics or vehicle actuation | Physical safety review + fail-safe verification + independent review |
| Military system integration | Government-body review + international law compliance |
| Public deployment of any kind | Independent security audit + governance review |

---

## Sandbox Requirements

During prototype development:

1. **Air-gapped testing only** — no live internet connections during
   security-sensitive testing

2. **Separate execution environment** — the system under test must not
   share resources with production systems

3. **Rollback capability** — every test environment must have a
   documented rollback procedure

4. **Session isolation** — each test session uses its own ledger,
   its own directory, and its own credentials

5. **No persistent external state** — sandbox sessions must not modify
   external systems, databases, or APIs

---

## The Deployment Decision Process

Before any capability escalation (see File 17), the following process
applies:

1. **Builder review** — document the new capability and its risk
   implications in the project's KNOWN_GAPS.md and this folder

2. **Architecture review** — a qualified reviewer who did not build
   the system reviews the new capability

3. **Red-team test** — adversarial testing of the new attack surface
   (see File 18)

4. **Incident response preparation** — update File 19 to cover the
   new capability's failure modes

5. **Stakeholder notification** — inform any parties who may be affected
   by the new capability before it is activated

This process must be completed for every step up in capability, not
just for major milestones.

---

## The Responsibility of Derivative Works

Anyone who derives a system from this architecture — who uses the
pattern, the codebase, the domain adapters, or the constitutional
topology — inherits the responsibility to maintain these restrictions.

Derivative works that remove these restrictions are not derivatives
of this project in any meaningful sense. They are new systems with
new responsibilities and must be treated as such.

This document records the builders' intent. The builders cannot control
what others do with this pattern. But the record of intent matters.

It always has.
