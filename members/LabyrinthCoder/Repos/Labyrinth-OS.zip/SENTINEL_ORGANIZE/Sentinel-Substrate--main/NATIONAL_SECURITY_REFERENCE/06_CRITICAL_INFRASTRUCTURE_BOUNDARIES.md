# 06 — Critical Infrastructure Boundaries

---

## The Domain Adapter Pattern and Its Risk Surface

The Labyrinth-OS domain adapter pattern is the feature that makes
this architecture class relevant to critical infrastructure. It is
also the feature that makes it potentially dangerous if misdeployed.

The pattern translates physical sensor readings from any domain into
the five abstract Sigma Anchor channels (tau, chi, drift, betti_1,
confidence) that the gate evaluates. The gate, ledger, and replay
logic are domain-agnostic.

This means the same enforcement substrate can, in principle, mediate
proposals from:

- AI governance systems (current implementation)
- Industrial CNC machines and process controllers (Phase 10.5)
- Medical decision support systems
- Financial trading and approval systems
- Autonomous vehicle control systems

The adapter is the only domain-specific component. Everything else
is identical.

---

## Current Domain Status

| Domain | Status | Risk Level |
|--------|--------|-----------|
| AI governance (LLM output gating) | Prototype — mock paths | Low (no live execution) |
| Industrial automation | Specification only (DOMAIN_ADAPTER_SPEC.md) | Not applicable — not built |
| Medical decision support | Specification only | Not applicable — not built |
| Financial systems | Specification only | Not applicable — not built |
| Autonomous vehicles | Specification only | Not applicable — not built |

**No domain adapter other than the AI governance mock is built or connected.**

---

## Hard Boundary: No Critical Infrastructure Without Independent Review

The following connections are prohibited at all prototype stages:

| Prohibited Connection | Reason |
|-----------------------|--------|
| Live power grid interfaces | Infrastructure impact without reversibility |
| Water treatment control | Direct public health risk |
| Financial system write access | Regulatory and systemic risk |
| Medical device actuation | Direct patient safety risk |
| Vehicle or robotics actuation | Direct physical safety risk |
| Air traffic or transport control | Direct public safety risk |
| Military system interfaces | National security and international law |
| Telecommunications infrastructure | Critical communications risk |

---

## What "Independent Review" Means

Before any critical infrastructure connection:

1. **Architecture review** — a qualified systems engineer who did not
   build the system must review the domain adapter design

2. **Failure mode analysis** — a formal FMEA (Failure Mode and Effects
   Analysis) for the specific domain adapter

3. **Penetration test** — adversarial testing of the gate in the
   specific domain context, including domain-specific attack vectors

4. **Human authority verification** — confirmation that human override
   authority is preserved at every execution crossing point

5. **Regulatory compliance check** — verification that the deployment
   satisfies all applicable regulatory requirements for the domain

6. **Incident response plan** — a domain-specific response protocol for
   unexpected behavior (see `19_INCIDENT_RESPONSE_PLAN.md`)

---

## The Legitimate Use Case

The domain adapter pattern is designed for one specific purpose:
to create an auditable, replayable, human-overseen mediation layer
between AI recommendations and infrastructure actions.

In this model:

- The AI system proposes actions (in Lane 1)
- The gate evaluates proposals against domain-specific thresholds
- Approved proposals are logged to the WORM ledger
- Human operators retain override authority at all times
- Every action is replayable from the ledger record

This is not autonomous infrastructure control. It is a structured
checkpoint between AI recommendations and human-authorized execution.

---

## The Risk If This Distinction Collapses

If the enforcement substrate is deployed without preserving human
authority at the crossing point — if the Reality Gate is configured
to auto-execute without human review — the system becomes an
autonomous actuator rather than a mediation layer.

That is the critical infrastructure boundary:

**Mediation layer (acceptable) → Autonomous actuator (not acceptable)**

This boundary must be enforced at the deployment level, not at the
code level. The code supports both configurations. The constraint
is operational and must be maintained by the operator.

This document records that the builders explicitly require mediation
layer deployment only. Autonomous actuation is not an intended use case.
