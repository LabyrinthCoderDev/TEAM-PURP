# 08 — Ledger, Replay, and Audit Requirements

---

## The Ledger Is the System's Memory of Itself

The WORM hash-chained ledger is the most important safety mechanism
in the architecture. It is not merely a log. It is the mechanism by
which the system can be held accountable after the fact.

Every execution either appears in the ledger — in order, with a
cryptographically valid chain — or it did not happen within the
constitutional substrate.

---

## Ledger Properties (Current Implementation)

| Property | Implementation | Status |
|----------|----------------|--------|
| Append-only | `hashchain.py` — no delete or update operations | Enforced |
| Hash-chained | SHA-256 chain: `h_n = SHA-256(h_{n-1} \|\| entry_n)` | Enforced |
| Tamper-evident | Chain break detectable at any entry | Enforced |
| File-locked | `fcntl.flock(LOCK_EX)` on every write | Enforced |
| Atomic writes | Write to temp file, then `os.replace()` | Enforced |
| Permission-restricted | `0o600` — owner read/write only | Enforced |
| Per-session isolation | Separate subdirectory per session | Enforced |
| Typed entries | `GateCrossing`, `FailedProposal`, `PromotionReceipt` | Enforced |

---

## Replay Properties (Current Implementation)

| Property | Implementation | Status |
|----------|----------------|--------|
| Structural replay | `replay_validator.py` | Enforced |
| Deterministic kernel | AEGIS CESK — same input = same output | A007 VERIFIED |
| Chain entry reconstruction | Every execution reproducible from ledger entries | Prototype |
| Cross-session replay | Replay of archived sessions | Prototype |

---

## What Structural Replay Does Not Prove

This is important. Structural replay verifies:

- The ledger entries are in the correct order
- The hash chain is unbroken
- The timestamps are non-decreasing
- The entries are internally consistent

Structural replay does **not** verify:

- That the gate's decision was semantically correct
- That the thresholds were appropriate for the context
- That the promoted proposal was truthful
- That the execution outcome was beneficial

This gap is documented as GAP 7 in `KNOWN_GAPS.md`. It is named
explicitly because it matters: a formally correct replay of a formally
correct execution of a semantically wrong proposal is still a problem.

---

## Audit Requirements for Any External Reviewer

If you are conducting an external audit of a Labyrinth-OS deployment:

**What to verify:**

1. The ledger file has not been modified since its creation (hash chain)
2. Every `GateCrossing` entry has a corresponding `PromotionReceipt`
3. Every `PromotionReceipt` has `approved=True` (no false receipt attack)
4. The timestamp sequence is strictly non-decreasing within each session
5. Every `FailedProposal` has a corresponding archive entry
6. The replay validator produces matching output for the chain

**Red flags:**

- A gap in sequence numbers
- A timestamp that runs backward
- A `GateCrossing` without a `PromotionReceipt`
- A `PromotionReceipt` with `approved=False` and a corresponding `GateCrossing`
- Any entry with a hash mismatch
- A session with executions but no corresponding ledger entries

---

## Audit Trail Requirements for High-Stakes Deployment

For any deployment in a high-stakes domain (medical, financial, legal,
infrastructure), the following audit trail requirements apply in addition
to the base implementation:

1. **Ledger must be stored on separate physical media** from the system
   producing the entries

2. **Real-time replication** — ledger entries must be replicated to at
   least one independent system as they are written

3. **Cryptographic signing** — ledger entries must be signed with a
   hardware-backed key (ATECC608B or equivalent), not a software key

4. **Auditor access** — a designated independent auditor must have
   read-only access to the ledger at all times

5. **Retention policy** — ledger entries must be retained for a period
   appropriate to the domain's regulatory requirements

6. **Incident preservation** — on any anomalous event, the ledger must
   be exported and cryptographically sealed before any recovery actions
   are taken

---

## What Is Not Yet Implemented

| Gap | Status |
|-----|--------|
| Hardware-backed signing | A014 OPEN — requires physical silicon |
| Distributed ledger | Phase 11 — not started |
| Real-time external replication | Not designed |
| Regulatory retention management | Not designed |
| Automated audit alert system | Not designed |

These gaps are acceptable at prototype stage. They must be resolved
before any high-stakes deployment.
