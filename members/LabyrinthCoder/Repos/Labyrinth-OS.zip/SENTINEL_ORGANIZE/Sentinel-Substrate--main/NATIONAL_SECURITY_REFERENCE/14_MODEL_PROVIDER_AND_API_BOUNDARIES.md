# 14 — Model Provider and API Boundaries

---

## Current State

No live model provider connection exists. All inference is mock.
The `APIAdapter` in `runtime/ignition.py` supports Anthropic, OpenAI,
and Ollama backends, but A010 (first live inference) has not been executed.

---

## When A010 Connects Live Inference

The following controls must be in place before any live inference:

### Data Classification

What may be sent to external providers:

| Data Type | Permitted | Notes |
|-----------|-----------|-------|
| Synthetic test prompts | Yes | No real-world content |
| Anonymized proposals | Conditional | Must be reviewed for sensitivity |
| System prompts | Conditional | Must not contain sensitive architecture details |
| User data of any kind | No | Until data handling agreement reviewed |
| Personally identifiable information | No | Prohibited |
| Classified or sensitive content | No | Prohibited |

### API Key Management

- Keys must be stored in environment variables, never in code or config files
- Keys must be rotated on any suspected exposure
- Different keys for development and production
- Key access must be logged and audited
- Keys must be revocable immediately without system downtime

### Response Handling

LLM API responses must be treated as **untrusted input** to the gate:

- Responses are passed to the logprob bridge, which extracts sensor signals
- Sensor signals are passed to the gate, which applies threshold checks
- The gate's BLOCK/EXECUTE/KILL decision does not depend on trusting the response
- A response that claims high confidence but has low logprob diversity will
  be caught by the chi and tau channels

This is the core security property: the gate evaluates the statistical
properties of the response, not its semantic content.

### Rate Limiting and Error Handling

- Rate limit errors must produce BLOCK, not EXECUTE
- Timeout errors must produce BLOCK, not EXECUTE
- Any API error that prevents logprob extraction must produce a
  MISSING_LOGPROB_CONFIDENCE_CAP (confidence capped at 0.35, below gate floor)
- The system must be functional in degraded mode (no API) for all operations
  except live inference

---

## Provider-Specific Considerations

### Anthropic

- The system uses Claude for inference; the same Claude series assists
  in development. This is documented and not a hidden relationship.
- Anthropic's API returns logprobs for selected tokens. The logprob bridge
  (`api_logprob_extractor.py`) extracts these for gate signal computation.
- Data retention policies apply — check current Anthropic API terms before
  sending sensitive content.

### OpenAI

- Alternative inference backend. Same logprob extraction path.
- GPT series was used for security analysis in this folder. That analysis
  is documented as external input, not as authoritative guidance.

### Ollama (Local)

- Preferred for any sensitive use case — runs locally, no data transmission
- Lower risk profile: no API key, no data exposure, no rate limiting
- Tradeoff: smaller models, lower capability

---

## What the Gate Does Not Know

The gate evaluates five scalar channels. It does not know:

- Which model produced the proposal
- What the proposal means semantically
- Whether the proposal is true
- Which provider was used

This is intentional. Provider-agnosticism is a security property: the gate
cannot be told "trust this response because it came from provider X."

---

## Future: Hardware-Backed Inference Verification

When A014 (hardware enforcement) is implemented:

- Inference requests should be signed with the hardware key before sending
- Responses should include provider attestation where available
- The signing chain (request → hardware signature → response) should be
  verifiable from the ledger record

This would close the gap between "the system claims this inference happened"
and "the inference can be cryptographically verified."
