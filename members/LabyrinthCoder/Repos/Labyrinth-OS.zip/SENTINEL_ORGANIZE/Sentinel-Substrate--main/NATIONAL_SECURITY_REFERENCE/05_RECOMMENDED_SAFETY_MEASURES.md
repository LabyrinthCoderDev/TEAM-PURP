# 05 — Recommended Safety Measures

For any system in this architectural class — agentic AI with execution
gates, persistent memory, replayable ledgers, and adaptive orchestration.

---

## Mandatory Structural Controls

These are not recommendations. They are constitutional requirements
for any deployment of this system or systems derived from it.

**1. Human authority over execution, override, rollback, and scope**

No execution path may bypass human authority at the crossing point.
The Reality Gate is the mechanism. Human override must exist at every
tier. No self-authorized escalation is permitted.

*Implementation in Labyrinth-OS:* Reality Gate (L09) with typed
`GateCrossing` artifact. `KILL` decisions cannot be downgraded within
a cycle. `approved=False` receipts cannot produce `EXECUTE`.

**2. Mandatory gate crossing — no hidden paths**

Every proposal that reaches execution must cross the gate. No bypass
modes may exist in production. Every crossing is logged.

*Implementation in Labyrinth-OS:* `assert_can_enter_cgir()` raises
`SystemError` (non-catchable) if any mandatory stage is missing.
`labeling_required=False` still requires `FAILOVER_ENTRY` stage
(GAP 10 fix, May 2026).

**3. Immutable audit trail**

Every proposal, gate decision, execution attempt, block, failure,
rollback, and override must be logged to an append-only, hash-chained
ledger. Nothing may be deleted or modified after writing.

*Implementation in Labyrinth-OS:* `hashchain.py` WORM ledger with
SHA-256 chaining. File permissions 0o600. Atomic writes. flock locking.

**4. Replayable execution**

Any execution must be deterministically reconstructable from its
ledger record. An unreplayable execution is not fully real.

*Implementation in Labyrinth-OS:* `replay_validator.py` structural
replay. AEGIS deterministic runtime (same input = same output, A007
VERIFIED).

**5. Separation of observation from execution**

Watchers, monitors, and observability layers must be downstream only.
They cannot initiate proposals, promote actions, or cross the gate.
Sensor signals annotate; they do not decide.

*Implementation in Labyrinth-OS:* Invariant I3 (Sensor Read-Only),
Invariant I4 (Council Authority), Invariant I7 (Epistemic Boundary).
All enforced in code.

**6. Non-silent failure**

Every failure must produce a typed artifact. Exceptions must be logged.
No proposal may be silently discarded.

*Implementation in Labyrinth-OS:* `FailedProposal` typed artifact.
`FailureRecord` in deferred node. Invariant I10 (Fail Closed) enforced.
Gate is fail-closed: any evaluator exception produces `BLOCK`.

**7. Formally verified thresholds**

Safety thresholds must be internally consistent, non-vacuous, and
change-controlled. Arbitrary threshold modification without proof
invalidates the safety claim.

*Implementation in Labyrinth-OS:* `z3_sovereignty_spec.py` (A021
VERIFIED). `sigma_anchors.py` as single source of truth. Z3 proof of
non-vacuity, consistency, and ordering.

---

## Strongly Recommended Controls

**8. Adversarial threat model with empirical test coverage**

Document attack classes. Test them. Report results. Update the model
when new attack vectors are found.

*Implementation in Labyrinth-OS:* TM-001 with 11 attack classes.
Detection tests for all 11. `A017 VERIFIED`.

**9. Assumption register with explicit status**

Every architectural assumption must be named, tracked, and assigned
VERIFIED / PARTIAL / OPEN status with falsification criteria.
A system that cannot articulate what it has not yet proved is a
system with hidden assumptions.

*Implementation in Labyrinth-OS:* `acp1_tracker.py`. 22 assumptions.
10 VERIFIED / 3 PARTIAL / 9 OPEN. Updated each session.

**10. Sandboxed deployment before any live integration**

No connection to external systems, live APIs, or infrastructure until
the system has been independently reviewed in sandbox conditions.

**11. Supply chain integrity**

All dependencies must be pinned, audited, and change-logged. AI-assisted
code changes must be reviewed by a human before merging. No auto-merge
of AI-generated patches.

**12. Red-team testing before any capability escalation**

Before any new capability is added (tool use, networking, infrastructure
connection), a red-team test must be conducted against the new attack
surface. See `18_RED_TEAM_TEST_PLAN.md`.

---

## Controls That Must Be Designed Before Phase 11 (Distributed)

These controls do not exist yet and must be designed before distributed
deployment begins:

- **Cross-node authority boundaries** — who may instruct whom across
  distributed enforcement nodes
- **Distributed ledger consistency** — what happens when nodes disagree
  on ledger state
- **Attribution protocol** — how to trace an outcome to a responsible
  operator in a distributed deployment
- **Cross-node refusal cascade prevention** — how to detect and interrupt
  propagating block cascades before they produce systemic paralysis
- **Jurisdiction and legal entity mapping** — which legal entity is
  responsible for each enforcement node

---

*See `09_HUMAN_AUTHORITY_AND_OVERRIDE.md` for the authority model.*
*See `10_DEPLOYMENT_RESTRICTIONS.md` for what is currently prohibited.*
