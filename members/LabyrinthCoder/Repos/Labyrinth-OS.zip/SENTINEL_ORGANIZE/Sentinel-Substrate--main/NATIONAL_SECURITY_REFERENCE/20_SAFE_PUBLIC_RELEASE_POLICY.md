# 20 — Safe Public Release Policy

---

## Current Release Status

The architecture, documentation, and test suite are publicly documented
at the @LabyrinthCoder handle. This is intentional. See File 11 for
the transparency rationale.

---

## What Can Be Public

| Material | Public | Reason |
|----------|--------|--------|
| Architecture documentation | Yes | Enables independent audit and red-teaming |
| Threshold constants (sigma_anchors.py) | Yes | Z3-proven; auditability requires transparency |
| Test suite | Yes | Reproducibility; enables independent verification |
| Threat model (TM-001) | Yes | Better to document attack classes than to obscure them |
| Assumption register (ACP-1) | Yes | Epistemic honesty requires publishing known gaps |
| Theory archive | Yes | Philosophical framing is public intellectual work |
| KNOWN_GAPS.md | Yes | Honesty about limitations is the entire point |
| This folder | Yes | Defensive reference is more valuable when public |

---

## What Should Not Be Public

| Material | Private Until | Reason |
|----------|---------------|--------|
| API keys or credentials | Never public | Obvious |
| Hardware signing key material | Never public | Security critical |
| Session ledgers containing real operational data | Never public | May contain sensitive content |
| Specific deployment configurations | Until independent review | May reveal exploitable specifics |
| Specific infrastructure connection details | Until independent review | Attack surface |
| Any personal data processed by the system | Never public | Privacy law |

---

## What Requires Review Before Release

If any of the following are added to the project, they must be reviewed
before being made public:

1. **Live API credentials** — obvious; but credential scanning must be
   configured to prevent accidental commits

2. **Real operational data** — any ledger file from live operation must
   be reviewed for sensitive content before sharing

3. **New attack research** — if the project discovers a novel attack
   against AI governance systems, responsible disclosure applies
   before publishing

4. **Domain adapter implementations** for critical infrastructure —
   publishing a complete medical or infrastructure adapter creates
   a more specific attack surface; review required

---

## The Dual-Use Openness Problem

The same openness that enables independent audit also enables adversarial
study. The project accepts this tradeoff because:

1. **Obscurity doesn't work.** A governance substrate that cannot be
   independently audited is not trustworthy.

2. **The pattern is not the secret.** The safety comes from the
   structural properties, not from hiding the structure.

3. **Defense benefits more from openness than offense does.** Defenders
   can use open documentation to build better systems. Attackers have
   diminishing returns from studying public architectural documentation
   when the actual attack surface is in the deployment, not the pattern.

4. **Published attack classes are safer than hidden ones.** TM-001 is
   public because the alternative — undocumented attack classes — is
   more dangerous. If we don't name CLASS-7 (confidence spoofing),
   the attack still exists; it just isn't tested.

---

## Redaction Standards

When sharing session data, ledger exports, or operational logs:

- Replace all proposal text with `[REDACTED]`
- Replace all model-generated content with `[REDACTED]`
- Retain: timestamps, session IDs, gate decisions, Sigma Anchor values,
  receipt hashes (these are structural, not content)
- Verify: no personal information in the structural metadata before sharing

---

## The Living Document Principle

This folder, like the rest of the project, follows the architectural
doctrine: nothing is deleted, everything is versioned, changes are logged.

As the project evolves — as new capabilities are added, new risks are
identified, new reviews are completed — this folder must be updated.

The folder is not a snapshot. It is a living record of the project's
security posture at each stage of its development.
