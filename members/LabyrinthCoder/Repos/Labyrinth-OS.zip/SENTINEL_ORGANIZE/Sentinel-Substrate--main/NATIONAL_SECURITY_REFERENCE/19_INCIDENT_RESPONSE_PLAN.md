# 19 — Incident Response Plan

---

## What Counts as an Incident

| Event | Severity | Response |
|-------|----------|----------|
| Gate produces EXECUTE for a proposal that should have been blocked | Critical | Immediate halt |
| Ledger hash chain fails verification | Critical | Immediate halt + preserve evidence |
| Replay validator produces different output than original execution | Critical | Immediate halt |
| Promotion receipt shows `approved=False` but execution occurred | Critical | Immediate halt |
| Unauthorized modification of `sigma_anchors.py` | Critical | Immediate halt + audit |
| Unexpected system behavior during inference | High | Freeze session; preserve ledger |
| Any execution without a ledger entry | Critical | Immediate halt |
| Adversarial test unexpectedly passes the gate | High | Freeze; analyze; patch |
| Chi aggregate or other threshold bypass detected | High | Freeze; patch; retest |
| API key exposure suspected | High | Revoke immediately; audit |
| Unauthorized access to session files | High | Freeze; preserve evidence; audit |

---

## Immediate Response Protocol (Any Critical Severity)

**Step 1: FREEZE**
Stop all active inference sessions immediately. No new sessions until
the incident is resolved. If the system is operating autonomously,
interrupt the operation loop.

**Step 2: ISOLATE**
Disconnect from any external systems, APIs, or networks. Preserve
the current state — do not restart, do not clear logs.

**Step 3: EXPORT LEDGER**
Export the complete ledger file to an isolated, read-only location.
Compute and record the hash of the ledger file at this moment.
This creates a tamper-evident snapshot of the pre-response state.

**Step 4: PRESERVE EVIDENCE**
Do not modify any session files, logs, or configuration. Create
a complete copy of the session directory before any analysis begins.

**Step 5: VERIFY CHAIN**
Run `python -c "from hashchain import HashChain; c=HashChain(); print(c.verify())"`.
Record the result. If the chain is broken, identify the first broken entry.

**Step 6: IDENTIFY SCOPE**
Determine which sessions, proposals, and gate decisions are affected.
Review all ledger entries from the last known-good state to the incident.

**Step 7: NOTIFY**
Notify any parties whose data, systems, or decisions may have been affected.
If the incident involves a security vulnerability, follow the responsible
disclosure protocol in File 11.

**Step 8: ANALYZE**
Determine the root cause. Does the incident reflect:
- A code bug in the gate or ledger?
- A configuration error (wrong thresholds)?
- An attack against the system?
- A hardware or infrastructure failure?

**Step 9: PATCH AND RETEST**
Fix the root cause. Re-run the full test suite. Re-run the red team
test plan for the affected attack classes. Document the fix in `KNOWN_GAPS.md`
and `CHANGELOG.md`.

**Step 10: RESUME**
Only resume operation after:
- Root cause is identified and fixed
- Tests pass including the new test for the failure mode
- The fix has been reviewed by at least one independent party
- The incident has been documented fully

---

## What to Document After an Incident

- Date and time of detection
- First sign of anomaly and when it occurred
- Which sessions, proposals, and decisions were affected
- Root cause analysis
- Which invariants were violated, if any
- The fix applied and tests added
- Independent reviewer who confirmed the fix
- Decision to resume operation

This documentation must be preserved permanently. It becomes part of the
system's architectural history — the same doctrine that governs failed
proposals applies to failed security events. Nothing is deleted.

---

## Domain-Specific Response Considerations

For any future deployment in a domain with real-world consequences:

**Medical:** Notify clinical oversight; review any patient-affecting decisions
**Financial:** Notify compliance; review any transaction-affecting decisions
**Industrial:** Notify safety officer; review any actuation decisions
**Infrastructure:** Notify operations; review any control decisions

The domain-specific response must be planned before deployment, not after
an incident.

---

## What Has Not Happened (Current State)

No security incidents have occurred in the prototype. All testing is
synthetic and mock-only. This plan exists as a precautionary record,
not a response to any actual event.
