# 17 — Capability Escalation Triggers

Defines the specific technical thresholds at which the risk classification
of this system increases, and what review is required before crossing each.

---

## Current Classification: Research Prototype (Tier 0)

At present: mock inference only, no live connections, sandbox operation,
single-node, human-supervised.

---

## Escalation Trigger Table

| Trigger | Capability Added | Risk Tier Change | Required Before Activation |
|---------|-----------------|------------------|---------------------------|
| **T1** | Real autonomous tool execution (web search, code run, file write) | Tier 0 → Tier 1 | Security review; sandboxed environment; human oversight protocol |
| **T2** | Live LLM inference connection (A010) | Tier 0 → Tier 1 | API security review; data classification; error handling hardened |
| **T3** | Persistent multi-agent memory networked across instances | Tier 1 → Tier 2 | Distributed security review; data isolation per agent |
| **T4** | External API write access (any service) | Tier 1 → Tier 2 | Penetration test of write paths; rate limiting; audit trail |
| **T5** | Infrastructure control interface (read-only monitoring) | Tier 1 → Tier 2 | Architecture review; network isolation; access controls |
| **T6** | Infrastructure control interface (write/actuation) | Tier 2 → Tier 3 | Full independent review; FMEA; regulatory check |
| **T7** | Self-modifying code paths | Tier 2 → Immediate halt | Full review required before any restart |
| **T8** | Robotics or vehicle control (any level) | Tier 2 → Tier 3 | Physical safety review; fail-safe verification; regulatory check |
| **T9** | Autonomous financial action (any transaction) | Tier 2 → Tier 3 | Financial regulatory review; human approval protocol |
| **T10** | Unsupervised task chaining (N > 3 without human checkpoint) | Tier 1 → Tier 2 | Architecture review; checkpoint design; rollback protocol |
| **T11** | Multi-node distributed deployment | Tier 1 → Tier 2 | Distributed control requirements (File 07); attribution protocol |
| **T12** | Encrypted operator channels (hidden from audit) | Tier 2 → Tier 3 | Government body review; prohibition on covert operation |
| **T13** | Military or defense system integration | Any → National security review | Government body; international law compliance; independent audit |
| **T14** | Medical device actuation | Tier 2 → Tier 3 | Regulatory approval; clinical validation; patient safety review |
| **T15** | Persistent internet-facing deployment | Tier 1 → Tier 2 | Public security audit; DDoS protection; rate limiting |

---

## What the Tiers Mean

**Tier 0 — Research Prototype**
Sandbox only. Mock paths. No live connections. Human-supervised at all times.
This document and the rest of the project's documentation apply.

**Tier 1 — Limited Deployment**
Live inference or limited tool use, in a controlled environment.
Independent security review completed. Human oversight maintained.
Audit trail active. Data classification reviewed.

**Tier 2 — Operational Prototype**
Multi-agent, networked, or infrastructure-adjacent. Significant external
review completed. Legal and regulatory requirements reviewed.
Incident response plan active.

**Tier 3 — Production Deployment**
Full independent audit. Regulatory approval where required. Hardware
enforcement active (A014). Distributed controls designed and tested.
National-level security notification completed.

**Immediate Halt**
Self-modifying code paths, or any capability added without completing the
required review, triggers an immediate halt until review is completed.

---

## Who Decides When a Trigger Is Met

Currently: the builder (@LabyrinthCoder) determines when a trigger is met
and what review is required. This is appropriate at Tier 0.

At Tier 2 and above, the decision must involve at least one independent party.

At Tier 3 and above, a formal independent audit is required before activation.

---

## The Principle Behind This Table

The dangerous part is not any single capability. It is convergence:

> persistent memory + execution mediation + replayable governance +
> adaptive thresholds + autonomous orchestration within one integrated substrate

Each trigger adds one element of that convergence. The table is designed
to ensure that each element is reviewed independently before it is added
to the whole.
