# 15 — Data Classification and Handling

---

## Data That Currently Exists in the System

| Data Type | Location | Sensitivity | Retention |
|-----------|----------|-------------|-----------|
| Mock proposals (synthetic) | Ledger files | Low | Per session |
| Gate decisions (mock) | Ledger files | Low | Per session |
| Sigma Anchor thresholds | `sigma_anchors.py` | Medium (architecture detail) | Permanent (version-controlled) |
| Assumption register | `acp1_tracker.py` | Medium (architecture detail) | Permanent |
| Theory archive | `archive/THEORY_AND_METAPHOR.md` | Low (public) | Permanent |
| Test vectors | `tests/adversarial/` | Low | Permanent |
| Session JSON files | Project root | Low (mock data) | Ephemeral |

No personal data. No real user data. No classified material.

---

## Data Classification for Future Deployment

| Classification | Definition | Gate Treatment |
|----------------|------------|----------------|
| Public | No sensitivity; can be logged fully | Log in full |
| Internal | Business-sensitive; controlled access | Log with redaction |
| Confidential | High sensitivity; legal/medical/financial | Log metadata only; redact content |
| Restricted | Regulated data; PII/PHI/classified | Do not process; reject at intake |

---

## What Must Never Enter the System

- Personal health information (PHI) without explicit regulatory authorization
- Personally identifiable information (PII) without consent and legal basis
- Classified government material without security clearance and isolated environment
- Cryptographic keys or credentials of any kind in proposals
- Payment card data
- Biometric data
- Data about minors

---

## Logging and Retention Rules

**What the ledger logs:**
- Proposal ID (not content, unless explicitly configured for low-sensitivity data)
- Gate decision (EXECUTE / BLOCK / KILL)
- Timestamp and session ID
- Sigma Anchor channel values (tau, chi, drift, betti_1, confidence)
- Receipt hash
- Crossing artifact (typed)

**What the ledger must not log by default:**
- Raw proposal text (may contain sensitive content)
- Raw LLM response text (may contain sensitive content)
- API keys or credentials
- Personal data from the proposal context

**Configuring content logging:**
Content logging (raw text) is available but must be explicitly enabled.
Before enabling, data classification and consent must be reviewed.
Content logs have shorter retention than structural logs.

---

## Encryption Requirements

For any deployment beyond sandbox:

| Layer | Requirement |
|-------|-------------|
| Ledger files at rest | AES-256 encryption required for confidential data |
| Session directories | Encrypted if any non-public content |
| API key storage | Encrypted at rest; environment variables for runtime |
| Network transmission | TLS 1.3 minimum for any API communication |
| Backup media | Full encryption required |

---

## Data Subject Rights

For any deployment where personal data may be processed:

- Right of access must be technically possible (the ledger can be queried)
- Right of correction: note that the WORM ledger cannot be modified — this is
  a genuine tension with GDPR Article 16 that must be resolved at the regulatory
  level before processing personal data
- Right of deletion: the WORM ledger cannot delete entries — this is the most
  significant tension with privacy regulation; it must be resolved by design
  (e.g., not storing personal data in the ledger) rather than by modifying
  the ledger

**Recommendation:** Do not process personal data in the ledger. Store personal
data in a separate, mutable system if required. The ledger records the
structural fact of gate decisions, not the content of the proposals.
