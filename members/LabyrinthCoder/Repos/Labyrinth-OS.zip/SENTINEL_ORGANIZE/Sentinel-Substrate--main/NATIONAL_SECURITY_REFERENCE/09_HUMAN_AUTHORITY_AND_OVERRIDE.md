# 09 — Human Authority and Override

---

## The Fundamental Principle

No AI proposal may execute without passing through a gate that a human
has the authority to configure, audit, and override.

This is not aspirational. It is the architectural foundation of the
system. The Reality Gate exists specifically to enforce this principle.
The ledger exists specifically to make it auditable. The replay system
exists specifically to make it verifiable after the fact.

---

## The Three Layers of Human Authority

### Layer 1: Constitutional Authority (Threshold Configuration)

A human operator or team configures the Sigma Anchor thresholds before
deployment. These thresholds define what the gate will block and what
it will allow.

**Current mechanism:** `sigma_anchors.py` — single source of truth,
change-controlled, Z3-proven for internal consistency.

**Constraint:** Threshold changes require code modification and
re-verification. They cannot be made at runtime by the system itself.

### Layer 2: Crossing-Point Authority (Gate Override)

A human operator has the authority to override a gate decision. This
authority must be exercised before the ledger entry is written, because
the ledger is append-only.

**Current mechanism:** `human_override` parameter in
`cgir_guardian_bridge.evaluate()`. Override is logged as part of the
crossing artifact.

**Constraint:** Override is logged. It cannot be silent. A reviewer
can always see that a human override occurred, when, and by whom.

### Layer 3: Post-Hoc Authority (Replay and Audit)

A human auditor has the authority to review any execution after the
fact, using the replay system to reconstruct exactly what happened.

**Current mechanism:** `replay_validator.py` structural replay.
`hashchain.verify()` tamper detection.

**Constraint:** Post-hoc authority cannot change what happened. It
can only establish what happened and trigger remediation.

---

## What Human Authority Cannot Do

For the system to function as a constitutional substrate, certain
actions must be impossible even for human operators:

| Action | Why Prohibited |
|--------|----------------|
| Delete a ledger entry | Destroys the accountability record |
| Modify a ledger entry | Destroys the tamper-evidence chain |
| Bypass the gate without logging | Creates an unaccountable execution |
| Promote a proposal without evidence | Violates I3 (Promotion requires evidence) |
| Approve a KILL decision within a cycle | KILL is irrevocable within a cycle |
| Modify thresholds at runtime without re-verification | Invalidates the Z3 proof |

These prohibitions are architectural. They are the price of accountability.
A system in which the auditor can rewrite the audit trail is not an
audit trail.

---

## The Override Protocol

When a human operator needs to override a gate decision:

1. The override must be logged with: operator identity, timestamp,
   reason, and the original gate decision being overridden.

2. The override must be made before the crossing artifact is written.

3. The override is included in the `GateCrossing` artifact as a
   first-class field (`is_override: bool`, `override_reason: str`).

4. An override that is not logged is not a valid override. It is a
   bypass.

---

## Self-Authorization Is Prohibited

The system must never be configured to authorize its own actions:

- The gate cannot promote a proposal it has previously blocked
- The healing loop cannot promote its own mutation candidates
  without passing through the full pipeline
- The watchers cannot override each other
- The council cannot override its own consensus
- No module may grant itself crossing authority

Every promotion requires a receipt. Every crossing requires a gate.
Every gate decision is final within its cycle.

---

## What Must Be Preserved in Any Future Version

Any future version of this system — any production deployment,
any distributed instance, any domain-adapted version — must preserve:

1. **Human authority over threshold configuration**
2. **Human authority over gate override (with mandatory logging)**
3. **Human authority over audit and replay**
4. **Prohibition on self-authorization**
5. **Prohibition on silent override (all overrides are logged)**
6. **Prohibition on ledger modification**

If any of these six properties is removed, the system is no longer
a constitutional substrate. It is an autonomous actuator.
That is a different system, with different requirements, and different
risks. It must be treated as such.
