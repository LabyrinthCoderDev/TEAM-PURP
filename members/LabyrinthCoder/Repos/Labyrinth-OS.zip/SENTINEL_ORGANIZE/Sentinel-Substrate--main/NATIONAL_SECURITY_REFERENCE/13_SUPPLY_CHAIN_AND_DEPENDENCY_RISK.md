# 13 — Supply Chain and Dependency Risk

---

## Dependencies That Exist

| Dependency | Role | Risk |
|------------|------|------|
| Python 3.12 | Orchestration runtime | Standard; CVE-tracked |
| Rust (stable) | Enforcement crates | Memory-safe; minimal attack surface |
| Z3 (z3-solver) | Formal verification | Read-only proof checking; no execution path |
| Hypothesis | Property-based testing | Test-time only; no production path |
| SQLite | Episodic memory index | Standard; file-level; no network |
| hashlib (stdlib) | WORM ledger chain | Standard library; no external dependency |
| fcntl (stdlib) | File locking | Standard library; OS-level |

**No cloud dependencies. No API keys required for the enforcement substrate.
No network connections in the enforcement path.**

---

## API Dependencies (Mock Path Only)

| Provider | Used For | Risk |
|----------|----------|------|
| Anthropic API | Live LLM inference (A010, not yet connected) | Data exposure on connect |
| OpenAI API | Alternative backend (mock path) | Data exposure on connect |
| Ollama | Local model backend | Lower risk — local only |

These are not present in the enforcement substrate. They are in the
inference layer (`runtime/ignition.py`) and are currently mock-only.

When A010 connects real inference:
- API key management must be audited
- Data passed to the API must be classified and approved
- Response data must be treated as untrusted input to the gate
- Rate limiting and error handling must be hardened

---

## AI-Assisted Development Risk

This project was built with AI assistance (Claude, GPT, DeepSeek used
for review and architectural feedback). This creates specific risks:

**AI-generated code risks:**
- Subtle bugs that pass review but have security implications
- Dependency recommendations that introduce unnecessary attack surface
- Plausible-sounding but incorrect security patterns

**Mitigations applied:**
- Every AI suggestion reviewed by the builder before integration
- Property-based tests (Hypothesis) run against gate logic
- Z3 proofs verify threshold consistency independently of any AI suggestion
- External reviewers (including the GPT security analysis) are treated as
  input, not authority

**What must never happen:**
- Auto-merge of AI-generated patches without human review
- AI-generated credentials, keys, or signing material
- AI-generated threshold values without Z3 verification
- AI-generated ledger entries treated as authentic

---

## Package Pinning Requirements

For any production deployment:

1. All Python dependencies must be pinned to exact versions with hash verification
2. All Rust crates must be pinned in `Cargo.lock`
3. Dependency updates must be reviewed and tested before deployment
4. No unpinned or floating dependencies in the enforcement path

---

## Hardware Supply Chain (A014)

When hardware enforcement is implemented (ATECC608B, FPGA):

- Hardware must be sourced from audited suppliers
- Firmware on hardware components must be verified before deployment
- Hardware signing keys must be generated on the device, never transmitted
- Physical access controls must be documented

---

## Recommended Supply Chain Controls

1. **Dependency audit** — review all transitive dependencies, not just
   direct dependencies

2. **SBOM (Software Bill of Materials)** — maintain a complete record of
   all software components and their versions

3. **Reproducible builds** — ensure the build process produces identical
   output given identical inputs

4. **Integrity verification** — verify checksums of all dependencies
   before installation

5. **Isolated build environment** — build the system in an environment
   that cannot be modified by external code execution

6. **No runtime package installation** — production deployments must not
   install packages at runtime
