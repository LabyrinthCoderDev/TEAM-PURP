# AUTHORITY — Labyrinth-OS

One job per layer. No layer does two things.

---

## Decision Authority Table

| Layer | File(s) | One Job | What It Cannot Do |
|-------|---------|---------|-------------------|
| **Labeling** | `lane1/05_epistemic_labeler/` | Classify inputs as UNKNOWN/EXPERIMENTAL/VALIDATED/etc | Cannot promote. Cannot execute. Cannot modify PipelineTrace. |
| **Promotion** | `lane1/08_promotion_protocol/promotion_protocol.py` | Evaluate maturity — does this candidate meet evidence threshold? | Cannot cross the gate. Cannot execute. Cannot relabel. |
| **Reality Gate** | `lane1/09_reality_gate/reality_gate.py` | Authorize lane crossing — the only crossing point (I4, I5) | Cannot modify the CGIR graph. Cannot label. Cannot log to ledger. |
| **CGIR** | `execution/cgir/cgir_types.py`, `cgir_core.py` | Formalize the execution graph — typed, validated, immutable | Cannot execute. Cannot gate. Cannot decide. |
| **Gate** | `execution/gate/cgir_gate.py`, `guardian_slot.py` | Binary decision: ALLOW or BLOCK. No middle ground. | Cannot mutate state. Cannot label. Cannot promote. |
| **AEGIS/CESK** | `execution/aegis/aegis_cesk.py` | Mutate state — the only thing that changes system state | Cannot gate. Cannot log. Cannot label. |
| **Ledger** | `execution/ledger/hashchain.py`, `receipt.py` | Record what happened — WORM, tamper-evident (I8) | Cannot decide. Cannot gate. Cannot delete. |
| **Replay** | `execution/replay/replay_validator.py` | Verify that past runs are exactly reproducible (I9) | Cannot modify. Cannot decide. Cannot label. |
| **Observability** | `execution/observability/` | Report on what happened — downstream only | Cannot execute. Cannot gate. Cannot promote. |
| **Governance** | `steward/acp1_tracker.py` | Track assumptions and evidence — what do we actually know? | Cannot execute. Cannot decide. |
| **Feedback** | `execution/observability/feedback_loop.py` | Suggest label confidence adjustments based on outcomes | Cannot force promotion. Cannot relabel directly. |
| **Council** | `epistemic/council/council_resolver.py` | Merge watcher signals into one normalized label | Cannot promote. Cannot gate. Cannot execute. |
| **Watcher-A** | `execution/cgir/watcher_a.py` | Internal consistency audit — does the graph make sense? | Cannot decide. Cannot block execution directly. |
| **Watcher-B** | `execution/cgir/watcher_b.py` | Adversarial audit — attack pattern detection | Cannot decide. Cannot block execution directly. |
| **Archive** | `epistemic/archive/memory_store.py` | Immutable append-only memory — nothing is deleted (I10) | Cannot promote. Cannot execute. Cannot modify past entries. |

---

## Gate Precedence (I5)

```
CGIR BLOCK  →  guardian MUST NOT execute  (binding)
CGIR ALLOW  →  necessary but not sufficient; guardian may still BLOCK/KILL
To execute:   CGIR ALLOW  AND  GuardianSlot EXECUTE
To stop:      CGIR BLOCK   OR  GuardianSlot BLOCK/KILL
```

---

## What Decides Execution

The question "who decides if something executes?" has one answer:

1. `cgir_gate.py` evaluates the CGIR graph against Sigma Anchors → ALLOW or BLOCK
2. `guardian_slot.py` evaluates sensor readings → EXECUTE, BLOCK, or KILL
3. Both must agree to ALLOW/EXECUTE for anything to run
4. Either can stop execution independently

No other layer can force execution. No other layer can override a BLOCK.

---

## What Is Truth

The ledger is truth. `execution/ledger/hashchain.py` is the WORM record.
If it is not in the ledger, it did not happen as far as the system is concerned.
If the ledger chain is broken, the run is rejected.

---

## What Cannot Be Confused

- **Signals annotate. They do not decide.** Watcher outputs are inputs to Council. Council output is input to Gate. Gate decides.
- **Labels classify. They do not execute.** A VALIDATED label is a necessary condition for execution. It is not sufficient.
- **Observability reports. It does not control.** Drift metrics and anomaly scores feed back to archive and governance. They do not gate future execution directly.
---

## Is Any Watcher Output Binding?

GPT review asked this directly. The answer is: **indirectly, yes. Directly, no.**

Watchers report findings. Council merges findings into a normalized signal.
That signal feeds sensor readings into the gate. The gate evaluates sensor
readings against Sigma Anchor thresholds.

So the chain is:

```
Watcher finding → Council signal → Gate sensor reading → Sigma Anchor check → ALLOW/BLOCK
```

A watcher **can** cause a BLOCK — but only by producing sensor readings that
violate Sigma Anchor thresholds (TAU, CHI, DRIFT, BETTI). A watcher **cannot**
directly force a BLOCK by reporting CRITICAL without a corresponding threshold
violation. This is proven in `tests/unit/test_watcher_council_bounds.py` (P1-P4).

This means: TM-001 detection identifies the attack. Blocking happens only if the
attack produces real threshold violations. Detection ≠ mitigation for attacks
that stay within Sigma Anchor bounds. That is a documented limitation.
