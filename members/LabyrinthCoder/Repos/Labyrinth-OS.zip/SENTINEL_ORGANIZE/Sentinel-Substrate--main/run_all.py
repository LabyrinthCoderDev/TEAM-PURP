# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          run_all.py — Labyrinth-OS / Test Runner
# ----------------------------------------------------------------------------

"""
run_all.py — Labyrinth-OS / Test Runner
========================================
Single entry point. Runs every test suite in dependency order.
Prints a unified receipt at the end.

Usage:
  python run_all.py           — run everything
  python run_all.py --fast    — skip Z3 (slow) and integration tests
  python run_all.py --suite cgir_types  — run one suite by name

Exit code: 0 = all pass, 1 = any failure.

Test order (dependency-ordered — each suite can import from those above it):
  Tier 0  Types and primitives
  Tier 1  Core containers
  Tier 2  Validation + determinism
  Tier 3  Gate + ledger
  Tier 4  Sensors + signal algebra
  Tier 5  Watchers + council
  Tier 6  AEGIS + bridge
  Tier 7  Replay + schema + threat model
  Tier 8  API + logprob bridge
  Tier 9  Ignition unit tests
  Tier 10 Integration + forced failure proof
  Tier Z  Formal (Z3 — slow, skipped with --fast)
"""

from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Add all module subdirectory paths so flat imports resolve correctly.
_SENTINEL = os.path.dirname(os.path.abspath(__file__))
for _subdir in [
    # Epistemic layer
    os.path.join(_SENTINEL, 'epistemic', 'labeling'),
    os.path.join(_SENTINEL, 'epistemic', 'archive'),
    os.path.join(_SENTINEL, 'epistemic', 'classification'),
    os.path.join(_SENTINEL, 'epistemic', 'council'),
    os.path.join(_SENTINEL, 'epistemic', 'logprob-bridge'),
    os.path.join(_SENTINEL, 'epistemic', 'signal-aggregation'),
    os.path.join(_SENTINEL, 'epistemic', 'vector'),
    os.path.join(_SENTINEL, 'epistemic', 'watcher-a'),
    os.path.join(_SENTINEL, 'epistemic', 'watcher-b'),
    # Execution layer
    os.path.join(_SENTINEL, 'execution', 'aegis'),
    os.path.join(_SENTINEL, 'execution', 'cgir'),
    os.path.join(_SENTINEL, 'execution', 'cgir', 'formal'),
    os.path.join(_SENTINEL, 'execution', 'cgir', 'schema'),
    os.path.join(_SENTINEL, 'execution', 'gate'),
    os.path.join(_SENTINEL, 'execution', 'gate'),
    os.path.join(_SENTINEL, 'execution', 'ledger'),
    os.path.join(_SENTINEL, 'execution', 'observability'),
    os.path.join(_SENTINEL, 'execution', 'pre_cgir_gate'),
    os.path.join(_SENTINEL, 'execution', 'reality_gate'),
    os.path.join(_SENTINEL, 'execution', 'replay'),
    os.path.join(_SENTINEL, 'execution', 'replay'),
    os.path.join(_SENTINEL, 'execution', 'runtime'),
    # Promotion, runtime, steward
    os.path.join(_SENTINEL, 'promotion'),
    os.path.join(_SENTINEL, 'runtime'),
    os.path.join(_SENTINEL, 'steward'),
    # Tests (flat + subdirs)
    os.path.join(_SENTINEL, 'tests'),
    os.path.join(_SENTINEL, 'tests', 'adversarial'),
    os.path.join(_SENTINEL, 'tests', 'determinism'),
    os.path.join(_SENTINEL, 'tests', 'epistemic'),
    os.path.join(_SENTINEL, 'tests', 'integration'),
    os.path.join(_SENTINEL, 'tests', 'unit'),
    os.path.join(_SENTINEL, 'tests', 'watcher-council'),
    # Lane 1 modules
    os.path.join(_SENTINEL, 'lane1', '00_boot_manifest'),
    os.path.join(_SENTINEL, 'lane1', '01_user_intent'),
    os.path.join(_SENTINEL, 'lane1', '02_mode_router'),
    os.path.join(_SENTINEL, 'lane1', '03_creative_zone'),
    os.path.join(_SENTINEL, 'lane1', '04_analytical_core'),
    os.path.join(_SENTINEL, 'lane1', '05_epistemic_labeling'),
    os.path.join(_SENTINEL, 'lane1', '06_archive_memory'),
    os.path.join(_SENTINEL, 'lane1', '07_deferred_exploration'),
    os.path.join(_SENTINEL, 'lane1', '08_promotion_protocol'),
    os.path.join(_SENTINEL, 'lane1', '09_reality_gate'),
    os.path.join(_SENTINEL, 'epistemic', 'archive'),
]:
    if os.path.isdir(_subdir) and _subdir not in sys.path:
        sys.path.insert(0, _subdir)


# ── TEST REGISTRY ─────────────────────────────────────────────────────────────
# (tier, module_name, description, skip_if_fast)

SUITES = [
    # Tier 0 — Types
    (0,  "cgir_types",               "CGIR types + dataclasses",          False),
    # Tier 1 — Core
    (1,  "cgir_core",                "CGIR graph container",               False),
    (1,  "receipt",                  "WORM receipt",                       False),
    (1,  "hashchain",                "SHA-256 append-only chain",          False),
    # Tier 2 — Validation + determinism
    (2,  "cgir_validator",           "CGIR graph validator",               False),
    (2,  "cgir_determinism",         "Canonical hash + ordering",          False),
    (2,  "cgir_schema",              "Proposal schema gate",               False),
    # Tier 3 — Gate + ledger
    (3,  "cgir_gate",                "Pure gate (I2, I5)",                 False),
    (3,  "cgir_ledger",              "CGIR WORM ledger",                   False),
    # Tier 4 — Sensors + signal algebra
    (4,  "tau_baseline_generator",   "τ baseline (P0 #2)",                 False),
    (4,  "cgir_signal_algebra",      "Sensor → SignalNode",                False),
    # Tier 5 — Watchers + council
    (5,  "watcher_a",                "Internal consistency auditor",       False),
    (5,  "watcher_b",                "Adversarial auditor",                False),
    (5,  "council_resolver",         "Watcher merge → SignalNode (I4)",    False),
    # Tier 6 — AEGIS + bridge
    (6,  "aegis_cesk",               "LOAD→PROPOSE→CHECK→COMMIT→PROVE",   False),
    (6,  "cgir_guardian_bridge",     "L10→L12 bridge",                    False),
    # Tier 7 — Replay + threat model
    (7,  "replay_validator",         "L14 Replay/Gnosis (I9)",             False),
    (7,  "threat_model",             "TM-001 (11 attack classes)",         False),
    # Tier 8 — API + logprob
    (8,  "logprob_bridge_adapter",   "LogprobMetrics → SensorReadings",   False),
    (8,  "api_adapter",              "Provider-agnostic API adapter",      False),
    (8,  "api_logprob_extractor",    "Provider logprob → LogprobMetrics",  False),
    # Tier 9 — Steward + ignition unit
    (9,  "acp1_tracker",             "ACP-1 assumption register",          False),
    # Lane 1 pipeline modules — 12 modules, 102 tests
    (3,  "user_intent",              "L01 User intent parser (8t)",         False),
    (3,  "mode_router",              "L02 Mode router — CREATIVE/ANALYTICAL/EXECUTION (8t)", False),
    (3,  "creative_zone",            "L03 Creative zone — unbounded generation (8t)", False),
    (3,  "analytical_core",          "L04 Analytical core — structured reasoning (8t)", False),
    (5,  "epistemic_labeler",        "L05 Epistemic labeler — SPECULATIVE/DEFERRED/TRUTH (11t)", False),
    (5,  "epistemic_types",          "L05 Epistemic types — IdeaNode/EpistemicLabel (12t)", False),
    (6,  "archive_memory",           "L06 Archive memory — append-only (10t)", False),
    (7,  "promotion_protocol",       "L08 Promotion protocol — typed receipt/rejection (10t)", False),
    (7,  "reality_gate",             "L09 Reality gate — single crossing point (11t)", False),
    # Tier 10 — Integration + forced failure proof
    (10, "test_full_pipeline",       "End-to-end integration (22 tests)",  True),
    (10, "test_forced_failure",      "Forced failure + replay proof",      True),
    (10, "verify_run",               "Exact-chain replay verifier",         False),
    (10, "test_classification_enforcement", "Adversarial classification tests",   False),
    (10, "test_ignition_enforcement",       "Ignition halt-before-trial proofs", False),
    # Tier Z — Formal verification (slow — ~5s per theorem)
    # Classification layer (artifact state machine)
    (4,  "artifact_state",           "Artifact state machine",               False),
    (4,  "classifier",               "Artifact classifier",                  False),
    (4,  "enforcement",              "Classification enforcement engine",     False),
    (4,  "transition_rules",         "Artifact transition rules",            False),
    # Sigma Anchors (single source of truth)
    (4,  "sigma_anchors",            "Sigma Anchor constants (Z3 proven)",   False),
    # Guardian slot (final execution gate)
    (7,  "guardian_slot",            "Guardian slot — final EXECUTE/BLOCK",  False),
    (7,  "deferred_node",            "Deferred exploration + mutation engine", False),
    (8,  "test_hybrid_enforcement",       "Hybrid: healing + gate concurrent",    False),
    (9,  "test_property_based",  "Property-based proofs P1-P10 (Hypothesis)", True),   # skip_fast — Hypothesis not installed in all envs
    (9,  "test_chronicle_dedicated",  "Chronicle JSONL+index dedicated suite", False),
    (9,  "test_guardian_bridge_dedicated",  "Guardian bridge: chi aggregate + layer tests", False),
    (9,  "test_sigma_boundary_sweep",  "Sigma anchor boundary sweep at every threshold", False),
    (9,  "test_rust_python_differential",  "Rust/Python differential parity (GAP R4)", False),
    (9,  "test_domain_adapter_contracts",  "Domain adapter contracts: 5 domains", False),
    (9,  "test_z3_extensions",  "Z3 proof extensions: chi aggregate + bounds", False),
    (9,  "test_deferred_node_convergence",  "Deferred node: convergence + mutation bounds", False),
    (8,  "test_persistent_memory_store", "PersistentMemoryStore: SQLite + similarity + risk", False),
    (7,  "boot_manifest",            "Boot manifest self-checks",             False),
    # Epistemic labeling
    (5,  "label_validator",          "Label record validator",               False),
    (5,  "confidence_meter",         "Confidence scoring engine",            False),
    # Epistemic archive
    (5,  "memory_store",             "Append-only epistemic memory store",   False),
    (5,  "confidence_record",        "Label confidence accuracy tracker",    False),
    (5,  "pattern_catalog",          "Pattern index and catalog",            False),
    (5,  "recall_protocol",          "Archive recall protocol",              False),
    # Promotion pipeline
    (6,  "promotion_rules",          "Promotion rules and decisions",        False),
    (6,  "audit_trail",              "Immutable promotion audit trail",      False),
    (6,  "rollback_protocol",        "Promotion rollback protocol",          False),
    # Pre-CGIR gate modules
    (7,  "gate_function",            "Pre-CGIR gate function",               False),
    (7,  "gate_binding",             "Gate binding rule checker",            False),
    (7,  "gate_proof",               "Gate proof issue and verify",          False),
    (7,  "gate_rejection",           "Gate rejection tracker",               False),
    # Observability layer
    (8,  "observability_tests",      "Observability layer (unittest)",       False),
    # Epistemic test suites (unittest-wrapped)
    (5,  "labeling_tests",           "Labeling layer full suite (40t)",      False),
    (5,  "archive_tests",            "Archive layer full suite (37t)",       False),
    (5,  "label_schema",             "Label schema types and records",       False),
    # Promotion test suites
    (6,  "promotion_tests",          "Promotion rules full suite (44t)",     False),
    (6,  "test_harness",             "Promotion test harness",               False),
    # Pre-CGIR gate full suite
    (7,  "reality_gate_tests",       "Reality gate full suite (35t)",        False),
    # Epistemic tests (tests/ directory)
    (5,  "test_labeling",                "Epistemic labeling tests",             False),
    (5,  "test_archive",                 "Epistemic archive tests",              False),
    (5,  "test_promotion",               "Epistemic promotion tests",            False),
    (5,  "test_observability",           "Epistemic observability tests",        False),
    (5,  "test_epistemic_boundary",      "Epistemic boundary tests",             False),
    # Integration tests
    (8,  "test_labeling_to_reality_gate","Integration: labeling → gate",         False),
    (8,  "test_observability_to_archive","Integration: observability → archive",  False),
    (5,  "chunk_store",              "Compressed archive + hot index",       False),
    (8,  "a010_monitor",            "A010 signal watcher",                  False),
    # Anti-staleness script (self-tests only — not the full runner)
    (2,  "update_docs",              "Doc update script (self-tests)",       False),
    # Cross-language parity (Rust == Python)
    # Observability layer (L19) — anomaly, metrics, drift, feedback
    (7,  "anomaly_log",              "Anomaly log (8t)",                     False),
    (7,  "metrics",                  "Metrics collector (10t)",              False),
    (7,  "drift_detector",           "Drift detector (8t)",                  False),
    (7,  "feedback_loop",            "Feedback loop (8t)",                   False),
    # End-to-end feedback loop proof
    # New modules from integration batch
    (6,  "chronicle_query",        "Chronicle query layer + DreamJournal (8t)",  False),
    (6,  "acbf_vm",               "ACBF/ITV deterministic reference VM (5t)",   False),
    (6,  "itv_vectors",           "ITV canonical test vectors (5t)",             False),
    (6,  "breakout_harness",      "Adversarial breakout harness (5t)",           False),
    # GPT audit structural fixes
    (4,  "promotion_receipt",           "PromotionReceipt typed artifact (7t)", False),
    (4,  "unlabeled_proposal",          "UnlabeledProposal typed artifact (6t)", False),
    (5,  "test_watcher_council_bounds", "Watcher→Council bounds P1-P4 (5t)",   False),
    (3,  "test_feedback_loop_e2e",    "Feedback loop e2e (7t)",               False),
    (9,  "test_rust_python_parity",  "Rust/Python parity proofs",            False),
    # Ignition launcher
    (8,  "run_ignition",             "Ignition launcher Option A/B",         False),
    # Pipeline wire + CI gaps (Lane 1 enforcement proofs)
    (3,  "pipeline_wire",            "PipelineTrace ordering proofs (17t)",  False),
    (3,  "test_ci_gaps",             "CI gap enforcement tests (18t)",       False),
    # Ignition session runner
    (8,  "ignition",                 "Ignition session (9t)",                False),
    (99, "z3_sovereignty_spec",      "Z3 sovereignty spec (A021 [REAL])",  True),
    (99, "z3_promotion_proof",       "Z3 promotion rule proofs PR1-PR8",  True),
    (99, "z3_predicate_proof",       "Z3 predicate invariant proofs PP1-PP9", True),
    (99, "z3_mutation_proof",        "Z3 directional mutation consistency MD1-MD6", True),
    # Explicit invariant coverage — I12, I13, I16, I19
    (8,  "test_invariants_i12_i13_i16_i19", "Invariant tests: archive, observability, gate upgrade, isolation", False),
    # Determinism + watcher-council adversarial
    (7,  "test_determinism",          "Determinism proofs (I2, I8)",         False),
    (7,  "test_watcher_council",      "Watcher-Council adversarial (I4,I7)", False),
    # Zero-day response modules (May 2026)
    (9,  "predicate_extractor",       "Logical Sentinel — predicate Z3 layer (20t)", False),
    (9,  "acp1_dependency_graph",     "ACP-1 collapse propagation graph (13t)",      False),
    # Constitutional deadlock resolution
    (9,  "circuit_breaker",           "Circuit breaker + degradation detector (13t)", False),
    # Epistemic + Lane 1 modules (from Quillan extraction, built natively)
    (6,  "epistemic_class",           "TCP truth-class schema (17t)",                False),
    (6,  "meta_goal_engine",          "Meta-goal engine — driver layer (14t)",       False),
    (6,  "domain_reasoning_profiles", "Domain reasoning profiles (14t)",             False),
    (6,  "cue_pattern_miner",         "Cue pattern miner — replay learning (22t)",   False),
    (6,  "continuous_learning_loop",  "Continuous learning loop wiring (12t)",       False),
    (6,  "boot_preflight",            "Boot manifest preflight integration (8t)",    False),
    # Tier 6 — Annunimas cross-pollination (new capabilities)
    (6,  "test_trial_reflection",        "TrialReflection — lessons from trials (15t)",         False),
    (6,  "test_retention_policy",        "RetentionPolicy — ledger entry retention (11t)",      False),
    (6,  "test_contract_version",        "Contract version — schema versioning (7t)",           False),
    (6,  "test_sensor_gate_and_permits", "BoundedSensorGate + MerklePermitSet integration (11t)", False),
    (6,  "test_check_consistency",       "Artifact consistency checker — drift detection (9t)",   False),
    (6,  "test_open_assumptions",         "A015/A016/A018/A020 assumption closure (42t+5 int)",    False),
    (6,  "test_registry_and_sync",        "Component registry + truth sync (10t)",                False),
    (6,  "test_sync_truth_standalone",    "sync_truth.py self-tests (4t)",                        False),
    (6,  "test_roadmap_items",            "tally + JouleWork + RSI + routers + injection + drift + dead_end (80t)",   False),
    (6,  "test_triad_intent_check",       "Triad intent check -- Sun Tzu axis (12t)",              False),
    (6,  "test_input_provenance",         "Input Constitution IC-1/IC-2 provenance depth (17t)", False),
    # Tier 6 — 777b Integration (Z3-dependent suites skip if Z3 unavailable)
    (6,  "test_vc_export",              "VC export — W3C Verifiable Credentials (13t)",  False),
    (6,  "test_hybrid_solver",          "Hybrid solver — Z3+Kissat+DRAT (9t)",            True),
    (6,  "test_logical_sentinel_cache", "Logical sentinel cache — LRU+Z3 (12t)",          True),
    (6,  "test_z3_proof_utils",         "Z3 proof utils — inspection+export (9t)",        True),
]


def run_suite(module_name: str) -> tuple[int, int, float, str]:
    """
    Run one test suite. Returns (passed, failed, elapsed_ms, error_detail).
    error_detail is empty string on success, exception message on failure.
    """
    t0 = time.perf_counter()
    try:
        mod = importlib.import_module(module_name)
        if not hasattr(mod, "run_tests"):
            return 0, 0, 0.0, ""
        result = mod.run_tests()
        # run_tests() returns (passed, failed, details_list)
        # details_list items may be (name, status, error) tuples
        p, f = result[0], result[1]
        details = result[2] if len(result) > 2 else []
        elapsed = (time.perf_counter() - t0) * 1000
        return p, f, elapsed, ""
    except Exception as exc:
        import traceback
        elapsed = (time.perf_counter() - t0) * 1000
        detail = f"{type(exc).__name__}: {exc}"
        return 0, 1, elapsed, detail


def _syntax_check_all_python() -> tuple[int, int]:
    """
    Parse every .py file with ast.parse before running any tests.
    Returns (passed, failed). Exits on any failure.
    """
    import ast
    passed = failed = 0
    broken = []
    scan_root = _SENTINEL
    for root, dirs, files in os.walk(scan_root):
        dirs[:] = [d for d in dirs
                   if d not in ('__pycache__', 'target', '.git')]
        for f in files:
            if not f.endswith('.py'): continue
            path = os.path.join(root, f)
            try:
                with open(path, errors='replace') as fh:
                    ast.parse(fh.read())
                passed += 1
            except SyntaxError as e:
                failed += 1
                rel = os.path.relpath(path, scan_root)
                broken.append(f"{rel}: {e}")
    for b in broken:
        print(f"  ✗ SYNTAX ERROR: {b}")
    return passed, failed


def main(argv=None):
    parser = argparse.ArgumentParser(description="Labyrinth-OS Test Runner")
    parser.add_argument("--fast",  action="store_true",
                        help="Skip Z3 and integration tests")
    parser.add_argument("--suite", default=None,
                        help="Run only this suite (module name)")
    parser.add_argument("--json",  default=None,
                        help="Write JSON report to this path")
    opts = parser.parse_args(argv)

    print("=" * 70)
    print("LABYRINTH-OS — FULL TEST SUITE")  # @LabyrinthCoder
    print("=" * 70)
    print()

    suites_to_run = SUITES
    if opts.suite:
        suites_to_run = [s for s in SUITES if s[1] == opts.suite]
        if not suites_to_run:
            print(f"  ERROR: Suite '{opts.suite}' not found.")
            print(f"  Available: {[s[1] for s in SUITES]}")
            return 1

    total_p = total_f = 0
    current_tier = -1
    results = []
    wall_start = time.time()

    # Step 0: syntax check all Python files before running any tests
    syn_pass, syn_fail = _syntax_check_all_python()
    if syn_fail:
        print(f"  ✗ SYNTAX ERRORS: {syn_fail} files cannot be parsed. Fix before running tests.")
        sys.exit(1)
    else:
        print(f"  ✓ Syntax: {syn_pass} Python files parse cleanly")
    print()

    for tier, name, desc, skip_fast in suites_to_run:
        if opts.fast and skip_fast:
            print(f"  SKIP  {name:35} (--fast)")
            results.append({"suite": name, "status": "SKIPPED", "passed": 0, "failed": 0})
            continue

        if tier != current_tier:
            current_tier = tier
            tier_label = "FORMAL" if tier == 99 else f"TIER {tier}"
            print(f"\n  ── {tier_label} ──")

        p, f, ms, err_detail = run_suite(name)
        total_p += p; total_f += f
        mark = "✓" if f == 0 else "✗"
        status = "PASS" if f == 0 else "FAIL"
        print(f"  {mark} {name:35} {p:3}/{p+f:<3}  {ms:6.0f}ms  {desc}")
        if f > 0 and err_detail:
            print(f"      ERROR: {err_detail}")
        results.append({"suite": name, "status": status,
                         "passed": p, "failed": f, "ms": round(ms),
                         "error": err_detail})

    wall_ms = (time.time() - wall_start) * 1000

    print(f"\n{'─'*70}")
    print(f"  TOTAL:  {total_p} passed  /  {total_f} failed  "
          f"/  {total_p+total_f} tests  ({wall_ms/1000:.1f}s)")
    print(f"{'─'*70}")

    # Receipt
    receipt_payload = json.dumps({
        "total_passed": total_p,
        "total_failed": total_f,
        "suites": results,
    }, sort_keys=True, separators=(",", ":"))
    receipt_hash = hashlib.sha256(receipt_payload.encode()).hexdigest()
    print(f"\n  Receipt: {receipt_hash[:32]}…")

    if opts.json:
        with open(opts.json, "w") as jf:
            json.dump({"receipt_hash": receipt_hash,
                       "total_passed": total_p,
                       "total_failed": total_f,
                       "suites": results}, jf, indent=2)
        print(f"  Report:  {opts.json}")

    # ── RUST TIER (cargo test --workspace) ───────────────────────────────────
    rust_p = rust_f = 0
    if not opts.fast:
        import shutil as _shutil, subprocess as _sp, re as _re
        if not _shutil.which('cargo'):
            print("  · Rust (cargo test): SKIP — cargo not in PATH (249 tests not run)")
        else:
            # crates/ lives alongside run_all.py — use _SENTINEL which is already set
            _sentinel = _SENTINEL
            if os.path.isdir(os.path.join(_sentinel, 'crates')):
                _r = _sp.run(['cargo', 'test', '--workspace', '--quiet'],
                             cwd=_sentinel, capture_output=True, text=True)
                rust_p = sum(int(m) for m in _re.findall(r'(\d+) passed', _r.stdout))
                rust_f = sum(int(m) for m in _re.findall(r'(\d+) failed', _r.stdout))
                _sym = "✓" if rust_f == 0 else "✗"
                print(f"  {_sym} {'Rust (cargo test)':40} {rust_p}/{rust_p+rust_f}")
                if rust_f > 0:
                    print(_r.stdout[-400:])
                    total_f += rust_f
            else:
                print("  · Rust (cargo test): SKIP — crates/ not found")

    grand_p = total_p + rust_p
    grand_f = total_f + rust_f

    if grand_f == 0:
        print(f"\n  ✓ ALL TESTS PASS  (Python: {total_p}  Rust: {rust_p}  Total: {grand_p})")
    else:
        failed_suites = [r["suite"] for r in results if r["status"] == "FAIL"]
        print(f"\n  ✗ FAILURES in: {failed_suites}")

    print(f"\n{'='*70}")
    return 0 if grand_f == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
