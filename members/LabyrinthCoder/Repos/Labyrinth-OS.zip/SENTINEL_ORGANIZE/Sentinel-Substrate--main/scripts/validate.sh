#!/usr/bin/env bash
set -euo pipefail

CGIR="${1:-}"

if [ -z "$CGIR" ]; then
    echo "Usage: $0 <cgir-path>"
    exit 1
fi

echo "Validating CGIR: $CGIR"
# TODO: cargo run -p cgir-validator -- --input "$CGIR"
echo "Validation not yet implemented. See crates/cgir-validator/."
