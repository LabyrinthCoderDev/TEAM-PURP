#!/usr/bin/env bash
set -euo pipefail

LEDGER="${1:-}"

if [ -z "$LEDGER" ]; then
    echo "Usage: $0 <ledger-path>"
    exit 1
fi

echo "Replaying from ledger: $LEDGER"
# TODO: cargo run -p replay-gnosis -- --ledger "$LEDGER"
echo "Replay not yet implemented. See crates/replay-gnosis/."
