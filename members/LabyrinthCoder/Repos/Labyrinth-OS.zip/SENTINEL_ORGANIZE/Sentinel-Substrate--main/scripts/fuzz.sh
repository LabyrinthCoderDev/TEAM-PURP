#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-}"

if [ -z "$TARGET" ]; then
    echo "Usage: $0 <fuzz-target>"
    echo "Available targets: see fuzz/targets/"
    exit 1
fi

echo "Running fuzzer target: $TARGET"
# TODO: cargo +nightly fuzz run "$TARGET"
echo "Fuzzing requires nightly Rust. See fuzz/targets/ for target definitions."
