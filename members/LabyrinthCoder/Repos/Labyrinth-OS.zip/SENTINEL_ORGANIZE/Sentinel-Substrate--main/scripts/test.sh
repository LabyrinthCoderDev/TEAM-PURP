#!/usr/bin/env bash
set -euo pipefail

echo "Running LABYRINTH-OS test suite..."
cargo test --workspace

echo "Tests complete."
