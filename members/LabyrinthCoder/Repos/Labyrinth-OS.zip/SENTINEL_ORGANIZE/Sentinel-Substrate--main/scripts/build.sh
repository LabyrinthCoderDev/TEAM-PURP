#!/usr/bin/env bash
set -euo pipefail

echo "Building LABYRINTH-OS workspace..."
cargo build --workspace

echo "Build complete."
