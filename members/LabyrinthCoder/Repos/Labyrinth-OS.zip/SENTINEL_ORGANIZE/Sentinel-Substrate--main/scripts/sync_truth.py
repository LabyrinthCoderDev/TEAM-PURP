# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          sync_truth.py — Labyrinth-OS / Scripts
# ----------------------------------------------------------------------------

"""
sync_truth.py — Labyrinth-OS / Scripts
========================================
Cross-Document Truth Synchronizer

GPT external review (June 2026):
  "You've reached the point where mistakes are more likely to come from
  humans updating one file and forgetting another than from broken Python."

This script checks that the key facts stated across multiple documents
all agree with each other:

  COMPONENT_REGISTRY.json  — component status and dependencies
  SYSTEM_REPORT.json       — test counts and file counts
  KNOWN_GAPS.md            — gap status (WIRED/PARTIAL/OPEN)
  steward/acp1_tracker.py  — assumption status (VERIFIED/PARTIAL/OPEN)
  run_all.py               — registered test suites

Usage
-----
    python3 scripts/sync_truth.py
    python3 scripts/sync_truth.py --report   # show full detail

Exit codes
----------
    0 — all sources agree
    1 — inconsistencies found
"""

from __future__ import annotations

import argparse
import ast
import json
import re
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple


def _find_root() -> Path:
    here = Path(__file__).resolve()
    for parent in [here, *here.parents]:
        if (parent / "run_all.py").exists():
            return parent
    raise FileNotFoundError("Cannot find repo root")


@dataclass
class SyncIssue:
    severity:   str    # "ERROR" | "WARNING" | "INFO"
    source_a:   str
    source_b:   str
    claim_a:    str
    claim_b:    str
    field:      str


@dataclass
class SyncResult:
    issues:     List[SyncIssue] = field(default_factory=list)
    checks_run: int = 0

    @property
    def errors(self): return [i for i in self.issues if i.severity == "ERROR"]
    @property
    def warnings(self): return [i for i in self.issues if i.severity == "WARNING"]
    @property
    def passed(self): return len(self.errors) == 0


def _load_registry(root: Path) -> Optional[dict]:
    p = root / "COMPONENT_REGISTRY.json"
    if not p.exists(): return None
    return json.loads(p.read_text())


def _load_system_report(root: Path) -> Optional[dict]:
    p = root / "SYSTEM_REPORT.json"
    if not p.exists(): return None
    return json.loads(p.read_text())


def _load_acp1_status(root: Path) -> dict:
    """Load ACP-1 assumption statuses from acp1_tracker.py."""
    try:
        steward = str(root / "steward")
        if steward not in sys.path:
            sys.path.insert(0, steward)
        root_str = str(root)
        if root_str not in sys.path:
            sys.path.insert(0, root_str)
        # Remove cached version to force fresh import
        for key in list(sys.modules.keys()):
            if 'acp1_tracker' in key:
                del sys.modules[key]
        import acp1_tracker as acp_mod
        return {a.id: a.status.value for a in acp_mod.ASSUMPTIONS}
    except Exception as e:
        print(f"  Warning: could not load acp1_tracker: {e}")
        return {}


def _load_known_gaps(root: Path) -> dict:
    """Extract gap statuses from KNOWN_GAPS.md."""
    p = root / "KNOWN_GAPS.md"
    if not p.exists(): return {}
    content = p.read_text()
    gaps = {}
    for line in content.split("\n"):
        m = re.match(r"\|\s*(GAP\s*\d+)[^|]*\|[^|]*\|[^|]*\|([^|]*WIRED[^|]*|[^|]*PARTIAL[^|]*|[^|]*OPEN[^|]*)\|", line, re.IGNORECASE)
        if m:
            gap_id = m.group(1).strip().replace(" ", "_")
            status_text = m.group(2).strip().upper()
            if "WIRED" in status_text: status = "WIRED"
            elif "PARTIAL" in status_text: status = "PARTIAL"
            else: status = "OPEN"
            gaps[gap_id] = status
    return gaps


def _count_registered_suites(root: Path) -> int:
    content = (root / "run_all.py").read_text()
    return len(re.findall(r'\(\d+,\s*"[^"]+"\s*,', content))


def run_sync(root: Path, verbose: bool = False) -> SyncResult:
    result = SyncResult()

    registry = _load_registry(root)
    report   = _load_system_report(root)
    acp1     = _load_acp1_status(root)
    gaps     = _load_known_gaps(root)
    suite_count = _count_registered_suites(root)

    print("=== CROSS-DOCUMENT TRUTH SYNC ===\n")

    # ── Check 1: SYSTEM_REPORT python file count vs actual ────────────────────
    if report:
        reported_py = report.get("files", {}).get("python", 0)
        actual_py = len([f for f in root.rglob("*.py")
                         if "__pycache__" not in str(f)])
        result.checks_run += 1
        if abs(reported_py - actual_py) > 2:
            result.issues.append(SyncIssue(
                severity="WARNING",
                source_a="SYSTEM_REPORT.json",
                source_b="filesystem",
                claim_a=f"python={reported_py}",
                claim_b=f"actual={actual_py}",
                field="python_file_count",
            ))
            print(f"  ⚠ Python count: report={reported_py} actual={actual_py}")
        else:
            print(f"  ✓ Python file count: {reported_py} (±2 tolerance)")

    # ── Check 2: SYSTEM_REPORT suite count vs run_all.py ─────────────────────
    if report:
        reported_suites = report.get("test_status", {}).get("suites_registered", 0)
        result.checks_run += 1
        if abs(reported_suites - suite_count) > 1:
            result.issues.append(SyncIssue(
                severity="ERROR",
                source_a="SYSTEM_REPORT.json",
                source_b="run_all.py",
                claim_a=f"suites={reported_suites}",
                claim_b=f"actual={suite_count}",
                field="suites_registered",
            ))
            print(f"  ✗ Suite count: report={reported_suites} run_all={suite_count}")
        else:
            print(f"  ✓ Suite count: {suite_count}")

    # ── Check 3: Registry component files exist ────────────────────────────────
    if registry:
        missing = []
        for comp in registry["components"]:
            f = root / comp["file"]
            if not f.exists() and not comp["file"].endswith(".toml"):
                missing.append(comp["file"])
        result.checks_run += 1
        if missing:
            for m in missing:
                result.issues.append(SyncIssue(
                    severity="ERROR",
                    source_a="COMPONENT_REGISTRY.json",
                    source_b="filesystem",
                    claim_a=f"file={m}",
                    claim_b="NOT FOUND",
                    field="component_file",
                ))
            print(f"  ✗ Missing component files: {missing}")
        else:
            print(f"  ✓ All {len(registry['components'])} registry component files exist")

    # ── Check 4: ACP-1 tracker assumption count ────────────────────────────────
    if acp1:
        result.checks_run += 1
        if len(acp1) != 22:
            result.issues.append(SyncIssue(
                severity="WARNING",
                source_a="acp1_tracker.py",
                source_b="expected",
                claim_a=f"assumptions={len(acp1)}",
                claim_b="expected=22",
                field="assumption_count",
            ))
            print(f"  ⚠ ACP-1 assumption count: {len(acp1)} (expected 22)")
        else:
            from collections import Counter
            counts = Counter(acp1.values())
            print(f"  ✓ ACP-1: {counts.get('VERIFIED',0)}V "
                  f"{counts.get('PARTIAL',0)}P {counts.get('OPEN',0)}O / 22")

    # Check 4b: registry component count matches expected minimum
    if registry:
        result.checks_run += 1
        comp_count = len(registry.get("components", []))
        if comp_count < 29:
            result.issues.append(SyncIssue(
                severity="WARNING",
                source_a="COMPONENT_REGISTRY.json",
                source_b="expected",
                claim_a=f"components={comp_count}",
                claim_b="expected>=29",
                field="registry_component_count",
            ))
            print(f"  ⚠ Registry component count: {comp_count} (expected >=29)")
        else:
            print(f"  ✓ Registry component count: {comp_count}")

    # ── Check 5: Registry partial components match ACP-1 partial assumptions ──
    if registry and acp1:
        result.checks_run += 1
        reg_partial_gates = set()
        for comp in registry["components"]:
            if comp["status"] == "partial":
                reg_partial_gates.update(comp.get("acp1_gates", []))

        acp1_partial = {aid for aid, status in acp1.items() if status == "PARTIAL"}
        acp1_open    = {aid for aid, status in acp1.items() if status == "OPEN"}

        unresolved = reg_partial_gates - acp1_partial - acp1_open
        if unresolved:
            result.issues.append(SyncIssue(
                severity="WARNING",
                source_a="COMPONENT_REGISTRY.json",
                source_b="acp1_tracker.py",
                claim_a=f"partial gates={reg_partial_gates}",
                claim_b=f"acp1_partial={acp1_partial}",
                field="partial_gate_alignment",
            ))
            print(f"  ⚠ Registry references ACP-1 gates not PARTIAL/OPEN: {unresolved}")
        else:
            print(f"  ✓ Registry partial gates align with ACP-1 status")

    # ── Check 6: Rust crate count ──────────────────────────────────────────────
    if report:
        reported_rust = report.get("files", {}).get("rust_crates", 0)
        actual_rust = len(set(
            p.parent.name for p in root.rglob("crates/*/Cargo.toml")
            if "crates" in str(p)
        ))
        result.checks_run += 1
        if reported_rust != actual_rust:
            result.issues.append(SyncIssue(
                severity="WARNING",
                source_a="SYSTEM_REPORT.json",
                source_b="filesystem",
                claim_a=f"rust_crates={reported_rust}",
                claim_b=f"actual={actual_rust}",
                field="rust_crate_count",
            ))
            print(f"  ⚠ Rust crate count: report={reported_rust} actual={actual_rust}")
        else:
            print(f"  ✓ Rust crate count: {actual_rust}")

    return result


def print_result(result: SyncResult, verbose: bool = False) -> int:
    print(f"\n  Checks run: {result.checks_run}")
    if result.passed:
        print("  ✓ ALL SOURCES CONSISTENT")
        return 0
    else:
        print(f"  ✗ {len(result.errors)} errors, {len(result.warnings)} warnings")
        if verbose:
            for issue in result.issues:
                print(f"    [{issue.severity}] {issue.field}: "
                      f"{issue.source_a}={issue.claim_a} "
                      f"vs {issue.source_b}={issue.claim_b}")
        return 1


def run_tests():
    passed = failed = 0
    tests = [
        _test_registry_loads,
        _test_report_loads,
        _test_sync_runs,
        _test_sync_passes_on_clean_repo,
    ]
    for fn in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {fn.__name__}: {e}")
    return passed, failed, []


def _test_registry_loads():
    root = _find_root()
    data = _load_registry(root)
    assert data is not None
    assert "components" in data
    assert len(data["components"]) > 0


def _test_report_loads():
    root = _find_root()
    data = _load_system_report(root)
    assert data is not None
    assert "test_status" in data


def _test_sync_runs():
    root = _find_root()
    result = run_sync(root)
    assert result.checks_run > 0


def _test_sync_passes_on_clean_repo():
    root = _find_root()
    result = run_sync(root)
    # Should have no errors (warnings OK)
    assert len(result.errors) == 0, f"Sync errors: {result.errors}"


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", action="store_true")
    opts = parser.parse_args()
    try:
        root = _find_root()
    except FileNotFoundError as e:
        print(f"Error: {e}")
        sys.exit(2)
    result = run_sync(root, verbose=opts.report)
    sys.exit(print_result(result, verbose=opts.report))
