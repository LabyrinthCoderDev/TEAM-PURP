# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          check_consistency.py — Labyrinth-OS / Scripts
# ----------------------------------------------------------------------------

"""
check_consistency.py — Labyrinth-OS / Scripts
==============================================
Artifact Consistency Checker

Verifies that the three truth sources describing system state
all agree with each other:

  1. run_all.py --fast    — live test count from execution
  2. SYSTEM_REPORT.json  — last recorded test count
  3. Most recent journal — what the last journal entry states

GPT external review (June 2026) identified "packaging drift" as
the core failure mode: documentation says one thing, exported
artifact contains another. This script makes that divergence
immediately visible.

Usage
-----
    python3 scripts/check_consistency.py
    python3 scripts/check_consistency.py --skip-live   # report vs journal only

Exit codes
----------
    0 — all sources agree
    1 — drift detected (details printed)
    2 — cannot run (missing deps)

References
----------
    JOURNAL-48     — GPT review that identified this gap
    SYSTEM_REPORT.json
    KNOWN_GAPS.md  — GAP 13 (input constitution)
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional


def _find_root() -> Path:
    """Walk up from this file to find repo root (contains run_all.py)."""
    here = Path(__file__).resolve()
    for parent in [here, *here.parents]:
        if (parent / "run_all.py").exists():
            return parent
    raise FileNotFoundError("Cannot find repo root — run_all.py not found")


@dataclass
class ConsistencyResult:
    live_passed:    Optional[int]
    live_failed:    Optional[int]
    report_passed:  Optional[int]
    report_date:    Optional[str]
    journal_passed: Optional[int]
    issues:         List[str] = field(default_factory=list)

    @property
    def drift_detected(self) -> bool:
        return len(self.issues) > 0

    @property
    def all_sources_present(self) -> bool:
        return all(x is not None for x in
                   [self.live_passed, self.report_passed, self.journal_passed])


def read_live_counts(root: Path):
    """Run run_all.py --fast and parse the TOTAL line."""
    try:
        result = subprocess.run(
            [sys.executable, "run_all.py", "--fast"],
            cwd=root, capture_output=True, text=True, timeout=120,
        )
        for line in result.stdout.split("\n"):
            m = re.search(r"TOTAL:\s+(\d+) passed\s+/\s+(\d+) failed", line)
            if m:
                return int(m.group(1)), int(m.group(2))
        return None, None
    except Exception as e:
        print(f"  Warning: live run failed: {e}")
        return None, None


def read_report(root: Path):
    """Read SYSTEM_REPORT.json."""
    path = root / "SYSTEM_REPORT.json"
    if not path.exists():
        return None, None
    try:
        data = json.loads(path.read_text())
        ts = data.get("test_status", {})
        passed = ts.get("python_pass") or ts.get("total_pass")
        date = data.get("generated_at", "unknown")[:19]
        return int(passed), date
    except Exception:
        return None, None


def read_journal(root: Path):
    """Find the most recent journal and extract its claimed passing count."""
    candidates = []
    # Check common locations
    for search_root in [root, root.parent.parent / "outputs"]:
        if search_root.exists():
            candidates.extend(sorted(search_root.rglob("*JOURNAL*.md"), reverse=True))

    for journal in candidates[:8]:
        content = journal.read_text(errors="replace")
        patterns = [
            r"(\d[,\d]{3,}) passing",
            r"python_pass.*?(\d{4,})",
            r"TOTAL.*?(\d[,\d]+) passed",
            r"Tests?:.*?(\d[,\d]+) passing",
            r"Delta.*?(\d[,\d]+) tests",
        ]
        for pattern in patterns:
            m = re.search(pattern, content)
            if m:
                return int(m.group(1).replace(",", "")), journal.name
    return None, None


def check(root: Path, skip_live: bool = False) -> ConsistencyResult:
    print("=== LABYRINTH-OS CONSISTENCY CHECK ===\n")

    # Live
    live_p = live_f = None
    if not skip_live:
        print("[1] Running test suite --fast ...")
        live_p, live_f = read_live_counts(root)
        if live_p is not None:
            print(f"    Live:   {live_p} passing / {live_f} failing")
        else:
            print("    Live:   COULD NOT READ")
    else:
        print("[1] Live run: SKIPPED (--skip-live)")

    # Report
    print("\n[2] Reading SYSTEM_REPORT.json ...")
    report_p, report_date = read_report(root)
    if report_p is not None:
        print(f"    Report: {report_p} passing  (generated {report_date})")
    else:
        print("    Report: NOT FOUND")

    # Journal
    print("\n[3] Searching recent journals ...")
    journal_p, journal_name = read_journal(root)
    if journal_p is not None:
        print(f"    Journal: {journal_p} passing  ({journal_name})")
    else:
        print("    Journal: not found or unparseable")

    # Compare
    issues = []
    pairs = [
        ("live", live_p, "report", report_p),
        ("live", live_p, "journal", journal_p),
        ("report", report_p, "journal", journal_p),
    ]
    for name_a, val_a, name_b, val_b in pairs:
        if val_a is not None and val_b is not None and val_a != val_b:
            diff = abs(val_a - val_b)
            issues.append(
                f"DRIFT: {name_a}={val_a} vs {name_b}={val_b}  (diff={diff})"
            )

    return ConsistencyResult(
        live_passed=live_p,
        live_failed=live_f,
        report_passed=report_p,
        report_date=report_date,
        journal_passed=journal_p,
        issues=issues,
    )


def print_result(result: ConsistencyResult) -> int:
    print()
    if not result.drift_detected:
        print("  ✓ ALL SOURCES AGREE — no packaging drift detected")
        if not result.all_sources_present:
            print("  ℹ Some sources could not be read — partial check only")
        return 0
    else:
        print("  ✗ PACKAGING DRIFT DETECTED:")
        for issue in result.issues:
            print(f"    → {issue}")
        print()
        print("  To fix:")
        print("    1. python3 run_all.py --fast   (get live count)")
        print("    2. Regenerate SYSTEM_REPORT.json with live count")
        print("    3. Repackage ZIP after regeneration")
        print("    4. Journal must state the live count, not the intended count")
        return 1


def run_tests():
    """Internal self-tests — no external deps required."""
    def _make(live, report, journal):
        issues = []
        pairs = [("live", live, "report", report), ("live", live, "journal", journal),
                 ("report", report, "journal", journal)]
        for na, va, nb, vb in pairs:
            if va is not None and vb is not None and va != vb:
                issues.append(f"DRIFT: {na}={va} vs {nb}={vb}")
        return ConsistencyResult(live, 0, report, "2026-06-04", journal, issues)

    tests = [
        (lambda: not _make(1530, 1530, 1530).drift_detected,   "three_way_agree"),
        (lambda: _make(1530, 1402, 1530).drift_detected,        "stale_report_caught"),
        (lambda: _make(1530, 1530, 1518).drift_detected,        "stale_journal_caught"),
        (lambda: len(_make(1530, 1402, 1518).issues) == 3,      "three_drifts"),
        (lambda: not _make(1530, 1530, None).drift_detected,    "missing_journal_no_false_pos"),
        (lambda: not _make(None, 1530, 1530).drift_detected,    "missing_live_no_false_pos"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            assert fn(), f"assertion failed"
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Labyrinth-OS consistency checker")
    parser.add_argument("--skip-live", action="store_true")
    opts = parser.parse_args()
    try:
        root = _find_root()
    except FileNotFoundError as e:
        print(f"Error: {e}")
        sys.exit(2)
    result = check(root, opts.skip_live)
    sys.exit(print_result(result))
