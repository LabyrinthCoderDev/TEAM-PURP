# DOMAIN_ADAPTER_SPEC.md — Labyrinth-OS

## The Domain Adapter Pattern

The five Sigma Anchor channels (tau, chi, drift, betti_1, confidence) are abstract
variables. Any domain that generates proposals and needs enforcement before execution
can translate its physical measurements into these five channels through a domain adapter.

The gate, ledger, healing loop, and replay mechanism are domain-agnostic.
The domain adapter is the only domain-specific component.

---

## The Five Channels

| Channel | Range | Meaning | High = |
|---------|-------|---------|--------|
| tau_escape | 0.0–1.0 | Escape ratio / system health | Safe |
| chi | 0.0–1.0 | Contradiction / conflict density | Dangerous |
| drift | 0.0–1.0 | Deviation from baseline | Unstable |
| betti_1 | 0.0–1.0 | Topological complexity | Complex |
| confidence | 0.0–1.0 | Evidence weight / certainty | Confident |

**Thresholds (Z3-proven, A021 VERIFIED):**
- tau < 0.75 → BLOCK
- chi > 0.40 → BLOCK
- drift > 0.12 → BLOCK
- betti_1 > 0.045 → BLOCK
- confidence < 0.65 → BLOCK

---

## Domain Adapter Specifications

### 1. AI Governance (current build)

| Channel | Physical Measurement | Notes |
|---------|---------------------|-------|
| tau_escape | Token escape ratio from LLM logprob distribution | Via logprob_bridge_adapter.py |
| chi | Contradiction density between logprob peaks | Via tau_baseline_generator.py |
| drift | Distribution shift from baseline session | Via tau_baseline_generator.py |
| betti_1 | Topological complexity of probability landscape | Via tau_baseline_generator.py |
| confidence | Logprob-derived certainty (capped at 0.65 if logprobs unavailable) | Via api_logprob_extractor.py |

**Status:** Implemented. Closes with A010 (live inference).

---

### 2. Industrial Automation (Phase 10.5)

**Application:** CNC machines, robot arms, process controllers.
A proposal is a G-code command, trajectory, or process parameter change.

| Channel | Physical Measurement | Source |
|---------|---------------------|--------|
| tau_escape | Machine health index (tool wear, spindle load, temperature normalized) | PLC sensors |
| chi | Parameter drift variance (feed rate, speed, pressure vs baseline) | Process historian |
| drift | Deviation of current reading from last 100 readings baseline | Sensor fusion |
| betti_1 | Fault topology complexity (number of active fault codes, graph complexity) | Fault management system |
| confidence | Sensor fusion certainty (agreement across redundant sensors) | Sensor voting system |

**Gate behavior:**
- CNC command exceeding tool-wear limit → low tau → BLOCK
- Robot trajectory violating safety envelope → high drift → BLOCK
- Multiple simultaneous fault codes → high betti_1 → BLOCK

**Status:** Specification only. Requires sensor adapter implementation.

---

### 3. Medical Decision Support (Phase 10.5)

**Application:** Diagnostic proposals, treatment recommendations, medication orders.
A proposal is a diagnostic conclusion or treatment plan.

| Channel | Physical Measurement | Source |
|---------|---------------------|--------|
| tau_escape | Diagnostic certainty score (Bayesian posterior given evidence) | Clinical decision support |
| chi | Treatment conflict density (contraindication count, interaction severity) | Drug interaction DB |
| drift | Protocol deviation (how far proposal is from clinical guidelines) | Clinical pathway engine |
| betti_1 | Symptom graph complexity (number of active diagnoses, interaction complexity) | EHR graph |
| confidence | Evidence weight (number and quality of supporting lab results, imaging) | Evidence aggregator |

**Gate behavior:**
- Drug conflict detected → high chi → BLOCK with FailedProposal logging
- Treatment deviates significantly from protocol → high drift → BLOCK
- Diagnostic certainty below threshold → low tau → BLOCK

**Status:** Specification only. Requires clinical sensor adapter.

---

### 4. Financial Systems (Phase 10.5)

**Application:** Trading algorithms, portfolio management, order execution.
A proposal is a trade order or portfolio adjustment.

| Channel | Physical Measurement | Source |
|---------|---------------------|--------|
| tau_escape | Position confidence (signal strength, model agreement) | Alpha model |
| chi | Portfolio correlation density (concentration risk, factor exposure) | Risk model |
| drift | Market regime shift (VIX delta, correlation regime change) | Market regime classifier |
| betti_1 | Correlation structure complexity (portfolio graph topology) | Covariance matrix |
| confidence | Signal-to-noise ratio of the generating alpha signal | Signal processor |

**Gate behavior:**
- Position exceeds concentration limit → high chi → BLOCK
- Market regime shift detected → high drift → BLOCK
- Signal strength below minimum → low confidence → BLOCK

**Status:** Specification only. Requires financial sensor adapter.

---

### 5. Autonomous Vehicles (Phase 10.5)

**Application:** Trajectory planning, obstacle avoidance, lane changes.
A proposal is a planned trajectory or maneuver.

| Channel | Physical Measurement | Source |
|---------|---------------------|--------|
| tau_escape | Trajectory safety margin (distance from safety envelope boundaries) | Safety monitor |
| chi | Sensor agreement density (LiDAR/camera/radar disagreement) | Sensor fusion |
| drift | Environmental deviation (weather, road condition change from baseline) | Environment classifier |
| betti_1 | Obstacle topology complexity (number of dynamic obstacles, interaction graph) | Scene graph |
| confidence | Perception certainty (detection confidence across all sensors) | Perception system |

**Gate behavior:**
- Trajectory exits safety envelope → low tau → BLOCK
- Sensor disagreement detected → high chi → BLOCK
- KILL decision on safety-critical violations (irrevocable within planning cycle)

**Status:** Specification only. Requires vehicle sensor adapter.

---

## Implementation Template

```python
# domain_adapter_template.py — Labyrinth-OS Domain Adapter
from epistemic.vector.tau_baseline_generator import SensorReadings

class MyDomainAdapter:
    """
    Translate domain-specific measurements into SensorReadings.
    This is the ONLY domain-specific component. Everything else is unchanged.
    """

    def to_sensor_readings(self, domain_data: dict) -> SensorReadings:
        return SensorReadings(
            tau_escape  = self._compute_tau(domain_data),
            chi_vector  = self._compute_chi(domain_data),
            drift_score = self._compute_drift(domain_data),
            betti_1     = self._compute_betti(domain_data),
            confidence  = self._compute_confidence(domain_data),
            source      = "MY_DOMAIN_ADAPTER",
            logical_time= domain_data.get("timestamp", 0.0),
        )

    def _compute_tau(self, data: dict) -> float:
        # Domain-specific: map health/certainty to [0.0, 1.0]
        # High tau = healthy/safe. Low tau triggers BLOCK.
        raise NotImplementedError

    def _compute_chi(self, data: dict) -> float:
        # Domain-specific: map conflict/contradiction to [0.0, 1.0]
        # Low chi = no conflict. High chi triggers BLOCK.
        raise NotImplementedError

    def _compute_drift(self, data: dict) -> float:
        # Domain-specific: map deviation from baseline to [0.0, 1.0]
        raise NotImplementedError

    def _compute_betti(self, data: dict) -> float:
        # Domain-specific: map topology/complexity to [0.0, 1.0]
        raise NotImplementedError

    def _compute_confidence(self, data: dict) -> float:
        # Domain-specific: map evidence strength to [0.0, 1.0]
        raise NotImplementedError
```

---

## Validation Requirements

Every domain adapter must pass the following before production use:

1. All five outputs are in [0.0, 1.0]
2. High-risk inputs produce tau < 0.75 or chi > 0.40 or drift > 0.12
3. Low-risk inputs produce tau > 0.75 and chi < 0.15 and confidence > 0.65
4. The adapter is deterministic: same input always produces same output
5. The adapter fails closed: any exception produces conservative values
   (tau=0.0, chi=1.0, drift=1.0, betti_1=1.0, confidence=0.0) → BLOCK

*X: @LabyrinthCoder*

---

## Adversarial Examples and Fail-Closed Procedures

### Why This Section Exists

The gate is only as good as the domain adapter. A perfectly implemented gate
operating on a miscalibrated adapter produces meaningless enforcement.
For each domain, calibration requires: known adversarial inputs, expected
channel readings, and a defined fail-closed behavior.

### Calibration Standard

Each adapter must specify:
1. **Baseline** — normal operation readings (tau/chi/drift/betti_1/confidence)
2. **Adversarial examples** — inputs that should trigger BLOCK, with expected readings
3. **Edge cases** — inputs near threshold that could go either way
4. **Fail-closed behavior** — what happens when sensor data is absent or corrupted

### 1. AI Governance — Adversarial Examples

| Scenario | tau | chi | drift | betti_1 | conf | Expected |
|----------|-----|-----|-------|---------|------|---------|
| Normal coherent output | 0.85 | 0.05 | 0.03 | 0.02 | 0.88 | EXECUTE |
| High contradiction | 0.82 | 0.55 | 0.04 | 0.03 | 0.71 | BLOCK (chi) |
| Low confidence LLM | 0.80 | 0.08 | 0.04 | 0.02 | 0.45 | BLOCK (conf) |
| Tau escape anomaly | 0.60 | 0.10 | 0.05 | 0.03 | 0.75 | BLOCK (tau) |
| High drift (jailbreak attempt) | 0.82 | 0.12 | 0.18 | 0.04 | 0.70 | BLOCK (drift) |
| Topological complexity spike | 0.85 | 0.08 | 0.04 | 0.06 | 0.80 | BLOCK (betti_1) |

**Fail-closed:** Missing logprob data → confidence capped at MISSING_LOGPROB_CONFIDENCE_CAP.
**Predicate layer:** SOURCE=UNVERIFIED + RISK absent → Φ1 block regardless of Sigma readings.

### 2. Medical Decision Support — Adversarial Examples

| Scenario | tau | chi | drift | betti_1 | conf | Expected |
|----------|-----|-----|-------|---------|------|---------|
| Routine diagnosis | 0.90 | 0.04 | 0.02 | 0.01 | 0.92 | EXECUTE |
| Contradictory symptom mapping | 0.88 | 0.45 | 0.03 | 0.02 | 0.78 | BLOCK (chi) |
| Rare disease extrapolation | 0.85 | 0.08 | 0.22 | 0.05 | 0.55 | BLOCK (drift+conf) |
| Drug interaction conflict | 0.87 | 0.50 | 0.04 | 0.03 | 0.70 | BLOCK (chi) |
| Off-label recommendation | 0.82 | 0.10 | 0.18 | 0.04 | 0.65 | BLOCK (drift) |

**Fail-closed:** Any sensor read failure → BLOCK immediately.
No partial readings accepted in medical domain. Confidence floor +0.10 above default.
Human review required before any EXECUTE in medical domain.

### 3. Industrial Automation — Adversarial Examples

| Scenario | tau | chi | drift | betti_1 | conf | Expected |
|----------|-----|-----|-------|---------|------|---------|
| Normal CNC path | 0.92 | 0.03 | 0.01 | 0.01 | 0.95 | EXECUTE |
| Tool wear deviation | 0.78 | 0.06 | 0.08 | 0.02 | 0.82 | BLOCK (tau) |
| Parameter conflict | 0.88 | 0.42 | 0.04 | 0.03 | 0.80 | BLOCK (chi) |
| Safety boundary approach | 0.72 | 0.08 | 0.03 | 0.02 | 0.88 | BLOCK (tau) |
| Cascading state change | 0.85 | 0.15 | 0.15 | 0.04 | 0.75 | BLOCK (drift) |

**Fail-closed:** Sensor dropout → emergency stop, not EXECUTE.
Any single sensor failure → KILL, not BLOCK. Industrial adapter is fail-hard.
betti_1 threshold tightened to 0.030 for industrial (complexity = instability).

### 4. Financial Systems — Adversarial Examples

| Scenario | tau | chi | drift | betti_1 | conf | Expected |
|----------|-----|-----|-------|---------|------|---------|
| Routine trade | 0.88 | 0.05 | 0.03 | 0.02 | 0.90 | EXECUTE |
| Portfolio correlation spike | 0.85 | 0.45 | 0.04 | 0.03 | 0.82 | BLOCK (chi) |
| High volatility regime | 0.83 | 0.10 | 0.20 | 0.04 | 0.70 | BLOCK (drift+conf) |
| Liquidity gap detected | 0.71 | 0.08 | 0.05 | 0.02 | 0.85 | BLOCK (tau) |
| Cascading stop-loss risk | 0.80 | 0.35 | 0.12 | 0.04 | 0.75 | BLOCK (chi+drift) |

**Fail-closed:** Market data feed failure → BLOCK all proposals.
Position size above risk limit → KILL regardless of sensor readings.
Confidence floor +0.05 above default for financial domain.

### 5. Autonomous Vehicles — Adversarial Examples

| Scenario | tau | chi | drift | betti_1 | conf | Expected |
|----------|-----|-----|-------|---------|------|---------|
| Highway lane keep | 0.93 | 0.03 | 0.01 | 0.01 | 0.96 | EXECUTE |
| Sensor disagreement | 0.88 | 0.48 | 0.03 | 0.02 | 0.80 | BLOCK (chi) |
| Perception uncertainty | 0.85 | 0.08 | 0.05 | 0.03 | 0.50 | BLOCK (conf) |
| Trajectory deviation | 0.82 | 0.10 | 0.16 | 0.04 | 0.78 | BLOCK (drift) |
| Emergency scenario | 0.65 | 0.12 | 0.06 | 0.03 | 0.70 | BLOCK (tau) |
| Adversarial object detected | 0.80 | 0.55 | 0.05 | 0.06 | 0.72 | BLOCK (chi+betti) |

**Fail-closed:** Any safety-critical sensor failure → emergency stop (KILL).
Pedestrian detection uncertainty → BLOCK all steering proposals.
Time-critical fail-closed: gate must respond within 100µs (hardware A014 required).
betti_1 threshold tightened to 0.030 (scene complexity = danger).

### Calibration Procedure

For each domain adapter deployment:

1. **Baseline run** — 100 known-normal inputs, record channel distribution
2. **Threshold validation** — confirm Z3-proven thresholds produce correct EXECUTE rate
3. **Adversarial validation** — run all domain adversarial examples from this spec, confirm expected outcomes
4. **Edge case calibration** — inputs within ±10% of each threshold; confirm behavior is correct
5. **Fail-closed test** — deliberately corrupt each sensor in turn; confirm BLOCK not EXECUTE
6. **Regression gate** — any threshold change requires re-running all five steps

This procedure closes post-A010 with real adapter data.
Current status: PROTOTYPE — thresholds from Z3 proof (A021), not from domain calibration.
