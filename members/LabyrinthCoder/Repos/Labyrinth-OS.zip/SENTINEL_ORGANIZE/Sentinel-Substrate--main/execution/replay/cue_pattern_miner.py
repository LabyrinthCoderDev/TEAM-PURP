# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          cue_pattern_miner.py — Labyrinth-OS / Lane 2 / replay
# ----------------------------------------------------------------------------

"""
cue_pattern_miner.py — Labyrinth-OS / Lane 2 / replay
=======================================================
Cue Pattern Mining — Extending Replay from Verification to Learning

The gap this closes:
  Current replay: validates that failures were correctly recorded.
  What it should also do: mine what CONDITIONS preceded each failure.

  Without this: replay confirms failures happened. Period.
  With this: replay surfaces the cue patterns that predict failures,
             turning the ledger into a learning signal.

Design (from Quillan Drift Paper — Behavior Loop Tracker, built natively):
  Each failure has a cue — a pattern of pre-failure conditions.
  If the same cue appears again, the system can anticipate the failure
  and route to DeferredExplorationNode proactively.

  Cue = sensor reading signature in the N entries preceding a BLOCK.

Sensor key resolution (Labyrinth-OS ledger structure):
  Ledger entries store sensor readings in multiple possible locations:
    1. entry["readings"]["tau_escape"]  — ProposalResult.to_dict() format
    2. entry["payload"]["readings"]["tau_escape"]  — HashLedger payload format
    3. entry["tau_escape"]  — flat format (some test/mock paths)
    4. entry["tau"]         — legacy/external format

  The miner checks all locations in order. If none found, the reading
  is recorded as None (not zero) so absent data is distinguishable
  from a genuine zero reading.

  Bug fixed: prior version used .get("chi", 0.0) which silently
  returned 0.0 for missing keys, making all-zero patterns look like
  valid sensor data. Now uses None for absent readings and excludes
  entries with no sensor data from aggregate computation.

What gets mined:
  - Sensor readings in the 3 entries preceding a BLOCK decision
  - Block reason that followed
  - How many times this cue pattern has preceded the same block reason
  - Cue signature (hash of rounded sensor readings)
  - Whether sensor data was present or absent

Output:
  CuePattern records stored as ANOMALY entries in ArchiveMemory.
  DeferredExplorationNode reads these to inform mutation strategy.

Integration:
  Called from replay_validator.py after chain integrity is verified.
  Does NOT affect replay outcome — it is a post-verification analysis.
  Fail-safe: mining failures never invalidate replay.

Quillan reference: Drift Paper (File 11) — Behavior Loop Tracker
See: archive/external_references/quillan/ASSESSMENT_quillan.md
"""

from __future__ import annotations

import hashlib
import json
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


# ─── CUE WINDOW ──────────────────────────────────────────────────────────────

CUE_WINDOW = 3  # number of entries before a BLOCK to examine

# Sentinel for absent sensor data — distinguishable from genuine 0.0
SENSOR_ABSENT = None


# ─── SENSOR EXTRACTION ───────────────────────────────────────────────────────

def _extract_sensor(entry: Dict[str, Any], key_tau: str = "tau_escape") -> Optional[Dict[str, float]]:
    """
    Extract sensor readings from a ledger entry.

    Checks multiple storage locations in priority order:
      1. entry["readings"]          — ProposalResult.to_dict() format
      2. entry["payload"]["readings"] — HashLedger payload format
      3. entry (flat)               — flat key format (tau_escape or tau)

    Returns dict with keys: tau, chi, drift, betti_1, confidence
    Returns None if no sensor data found at any location.
    """

    def _read_from(source: Dict[str, Any]) -> Optional[Dict[str, float]]:
        """Try to read all five sensor values from a dict."""
        # Accept both tau_escape (Labyrinth-OS native) and tau (external/legacy)
        tau = source.get("tau_escape") if source.get("tau_escape") is not None else source.get("tau")
        chi = source.get("chi")
        drift = source.get("drift")
        betti = source.get("betti_1") or source.get("betti1") or source.get("betti")
        conf = source.get("confidence")

        # At least tau and chi must be present for a valid reading
        if tau is None or chi is None:
            return None

        return {
            "tau":        float(tau),
            "chi":        float(chi),
            "drift":      float(drift) if drift is not None else 0.0,
            "betti_1":    float(betti) if betti is not None else 0.0,
            "confidence": float(conf)  if conf  is not None else 0.0,
        }

    if not isinstance(entry, dict):
        return None

    # Priority 1: entry["readings"]
    readings = entry.get("readings")
    if isinstance(readings, dict):
        result = _read_from(readings)
        if result is not None:
            return result

    # Priority 2: entry["payload"]["readings"]
    payload = entry.get("payload")
    if isinstance(payload, dict):
        nested = payload.get("readings")
        if isinstance(nested, dict):
            result = _read_from(nested)
            if result is not None:
                return result
        # Also try payload itself as flat sensor source
        result = _read_from(payload)
        if result is not None:
            return result

    # Priority 3: entry itself (flat)
    result = _read_from(entry)
    return result


def _extract_decision(entry: Dict[str, Any]) -> str:
    """
    Extract decision from a ledger entry.
    Checks entry["decision"], entry["outcome"], entry["gate_decision"].
    """
    if not isinstance(entry, dict):
        return "UNKNOWN"

    decision = entry.get("decision")
    if decision:
        return str(decision).upper()

    # outcome field used in ProposalResult format
    outcome = entry.get("outcome", "")
    if "BLOCK" in str(outcome).upper():
        return "BLOCK"
    if "EXECUTE" in str(outcome).upper() or "SUCCEED" in str(outcome).upper():
        return "EXECUTE"
    if "KILL" in str(outcome).upper():
        return "KILL"

    # gate_decision field used in CGIR ledger format
    gate = entry.get("gate_decision", "")
    if gate:
        return str(gate).upper()

    return "UNKNOWN"


def _extract_block_reason(entry: Dict[str, Any]) -> str:
    """Extract block reason from a ledger entry."""
    if not isinstance(entry, dict):
        return "UNKNOWN"

    reason = (entry.get("block_reason")
              or entry.get("sigma_block_reason")
              or entry.get("gate_block_reason")
              or "")

    # Also check nested payload
    if not reason:
        payload = entry.get("payload", {})
        if isinstance(payload, dict):
            reason = (payload.get("block_reason")
                      or payload.get("sigma_block_reason")
                      or "")

    return str(reason).upper() if reason else "UNKNOWN"


# ─── CUE SIGNATURE ───────────────────────────────────────────────────────────

def _round_for_signature(value: float, precision: int = 2) -> float:
    """Round sensor value for cue signature — groups similar readings."""
    return round(value, precision)


def compute_cue_signature(preceding_entries: List[Dict[str, Any]]) -> str:
    """
    Compute a hash signature from the sensor readings
    in the entries preceding a BLOCK decision.

    Rounds values to group similar patterns together.
    Uses None for absent readings so missing data has a distinct signature
    from zero readings.
    """
    features = []
    for entry in preceding_entries[-CUE_WINDOW:]:
        sensors = _extract_sensor(entry)
        decision = _extract_decision(entry)

        if sensors is not None:
            tau   = _round_for_signature(sensors["tau"])
            chi   = _round_for_signature(sensors["chi"])
            drift = _round_for_signature(sensors["drift"])
            betti = _round_for_signature(sensors["betti_1"])
            conf  = _round_for_signature(sensors["confidence"])
            features.append(f"{tau}|{chi}|{drift}|{betti}|{conf}|{decision}")
        else:
            # No sensor data — use a distinct marker so absent != zero
            features.append(f"NO_SENSOR|{decision}")

    content = ";".join(features)
    return hashlib.sha256(content.encode()).hexdigest()[:16]


# ─── CUE PATTERN ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class CuePattern:
    """
    Immutable record of a recurring cue pattern preceding a failure.

    Stored as ANOMALY entry in ArchiveMemory.
    Read by DeferredExplorationNode for proactive routing.

    avg_chi, avg_drift, avg_confidence:
      Computed only from entries that had sensor data.
      None means no entries in the cue window had sensor readings.
      This distinguishes "all zeros" from "no data available".
    """
    cue_signature:       str
    block_reason:        str
    occurrence_count:    int
    first_seen:          float
    last_seen:           float
    preceding_decisions: List[str]
    avg_chi:             Optional[float]    # None if no sensor data in window
    avg_drift:           Optional[float]
    avg_confidence:      Optional[float]
    session_ids:         List[str]
    sensor_data_present: bool               # True if at least one entry had readings

    @property
    def is_high_frequency(self) -> bool:
        """Cue has appeared 3+ times — worth proactive attention."""
        return self.occurrence_count >= 3

    @property
    def is_recent(self) -> bool:
        """Cue appeared in the last 24 hours."""
        return (time.time() - self.last_seen) < 86400

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cue_signature":       self.cue_signature,
            "block_reason":        self.block_reason,
            "occurrence_count":    self.occurrence_count,
            "first_seen":          self.first_seen,
            "last_seen":           self.last_seen,
            "preceding_decisions": self.preceding_decisions,
            "avg_chi":             self.avg_chi,
            "avg_drift":           self.avg_drift,
            "avg_confidence":      self.avg_confidence,
            "session_ids":         self.session_ids,
            "sensor_data_present": self.sensor_data_present,
            "is_high_frequency":   self.is_high_frequency,
            "is_recent":           self.is_recent,
        }


# ─── MINING RESULT ───────────────────────────────────────────────────────────

@dataclass(frozen=True)
class MiningResult:
    """Result of a cue pattern mining pass over a replay chain."""
    patterns_found:        int
    high_frequency:        int
    new_patterns:          int
    updated_patterns:      int
    missing_sensor_data:   int    # blocks where preceding entries had no sensor data
    mining_time:           float
    patterns:              List[CuePattern]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "patterns_found":      self.patterns_found,
            "high_frequency":      self.high_frequency,
            "new_patterns":        self.new_patterns,
            "updated_patterns":    self.updated_patterns,
            "missing_sensor_data": self.missing_sensor_data,
            "mining_time":         self.mining_time,
            "patterns":            [p.to_dict() for p in self.patterns],
        }


# ─── CUE PATTERN MINER ───────────────────────────────────────────────────────

class CuePatternMiner:
    """
    Mines cue patterns from replay chain entries.

    Called after replay chain integrity is verified.
    Does not affect replay outcome.
    Fail-safe: all exceptions are caught, never propagated.

    Handles Labyrinth-OS ledger entry formats:
      - ProposalResult.to_dict() format (readings nested under "readings" key)
      - HashLedger payload format (readings under "payload"."readings")
      - Flat format (tau_escape at top level)
      - Legacy/external format (tau at top level)
    """

    def __init__(
        self,
        known_patterns: Optional[Dict[str, CuePattern]] = None,
    ):
        self._known: Dict[str, CuePattern] = known_patterns or {}

    def mine(
        self,
        chain_entries: List[Dict[str, Any]],
        session_id: str = "unknown",
    ) -> MiningResult:
        """
        Mine cue patterns from a sequence of chain entries.

        chain_entries: list of ledger entries in order.
        Returns MiningResult with discovered/updated patterns.
        """
        start = time.time()
        new_count          = 0
        updated_count      = 0
        missing_sensor     = 0
        found_patterns: Dict[str, CuePattern] = {}

        try:
            for i, entry in enumerate(chain_entries):
                if not isinstance(entry, dict):
                    continue

                decision = _extract_decision(entry)
                if decision not in ("BLOCK", "KILL"):
                    continue

                block_reason = _extract_block_reason(entry)

                # Gather preceding entries (cue window)
                preceding = chain_entries[max(0, i - CUE_WINDOW):i]
                if not preceding:
                    continue

                # Extract sensor data from each preceding entry
                sensor_readings = [_extract_sensor(e) for e in preceding]
                valid_readings  = [s for s in sensor_readings if s is not None]
                has_sensor_data = len(valid_readings) > 0

                if not has_sensor_data:
                    missing_sensor += 1

                sig = compute_cue_signature(preceding)

                # Compute aggregates only from entries that had sensor data
                if valid_readings:
                    avg_chi   = sum(s["chi"]        for s in valid_readings) / len(valid_readings)
                    avg_drift = sum(s["drift"]       for s in valid_readings) / len(valid_readings)
                    avg_conf  = sum(s["confidence"]  for s in valid_readings) / len(valid_readings)
                else:
                    avg_chi = avg_drift = avg_conf = None

                decisions = [_extract_decision(e) for e in preceding]
                now_ts    = entry.get("timestamp", time.time())
                if not isinstance(now_ts, (int, float)):
                    now_ts = time.time()

                key = f"{sig}:{block_reason}"
                existing = found_patterns.get(key) or self._known.get(key)

                if existing is not None:
                    # Update — merge averages only when both have sensor data
                    if existing.avg_chi is not None and avg_chi is not None:
                        new_avg_chi   = (existing.avg_chi  + avg_chi)  / 2
                        new_avg_drift = (existing.avg_drift + avg_drift) / 2
                        new_avg_conf  = (existing.avg_confidence + avg_conf) / 2
                    else:
                        # Keep whichever is not None
                        new_avg_chi   = avg_chi   if avg_chi   is not None else existing.avg_chi
                        new_avg_drift = avg_drift if avg_drift is not None else existing.avg_drift
                        new_avg_conf  = avg_conf  if avg_conf  is not None else existing.avg_confidence

                    updated = CuePattern(
                        cue_signature       = sig,
                        block_reason        = block_reason,
                        occurrence_count    = existing.occurrence_count + 1,
                        first_seen          = existing.first_seen,
                        last_seen           = now_ts,
                        preceding_decisions = decisions,
                        avg_chi             = new_avg_chi,
                        avg_drift           = new_avg_drift,
                        avg_confidence      = new_avg_conf,
                        session_ids         = list(set(existing.session_ids + [session_id])),
                        sensor_data_present = has_sensor_data or existing.sensor_data_present,
                    )
                    found_patterns[key] = updated
                    updated_count += 1
                else:
                    new_pattern = CuePattern(
                        cue_signature       = sig,
                        block_reason        = block_reason,
                        occurrence_count    = 1,
                        first_seen          = now_ts,
                        last_seen           = now_ts,
                        preceding_decisions = decisions,
                        avg_chi             = avg_chi,
                        avg_drift           = avg_drift,
                        avg_confidence      = avg_conf,
                        session_ids         = [session_id],
                        sensor_data_present = has_sensor_data,
                    )
                    found_patterns[key] = new_pattern
                    new_count += 1

        except Exception:
            pass  # fail-safe

        patterns    = list(found_patterns.values())
        high_freq   = sum(1 for p in patterns if p.is_high_frequency)
        mining_time = time.time() - start

        self._known.update(found_patterns)

        return MiningResult(
            patterns_found      = len(patterns),
            high_frequency      = high_freq,
            new_patterns        = new_count,
            updated_patterns    = updated_count,
            missing_sensor_data = missing_sensor,
            mining_time         = mining_time,
            patterns            = patterns,
        )

    def get_known_patterns(self) -> Dict[str, CuePattern]:
        return dict(self._known)

    def get_high_frequency_patterns(self) -> List[CuePattern]:
        return [p for p in self._known.values() if p.is_high_frequency]


# ─── TEST HELPERS ────────────────────────────────────────────────────────────

def _make_entry_flat(
    decision: str,
    block_reason: str = "",
    tau: float = 0.80,
    chi: float = 0.10,
    drift: float = 0.05,
    confidence: float = 0.88,
    timestamp: float = 0.0,
) -> Dict[str, Any]:
    """Flat format — tau_escape at top level (Labyrinth-OS native)."""
    return {
        "decision":    decision,
        "block_reason": block_reason,
        "tau_escape":  tau,
        "chi":         chi,
        "drift":       drift,
        "betti_1":     0.02,
        "confidence":  confidence,
        "timestamp":   timestamp or time.time(),
    }


def _make_entry_nested(
    decision: str,
    block_reason: str = "",
    tau: float = 0.80,
    chi: float = 0.10,
    drift: float = 0.05,
    confidence: float = 0.88,
) -> Dict[str, Any]:
    """Nested format — ProposalResult.to_dict() style."""
    return {
        "decision":    decision,
        "block_reason": block_reason,
        "readings": {
            "tau_escape":  tau,
            "chi":         chi,
            "drift":       drift,
            "betti_1":     0.02,
            "confidence":  confidence,
        },
        "timestamp": time.time(),
    }


def _make_entry_no_sensors(decision: str, block_reason: str = "") -> Dict[str, Any]:
    """Entry with no sensor data — simulates pre-sensor ledger entries."""
    return {
        "decision":     decision,
        "block_reason": block_reason,
        "timestamp":    time.time(),
    }


# ─── TESTS ───────────────────────────────────────────────────────────────────

def run_tests() -> tuple:
    passed = failed = 0
    results = []

    def t(name, fn):
        nonlocal passed, failed
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))

    # ── Sensor extraction tests ───────────────────────────────────────────────

    def test_extract_sensor_flat_format():
        entry = _make_entry_flat("EXECUTE", tau=0.80, chi=0.12)
        s = _extract_sensor(entry)
        assert s is not None
        assert s["tau"] == 0.80
        assert s["chi"] == 0.12
    t("test_extract_sensor_flat_format", test_extract_sensor_flat_format)

    def test_extract_sensor_nested_format():
        entry = _make_entry_nested("EXECUTE", tau=0.77, chi=0.15)
        s = _extract_sensor(entry)
        assert s is not None
        assert s["tau"] == 0.77
        assert s["chi"] == 0.15
    t("test_extract_sensor_nested_format", test_extract_sensor_nested_format)

    def test_extract_sensor_returns_none_when_absent():
        entry = _make_entry_no_sensors("EXECUTE")
        s = _extract_sensor(entry)
        assert s is None
    t("test_extract_sensor_returns_none_when_absent",
      test_extract_sensor_returns_none_when_absent)

    def test_extract_sensor_not_zero_when_absent():
        """The fix: absent sensor data is None, not 0.0."""
        entry = _make_entry_no_sensors("EXECUTE")
        s = _extract_sensor(entry)
        assert s is None, f"Expected None, got {s}"
    t("test_extract_sensor_not_zero_when_absent",
      test_extract_sensor_not_zero_when_absent)

    def test_extract_decision_flat():
        assert _extract_decision({"decision": "BLOCK"}) == "BLOCK"
    t("test_extract_decision_flat", test_extract_decision_flat)

    def test_extract_decision_outcome_format():
        assert _extract_decision({"outcome": "GATE_BLOCKED"}) == "BLOCK"
    t("test_extract_decision_outcome_format", test_extract_decision_outcome_format)

    # ── Mining with sensor data ───────────────────────────────────────────────

    def test_mine_flat_format_real_values():
        miner = CuePatternMiner()
        entries = [
            _make_entry_flat("EXECUTE", tau=0.80, chi=0.10, drift=0.05, confidence=0.88),
            _make_entry_flat("EXECUTE", tau=0.78, chi=0.12, drift=0.06, confidence=0.85),
            _make_entry_flat("EXECUTE", tau=0.76, chi=0.14, drift=0.07, confidence=0.82),
            _make_entry_flat("BLOCK",   block_reason="CHI_COLLAPSE", tau=0.60, chi=0.45),
        ]
        result = miner.mine(entries, session_id="s_flat")
        assert result.patterns_found == 1
        p = result.patterns[0]
        assert p.sensor_data_present
        assert p.avg_chi is not None
        assert p.avg_chi > 0.0, f"Expected real chi value, got {p.avg_chi}"
        assert abs(p.avg_chi - 0.12) < 0.01
    t("test_mine_flat_format_real_values", test_mine_flat_format_real_values)

    def test_mine_nested_format_real_values():
        miner = CuePatternMiner()
        entries = [
            _make_entry_nested("EXECUTE", tau=0.80, chi=0.10, drift=0.05, confidence=0.88),
            _make_entry_nested("EXECUTE", tau=0.78, chi=0.13, drift=0.06, confidence=0.86),
            _make_entry_nested("BLOCK",   block_reason="TAU_COLLAPSE"),
        ]
        result = miner.mine(entries, session_id="s_nested")
        assert result.patterns_found == 1
        p = result.patterns[0]
        assert p.sensor_data_present
        assert p.avg_chi is not None
        assert p.avg_chi > 0.0
    t("test_mine_nested_format_real_values", test_mine_nested_format_real_values)

    def test_mine_no_sensor_data_returns_none_not_zero():
        """Core fix: patterns from sensor-less entries have None, not 0.0."""
        miner = CuePatternMiner()
        entries = [
            _make_entry_no_sensors("EXECUTE"),
            _make_entry_no_sensors("EXECUTE"),
            _make_entry_no_sensors("BLOCK", block_reason="UNKNOWN"),
        ]
        result = miner.mine(entries, session_id="s_nosensor")
        assert result.patterns_found == 1
        p = result.patterns[0]
        assert not p.sensor_data_present
        assert p.avg_chi is None, f"Expected None for missing sensor, got {p.avg_chi}"
        assert p.avg_drift is None
        assert p.avg_confidence is None
        assert result.missing_sensor_data == 1
    t("test_mine_no_sensor_data_returns_none_not_zero",
      test_mine_no_sensor_data_returns_none_not_zero)

    def test_mine_empty_chain():
        miner = CuePatternMiner()
        result = miner.mine([], session_id="s0")
        assert result.patterns_found == 0
    t("test_mine_empty_chain", test_mine_empty_chain)

    def test_mine_no_blocks():
        miner = CuePatternMiner()
        entries = [_make_entry_flat("EXECUTE") for _ in range(5)]
        result = miner.mine(entries, session_id="s1")
        assert result.patterns_found == 0
    t("test_mine_no_blocks", test_mine_no_blocks)

    def test_mine_updates_existing_pattern():
        miner = CuePatternMiner()
        entries = [
            _make_entry_flat("EXECUTE", tau=0.80, chi=0.10),
            _make_entry_flat("EXECUTE", tau=0.78, chi=0.12),
            _make_entry_flat("BLOCK",   block_reason="TAU_COLLAPSE"),
        ]
        miner.mine(entries, session_id="s3")
        result = miner.mine(entries, session_id="s4")
        assert result.updated_patterns >= 1
    t("test_mine_updates_existing_pattern", test_mine_updates_existing_pattern)

    def test_pattern_tracks_session_ids():
        miner = CuePatternMiner()
        entries = [
            _make_entry_flat("EXECUTE", tau=0.80, chi=0.10),
            _make_entry_flat("BLOCK", block_reason="DRIFT_EXCEEDED"),
        ]
        miner.mine(entries, session_id="session_A")
        miner.mine(entries, session_id="session_B")
        patterns = list(miner.get_known_patterns().values())
        assert len(patterns) >= 1
        sids = patterns[0].session_ids
        assert "session_A" in sids
        assert "session_B" in sids
    t("test_pattern_tracks_session_ids", test_pattern_tracks_session_ids)

    def test_high_frequency_threshold():
        miner = CuePatternMiner()
        entries = [
            _make_entry_flat("EXECUTE", chi=0.10),
            _make_entry_flat("EXECUTE", chi=0.11),
            _make_entry_flat("BLOCK", block_reason="CHI_COLLAPSE"),
        ]
        for i in range(3):
            miner.mine(entries, session_id=f"s{i}")
        high_freq = miner.get_high_frequency_patterns()
        assert len(high_freq) >= 1
        assert all(p.occurrence_count >= 3 for p in high_freq)
    t("test_high_frequency_threshold", test_high_frequency_threshold)

    def test_cue_signature_consistent():
        entries = [
            _make_entry_flat("EXECUTE", tau=0.80, chi=0.10),
            _make_entry_flat("EXECUTE", tau=0.79, chi=0.11),
        ]
        sig1 = compute_cue_signature(entries)
        sig2 = compute_cue_signature(entries)
        assert sig1 == sig2
    t("test_cue_signature_consistent", test_cue_signature_consistent)

    def test_cue_signature_differs_for_different_readings():
        entries_a = [_make_entry_flat("EXECUTE", tau=0.80, chi=0.10)]
        entries_b = [_make_entry_flat("EXECUTE", tau=0.50, chi=0.40)]
        assert compute_cue_signature(entries_a) != compute_cue_signature(entries_b)
    t("test_cue_signature_differs_for_different_readings",
      test_cue_signature_differs_for_different_readings)

    def test_absent_and_zero_have_different_signatures():
        """Absent sensor data must produce a different signature than zero readings."""
        entries_absent = [_make_entry_no_sensors("EXECUTE")]
        entries_zero   = [_make_entry_flat("EXECUTE", tau=0.0, chi=0.0, drift=0.0, confidence=0.0)]
        sig_absent = compute_cue_signature(entries_absent)
        sig_zero   = compute_cue_signature(entries_zero)
        assert sig_absent != sig_zero, "Absent and zero must have distinct signatures"
    t("test_absent_and_zero_have_different_signatures",
      test_absent_and_zero_have_different_signatures)

    def test_pattern_is_immutable():
        miner = CuePatternMiner()
        entries = [
            _make_entry_flat("EXECUTE"),
            _make_entry_flat("BLOCK", block_reason="CONFIDENCE_FLOOR"),
        ]
        result = miner.mine(entries, session_id="s_immut")
        if result.patterns:
            p = result.patterns[0]
            try:
                p.occurrence_count = 999
                raise AssertionError("Should be immutable")
            except Exception as e:
                assert "frozen" in str(e).lower() or "can't" in str(e).lower() or "FrozenInstanceError" in type(e).__name__
    t("test_pattern_is_immutable", test_pattern_is_immutable)

    def test_pattern_to_dict_serializable():
        miner = CuePatternMiner()
        entries = [
            _make_entry_nested("EXECUTE", chi=0.10),
            _make_entry_nested("BLOCK", block_reason="CHI_COLLAPSE"),
        ]
        result = miner.mine(entries, session_id="s_serial")
        for p in result.patterns:
            json.dumps(p.to_dict())
    t("test_pattern_to_dict_serializable", test_pattern_to_dict_serializable)

    def test_mining_result_to_dict_serializable():
        miner = CuePatternMiner()
        result = miner.mine([], session_id="s_empty")
        json.dumps(result.to_dict())
    t("test_mining_result_to_dict_serializable",
      test_mining_result_to_dict_serializable)

    def test_mine_fails_safely_on_bad_entries():
        miner = CuePatternMiner()
        bad_entries = [{"completely": "wrong"}, None, 42]
        try:
            result = miner.mine(bad_entries, session_id="s_bad")
        except Exception as e:
            raise AssertionError(f"Mining should be fail-safe, got: {e}")
    t("test_mine_fails_safely_on_bad_entries",
      test_mine_fails_safely_on_bad_entries)

    def test_missing_sensor_data_counter():
        miner = CuePatternMiner()
        entries = [
            _make_entry_no_sensors("EXECUTE"),
            _make_entry_no_sensors("EXECUTE"),
            _make_entry_no_sensors("BLOCK", block_reason="UNKNOWN"),
            _make_entry_no_sensors("EXECUTE"),
            _make_entry_no_sensors("BLOCK", block_reason="UNKNOWN"),
        ]
        result = miner.mine(entries, session_id="s_counter")
        assert result.missing_sensor_data == 2
    t("test_missing_sensor_data_counter", test_missing_sensor_data_counter)

    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("Labyrinth-OS — Cue Pattern Miner (fixed)")
    print("Extends replay from verification to learning.")
    print("Bug fixed: absent sensor data is None, not 0.0.")
    print("=" * 70)
    print()
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err:
            line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed")
    if failed:
        raise SystemExit(1)
    print("\n  Cue Pattern Miner — COMPLETE")
    print("=" * 70)
