# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          bounded_sensor_gate.py — Labyrinth-OS / Execution / Pre-CGIR Gate
# ----------------------------------------------------------------------------

"""
bounded_sensor_gate.py — Labyrinth-OS / Execution / Pre-CGIR Gate
===================================================================
BoundedSensorGate — Rate-Limit and Bound-Limit on Raw Sensor Data

This module sits BEFORE the PhysicsSentinel and the constitutional
pipeline. It enforces two independent constraints on every incoming
sensor reading:

  1. Rate gate:  readings cannot arrive faster than MIN_SENSOR_UPDATE_INTERVAL_S.
                 Prevents flooding the pipeline with artificially rapid reads.

  2. Bound gate: readings cannot change by more than MAX_SENSOR_CHANGE_PER_CYCLE
                 relative to the previous accepted value in a single cycle.
                 A joint position that jumps 40% in 50ms is a spike or attack,
                 not a legitimate reading.

  3. Staleness gate: readings older than SENSOR_STALENESS_THRESHOLD_S are
                     treated as missing data, not stale data. This closes
                     the gap where an old reading passes geometric checks
                     but should never have entered the pipeline.

Architecture
------------
Pattern independently derived from studying:
  - BoringVault AccountantWithRateProviders (Se7en-Seas / Veda.tech) — rate
    limiting and bound limiting concept (UNLICENSED — studied only, not copied)
  - SEDA Chainlink Adapter (MIT) — staleness gate pattern, fail-closed on zero

This is an original Python implementation of those architectural patterns.

Relationships
-------------
  → Sits upstream of: physics_sentinel.py (Layer 0 pre-gate)
  → Feeds: humanoid_robot_adapter.py, logprob_bridge_adapter.py
  → Constants from: sigma_anchors.py (single source of truth)

Invariant
---------
  I_BSG_1: A rejected reading NEVER enters the downstream pipeline.
  I_BSG_2: An accepted reading is always stamped with its acceptance time.
  I_BSG_3: The gate never raises — all errors produce SensorGateResult.REJECTED.
  I_BSG_4: Staleness is computed against wall clock, not pipeline clock.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Optional

try:
    from sigma_anchors import (
        MAX_SENSOR_CHANGE_PER_CYCLE,
        MIN_SENSOR_UPDATE_INTERVAL_S,
        SENSOR_STALENESS_THRESHOLD_S,
    )
except ImportError:
    MAX_SENSOR_CHANGE_PER_CYCLE  = 0.40
    MIN_SENSOR_UPDATE_INTERVAL_S = 0.05
    SENSOR_STALENESS_THRESHOLD_S = 30.0


# ─── RESULT ───────────────────────────────────────────────────────────────────

@unique
class SensorGateVerdict(str, Enum):
    ACCEPTED          = "ACCEPTED"
    REJECTED_RATE     = "REJECTED_RATE"     # arrived too fast
    REJECTED_BOUND    = "REJECTED_BOUND"    # changed too much
    REJECTED_STALE    = "REJECTED_STALE"    # data too old
    REJECTED_INVALID  = "REJECTED_INVALID"  # None, NaN, infinite
    REJECTED_ZERO     = "REJECTED_ZERO"     # zero when non-zero required


@dataclass
class SensorGateResult:
    verdict:       SensorGateVerdict
    value:         Optional[float]     # accepted value, or None on rejection
    sensor_name:   str
    reason:        str
    age_s:         Optional[float] = None  # age of reading at gate time
    change_frac:   Optional[float] = None  # fractional change from last accepted
    accepted_at:   float = field(default_factory=time.time)

    @property
    def accepted(self) -> bool:
        return self.verdict == SensorGateVerdict.ACCEPTED


# ─── GATE ─────────────────────────────────────────────────────────────────────

class BoundedSensorGate:
    """
    Rate-limit and bound-limit a single named sensor channel.

    One gate per sensor channel. Thread-safe for single-threaded use
    (no locking — callers must serialize if multi-threaded).

    Parameters
    ----------
    sensor_name:
        Human-readable name for error messages and ledger entries.
    max_change_per_cycle:
        Maximum fractional change from previous accepted value in one cycle.
        Default: MAX_SENSOR_CHANGE_PER_CYCLE from sigma_anchors.py (0.40).
    min_update_interval_s:
        Minimum seconds between accepted readings.
        Default: MIN_SENSOR_UPDATE_INTERVAL_S from sigma_anchors.py (0.05s).
    staleness_threshold_s:
        Maximum age in seconds for a reading to be considered current.
        Default: SENSOR_STALENESS_THRESHOLD_S from sigma_anchors.py (30.0s).
    require_nonzero:
        If True, zero values are rejected. Default False.
    """

    def __init__(
        self,
        sensor_name: str,
        max_change_per_cycle: float   = MAX_SENSOR_CHANGE_PER_CYCLE,
        min_update_interval_s: float  = MIN_SENSOR_UPDATE_INTERVAL_S,
        staleness_threshold_s: float  = SENSOR_STALENESS_THRESHOLD_S,
        require_nonzero: bool         = False,
    ) -> None:
        self.sensor_name           = sensor_name
        self.max_change            = max_change_per_cycle
        self.min_interval          = min_update_interval_s
        self.staleness_threshold   = staleness_threshold_s
        self.require_nonzero       = require_nonzero

        self._last_value:         Optional[float] = None
        self._last_accepted_at:   float           = 0.0
        self._accept_count:       int             = 0
        self._reject_count:       int             = 0

    # ── PUBLIC ────────────────────────────────────────────────────────────────

    def accept(
        self,
        value: Optional[float],
        reading_timestamp: Optional[float] = None,
        now: Optional[float] = None,
    ) -> SensorGateResult:
        """
        Attempt to accept a sensor reading.

        Parameters
        ----------
        value:
            The sensor reading. None → REJECTED_INVALID.
        reading_timestamp:
            When the reading was produced (wall clock seconds).
            None → treated as current time (no staleness check).
        now:
            Current wall clock time. None → time.time().

        Returns
        -------
        SensorGateResult with verdict and reason.
        """
        _now = now if now is not None else time.time()

        # ── VALIDITY ──────────────────────────────────────────────────────────
        if value is None:
            return self._reject(SensorGateVerdict.REJECTED_INVALID, "value is None")

        try:
            fval = float(value)
        except (TypeError, ValueError):
            return self._reject(SensorGateVerdict.REJECTED_INVALID, f"value not numeric: {value!r}")

        import math
        if math.isnan(fval) or math.isinf(fval):
            return self._reject(SensorGateVerdict.REJECTED_INVALID, f"value is {fval}")

        if self.require_nonzero and fval == 0.0:
            return self._reject(SensorGateVerdict.REJECTED_ZERO, "zero value rejected (require_nonzero=True)")

        # ── STALENESS ─────────────────────────────────────────────────────────
        age_s: Optional[float] = None
        if reading_timestamp is not None:
            age_s = _now - reading_timestamp
            if age_s < 0:
                return self._reject(
                    SensorGateVerdict.REJECTED_STALE,
                    f"future-dated reading: age={age_s:.3f}s",
                    age_s=age_s,
                )
            if self.staleness_threshold > 0 and age_s > self.staleness_threshold:
                return self._reject(
                    SensorGateVerdict.REJECTED_STALE,
                    f"reading too old: age={age_s:.3f}s > threshold={self.staleness_threshold}s",
                    age_s=age_s,
                )

        # ── RATE ──────────────────────────────────────────────────────────────
        time_since_last = _now - self._last_accepted_at
        if self._last_accepted_at > 0 and time_since_last < self.min_interval:
            return self._reject(
                SensorGateVerdict.REJECTED_RATE,
                f"update too frequent: {time_since_last*1000:.1f}ms < {self.min_interval*1000:.1f}ms",
            )

        # ── BOUND ─────────────────────────────────────────────────────────────
        change_frac: Optional[float] = None
        if self._last_value is not None:
            denominator = max(abs(self._last_value), 1e-9)
            change_frac = abs(fval - self._last_value) / denominator
            if change_frac > self.max_change:
                return self._reject(
                    SensorGateVerdict.REJECTED_BOUND,
                    f"change {change_frac:.3f} > max {self.max_change:.3f} "
                    f"(prev={self._last_value:.4f} new={fval:.4f})",
                    change_frac=change_frac,
                )

        # ── ACCEPT ────────────────────────────────────────────────────────────
        self._last_value      = fval
        self._last_accepted_at = _now
        self._accept_count    += 1

        return SensorGateResult(
            verdict=SensorGateVerdict.ACCEPTED,
            value=fval,
            sensor_name=self.sensor_name,
            reason="ACCEPTED",
            age_s=age_s,
            change_frac=change_frac,
            accepted_at=_now,
        )

    def reset(self) -> None:
        """Reset gate state. Use when sensor is restarted or recalibrated."""
        self._last_value      = None
        self._last_accepted_at = 0.0

    @property
    def stats(self) -> dict:
        return {
            "sensor": self.sensor_name,
            "accepted": self._accept_count,
            "rejected": self._reject_count,
            "last_value": self._last_value,
        }

    # ── PRIVATE ───────────────────────────────────────────────────────────────

    def _reject(
        self,
        verdict: SensorGateVerdict,
        reason: str,
        age_s: Optional[float] = None,
        change_frac: Optional[float] = None,
    ) -> SensorGateResult:
        self._reject_count += 1
        return SensorGateResult(
            verdict=verdict,
            value=None,
            sensor_name=self.sensor_name,
            reason=reason,
            age_s=age_s,
            change_frac=change_frac,
        )


# ─── MULTI-CHANNEL GATE ───────────────────────────────────────────────────────

class MultiChannelSensorGate:
    """
    Manage BoundedSensorGate instances for multiple sensor channels.

    Usage
    -----
        gate = MultiChannelSensorGate.for_sigma_anchors()
        result = gate.accept("tau", 0.83)
        if not result.accepted:
            # reading rejected — do not enter pipeline
    """

    def __init__(
        self,
        channels: dict[str, BoundedSensorGate],
    ) -> None:
        self._channels = channels

    @classmethod
    def for_sigma_anchors(cls) -> "MultiChannelSensorGate":
        """
        Pre-configured gate for the five Sigma Anchor channels.
        Uses constants from sigma_anchors.py as defaults.
        """
        channels = {
            "tau":        BoundedSensorGate("tau",        require_nonzero=True),
            "chi":        BoundedSensorGate("chi",        require_nonzero=False),
            "drift":      BoundedSensorGate("drift",      require_nonzero=False),
            "betti_1":    BoundedSensorGate("betti_1",    require_nonzero=False),
            "confidence": BoundedSensorGate("confidence", require_nonzero=True),
        }
        return cls(channels)

    def accept(
        self,
        channel: str,
        value: Optional[float],
        reading_timestamp: Optional[float] = None,
        now: Optional[float] = None,
    ) -> SensorGateResult:
        if channel not in self._channels:
            return SensorGateResult(
                verdict=SensorGateVerdict.REJECTED_INVALID,
                value=None,
                sensor_name=channel,
                reason=f"unknown channel: {channel}",
            )
        return self._channels[channel].accept(value, reading_timestamp, now)

    def accept_all(
        self,
        readings: dict[str, Optional[float]],
        reading_timestamp: Optional[float] = None,
        now: Optional[float] = None,
    ) -> dict[str, SensorGateResult]:
        """Accept readings for multiple channels at once."""
        return {
            ch: self.accept(ch, val, reading_timestamp, now)
            for ch, val in readings.items()
        }

    @property
    def all_stats(self) -> dict:
        return {ch: gate.stats for ch, gate in self._channels.items()}


# ─── SAFE MEDIAN ──────────────────────────────────────────────────────────────

def safe_median_int(values: list[int]) -> Optional[int]:
    """
    Overflow-safe integer median.

    Uses a/2 + b/2 + (a%2 + b%2)//2 for even-length slices to avoid
    integer overflow when (a+b) would exceed the type's range.

    Pattern ported from SEDA Oracle common/math.rs (MIT license).
    Original: https://github.com/sedaprotocol/seda-oracle-starter
    """
    if not values:
        return None
    sorted_vals = sorted(values)
    n = len(sorted_vals)
    if n % 2 == 1:
        return sorted_vals[n // 2]
    a = sorted_vals[n // 2 - 1]
    b = sorted_vals[n // 2]
    return a // 2 + b // 2 + (a % 2 + b % 2) // 2


def safe_median_float(values: list[float]) -> Optional[float]:
    """Standard float median. Returns None for empty list."""
    if not values:
        return None
    sorted_vals = sorted(values)
    n = len(sorted_vals)
    if n % 2 == 1:
        return sorted_vals[n // 2]
    return (sorted_vals[n // 2 - 1] + sorted_vals[n // 2]) / 2.0


# ─── JSON PATH FETCHER ────────────────────────────────────────────────────────

def extract_from_json(
    data: object,
    json_path: list[str],
) -> Optional[float]:
    """
    Safe JSON path traversal — returns None on any missing key or type error.

    Traverses a nested dict/list structure by following json_path.
    Handles both string-encoded and numeric JSON values.
    Returns None if path doesn't resolve, or if resolved value is
    non-positive, NaN, infinite, or non-numeric.

    Pattern ported from SEDA Oracle common/fetch.rs (MIT license).
    Original: https://github.com/sedaprotocol/seda-oracle-starter

    Examples
    --------
        # Bybit response: {"result": {"list": [{"lastPrice": "25.50"}]}}
        val = extract_from_json(resp, ["result", "list", "0", "lastPrice"])
        # → 25.5

        # OpenAI logprob: {"content": [{"logprob": -0.023}]}
        val = extract_from_json(resp, ["content", "0", "logprob"])
        # → -0.023 (negative is valid for logprobs)
    """
    import math

    current: object = data
    for segment in json_path:
        try:
            if isinstance(current, list):
                current = current[int(segment)]
            elif isinstance(current, dict):
                current = current[segment]
            else:
                return None
        except (KeyError, IndexError, ValueError, TypeError):
            return None

    try:
        if isinstance(current, str):
            val = float(current)
        elif isinstance(current, (int, float)):
            val = float(current)
        else:
            return None

        if math.isnan(val) or math.isinf(val):
            return None

        return val

    except (ValueError, TypeError):
        return None


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_basic_accept() -> bool:
    gate = BoundedSensorGate("test")
    r = gate.accept(0.83)
    assert r.accepted
    assert r.value == 0.83
    return True


def _test_rate_rejection() -> bool:
    gate = BoundedSensorGate("test", min_update_interval_s=1.0)
    now = time.time()
    gate.accept(0.80, now=now)
    r = gate.accept(0.81, now=now + 0.5)  # only 0.5s later
    assert not r.accepted
    assert r.verdict == SensorGateVerdict.REJECTED_RATE
    return True


def _test_bound_rejection() -> bool:
    gate = BoundedSensorGate("test", max_change_per_cycle=0.40)
    now = time.time()
    gate.accept(1.0, now=now)
    r = gate.accept(2.0, now=now + 1.0)  # 100% change — exceeds 40%
    assert not r.accepted
    assert r.verdict == SensorGateVerdict.REJECTED_BOUND
    assert r.change_frac is not None and r.change_frac > 0.40
    return True


def _test_staleness_rejection() -> bool:
    gate = BoundedSensorGate("test", staleness_threshold_s=5.0)
    now = time.time()
    old_ts = now - 10.0   # 10 seconds old
    r = gate.accept(0.83, reading_timestamp=old_ts, now=now)
    assert not r.accepted
    assert r.verdict == SensorGateVerdict.REJECTED_STALE
    assert r.age_s is not None and r.age_s > 5.0
    return True


def _test_future_dated_rejection() -> bool:
    gate = BoundedSensorGate("test")
    now = time.time()
    future_ts = now + 100.0
    r = gate.accept(0.83, reading_timestamp=future_ts, now=now)
    assert not r.accepted
    assert r.verdict == SensorGateVerdict.REJECTED_STALE
    return True


def _test_none_rejected() -> bool:
    gate = BoundedSensorGate("test")
    r = gate.accept(None)
    assert not r.accepted
    assert r.verdict == SensorGateVerdict.REJECTED_INVALID
    return True


def _test_nan_rejected() -> bool:
    import math
    gate = BoundedSensorGate("test")
    r = gate.accept(math.nan)
    assert not r.accepted
    assert r.verdict == SensorGateVerdict.REJECTED_INVALID
    return True


def _test_first_reading_no_bound_check() -> bool:
    gate = BoundedSensorGate("test", max_change_per_cycle=0.01)
    r = gate.accept(100.0)  # first reading — no previous to compare
    assert r.accepted
    return True


def _test_multichannel_gate() -> bool:
    gate = MultiChannelSensorGate.for_sigma_anchors()
    results = gate.accept_all({
        "tau": 0.83,
        "chi": 0.12,
        "drift": 0.05,
        "betti_1": 0.02,
        "confidence": 0.90,
    })
    assert all(r.accepted for r in results.values()), \
        f"Unexpected rejections: {[k for k,r in results.items() if not r.accepted]}"
    return True


def _test_safe_median_int_odd() -> bool:
    assert safe_median_int([3, 1, 4, 1, 5]) == 3
    return True


def _test_safe_median_int_even() -> bool:
    assert safe_median_int([1, 2, 3, 4]) == 2
    return True


def _test_safe_median_int_empty() -> bool:
    assert safe_median_int([]) is None
    return True


def _test_safe_median_float() -> bool:
    assert safe_median_float([1.0, 2.0, 3.0]) == 2.0
    assert safe_median_float([1.0, 3.0]) == 2.0
    assert safe_median_float([]) is None
    return True


def _test_extract_from_json_simple() -> bool:
    data = {"result": {"price": "25.50"}}
    val = extract_from_json(data, ["result", "price"])
    assert val == 25.50
    return True


def _test_extract_from_json_list_index() -> bool:
    data = {"list": [{"lastPrice": "42.0"}]}
    val = extract_from_json(data, ["list", "0", "lastPrice"])
    assert val == 42.0
    return True


def _test_extract_from_json_missing_key() -> bool:
    data = {"a": {"b": 1}}
    val = extract_from_json(data, ["a", "c", "d"])
    assert val is None
    return True


def _test_extract_from_json_negative_valid() -> bool:
    # Logprobs are negative — should not be rejected
    data = {"logprob": -0.023}
    val = extract_from_json(data, ["logprob"])
    assert val == -0.023
    return True


def _test_reset_clears_state() -> bool:
    gate = BoundedSensorGate("test", max_change_per_cycle=0.10)
    now = time.time()
    gate.accept(1.0, now=now)
    gate.reset()
    r = gate.accept(100.0, now=now + 1.0)  # would fail bound without reset
    assert r.accepted
    return True


def run_tests():
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed = failed = 0
    for name, fn in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []


if __name__ == "__main__":
    p, f, _ = run_tests()
    print(f"bounded_sensor_gate: {p} passed, {f} failed")
