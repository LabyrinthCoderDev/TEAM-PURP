# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          pre_cgir_gate — Labyrinth-OS / Execution
# ----------------------------------------------------------------------------

"""
pre_cgir_gate — Labyrinth-OS / Execution
=========================================
PRE-CGIR Gate (Lane 1 → Lane 2 crossing).

This directory contains the gate that executes BEFORE CGIR translation.
Hard Invariant I5: REALITY_GATE occurs BEFORE CGIR.

Gate order (strictly enforced):
  1. PROMOTION_PROTOCOL  (lane1/08 — only bridge between lanes)
  2. REALITY_GATE        (this directory — pre-CGIR, post-promotion)
  3. EXECUTION_GATE      (execution/gate — post-solver, post-adversarial)

Modules:
  gate_function.py   — pure decision: GatePassage | GateBlock
  gate_binding.py    — binds passage to CGIR proposal
  gate_proof.py      — proof record for ledger
  gate_rejection.py  — structured rejection with reason
"""
