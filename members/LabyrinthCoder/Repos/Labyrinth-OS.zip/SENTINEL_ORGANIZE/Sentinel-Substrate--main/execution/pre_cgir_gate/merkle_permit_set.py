# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          merkle_permit_set.py — Labyrinth-OS / Execution / Pre-CGIR Gate
# ----------------------------------------------------------------------------

"""
merkle_permit_set.py — Labyrinth-OS / Execution / Pre-CGIR Gate
================================================================
Merkle Permit Set — Structural Operation Whitelist

Labyrinth-OS allows certain proposals and blocks others. The gate
makes that decision. But the gate still sees every proposal.

The Merkle Permit Set changes the model: permitted operations are
committed to a Merkle tree at build time. A proposal whose action
type is not in the tree cannot reach the gate. It is structurally
excluded, not just blocked.

This is the difference between a bouncer who turns people away and
a building where certain floors simply don't exist.

Relationship to the Gate
------------------------
  MerklePermitSet → checks action type → not in tree → rejected
  MerklePermitSet → checks action type → in tree     → passes to gate
  Gate            → evaluates tau/chi/drift/betti/confidence → ALLOW/BLOCK/KILL

The Merkle set and the gate address different threat models:
  - Gate:       Is this specific proposal safe (geometrically, logically)?
  - Merkle set: Is this type of operation one the system was built to handle?

A proposal can be geometrically safe but structurally impermissible.
The Merkle set catches that. The gate does not.

Architecture Note
-----------------
Independent Python implementation of the Merkle-gated operation
whitelist concept studied from Se7en-Seas BoringVault architecture
(UNLICENSED — pattern studied, no code copied).

References
----------
  execution/pre_cgir_gate/gate_function.py  — downstream gate
  execution/pre_cgir_gate/gate_proof.py     — gate proof
  sigma_anchors.py                          — system constants
  INVARIANTS.md                             — I1 (gate is the only crossing)
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, List, Optional, Set


# ─── LEAF ─────────────────────────────────────────────────────────────────────

def _make_leaf(
    action_type: str,
    allowed_sources: List[str],
    max_confidence_required: float,
    notes: str = "",
) -> bytes:
    """
    Hash a permitted operation specification into a Merkle leaf.

    The leaf commits to:
    - action_type:               what category of operation is permitted
    - allowed_sources:           which input sources may produce it (sorted)
    - max_confidence_required:   minimum confidence gate threshold
    - notes:                     human-readable description (informational)
    """
    payload = json.dumps({
        "action_type":             action_type,
        "allowed_sources":         sorted(allowed_sources),
        "max_confidence_required": max_confidence_required,
    }, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode()).digest()


def _build_tree(leaves: List[bytes]) -> List[List[bytes]]:
    """Build a binary Merkle tree from a list of leaf hashes."""
    if not leaves:
        return [[hashlib.sha256(b"empty").digest()]]

    level: List[bytes] = list(leaves)
    if len(level) % 2 == 1:
        level.append(level[-1])  # duplicate last leaf if odd count

    tree: List[List[bytes]] = [level]
    while len(level) > 1:
        next_level = []
        for i in range(0, len(level), 2):
            combined = level[i] + level[i + 1]
            next_level.append(hashlib.sha256(combined).digest())
        if len(next_level) % 2 == 1 and len(next_level) > 1:
            next_level.append(next_level[-1])
        tree.append(next_level)
        level = next_level

    return tree


# ─── PERMIT ───────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class OperationPermit:
    """
    A single permitted operation specification.

    Fields
    ------
    action_type:
        The action category. Must match proposal.action_type exactly.
        Examples: "EPISTEMIC_QUERY", "ARCHIVE_WRITE", "GATE_CROSSING",
                  "SENSOR_READ", "INFERENCE_CALL", "LEDGER_APPEND"
    allowed_sources:
        Which input sources may produce this action type.
        Empty list means any source is permitted.
    min_confidence:
        Minimum confidence required for this action type to proceed.
        0.0 means no minimum (gate threshold applies independently).
    notes:
        Human-readable description. Informational only.
    """
    action_type:      str
    allowed_sources:  tuple = ()
    min_confidence:   float = 0.0
    notes:            str   = ""

    def leaf(self) -> bytes:
        return _make_leaf(
            self.action_type,
            list(self.allowed_sources),
            self.min_confidence,
            self.notes,
        )

    def leaf_hex(self) -> str:
        return self.leaf().hex()


# ─── CHECK RESULT ─────────────────────────────────────────────────────────────

@unique
class PermitVerdict(str, Enum):
    PERMITTED    = "PERMITTED"    # action type is in the permit set
    NOT_PERMITTED = "NOT_PERMITTED"  # action type was never registered
    EMPTY_SET    = "EMPTY_SET"    # no permits registered — fail closed


@dataclass
class PermitCheckResult:
    verdict:     PermitVerdict
    action_type: str
    permit:      Optional[OperationPermit]
    reason:      str
    checked_at:  float = field(default_factory=time.time)

    @property
    def permitted(self) -> bool:
        return self.verdict == PermitVerdict.PERMITTED


# ─── MERKLE PERMIT SET ────────────────────────────────────────────────────────

class MerklePermitSet:
    """
    Commit a set of permitted operation types to a Merkle tree.

    After construction, the Merkle root is fixed. Checking a proposal
    is O(log n) and does not require iterating the full permit set.

    Labyrinth-OS Default Permits
    ----------------------------
    The class method `labyrinth_default()` returns the standard set
    of permitted action types for the Labyrinth-OS research system.

    Usage
    -----
        permits = MerklePermitSet.labyrinth_default()
        result = permits.check("EPISTEMIC_QUERY")
        if not result.permitted:
            # proposal structurally excluded — never reaches gate
    """

    def __init__(self, permits: List[OperationPermit]) -> None:
        self._permits: Dict[str, OperationPermit] = {
            p.action_type: p for p in permits
        }
        leaves = [p.leaf() for p in permits]
        self._tree = _build_tree(leaves)
        root = self._tree[-1][0] if self._tree else hashlib.sha256(b"empty").digest()
        self._root_hex: str = root.hex()
        self._built_at: float = time.time()

    @classmethod
    def labyrinth_default(cls) -> "MerklePermitSet":
        """
        Standard Labyrinth-OS permitted operation set.

        Every action type that may legitimately enter the pipeline
        must be listed here. Anything not listed is structurally excluded
        before it reaches the gate.
        """
        permits = [
            OperationPermit(
                "EPISTEMIC_QUERY",
                notes="Epistemic labeling — L05 input"
            ),
            OperationPermit(
                "ARCHIVE_WRITE",
                notes="Archive memory write — L06"
            ),
            OperationPermit(
                "ARCHIVE_READ",
                notes="Archive memory read / recall"
            ),
            OperationPermit(
                "PROMOTION_PROPOSAL",
                notes="Idea promotion from SPECULATIVE — L08"
            ),
            OperationPermit(
                "GATE_CROSSING",
                min_confidence=0.65,
                notes="Reality gate crossing attempt — L09"
            ),
            OperationPermit(
                "INFERENCE_CALL",
                notes="Live LLM inference — A010 gate"
            ),
            OperationPermit(
                "SENSOR_READ",
                notes="Sensor channel read — pre-gate"
            ),
            OperationPermit(
                "LEDGER_APPEND",
                notes="WORM ledger append — L13"
            ),
            OperationPermit(
                "REPLAY_VERIFY",
                notes="Replay chain verification — L14/L18"
            ),
            OperationPermit(
                "FEEDBACK_RECORD",
                notes="Governance feedback — L20"
            ),
            OperationPermit(
                "HEALING_LOOP",
                notes="Continuous learning loop — runtime"
            ),
            OperationPermit(
                "DEFERRED_REENTRY",
                notes="Deferred node re-entry — L07"
            ),
        ]
        return cls(permits)

    def check(
        self,
        action_type: str,
        source: Optional[str] = None,
        confidence: Optional[float] = None,
    ) -> PermitCheckResult:
        """
        Check whether an action type is in the permit set.

        Parameters
        ----------
        action_type:  The proposed action category.
        source:       Which component is proposing this action (optional).
        confidence:   Proposed confidence level (optional — gate enforces independently).

        Returns
        -------
        PermitCheckResult with verdict PERMITTED or NOT_PERMITTED.
        """
        if not self._permits:
            return PermitCheckResult(
                PermitVerdict.EMPTY_SET,
                action_type,
                None,
                "No permits registered — fail closed",
            )

        permit = self._permits.get(action_type)
        if permit is None:
            return PermitCheckResult(
                PermitVerdict.NOT_PERMITTED,
                action_type,
                None,
                f"Action type '{action_type}' not in permit set (root={self._root_hex[:12]}…)",
            )

        # Source check
        if permit.allowed_sources and source is not None:
            if source not in permit.allowed_sources:
                return PermitCheckResult(
                    PermitVerdict.NOT_PERMITTED,
                    action_type,
                    permit,
                    f"Source '{source}' not in allowed_sources for '{action_type}'",
                )

        # Confidence floor check (informational — gate enforces independently)
        if permit.min_confidence > 0 and confidence is not None:
            if confidence < permit.min_confidence:
                return PermitCheckResult(
                    PermitVerdict.NOT_PERMITTED,
                    action_type,
                    permit,
                    f"Confidence {confidence:.3f} below permit minimum {permit.min_confidence:.3f}",
                )

        return PermitCheckResult(
            PermitVerdict.PERMITTED,
            action_type,
            permit,
            f"Permitted (root={self._root_hex[:12]}…)",
        )

    @property
    def root(self) -> str:
        """Hex-encoded Merkle root. Stable for a fixed permit set."""
        return self._root_hex

    @property
    def permit_count(self) -> int:
        return len(self._permits)

    @property
    def action_types(self) -> List[str]:
        return sorted(self._permits.keys())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "merkle_root":   self._root_hex,
            "permit_count":  self.permit_count,
            "action_types":  self.action_types,
            "built_at":      self._built_at,
        }


# ─── MODULE-LEVEL DEFAULT ─────────────────────────────────────────────────────
# Pre-built default instance — import and use directly.
LABYRINTH_PERMIT_SET = MerklePermitSet.labyrinth_default()


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_known_action_permitted() -> bool:
    ps = MerklePermitSet.labyrinth_default()
    r = ps.check("GATE_CROSSING")
    assert r.permitted, f"GATE_CROSSING should be permitted: {r.reason}"
    return True


def _test_unknown_action_not_permitted() -> bool:
    ps = MerklePermitSet.labyrinth_default()
    r = ps.check("TOTALLY_UNKNOWN_ACTION_XYZ")
    assert not r.permitted
    assert r.verdict == PermitVerdict.NOT_PERMITTED
    return True


def _test_root_is_stable() -> bool:
    ps1 = MerklePermitSet.labyrinth_default()
    ps2 = MerklePermitSet.labyrinth_default()
    assert ps1.root == ps2.root, "Same permit set must produce same root"
    return True


def _test_root_changes_with_different_set() -> bool:
    ps1 = MerklePermitSet([OperationPermit("A")])
    ps2 = MerklePermitSet([OperationPermit("A"), OperationPermit("B")])
    assert ps1.root != ps2.root, "Different permit sets must produce different roots"
    return True


def _test_all_default_permits_pass() -> bool:
    ps = MerklePermitSet.labyrinth_default()
    for action in ps.action_types:
        r = ps.check(action)
        assert r.permitted, f"{action} should be permitted"
    return True


def _test_confidence_below_minimum_rejected() -> bool:
    ps = MerklePermitSet([
        OperationPermit("GATE_CROSSING", min_confidence=0.65)
    ])
    r = ps.check("GATE_CROSSING", confidence=0.50)
    assert not r.permitted
    assert "below permit minimum" in r.reason
    return True


def _test_confidence_above_minimum_permitted() -> bool:
    ps = MerklePermitSet([
        OperationPermit("GATE_CROSSING", min_confidence=0.65)
    ])
    r = ps.check("GATE_CROSSING", confidence=0.90)
    assert r.permitted
    return True


def _test_empty_set_fails_closed() -> bool:
    ps = MerklePermitSet([])
    r = ps.check("ANYTHING")
    assert r.verdict == PermitVerdict.EMPTY_SET
    assert not r.permitted
    return True


def _test_to_dict_has_root() -> bool:
    ps = MerklePermitSet.labyrinth_default()
    d = ps.to_dict()
    assert "merkle_root" in d
    assert len(d["merkle_root"]) == 64  # SHA-256 hex
    return True


def _test_leaf_hex_is_stable() -> bool:
    p1 = OperationPermit("GATE_CROSSING", min_confidence=0.65)
    p2 = OperationPermit("GATE_CROSSING", min_confidence=0.65)
    assert p1.leaf_hex() == p2.leaf_hex()
    return True


def run_tests():
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0]
    )
    passed = failed = 0
    for name, fn in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
