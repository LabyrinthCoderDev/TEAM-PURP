# Reality Gate — Labyrinth-OS / L10.5

## Purpose

The Reality Gate is the **explicit architectural boundary** between the
epistemic side (labels, promotion) and the execution substrate (CGIR → Gate →
AEGIS → Ledger → Replay).

Nothing may cross this boundary without:
1. A **VALID** label category.
2. An **APPROVED** promotion decision.
3. An **AuditRecord** in the AuditTrail.
4. A **CGIR proof** for the edge.
5. Confidence ≥ **0.85**.

## Position in the Architecture

```
EPISTEMIC SIDE                    EXECUTION SIDE
──────────────────────────────────────────────────
Labeling (L3.5)
   ↓
Promotion (L6.5) ──→ [ REALITY GATE ] ──→ CGIR (L10)
                                      ↓
                                    Gate (L11)
                                      ↓
                                   AEGIS (L12)
                                      ↓
                                  Ledger (L13)
                                      ↓
                                  Replay (L14)
```

## Modules

| File | Role |
|------|------|
| `gate_function.py` | Pure deterministic decision: YES or NO |
| `gate_binding.py` | Enumerate and check binding rules |
| `gate_proof.py` | Cryptographic receipt of gate passage |
| `gate_rejection.py` | Log and escalate rejections |
| `reality_gate_tests.py` | Unit tests |

## Invariants

- **I2** — Gate Determinism: same inputs → same decision.
- **I5** — Gate Precedence: Reality Gate NO is binding; execution gate may not upgrade.
- **I10** — Fail Closed: ambiguity → NO.

## Non-Negotiable Rules

1. The gate is a **pure function** — no state, no side effects.
2. Every YES decision produces a **GateProof** anchored to the Ledger.
3. Every NO decision is logged in **GateRejector**.
4. **NOT_PROMOTED** is always a rejection — no exceptions.
5. The gate threshold (0.85) may not be lowered without an architectural review.
