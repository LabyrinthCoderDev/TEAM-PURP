# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          reality_gate_tests.py — Labyrinth-OS / Reality Gate (L10.5)
# ----------------------------------------------------------------------------

"""
reality_gate_tests.py — Labyrinth-OS / Reality Gate (L10.5)
============================================================
Unit tests for the Reality Gate layer.

Run with:
    python -m pytest execution/reality_gate/reality_gate_tests.py -v
"""

from __future__ import annotations

import time
import unittest

from gate_function import GateFunction, GateDecision, GateVerdict
from gate_binding import GateBinding, BindingRule, BindingResult
from gate_proof import GateProof
from gate_rejection import GateRejector, GateRejection, GateRejectionReason


# ─── GATE FUNCTION TESTS ─────────────────────────────────────────────────────

class TestGateFunction(unittest.TestCase):

    def setUp(self):
        self.gate = GateFunction()

    def _eval(self, **kw) -> GateDecision:
        defaults = dict(
            label_id="lbl-001",
            confidence=0.92,
            promoted=True,
            label_category="VALID",
            timestamp=1000.0,
        )
        defaults.update(kw)
        return self.gate.evaluate(**defaults)

    # ── allowed ───────────────────────────────────────────────────────────────

    def test_valid_promoted_allows(self):
        decision = self._eval()
        self.assertEqual(decision.verdict, GateVerdict.YES)
        self.assertTrue(decision.allowed)

    # ── blocked ───────────────────────────────────────────────────────────────

    def test_not_promoted_blocks(self):
        decision = self._eval(promoted=False)
        self.assertEqual(decision.verdict, GateVerdict.NO)
        self.assertFalse(decision.allowed)
        self.assertIn("NOT_PROMOTED", decision.rejection_reason)

    def test_low_confidence_blocks(self):
        decision = self._eval(confidence=0.50)
        self.assertEqual(decision.verdict, GateVerdict.NO)
        self.assertIn("CONFIDENCE_TOO_LOW", decision.rejection_reason)

    def test_invalid_category_blocks(self):
        decision = self._eval(label_category="UNCERTAIN")
        self.assertEqual(decision.verdict, GateVerdict.NO)
        self.assertIn("INVALID_CATEGORY", decision.rejection_reason)

    # ── determinism ───────────────────────────────────────────────────────────

    def test_deterministic_same_inputs_same_output(self):
        d1 = self._eval()
        d2 = self._eval()
        self.assertEqual(d1.decision_hash, d2.decision_hash)

    def test_different_label_id_different_hash(self):
        d1 = self._eval(label_id="lbl-A")
        d2 = self._eval(label_id="lbl-B")
        self.assertNotEqual(d1.decision_hash, d2.decision_hash)

    def test_decision_hash_is_hex(self):
        decision = self._eval()
        int(decision.decision_hash, 16)  # raises if not hex

    # ── no side effects ───────────────────────────────────────────────────────

    def test_multiple_evaluations_independent(self):
        for _ in range(10):
            d = self._eval(label_id="lbl-repeated", timestamp=1000.0)
            self.assertEqual(d.verdict, GateVerdict.YES)

    # ── fail closed ───────────────────────────────────────────────────────────

    def test_zero_confidence_blocked(self):
        d = self._eval(confidence=0.0)
        self.assertEqual(d.verdict, GateVerdict.NO)

    def test_empty_label_id_still_evaluated(self):
        d = self._eval(label_id="")
        # Gate still runs; block due to empty is not a hard rule, but
        # we verify it at least returns a decision.
        self.assertIsInstance(d, GateDecision)


# ─── GATE BINDING TESTS ──────────────────────────────────────────────────────

class TestGateBinding(unittest.TestCase):

    def setUp(self):
        self.binding = GateBinding()

    def _check(self, **kw) -> BindingResult:
        defaults = dict(
            promoted=True,
            has_audit_record=True,
            has_cgir_proof=True,
            confidence=0.90,
            category="VALID",
        )
        defaults.update(kw)
        return self.binding.check(**defaults)

    def test_all_rules_pass(self):
        result = self._check()
        self.assertTrue(result.passed)
        self.assertEqual(result.failed_rules, [])

    def test_not_promoted_fails(self):
        result = self._check(promoted=False)
        self.assertFalse(result.passed)
        self.assertIn(BindingRule.MUST_BE_PROMOTED, result.failed_rules)

    def test_no_audit_record_fails(self):
        result = self._check(has_audit_record=False)
        self.assertIn(BindingRule.MUST_HAVE_AUDIT_RECORD, result.failed_rules)

    def test_no_cgir_proof_fails(self):
        result = self._check(has_cgir_proof=False)
        self.assertIn(BindingRule.MUST_HAVE_CGIR_PROOF, result.failed_rules)

    def test_low_confidence_fails(self):
        result = self._check(confidence=0.50)
        self.assertIn(BindingRule.CONFIDENCE_ABOVE_THRESHOLD, result.failed_rules)

    def test_invalid_category_fails(self):
        result = self._check(category="REJECTED")
        self.assertIn(BindingRule.CATEGORY_MUST_BE_VALID, result.failed_rules)

    def test_multiple_failures_all_captured(self):
        result = self._check(promoted=False, has_audit_record=False, confidence=0.10)
        self.assertGreaterEqual(len(result.failed_rules), 3)

    def test_all_rules_enumerated(self):
        self.assertEqual(len(self.binding.all_rules()), len(BindingRule))


# ─── GATE PROOF TESTS ────────────────────────────────────────────────────────

class TestGateProof(unittest.TestCase):

    def _proof(self, **kw) -> GateProof:
        defaults = dict(
            label_id="lbl-001",
            decision_hash="a" * 64,
            audit_trail_hash="b" * 64,
            confidence=0.92,
            timestamp=1000.0,
        )
        defaults.update(kw)
        return GateProof.issue(**defaults)

    def test_issue_returns_proof(self):
        proof = self._proof()
        self.assertIsInstance(proof, GateProof)

    def test_proof_hash_is_hex(self):
        proof = self._proof()
        int(proof.proof_hash, 16)

    def test_verify_with_same_inputs(self):
        proof = self._proof()
        self.assertTrue(proof.verify(
            label_id="lbl-001",
            decision_hash="a" * 64,
            audit_trail_hash="b" * 64,
            confidence=0.92,
            timestamp=1000.0,
        ))

    def test_verify_fails_with_tampered_label_id(self):
        proof = self._proof()
        self.assertFalse(proof.verify(
            label_id="lbl-TAMPERED",
            decision_hash="a" * 64,
            audit_trail_hash="b" * 64,
            confidence=0.92,
            timestamp=1000.0,
        ))

    def test_verify_fails_with_tampered_confidence(self):
        proof = self._proof()
        self.assertFalse(proof.verify(
            label_id="lbl-001",
            decision_hash="a" * 64,
            audit_trail_hash="b" * 64,
            confidence=0.50,   # tampered
            timestamp=1000.0,
        ))

    def test_proof_is_immutable(self):
        proof = self._proof()
        with self.assertRaises(Exception):
            proof.proof_hash = "tampered"  # type: ignore[misc]

    def test_different_inputs_different_hash(self):
        p1 = self._proof(label_id="lbl-A")
        p2 = self._proof(label_id="lbl-B")
        self.assertNotEqual(p1.proof_hash, p2.proof_hash)

    def test_deterministic(self):
        p1 = self._proof()
        p2 = self._proof()
        self.assertEqual(p1.proof_hash, p2.proof_hash)


# ─── GATE REJECTION TESTS ────────────────────────────────────────────────────

class TestGateRejector(unittest.TestCase):

    def setUp(self):
        self.rejector = GateRejector(escalation_threshold=3)

    def test_reject_returns_record(self):
        r = self.rejector.reject(
            label_id="lbl-001",
            reason=GateRejectionReason.NOT_PROMOTED,
            detail="not promoted",
        )
        self.assertIsInstance(r, GateRejection)
        self.assertEqual(r.rejection_id, 1)

    def test_sequential_ids(self):
        for i in range(5):
            r = self.rejector.reject(f"lbl-{i}", GateRejectionReason.CONFIDENCE_TOO_LOW, "low")
        self.assertEqual(r.rejection_id, 5)

    def test_count_all(self):
        for _ in range(3):
            self.rejector.reject("lbl-x", GateRejectionReason.NOT_PROMOTED, "x")
        self.assertEqual(self.rejector.count(), 3)

    def test_count_by_reason(self):
        self.rejector.reject("lbl-a", GateRejectionReason.NOT_PROMOTED, "a")
        self.rejector.reject("lbl-b", GateRejectionReason.CONFIDENCE_TOO_LOW, "b")
        self.assertEqual(self.rejector.count(GateRejectionReason.NOT_PROMOTED), 1)

    def test_should_not_escalate_below_threshold(self):
        self.rejector.reject("lbl-1", GateRejectionReason.NOT_PROMOTED, "a")
        self.assertFalse(self.rejector.should_escalate())

    def test_should_escalate_at_threshold(self):
        for i in range(3):
            self.rejector.reject(f"lbl-{i}", GateRejectionReason.NOT_PROMOTED, "x")
        self.assertTrue(self.rejector.should_escalate())

    def test_rejection_rate(self):
        for _ in range(2):
            self.rejector.reject("lbl-x", GateRejectionReason.NOT_PROMOTED, "x")
        self.assertAlmostEqual(self.rejector.rejection_rate(total_evaluated=10), 0.2)

    def test_query_by_label_id(self):
        self.rejector.reject("lbl-A", GateRejectionReason.NOT_PROMOTED, "a")
        self.rejector.reject("lbl-B", GateRejectionReason.NOT_PROMOTED, "b")
        results = self.rejector.query(label_id="lbl-A")
        self.assertEqual(len(results), 1)

    def test_append_only_no_delete(self):
        self.assertFalse(hasattr(self.rejector, "delete"))



def run_tests() -> tuple:
    """Labyrinth-OS standard runner — wraps unittest for run_all.py compatibility."""
    import unittest, io
    loader = unittest.TestLoader()
    suite  = loader.loadTestsFromModule(__import__(__name__))
    buf    = io.StringIO()
    runner = unittest.TextTestRunner(stream=buf, verbosity=0)
    result = runner.run(suite)
    passed = result.testsRun - len(result.failures) - len(result.errors)
    failed = len(result.failures) + len(result.errors)
    results = []
    for test, tb in result.failures + result.errors:
        results.append((str(test), "FAIL", tb.split("\n")[-2]))
    for i in range(passed):
        results.append((f"test_{i:03}", "PASS", None))
    return passed, failed, results


if __name__ == "__main__":
    import unittest
    unittest.main()
