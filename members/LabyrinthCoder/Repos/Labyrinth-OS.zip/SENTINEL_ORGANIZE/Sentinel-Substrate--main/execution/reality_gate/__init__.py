# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          execution/reality_gate — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
execution/reality_gate — Labyrinth-OS
======================================
Lane 1 → Lane 2 crossing gate. Preserved location.

See also: execution/pre_cgir_gate/ — same modules, renamed for clarity.
pre_cgir_gate is the canonical name (enforces I5: gate BEFORE CGIR).
This directory is preserved as a reference and for backward compatibility.

Gate ordering:
  1. PROMOTION_PROTOCOL  (lane1/08)
  2. REALITY_GATE        (this dir / pre_cgir_gate)  ← BEFORE CGIR
  3. EXECUTION_GATE      (execution/gate)
"""
