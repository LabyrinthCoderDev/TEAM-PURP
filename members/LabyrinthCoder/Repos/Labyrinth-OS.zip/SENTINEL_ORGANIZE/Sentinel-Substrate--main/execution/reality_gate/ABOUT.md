# execution/reality_gate — About This Directory

This directory is preserved intentionally. It is not empty by mistake.

## What This Was
The original location for the pre-CGIR gate modules before the
architectural audit renamed them for clarity.

## What Happened
During an audit pass, these modules were copied to:
  execution/pre_cgir_gate/

The new name makes Invariant I5 explicit in the directory name itself:
"pre_cgir" = this gate runs BEFORE CGIR translation.

## Why This Directory Still Exists
Hard Invariant I10: nothing is deleted.
This directory is preserved for backward compatibility and provenance.

## What To Use
For all active development: use execution/pre_cgir_gate/
The __init__.py in this directory documents the relationship.

## Gate Order (for reference)
1. PROMOTION_PROTOCOL  (lane1/08_promotion_protocol/)
2. REALITY_GATE        (this dir / execution/pre_cgir_gate/) ← BEFORE CGIR
3. EXECUTION_GATE      (execution/gate/cgir_gate.py)
