# Observability — Labyrinth-OS / Epistemic L5.75

## Purpose

Provide end-to-end visibility into the epistemic pipeline: collect metrics at
each stage, detect drift, log anomalies, and close the feedback loop back into
the labeling validator and promotion rules.

## Position in the Architecture

```
Labeling (L3.5) ──→ Archive (L5.5) ──→ Promotion (L6.5) → Reality Gate
       ↑                  ↑
  Observability (L5.75) feeds anomalies back to both
```

## Σ Anchor Constants (mirrored from execution/gate)

| Constant | Value | Meaning |
|----------|-------|---------|
| `TAU_ESCAPE_FLOOR` | 0.75 | τ below → CRITICAL |
| `DRIFT_THRESHOLD` | 0.12 | drift at/above → ERROR |
| `CHI_WARN` | 0.15 | χ at/above → WARN |
| `CHI_COLLAPSE` | 0.40 | χ at/above → CRITICAL |
| `BETTI_1_CAP` | 0.045 | β₁ at/above → ERROR |

## Feedback Loop Path

```
Anomaly detected
  → AnomalyLog.append()
  → FeedbackLoop.process()
  → confidence_adjustment computed
  → LabelValidator receives suggested confidence delta
  → PromotionRules re-evaluated
  → Archive updated with outcome
```

## Modules

| File | Role |
|------|------|
| `metrics.py` | SystemMetrics snapshot + MetricsCollector |
| `drift_detector.py` | Compare snapshots to baseline; emit DriftAlert |
| `anomaly_log.py` | Append-only anomaly record |
| `feedback_loop.py` | Anomalies → confidence adjustments → flags |
| `observability_tests.py` | Unit tests |

## Invariants

- **I13** — Observability Completeness: all metrics logged.
- **I15** — Feedback Loop Closure: anomalies → archive → label confidence.
- **I10** — Fail Closed: anomalies always reduce confidence, never increase it.
