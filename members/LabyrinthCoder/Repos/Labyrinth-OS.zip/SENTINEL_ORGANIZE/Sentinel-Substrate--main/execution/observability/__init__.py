# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          epistemic/observability — Labyrinth-OS / Epistemic Layer L5.75
# ----------------------------------------------------------------------------

"""
epistemic/observability — Labyrinth-OS / Epistemic Layer L5.75
===============================================================
Observability: metrics, drift detection, anomaly logging, feedback loop.

Exports:
    SystemMetrics, MetricsCollector   — metric collection
    DriftDetector                      — detect system drift
    AnomalyLog, AnomalyEntry           — anomaly record
    FeedbackLoop                       — metrics → archive → labeling cycle
"""

from metrics import SystemMetrics, MetricsCollector
from drift_detector import DriftDetector, DriftAlert
from anomaly_log import AnomalyLog, AnomalyEntry, AnomalySeverity
from feedback_loop import FeedbackLoop, FeedbackResult

__all__ = [
    "SystemMetrics",
    "MetricsCollector",
    "DriftDetector",
    "DriftAlert",
    "AnomalyLog",
    "AnomalyEntry",
    "AnomalySeverity",
    "FeedbackLoop",
    "FeedbackResult",
]
