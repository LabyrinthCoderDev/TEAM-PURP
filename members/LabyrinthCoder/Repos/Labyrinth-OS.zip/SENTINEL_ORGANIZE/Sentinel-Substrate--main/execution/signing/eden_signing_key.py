# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          eden_signing_key.py — Labyrinth-OS / Execution / Signing
# ----------------------------------------------------------------------------

"""
eden_signing_key.py — Labyrinth-OS / Execution / Signing
==========================================================
A018 — EDEN_SIGNING_KEY Survives Daemon Restart Without Rekey

The signing key must persist across daemon restarts and produce
valid Chronicle signatures after each restart cycle. Rekeying
on every restart would break Chronicle chain continuity —
signatures from before and after restart would use different keys,
making cross-restart audit impossible.

Architecture
------------
The key is derived deterministically from a stable secret (env var or
keyfile) using HKDF-SHA256. The same input always produces the same
key. No state needs to be persisted between restarts — the key is
regenerated from the same stable source on each boot.

This means:
  - Key survives restart because it can be regenerated, not stored
  - No key material is written to disk (reduces attack surface)
  - Chronicle signatures are verifiable across restart boundaries
  - If the stable secret changes, all old signatures remain valid
    (old key was deterministic from old secret — still reproducible)

A018 closes when:
  - Key persists across 3 restart cycles with valid Chronicle signatures
  - Signatures produced before restart verify against post-restart key
  - Key derivation is deterministic (same input → same key always)

References
----------
  ACP-1 A018
  execution/ledger/cgir_ledger.py  — Chronicle signatures
  runtime/ignition.py              — model_fingerprint field
"""

from __future__ import annotations

import hashlib
import hmac
import os
import time
from dataclasses import dataclass
from typing import Optional

# Key derivation constants
_HKDF_HASH      = "sha256"
_KEY_LEN        = 32        # 256-bit signing key
_SIGNING_SALT   = b"labyrinth-os-eden-signing-v1"
_INFO_BYTES     = b"chronicle-signing-key"

# Environment variable name for the stable secret
EDEN_SECRET_ENV = "EDEN_SIGNING_SECRET"

# Fallback file path for secret (if env var not set)
EDEN_SECRET_FILE = os.path.join(
    os.path.dirname(__file__), '..', '..', 'config', 'eden_secret.key'
)


# ─── KEY DERIVATION ───────────────────────────────────────────────────────────

def _hkdf_extract(salt: bytes, ikm: bytes) -> bytes:
    """HKDF extract step: PRK = HMAC-Hash(salt, IKM)."""
    return hmac.new(salt, ikm, _HKDF_HASH).digest()


def _hkdf_expand(prk: bytes, info: bytes, length: int) -> bytes:
    """HKDF expand step: produce `length` bytes of keying material."""
    n = (length + 31) // 32  # ceil(length / hashlen) for SHA-256
    okm = b""
    t = b""
    for i in range(1, n + 1):
        t = hmac.new(prk, t + info + bytes([i]), _HKDF_HASH).digest()
        okm += t
    return okm[:length]


def derive_signing_key(secret: bytes) -> bytes:
    """
    Derive a deterministic 256-bit signing key from a stable secret.

    Uses HKDF-SHA256 with a fixed salt and info string. The same
    secret always produces the same key. Safe to call on every restart.

    Parameters
    ----------
    secret: Raw secret bytes (from env var or key file).

    Returns
    -------
    32-byte signing key.
    """
    prk = _hkdf_extract(_SIGNING_SALT, secret)
    return _hkdf_expand(prk, _INFO_BYTES, _KEY_LEN)


# ─── SECRET LOADING ───────────────────────────────────────────────────────────

def load_secret() -> Optional[bytes]:
    """
    Load the stable secret from environment or key file.

    Priority:
    1. EDEN_SIGNING_SECRET environment variable (hex or raw)
    2. config/eden_secret.key file (hex or raw bytes)
    3. None — caller must handle missing secret

    Returns
    -------
    Secret bytes or None if unavailable.
    """
    # Check env var
    env_secret = os.environ.get(EDEN_SECRET_ENV)
    if env_secret:
        try:
            return bytes.fromhex(env_secret)
        except ValueError:
            return env_secret.encode()

    # Check key file
    key_path = os.path.normpath(EDEN_SECRET_FILE)
    if os.path.exists(key_path):
        try:
            raw = open(key_path, 'rb').read().strip()
            try:
                return bytes.fromhex(raw.decode())
            except (ValueError, UnicodeDecodeError):
                return raw
        except (IOError, OSError):
            pass

    return None


# ─── SIGNING ──────────────────────────────────────────────────────────────────

def sign_chronicle_entry(key: bytes, entry_json: str) -> str:
    """
    Produce an HMAC-SHA256 signature over a Chronicle entry.

    Parameters
    ----------
    key:         32-byte signing key from derive_signing_key().
    entry_json:  JSON string of the Chronicle entry.

    Returns
    -------
    Hex-encoded HMAC-SHA256 signature.
    """
    return hmac.new(key, entry_json.encode(), "sha256").hexdigest()


def verify_chronicle_entry(key: bytes, entry_json: str, signature: str) -> bool:
    """
    Verify an HMAC-SHA256 signature over a Chronicle entry.

    Uses hmac.compare_digest to prevent timing attacks.

    Returns
    -------
    True if signature is valid.
    """
    expected = sign_chronicle_entry(key, entry_json)
    return hmac.compare_digest(expected, signature)


# ─── SESSION KEY MANAGER ──────────────────────────────────────────────────────

@dataclass
class SigningKeyManager:
    """
    Manages the session signing key lifecycle.

    On init: derives key from stable secret.
    On restart: same derivation produces same key — no rekey needed.
    Tracks restart cycles for A018 verification.

    Usage
    -----
        mgr = SigningKeyManager.from_environment()
        sig = mgr.sign(entry_json)
        assert mgr.verify(entry_json, sig)
    """
    key:              bytes
    secret_source:    str     # "env", "file", or "generated"
    restart_cycle:    int
    initialized_at:   float

    @classmethod
    def from_environment(cls, restart_cycle: int = 0) -> "SigningKeyManager":
        """
        Create a SigningKeyManager from the environment.
        Safe to call on every daemon restart — deterministic.
        """
        secret = load_secret()
        if secret is None:
            # No secret configured — derive from a stable machine fingerprint
            # This is a prototype fallback; production requires EDEN_SIGNING_SECRET
            machine_id = _get_machine_fingerprint()
            secret = machine_id.encode()
            source = "generated"
        else:
            source = "env" if os.environ.get(EDEN_SECRET_ENV) else "file"

        key = derive_signing_key(secret)
        return cls(
            key=key,
            secret_source=source,
            restart_cycle=restart_cycle,
            initialized_at=time.time(),
        )

    def sign(self, entry_json: str) -> str:
        return sign_chronicle_entry(self.key, entry_json)

    def verify(self, entry_json: str, signature: str) -> bool:
        return verify_chronicle_entry(self.key, entry_json, signature)

    @property
    def key_hex(self) -> str:
        return self.key.hex()

    @property
    def key_fingerprint(self) -> str:
        """Short public fingerprint — first 16 hex chars of SHA-256 of key."""
        return hashlib.sha256(self.key).hexdigest()[:16]


def _get_machine_fingerprint() -> str:
    """
    Produce a stable machine fingerprint for fallback key derivation.
    Uses /etc/machine-id or a hash of the hostname.
    Not cryptographically strong — prototype fallback only.
    """
    machine_id_path = "/etc/machine-id"
    if os.path.exists(machine_id_path):
        try:
            return open(machine_id_path).read().strip()
        except (IOError, OSError):
            pass
    import socket
    return hashlib.sha256(socket.gethostname().encode()).hexdigest()


# ─── A018 RESTART VERIFICATION ────────────────────────────────────────────────

def verify_restart_persistence(
    n_restarts: int = 3,
    secret: Optional[bytes] = None,
) -> dict:
    """
    Verify that the signing key persists across n_restarts restart cycles.

    Simulates n_restarts independent key derivations and verifies:
    1. All derivations produce the same key
    2. Signatures from one cycle verify against keys from other cycles
    3. Each cycle's signatures are independent but mutually verifiable

    Returns
    -------
    dict with:
      - passed: bool
      - restart_count: int
      - key_stable: bool
      - cross_verify_passed: bool
      - fingerprint: str (stable across restarts)
    """
    if secret is None:
        secret = load_secret() or _get_machine_fingerprint().encode()

    keys = []
    signatures = []
    test_entry = '{"event":"TEST","timestamp":1234567890}'

    for i in range(n_restarts):
        key = derive_signing_key(secret)
        sig = sign_chronicle_entry(key, test_entry)
        keys.append(key)
        signatures.append(sig)

    # All keys must be identical (deterministic derivation)
    key_stable = all(k == keys[0] for k in keys)

    # All signatures must be identical (same key + same content)
    sigs_stable = all(s == signatures[0] for s in signatures)

    # Cross-verify: sign with key[0], verify with key[1], key[2]
    cross_verify = all(
        verify_chronicle_entry(keys[j], test_entry, signatures[0])
        for j in range(1, n_restarts)
    )

    passed = key_stable and sigs_stable and cross_verify

    return {
        "passed":              passed,
        "restart_count":       n_restarts,
        "key_stable":          key_stable,
        "sigs_stable":         sigs_stable,
        "cross_verify_passed": cross_verify,
        "fingerprint":         hashlib.sha256(keys[0]).hexdigest()[:16],
        "secret_source":       "env" if os.environ.get(EDEN_SECRET_ENV) else "derived",
    }


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_key_derivation_deterministic() -> bool:
    secret = b"test-secret-for-unit-test"
    k1 = derive_signing_key(secret)
    k2 = derive_signing_key(secret)
    assert k1 == k2, "Same secret must produce same key"
    assert len(k1) == 32
    return True


def _test_different_secrets_different_keys() -> bool:
    k1 = derive_signing_key(b"secret-a")
    k2 = derive_signing_key(b"secret-b")
    assert k1 != k2
    return True


def _test_sign_and_verify() -> bool:
    key = derive_signing_key(b"test-key")
    entry = '{"event":"GATE_ALLOW","label_id":"L001"}'
    sig = sign_chronicle_entry(key, entry)
    assert verify_chronicle_entry(key, entry, sig)
    return True


def _test_tampered_entry_fails_verify() -> bool:
    key = derive_signing_key(b"test-key")
    entry = '{"event":"GATE_ALLOW"}'
    sig = sign_chronicle_entry(key, entry)
    tampered = '{"event":"GATE_BLOCK"}'
    assert not verify_chronicle_entry(key, tampered, sig)
    return True


def _test_wrong_key_fails_verify() -> bool:
    k1 = derive_signing_key(b"key-a")
    k2 = derive_signing_key(b"key-b")
    entry = '{"event":"TEST"}'
    sig = sign_chronicle_entry(k1, entry)
    assert not verify_chronicle_entry(k2, entry, sig)
    return True


def _test_restart_persistence_3_cycles() -> bool:
    result = verify_restart_persistence(n_restarts=3, secret=b"test-stable-secret")
    assert result["passed"], f"A018 restart check failed: {result}"
    assert result["key_stable"]
    assert result["cross_verify_passed"]
    return True


def _test_signing_key_manager_from_env() -> bool:
    mgr = SigningKeyManager.from_environment(restart_cycle=0)
    assert len(mgr.key) == 32
    assert mgr.key_fingerprint and len(mgr.key_fingerprint) == 16
    return True


def _test_manager_sign_verify() -> bool:
    mgr = SigningKeyManager.from_environment()
    entry = '{"event":"LEDGER_APPEND","seq":42}'
    sig = mgr.sign(entry)
    assert mgr.verify(entry, sig)
    assert not mgr.verify('{"event":"TAMPERED"}', sig)
    return True


def _test_manager_restart_same_key() -> bool:
    """Two managers initialized from same env produce same key."""
    mgr1 = SigningKeyManager.from_environment(restart_cycle=0)
    mgr2 = SigningKeyManager.from_environment(restart_cycle=1)
    assert mgr1.key == mgr2.key, \
        "Key must be identical across restart cycles"
    assert mgr1.key_fingerprint == mgr2.key_fingerprint
    return True


def _test_a018_full_verification() -> bool:
    result = verify_restart_persistence(n_restarts=3)
    assert result["passed"]
    assert result["restart_count"] == 3
    return True


def run_tests():
    tests = [
        (_test_key_derivation_deterministic,    "key_derivation_deterministic"),
        (_test_different_secrets_different_keys, "different_secrets"),
        (_test_sign_and_verify,                  "sign_and_verify"),
        (_test_tampered_entry_fails_verify,      "tampered_entry_fails"),
        (_test_wrong_key_fails_verify,           "wrong_key_fails"),
        (_test_restart_persistence_3_cycles,     "restart_3_cycles"),
        (_test_signing_key_manager_from_env,     "manager_from_env"),
        (_test_manager_sign_verify,              "manager_sign_verify"),
        (_test_manager_restart_same_key,         "manager_restart_same_key"),
        (_test_a018_full_verification,           "a018_full_verify"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
