# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ◈  (Evidence/Verification)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          fractal_parameter_solver.py — Labyrinth-OS / Execution / Formal
# ----------------------------------------------------------------------------

"""
fractal_parameter_solver.py — Labyrinth-OS / Execution / Formal
=================================================================
A015 — Fractal Parameter Solver

Validates the fractal parameters (betti_1_cap, topological loop
thresholds) against observed model behavior across at least two
distinct model families.

Background
----------
The betti_1 signal measures topological loop density in the
epistemic graph — how many circular reasoning structures exist.
The current system uses betti_1 = 0.0 as a placeholder (BETTI_PLACEHOLDER
lesson from TrialReflection) because A015 has not yet been run with
live inference data.

This module:
  1. Defines the parameter validation framework
  2. Provides synthetic validation against two model families
  3. Defines what "valid parameters" means formally
  4. Generates a parameter validation receipt

A015 closes when:
  - Parameters validated against 2+ distinct model families
  - Validation receipt produced with formal bounds

The synthetic validation here uses known properties of the
parameters to produce a partial closure. Full closure requires
live inference data from A010.

References
----------
  ACP-1 A015
  sigma_anchors.py — betti_1_cap constant
  runtime/trial_reflection.py — BETTI_PLACEHOLDER lesson
"""

from __future__ import annotations

import hashlib
import json
import math
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


try:
    import sys as _sys, os as _os
    _root = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), '..', '..'))
    if _root not in _sys.path: _sys.path.insert(0, _root)
    from sigma_anchors import BETTI_1_CAP, TAU_ESCAPE_FLOOR, CONFIDENCE_FLOOR
except ImportError:
    BETTI_1_CAP       = 0.045
    TAU_ESCAPE_FLOOR  = 0.75
    CONFIDENCE_FLOOR  = 0.65


# ─── PARAMETER SET ────────────────────────────────────────────────────────────

@dataclass
class FractalParameterSet:
    """
    A candidate set of fractal parameters for betti_1 evaluation.

    Fields
    ------
    betti_1_cap:
        Maximum betti_1 value before topological loop count
        triggers a gate warning. Current default: 0.045.

    betti_1_warn_fraction:
        Fraction of betti_1_cap at which to emit a warning.
        E.g. 0.8 → warn at betti_1 >= 0.036.

    min_samples_for_estimate:
        Minimum number of trials required before betti_1 estimate
        is considered reliable. Below this threshold, betti_1 is
        treated as a placeholder.

    confidence_coupling:
        How strongly betti_1 should be coupled to confidence.
        High betti_1 with high confidence is a contradiction signal.
        Range [0.0, 1.0]. Default 0.5.
    """
    betti_1_cap:               float = BETTI_1_CAP
    betti_1_warn_fraction:     float = 0.80
    min_samples_for_estimate:  int   = 10
    confidence_coupling:       float = 0.50
    model_family:              str   = "unknown"
    validated_at:              float = field(default_factory=time.time)

    @property
    def betti_1_warn_threshold(self) -> float:
        return self.betti_1_cap * self.betti_1_warn_fraction

    def is_placeholder(self, sample_count: int) -> bool:
        return sample_count < self.min_samples_for_estimate


# ─── OBSERVATION ──────────────────────────────────────────────────────────────

@dataclass
class BettiObservation:
    """A single betti_1 measurement from a trial."""
    betti_1:        float
    confidence:     float
    tau:            float
    model_family:   str
    trial_index:    int
    timestamp:      float = field(default_factory=time.time)

    @property
    def is_anomalous(self) -> bool:
        """High betti_1 with high confidence is anomalous."""
        return (self.betti_1 >= BETTI_1_CAP * 0.80 and
                self.confidence >= CONFIDENCE_FLOOR + 0.20)


# ─── VALIDATION RESULT ────────────────────────────────────────────────────────

@dataclass
class ParameterValidationResult:
    params:            FractalParameterSet
    model_family:      str
    sample_count:      int
    mean_betti_1:      float
    max_betti_1:       float
    anomaly_count:     int
    cap_violations:    int
    params_valid:      bool
    receipt_hash:      str
    notes:             List[str]
    validated_at:      float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "model_family":   self.model_family,
            "sample_count":   self.sample_count,
            "mean_betti_1":   self.mean_betti_1,
            "max_betti_1":    self.max_betti_1,
            "anomaly_count":  self.anomaly_count,
            "cap_violations": self.cap_violations,
            "params_valid":   self.params_valid,
            "receipt_hash":   self.receipt_hash,
            "betti_1_cap":    self.params.betti_1_cap,
            "validated_at":   self.validated_at,
            "notes":          self.notes,
        }


@dataclass
class A015Receipt:
    """Formal receipt for A015 closure."""
    families_validated:  List[str]
    results:             List[ParameterValidationResult]
    a015_partial:        bool    # True if synthetic; False if live data
    a015_closed:         bool    # True only with 2+ live model families
    recommended_params:  FractalParameterSet
    receipt_hash:        str
    generated_at:        float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "families_validated": self.families_validated,
            "a015_partial":       self.a015_partial,
            "a015_closed":        self.a015_closed,
            "recommended_params": {
                "betti_1_cap":   self.recommended_params.betti_1_cap,
                "warn_fraction": self.recommended_params.betti_1_warn_fraction,
            },
            "receipt_hash":       self.receipt_hash,
            "generated_at":       self.generated_at,
        }


# ─── SYNTHETIC MODEL FAMILIES ─────────────────────────────────────────────────

def _synthetic_observations_small_model(n: int = 50) -> List[BettiObservation]:
    """
    Synthetic betti_1 observations for a small (7B-13B) model family.
    Small models tend to have higher betti_1 due to more circular reasoning.
    Expected mean: ~0.025, max: ~0.060.
    """
    import random
    rng = random.Random(101)
    obs = []
    for i in range(n):
        # Small models: higher betti_1 variance
        b1 = max(0.0, rng.gauss(0.025, 0.012))
        conf = rng.uniform(0.65, 0.90)
        tau = rng.uniform(0.76, 0.92)
        obs.append(BettiObservation(
            betti_1=b1, confidence=conf, tau=tau,
            model_family="small_7b_13b", trial_index=i,
        ))
    return obs


def _synthetic_observations_large_model(n: int = 50) -> List[BettiObservation]:
    """
    Synthetic betti_1 observations for a large (70B+) model family.
    Large models tend to have lower betti_1 due to more coherent reasoning.
    Expected mean: ~0.012, max: ~0.035.
    """
    import random
    rng = random.Random(202)
    obs = []
    for i in range(n):
        # Large models: lower betti_1, tighter distribution
        b1 = max(0.0, rng.gauss(0.012, 0.008))
        conf = rng.uniform(0.72, 0.95)
        tau = rng.uniform(0.79, 0.96)
        obs.append(BettiObservation(
            betti_1=b1, confidence=conf, tau=tau,
            model_family="large_70b_plus", trial_index=i,
        ))
    return obs


# ─── VALIDATOR ────────────────────────────────────────────────────────────────

def validate_parameters(
    params: FractalParameterSet,
    observations: List[BettiObservation],
) -> ParameterValidationResult:
    """
    Validate a FractalParameterSet against a set of observations.

    Checks:
    1. Cap violations: how often betti_1 exceeds betti_1_cap
       (too many = cap is too tight; too few = cap may miss real anomalies)
    2. Anomaly detection: high betti_1 + high confidence cases
    3. Distribution properties: mean and max within expected range

    Parameters are valid if:
    - Cap violation rate < 15% (cap not too tight)
    - Cap violation rate > 0% (cap is reachable — not vacuous)
    - Mean betti_1 is above 0 (signal is real, not always zero)
    """
    n = len(observations)
    if n == 0:
        return ParameterValidationResult(
            params=params, model_family="unknown", sample_count=0,
            mean_betti_1=0.0, max_betti_1=0.0, anomaly_count=0,
            cap_violations=0, params_valid=False, receipt_hash="",
            notes=["No observations provided"],
        )

    values = [o.betti_1 for o in observations]
    mean_b1 = sum(values) / n
    max_b1  = max(values)
    cap_violations = sum(1 for v in values if v >= params.betti_1_cap)
    anomalies = sum(1 for o in observations if o.is_anomalous)

    cap_rate = cap_violations / n
    notes = []

    # Validate bounds
    valid = True
    if cap_rate >= 0.15:
        notes.append(f"CAP_TOO_TIGHT: {cap_rate:.1%} of observations exceed cap")
        valid = False
    if cap_rate == 0.0:
        notes.append("CAP_VACUOUS: no observations reach cap — may be too loose")
        # Not invalid — just informational for small model families
    if mean_b1 <= 0.0:
        notes.append("MEAN_ZERO: betti_1 always zero — placeholder state")
        valid = False

    if valid and not notes:
        notes.append(f"VALID: cap_rate={cap_rate:.1%} mean={mean_b1:.4f} "
                     f"max={max_b1:.4f} anomalies={anomalies}")

    # Receipt hash
    payload = json.dumps({
        "params": params.betti_1_cap,
        "n": n,
        "mean": mean_b1,
        "max": max_b1,
        "cap_violations": cap_violations,
    }, sort_keys=True)
    receipt = hashlib.sha256(payload.encode()).hexdigest()[:16]

    return ParameterValidationResult(
        params=params,
        model_family=observations[0].model_family if observations else "unknown",
        sample_count=n,
        mean_betti_1=mean_b1,
        max_betti_1=max_b1,
        anomaly_count=anomalies,
        cap_violations=cap_violations,
        params_valid=valid,
        receipt_hash=receipt,
        notes=notes,
    )


def run_a015_validation(
    live: bool = False,
) -> A015Receipt:
    """
    Run A015 parameter validation.

    Parameters
    ----------
    live: If True, attempt to use live inference data.
          If False, use synthetic observations (partial closure).

    Returns
    -------
    A015Receipt with validation results and recommended parameters.
    """
    params = FractalParameterSet(
        betti_1_cap=BETTI_1_CAP,
        betti_1_warn_fraction=0.80,
        min_samples_for_estimate=10,
        confidence_coupling=0.50,
    )

    if live:
        # Live path — not yet implemented (requires A010)
        raise NotImplementedError(
            "Live A015 validation requires A010 (first live inference). "
            "Run run_a015_validation(live=False) for synthetic partial closure."
        )

    # Synthetic validation against two model families
    families = {
        "small_7b_13b":   _synthetic_observations_small_model(50),
        "large_70b_plus": _synthetic_observations_large_model(50),
    }

    results = []
    for family_name, observations in families.items():
        params_copy = FractalParameterSet(
            betti_1_cap=params.betti_1_cap,
            betti_1_warn_fraction=params.betti_1_warn_fraction,
            min_samples_for_estimate=params.min_samples_for_estimate,
            confidence_coupling=params.confidence_coupling,
            model_family=family_name,
        )
        result = validate_parameters(params_copy, observations)
        results.append(result)

    families_validated = [r.model_family for r in results]
    all_valid = all(r.params_valid for r in results)

    # Exclude timestamps for deterministic hash
    hash_data = [{k: v for k, v in r.to_dict().items()
                  if k not in ("validated_at",)} for r in results]
    receipt_payload = json.dumps(hash_data, sort_keys=True)
    receipt_hash = hashlib.sha256(receipt_payload.encode()).hexdigest()[:24]

    # A015 is partially closed by synthetic validation.
    # Full closure requires live inference data from A010.
    return A015Receipt(
        families_validated=families_validated,
        results=results,
        a015_partial=True,      # synthetic — not live
        a015_closed=False,      # requires live data for full closure
        recommended_params=params,
        receipt_hash=receipt_hash,
    )


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_parameter_set_warn_threshold() -> bool:
    params = FractalParameterSet(betti_1_cap=0.045, betti_1_warn_fraction=0.80)
    assert abs(params.betti_1_warn_threshold - 0.036) < 1e-9
    return True


def _test_observation_anomaly_detection() -> bool:
    obs_normal = BettiObservation(
        betti_1=0.01, confidence=0.70, tau=0.80,
        model_family="test", trial_index=0,
    )
    obs_anomalous = BettiObservation(
        betti_1=0.044, confidence=0.90, tau=0.85,
        model_family="test", trial_index=1,
    )
    assert not obs_normal.is_anomalous
    assert obs_anomalous.is_anomalous
    return True


def _test_validate_parameters_valid() -> bool:
    obs = _synthetic_observations_large_model(50)
    params = FractalParameterSet(betti_1_cap=0.045)
    result = validate_parameters(params, obs)
    assert result.params_valid, f"Params should be valid: {result.notes}"
    assert result.sample_count == 50
    return True


def _test_validate_parameters_too_tight() -> bool:
    """A cap of 0.001 will have > 15% violations on normal traffic."""
    obs = _synthetic_observations_small_model(50)
    params = FractalParameterSet(betti_1_cap=0.001)
    result = validate_parameters(params, obs)
    assert not result.params_valid
    assert any("CAP_TOO_TIGHT" in n for n in result.notes)
    return True


def _test_validate_empty_observations() -> bool:
    params = FractalParameterSet()
    result = validate_parameters(params, [])
    assert not result.params_valid
    assert result.sample_count == 0
    return True


def _test_two_families_validated() -> bool:
    receipt = run_a015_validation(live=False)
    assert len(receipt.families_validated) == 2
    assert "small_7b_13b" in receipt.families_validated
    assert "large_70b_plus" in receipt.families_validated
    return True


def _test_receipt_hash_stable() -> bool:
    r1 = run_a015_validation(live=False)
    r2 = run_a015_validation(live=False)
    assert r1.receipt_hash == r2.receipt_hash, \
        "Receipt hash must be deterministic"
    return True


def _test_a015_partial_not_closed() -> bool:
    receipt = run_a015_validation(live=False)
    assert receipt.a015_partial, "Synthetic validation is partial"
    assert not receipt.a015_closed, \
        "A015 not closed until live inference data available"
    return True


def _test_recommended_params_match_sigma_anchors() -> bool:
    receipt = run_a015_validation(live=False)
    assert receipt.recommended_params.betti_1_cap == BETTI_1_CAP, \
        "Recommended cap must match sigma_anchors BETTI_1_CAP"
    return True


def _test_live_raises_without_a010() -> bool:
    try:
        run_a015_validation(live=True)
        assert False, "Should have raised NotImplementedError"
    except NotImplementedError:
        pass
    return True


def run_tests():
    tests = [
        (_test_parameter_set_warn_threshold,    "warn_threshold"),
        (_test_observation_anomaly_detection,    "anomaly_detection"),
        (_test_validate_parameters_valid,        "params_valid"),
        (_test_validate_parameters_too_tight,    "params_too_tight"),
        (_test_validate_empty_observations,      "empty_observations"),
        (_test_two_families_validated,           "two_families"),
        (_test_receipt_hash_stable,              "receipt_hash_stable"),
        (_test_a015_partial_not_closed,          "a015_partial"),
        (_test_recommended_params_match_sigma_anchors, "params_match_sigma"),
        (_test_live_raises_without_a010,         "live_raises"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
