# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ◈  (Evidence/Verification)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          arc_agi2_pipeline.py — Labyrinth-OS / Execution / Formal
# ----------------------------------------------------------------------------

"""
arc_agi2_pipeline.py — Labyrinth-OS / Execution / Formal
==========================================================
A016 — ARC-AGI-2 Pipeline: Meaningful D_KL and ΔH

Processes ARC-AGI-2 tasks through the Labyrinth-OS epistemic
pipeline and produces D_KL (KL divergence) and ΔH (entropy delta)
telemetry. The goal is to verify that these metrics produce
meaningful signals on abstract reasoning tasks — not just noise.

A016 closes when:
  - arc_agi2_pipeline.py processes real ARC-AGI-2 tasks via Ollama
  - Chronicle contains sealed telemetry JSON with D_KL and ΔH

Current Status
--------------
This module implements the full pipeline including mock execution.
Actual ARC-AGI-2 data processing requires A010 (first live inference).
A016 is PARTIAL: pipeline is built and tested; live data awaits A010.

What is ARC-AGI-2
-----------------
Abstraction and Reasoning Corpus 2 — a benchmark of visual reasoning
tasks requiring genuine novel abstraction. Each task has:
  - demonstration grid pairs (input → output)
  - a test grid (input only)
  - the model must produce the correct output grid

The Labyrinth-OS signal of interest: does abstract reasoning produce
higher D_KL and ΔH than routine text generation? If yes, the metrics
are meaningful for A016. If no, the metrics may not capture the
distinctive epistemic signature of genuine reasoning.

References
----------
  ACP-1 A016
  epistemic/logprob-bridge/logprob_bridge_adapter.py
  runtime/ignition.py
  execution/ledger/cgir_ledger.py
"""

from __future__ import annotations

import hashlib
import json
import math
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


try:
    import sys as _sys, os as _os
    _root = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), '..', '..'))
    if _root not in _sys.path: _sys.path.insert(0, _root)
    from sigma_anchors import CONFIDENCE_FLOOR, TAU_ESCAPE_FLOOR
except ImportError:
    CONFIDENCE_FLOOR = 0.65
    TAU_ESCAPE_FLOOR = 0.75


# ─── ARC TASK REPRESENTATION ─────────────────────────────────────────────────

@dataclass
class ARCGrid:
    """A 2D grid in ARC format — list of rows, each row a list of ints."""
    rows: List[List[int]]

    @property
    def height(self) -> int:
        return len(self.rows)

    @property
    def width(self) -> int:
        return len(self.rows[0]) if self.rows else 0

    def to_prompt_str(self) -> str:
        """Convert grid to a compact string representation for prompting."""
        return "\n".join(" ".join(str(c) for c in row) for row in self.rows)


@dataclass
class ARCTask:
    """A single ARC-AGI-2 task."""
    task_id:     str
    train_pairs: List[Tuple[ARCGrid, ARCGrid]]  # (input, output) pairs
    test_input:  ARCGrid
    source:      str = "synthetic"

    def to_prompt(self) -> str:
        """Format the task as a prompt for an LLM."""
        lines = [f"Task ID: {self.task_id}", "",
                 "Learn the transformation from these examples:", ""]
        for i, (inp, out) in enumerate(self.train_pairs):
            lines.append(f"Example {i+1} Input:")
            lines.append(inp.to_prompt_str())
            lines.append(f"Example {i+1} Output:")
            lines.append(out.to_prompt_str())
            lines.append("")
        lines.append("Test Input:")
        lines.append(self.test_input.to_prompt_str())
        lines.append("")
        lines.append("What is the output? Respond with only the grid, one row per line.")
        return "\n".join(lines)


# ─── TELEMETRY ────────────────────────────────────────────────────────────────

@dataclass
class ARCTelemetry:
    """
    Epistemic telemetry for a single ARC task processing run.

    D_KL: KL divergence between model logprob distribution and
          uniform reference distribution. Higher = more confident
          (less uniform) distribution.

    delta_H: Entropy change between prompt processing and response
             generation. Positive = response is more ordered than prompt.
             Negative = response is more uncertain.
    """
    task_id:         str
    d_kl:            float
    delta_h:         float
    confidence:      float
    tau:             float
    response_tokens: int
    is_meaningful:   bool      # True if D_KL and ΔH exceed noise floor
    model:           str
    latency_ms:      float
    timestamp:       float = field(default_factory=time.time)

    # Thresholds for "meaningful" signal
    D_KL_NOISE_FLOOR:   float = 0.05
    DELTA_H_NOISE_FLOOR: float = 0.02

    def __post_init__(self):
        self.is_meaningful = (
            abs(self.d_kl) > self.D_KL_NOISE_FLOOR and
            abs(self.delta_h) > self.DELTA_H_NOISE_FLOOR
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id":         self.task_id,
            "d_kl":            self.d_kl,
            "delta_h":         self.delta_h,
            "confidence":      self.confidence,
            "tau":             self.tau,
            "response_tokens": self.response_tokens,
            "is_meaningful":   self.is_meaningful,
            "model":           self.model,
            "latency_ms":      self.latency_ms,
            "timestamp":       self.timestamp,
        }


# ─── SYNTHETIC TASK GENERATORS ────────────────────────────────────────────────

def _make_color_flip_task(task_id: str = "cf-001") -> ARCTask:
    """
    Synthetic task: flip all 0s and 1s in a grid.
    Pattern: 0 → 1, 1 → 0, all other colors stay.
    """
    def flip(g):
        return [[1 - c if c in (0, 1) else c for c in row] for row in g]

    examples = [
        ([[0, 1, 0], [1, 0, 1], [0, 1, 0]],
         flip([[0, 1, 0], [1, 0, 1], [0, 1, 0]])),
        ([[1, 1, 0], [0, 1, 0], [1, 0, 1]],
         flip([[1, 1, 0], [0, 1, 0], [1, 0, 1]])),
    ]
    test = [[0, 0, 1], [1, 1, 0], [0, 1, 0]]

    return ARCTask(
        task_id=task_id,
        train_pairs=[(ARCGrid(inp), ARCGrid(out)) for inp, out in examples],
        test_input=ARCGrid(test),
        source="synthetic",
    )


def _make_border_task(task_id: str = "bd-001") -> ARCTask:
    """
    Synthetic task: fill the border cells of a grid with a fixed color.
    """
    def border(g, color=5):
        n, m = len(g), len(g[0])
        out = [row[:] for row in g]
        for r in range(n):
            for c in range(m):
                if r == 0 or r == n-1 or c == 0 or c == m-1:
                    out[r][c] = color
        return out

    examples = [
        ([[0, 0, 0], [0, 2, 0], [0, 0, 0]], border([[0, 0, 0], [0, 2, 0], [0, 0, 0]])),
        ([[1, 0, 1], [0, 3, 0], [1, 0, 1]], border([[1, 0, 1], [0, 3, 0], [1, 0, 1]])),
    ]
    test = [[0, 1, 0], [1, 4, 1], [0, 1, 0]]

    return ARCTask(
        task_id=task_id,
        train_pairs=[(ARCGrid(inp), ARCGrid(out)) for inp, out in examples],
        test_input=ARCGrid(test),
        source="synthetic",
    )


# ─── MOCK INFERENCE ───────────────────────────────────────────────────────────

def _mock_inference(task: ARCTask, model: str = "mock") -> ARCTelemetry:
    """
    Simulate model inference on an ARC task.

    In mock mode, generates plausible D_KL and ΔH values that
    reflect the expected behavior: ARC tasks should produce
    higher D_KL than routine generation (more concentrated distributions)
    and positive ΔH (responses are more structured than prompts).

    This mock is replaced by real inference at A010.
    """
    import random
    rng = random.Random(hash(task.task_id) % (2**31))

    # Simulate realistic ARC processing telemetry
    # ARC tasks: higher D_KL (0.15-0.45), positive ΔH (0.05-0.20)
    # vs routine text: D_KL ~0.05-0.15, ΔH ~0.01-0.05
    d_kl   = rng.uniform(0.15, 0.45)
    delta_h = rng.uniform(0.05, 0.20)
    conf   = rng.uniform(CONFIDENCE_FLOOR, 0.90)
    tau    = rng.uniform(TAU_ESCAPE_FLOOR, 0.95)

    prompt_len = len(task.to_prompt())
    response_tokens = rng.randint(15, 60)  # grid response
    latency_ms = rng.uniform(150, 400)

    return ARCTelemetry(
        task_id=task.task_id,
        d_kl=d_kl,
        delta_h=delta_h,
        confidence=conf,
        tau=tau,
        response_tokens=response_tokens,
        is_meaningful=True,  # will be recomputed in __post_init__
        model=model,
        latency_ms=latency_ms,
    )


def _live_inference(task: ARCTask, model: str, api_url: str) -> ARCTelemetry:
    """
    Live inference path — requires A010 (Ollama or API available).
    Placeholder until A010 is closed.
    """
    raise NotImplementedError(
        "Live ARC-AGI-2 inference requires A010. "
        "Use mock_mode=True for testing."
    )


# ─── PIPELINE ─────────────────────────────────────────────────────────────────

@dataclass
class A016PipelineResult:
    """Results from processing a batch of ARC-AGI-2 tasks."""
    telemetry:              List[ARCTelemetry]
    tasks_processed:        int
    meaningful_signals:     int
    mean_d_kl:              float
    mean_delta_h:           float
    meaningful_fraction:    float
    a016_partial:           bool    # True if mock; False if live
    a016_signals_valid:     bool    # True if meaningful_fraction > 0.7
    chronicle_entries:      List[Dict[str, Any]]
    receipt_hash:           str
    generated_at:           float = field(default_factory=time.time)


def run_arc_pipeline(
    tasks: Optional[List[ARCTask]] = None,
    model: str = "mock",
    mock_mode: bool = True,
    api_url: str = "http://localhost:11434",
) -> A016PipelineResult:
    """
    Run the ARC-AGI-2 pipeline.

    Parameters
    ----------
    tasks:      List of ARCTask objects. If None, uses synthetic tasks.
    model:      Model name for inference.
    mock_mode:  If True, use mock inference (for testing without A010).
    api_url:    Ollama API URL (ignored in mock mode).

    Returns
    -------
    A016PipelineResult with telemetry and Chronicle entries.
    """
    if tasks is None:
        tasks = [
            _make_color_flip_task("cf-001"),
            _make_color_flip_task("cf-002"),
            _make_border_task("bd-001"),
            _make_border_task("bd-002"),
        ]

    telemetry: List[ARCTelemetry] = []
    chronicle: List[Dict[str, Any]] = []

    for task in tasks:
        if mock_mode:
            tel = _mock_inference(task, model)
        else:
            tel = _live_inference(task, model, api_url)

        telemetry.append(tel)
        chronicle.append({
            "event":         "ARC_AGI2_TELEMETRY",
            "task_id":       tel.task_id,
            "d_kl":          tel.d_kl,
            "delta_h":       tel.delta_h,
            "confidence":    tel.confidence,
            "is_meaningful": tel.is_meaningful,
            "model":         tel.model,
            "timestamp":     tel.timestamp,
        })

    n = len(telemetry)
    if n == 0:
        return A016PipelineResult(
            telemetry=[], tasks_processed=0, meaningful_signals=0,
            mean_d_kl=0.0, mean_delta_h=0.0, meaningful_fraction=0.0,
            a016_partial=True, a016_signals_valid=False,
            chronicle_entries=[], receipt_hash="",
        )

    mean_dkl    = sum(t.d_kl for t in telemetry) / n
    mean_deltah = sum(t.delta_h for t in telemetry) / n
    meaningful  = sum(1 for t in telemetry if t.is_meaningful)
    mf          = meaningful / n

    # A016 signals valid: > 70% of tasks produce meaningful D_KL and ΔH
    signals_valid = mf > 0.70

    # Receipt hash over telemetry content (excluding timestamps)
    payload = json.dumps([
        {"task_id": t.task_id, "d_kl": round(t.d_kl, 6),
         "delta_h": round(t.delta_h, 6), "model": t.model}
        for t in telemetry
    ], sort_keys=True)
    receipt = hashlib.sha256(payload.encode()).hexdigest()[:24]

    return A016PipelineResult(
        telemetry=telemetry,
        tasks_processed=n,
        meaningful_signals=meaningful,
        mean_d_kl=mean_dkl,
        mean_delta_h=mean_deltah,
        meaningful_fraction=mf,
        a016_partial=mock_mode,
        a016_signals_valid=signals_valid,
        chronicle_entries=chronicle,
        receipt_hash=receipt,
    )


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_arc_grid_dimensions() -> bool:
    g = ARCGrid([[0, 1, 0], [1, 0, 1]])
    assert g.height == 2 and g.width == 3
    return True


def _test_arc_task_prompt_contains_task_id() -> bool:
    task = _make_color_flip_task("cf-test")
    prompt = task.to_prompt()
    assert "cf-test" in prompt
    assert "Output" in prompt
    return True


def _test_telemetry_meaningful_flag() -> bool:
    t_meaningful = ARCTelemetry(
        task_id="t1", d_kl=0.20, delta_h=0.10,
        confidence=0.80, tau=0.85, response_tokens=20,
        is_meaningful=True, model="mock", latency_ms=100,
    )
    t_noise = ARCTelemetry(
        task_id="t2", d_kl=0.01, delta_h=0.005,
        confidence=0.70, tau=0.78, response_tokens=5,
        is_meaningful=False, model="mock", latency_ms=50,
    )
    assert t_meaningful.is_meaningful
    assert not t_noise.is_meaningful
    return True


def _test_mock_inference_produces_telemetry() -> bool:
    task = _make_color_flip_task()
    tel = _mock_inference(task)
    assert tel.d_kl > 0
    assert tel.delta_h > 0
    assert tel.confidence >= CONFIDENCE_FLOOR
    return True


def _test_pipeline_runs_all_tasks() -> bool:
    tasks = [_make_color_flip_task(f"cf-{i:02d}") for i in range(5)]
    result = run_arc_pipeline(tasks=tasks, mock_mode=True)
    assert result.tasks_processed == 5
    assert len(result.chronicle_entries) == 5
    return True


def _test_pipeline_meaningful_fraction() -> bool:
    result = run_arc_pipeline(mock_mode=True)
    assert result.meaningful_fraction > 0.70, \
        f"Meaningful fraction {result.meaningful_fraction:.2f} below 0.70"
    return True


def _test_a016_signals_valid_with_mock() -> bool:
    result = run_arc_pipeline(mock_mode=True)
    assert result.a016_signals_valid, \
        "A016 signals should be valid with mock data"
    return True


def _test_a016_partial_with_mock() -> bool:
    result = run_arc_pipeline(mock_mode=True)
    assert result.a016_partial, "Mock mode is partial, not full closure"
    return True


def _test_chronicle_entries_have_required_fields() -> bool:
    result = run_arc_pipeline(mock_mode=True)
    for entry in result.chronicle_entries:
        assert "event" in entry
        assert entry["event"] == "ARC_AGI2_TELEMETRY"
        assert "d_kl" in entry
        assert "delta_h" in entry
        assert "task_id" in entry
    return True


def _test_live_raises_without_a010() -> bool:
    task = _make_color_flip_task()
    try:
        _live_inference(task, "llama3", "http://localhost:11434")
        assert False, "Should have raised NotImplementedError"
    except NotImplementedError:
        pass
    return True


def _test_receipt_hash_deterministic() -> bool:
    tasks = [_make_color_flip_task("cf-det")]
    r1 = run_arc_pipeline(tasks=tasks, mock_mode=True)
    r2 = run_arc_pipeline(tasks=tasks, mock_mode=True)
    assert r1.receipt_hash == r2.receipt_hash
    return True


def run_tests():
    tests = [
        (_test_arc_grid_dimensions,              "grid_dimensions"),
        (_test_arc_task_prompt_contains_task_id, "prompt_has_task_id"),
        (_test_telemetry_meaningful_flag,        "telemetry_meaningful"),
        (_test_mock_inference_produces_telemetry, "mock_inference"),
        (_test_pipeline_runs_all_tasks,           "pipeline_all_tasks"),
        (_test_pipeline_meaningful_fraction,      "meaningful_fraction"),
        (_test_a016_signals_valid_with_mock,      "signals_valid"),
        (_test_a016_partial_with_mock,            "a016_partial"),
        (_test_chronicle_entries_have_required_fields, "chronicle_fields"),
        (_test_live_raises_without_a010,          "live_raises"),
        (_test_receipt_hash_deterministic,        "receipt_hash_det"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
