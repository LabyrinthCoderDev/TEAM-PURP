# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ◈  (Evidence/Verification)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          logical_sentinel_cache.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
logical_sentinel_cache.py — Labyrinth-OS
Cached Predicate Checking with HybridSolver
"""

import hashlib
from hybrid_solver import hybrid_solver
import z3

class PredicateCache:
    def __init__(self, maxsize=2000):
        self.cache = {}
        self.maxsize = maxsize

    def get(self, key):
        return self.cache.get(key)

    def put(self, key, value):
        if len(self.cache) >= self.maxsize:
            # Simple LRU
            self.cache.pop(next(iter(self.cache)), None)
        self.cache[key] = value

class LogicalSentinel:
    def __init__(self):
        self.cache = PredicateCache(maxsize=2000)
        self.hybrid = hybrid_solver

    def get_proposal_hash(self, proposal) -> str:
        data = str(vars(proposal) if hasattr(proposal, '__dict__') else proposal)
        return hashlib.sha256(data.encode()).hexdigest()[:16]

    def check_predicates(self, proposal) -> bool:
        """Check with cache + hybrid solver."""
        key = self.get_proposal_hash(proposal)

        cached = self.cache.get(key)
        if cached is not None:
            return cached

        # Run hybrid check (Z3 primary + Kissat fallback)
        result = self.hybrid.check()
        is_valid = (result == z3.unsat)  # No violation possible = valid

        self.cache.put(key, is_valid)
        return is_valid


# Global instance
logical_sentinel = LogicalSentinel()