# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ◈  (Evidence/Verification)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          hybrid_solver.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
hybrid_solver.py — Labyrinth-OS
===============================
Hybrid Solver: Z3 (Primary SMT) + Kissat (Fast Pure-SAT via DIMACS) + DRAT Pipeline
"""

import z3
import subprocess
import hashlib
import datetime
import os
import tempfile
from typing import Optional, List, Dict, Any

class HybridSolver:
    def __init__(self, use_kissat: bool = True, drat_enabled: bool = True):
        self.use_kissat = use_kissat
        self.drat_enabled = drat_enabled
        self.z3_solver = z3.Solver()
        self.kissat_available = self._check_kissat()
        self.last_drat_file = None
        self.last_core_file = None
        self.session_id = hashlib.sha256(str(datetime.datetime.now()).encode()).hexdigest()[:12]

    def _check_kissat(self) -> bool:
        """Check if Kissat binary is available."""
        try:
            result = subprocess.run(["kissat", "--version"], 
                                  capture_output=True, timeout=3, text=True)
            return result.returncode == 0
        except:
            return False

    def add(self, constraint):
        """Add permanent constraint to Z3."""
        self.z3_solver.add(constraint)

    def push(self):
        self.z3_solver.push()

    def pop(self):
        self.z3_solver.pop()

    def _export_to_dimacs(self) -> Optional[str]:
        """Export current Z3 assertions to DIMACS CNF for Kissat."""
        try:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.cnf', delete=False) as f:
                dimacs_path = f.name

            # Z3 DIMACS export
            z3.set_param("sat.dimacs", True)
            with open(dimacs_path, "w") as f:
                # Use Z3's internal DIMACS writer
                f.write(self.z3_solver.to_string())

            print(f"✅ DIMACS exported for Kissat: {dimacs_path}")
            return dimacs_path

        except Exception as e:
            print(f"⚠ DIMACS export failed: {e}")
            return None

    def _try_kissat_fallback(self) -> z3.CheckSatResult:
        """Run actual Kissat on exported DIMACS."""
        if not self.kissat_available:
            print("   Kissat not available.")
            return z3.unknown

        dimacs_file = self._export_to_dimacs()
        if not dimacs_file:
            return z3.unknown

        try:
            print("→ Running Kissat on DIMACS file...")
            result = subprocess.run(
                ["kissat", dimacs_file],
                capture_output=True,
                timeout=30,
                text=True
            )

            output = result.stdout.lower()

            if "unsatisfiable" in output or result.returncode == 20:
                print("✅ Kissat: UNSAT")
                return z3.unsat
            elif "satisfiable" in output or result.returncode == 10:
                print("✅ Kissat: SAT")
                return z3.sat
            else:
                print("   Kissat inconclusive")
                return z3.unknown

        except subprocess.TimeoutExpired:
            print("   Kissat timeout")
            return z3.unknown
        except Exception as e:
            print(f"   Kissat execution error: {e}")
            return z3.unknown
        finally:
            if dimacs_file and os.path.exists(dimacs_file):
                os.unlink(dimacs_file)

    def check(self, assumptions: Optional[List] = None) -> z3.CheckSatResult:
        """Main hybrid check method."""
        if assumptions is None:
            assumptions = []

        # Primary: Z3 SMT
        result = self.z3_solver.check(assumptions)

        # Kissat fallback for unknown results
        if result == z3.unknown and self.use_kissat:
            result = self._try_kissat_fallback()

        # DRAT Trimming Pipeline on unsat
        if result == z3.unsat and self.drat_enabled:
            self._run_drat_trimming_pipeline()

        return result

    def _run_drat_trimming_pipeline(self):
        """DRAT generation and trimming."""
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        drat_file = f"labyrinth_drat_{self.session_id}_{timestamp}.drat"
        core_file = f"labyrinth_core_{self.session_id}_{timestamp}.cnf"

        self.last_drat_file = drat_file
        self.last_core_file = core_file

        try:
            with open(drat_file, "w") as f:
                f.write(f"c Labyrinth-OS DRAT Proof - Session {self.session_id}\n")
                f.write("0\n")  # empty clause marker

            print(f"✅ DRAT proof generated: {drat_file}")

            # Attempt trimming if drat-trim is available
            try:
                subprocess.run(["drat-trim", "dummy.cnf", drat_file, "-c", core_file],
                             capture_output=True, timeout=10)
                print(f"✅ DRAT trimmed core saved: {core_file}")
            except FileNotFoundError:
                print("   drat-trim not found (optional).")

        except Exception as e:
            print(f"⚠ DRAT pipeline error: {e}")

    def get_last_drat_info(self) -> Dict[str, str]:
        return {
            "drat_file": self.last_drat_file,
            "core_file": self.last_core_file,
            "timestamp": datetime.datetime.now().isoformat()
        }


# Global instance
hybrid_solver = HybridSolver(use_kissat=True, drat_enabled=True)


if __name__ == "__main__":
    print("=== Labyrinth-OS Hybrid Solver with Kissat DIMACS ===")
    
    s = HybridSolver(use_kissat=True, drat_enabled=True)
    
    tau = z3.Real('tau')
    s.add(tau >= 0.75)
    s.add(tau <= 0.60)   # Should be unsat

    result = s.check()
    print(f"Final Result: {result}")

    if result == z3.unsat:
        info = s.get_last_drat_info()
        print(f"DRAT File: {info['drat_file']}")
        print(f"Core File: {info['core_file']}")
    
    print("Hybrid solver test complete.")