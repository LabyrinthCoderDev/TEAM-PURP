# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          cgir_schema.py — Labyrinth-OS / CGIR
# ----------------------------------------------------------------------------

"""
cgir_schema.py — Labyrinth-OS / CGIR
=====================================
Canonical CGIR Proposal Schema

Validates a raw proposal dict before it enters the AEGIS compiler.
This is the first gate — before cgir_validator, before the gate,
before any execution.

If a proposal doesn't match the schema, it is rejected at the door.
The AEGIS compiler (aegis_cesk.py) trusts that what it receives is
schema-valid. This module provides that guarantee.

Schema rules:
  - nodes:   required, list, each node has id+node_type+logical_time
  - edges:   required, list, each edge has id+from_id+to_id+event_type
  - signals: optional, list, each signal has id+logical_time+severity+confidence
  - root:    optional string
  - tip:     optional string

All fields are typed. No extra fields silently ignored —
unknown fields are flagged (defense against injection via metadata).

Also provides:
  - canonical CGIR example proposals (valid + invalid) for testing
  - schema_hash: stable SHA-256 of the schema definition

References:
  ARCHITECTURE.md  — L10 CGIR
  aegis_cesk.py    — ProposalCompiler (trusts schema-valid input)
  spec/CGIR.md
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

# ─── VALID NODE TYPES ─────────────────────────────────────────────────────────
VALID_NODE_TYPES = {"STATE", "EVENT_EDGE", "SIGNAL", "TIMED_EDGE", "INVARIANT", "HARDWARE"}
VALID_SEVERITIES = {"INFO", "WARNING", "ERROR", "CRITICAL"}
REQUIRED_TOP_KEYS = {"nodes", "edges"}
ALLOWED_TOP_KEYS  = {"nodes", "edges", "signals", "root", "tip"}
REQUIRED_NODE_KEYS = {"id", "node_type", "logical_time"}
ALLOWED_NODE_KEYS  = {"id", "node_type", "logical_time", "metadata"}
REQUIRED_EDGE_KEYS = {"id", "from_id", "to_id", "event_type"}
ALLOWED_EDGE_KEYS  = {"id", "from_id", "to_id", "event_type", "invariant_mask", "signal_binding"}
REQUIRED_SIG_KEYS  = {"id", "logical_time", "severity", "confidence"}
ALLOWED_SIG_KEYS   = {"id", "logical_time", "severity", "confidence", "category",
                       "source", "emitted_by", "evidence_refs", "valid_for"}


# ─── SCHEMA ERROR ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class SchemaError:
    field: str
    message: str

    def to_dict(self) -> Dict[str, str]:
        return {"field": self.field, "message": self.message}


# ─── SCHEMA RESULT ────────────────────────────────────────────────────────────

@dataclass
class SchemaResult:
    valid: bool
    errors: List[SchemaError]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "valid": self.valid,
            "errors": [e.to_dict() for e in self.errors],
        }


# ─── SCHEMA VALIDATOR ─────────────────────────────────────────────────────────

class CGIRSchema:
    """
    Validates a raw proposal dict against the CGIR schema.
    Returns SchemaResult. Never raises.
    """

    def validate(self, proposal: Any) -> SchemaResult:
        errors: List[SchemaError] = []

        if not isinstance(proposal, dict):
            return SchemaResult(valid=False, errors=[
                SchemaError("root", f"Proposal must be a dict, got {type(proposal).__name__}")
            ])

        # Top-level required keys
        for k in REQUIRED_TOP_KEYS:
            if k not in proposal:
                errors.append(SchemaError(k, f"Required key '{k}' missing"))

        # Top-level unknown keys
        for k in proposal:
            if k not in ALLOWED_TOP_KEYS:
                errors.append(SchemaError(k, f"Unknown top-level key '{k}'"))

        # nodes
        nodes = proposal.get("nodes", [])
        if not isinstance(nodes, list):
            errors.append(SchemaError("nodes", "Must be a list"))
        else:
            for i, node in enumerate(nodes):
                errors.extend(self._check_node(i, node))

        # edges
        edges = proposal.get("edges", [])
        if not isinstance(edges, list):
            errors.append(SchemaError("edges", "Must be a list"))
        else:
            for i, edge in enumerate(edges):
                errors.extend(self._check_edge(i, edge))

        # signals (optional)
        signals = proposal.get("signals", [])
        if not isinstance(signals, list):
            errors.append(SchemaError("signals", "Must be a list if present"))
        else:
            for i, sig in enumerate(signals):
                errors.extend(self._check_signal(i, sig))

        # root / tip (optional strings)
        for field in ("root", "tip"):
            val = proposal.get(field)
            if val is not None and not isinstance(val, str):
                errors.append(SchemaError(field, f"Must be a string if present"))

        return SchemaResult(valid=len(errors) == 0, errors=errors)

    def _check_node(self, i: int, node: Any) -> List[SchemaError]:
        errors = []
        prefix = f"nodes[{i}]"
        if not isinstance(node, dict):
            return [SchemaError(prefix, "Must be a dict")]
        for k in REQUIRED_NODE_KEYS:
            if k not in node:
                errors.append(SchemaError(f"{prefix}.{k}", f"Required key '{k}' missing"))
        for k in node:
            if k not in ALLOWED_NODE_KEYS:
                errors.append(SchemaError(f"{prefix}.{k}", f"Unknown key '{k}'"))
        if "id" in node and not isinstance(node["id"], str):
            errors.append(SchemaError(f"{prefix}.id", "Must be a string"))
        if "node_type" in node and node["node_type"] not in VALID_NODE_TYPES:
            errors.append(SchemaError(
                f"{prefix}.node_type",
                f"Invalid node_type '{node['node_type']}'. Valid: {sorted(VALID_NODE_TYPES)}"
            ))
        if "logical_time" in node and not isinstance(node["logical_time"], int):
            errors.append(SchemaError(f"{prefix}.logical_time", "Must be an integer"))
        if "logical_time" in node and isinstance(node["logical_time"], int) and node["logical_time"] < 0:
            errors.append(SchemaError(f"{prefix}.logical_time", "Must be non-negative"))
        return errors

    def _check_edge(self, i: int, edge: Any) -> List[SchemaError]:
        errors = []
        prefix = f"edges[{i}]"
        if not isinstance(edge, dict):
            return [SchemaError(prefix, "Must be a dict")]
        for k in REQUIRED_EDGE_KEYS:
            if k not in edge:
                errors.append(SchemaError(f"{prefix}.{k}", f"Required key '{k}' missing"))
        for k in edge:
            if k not in ALLOWED_EDGE_KEYS:
                errors.append(SchemaError(f"{prefix}.{k}", f"Unknown key '{k}'"))
        for str_field in ("id", "from_id", "to_id", "event_type"):
            if str_field in edge and not isinstance(edge[str_field], str):
                errors.append(SchemaError(f"{prefix}.{str_field}", "Must be a string"))
        if "invariant_mask" in edge:
            mask = edge["invariant_mask"]
            if not isinstance(mask, list):
                errors.append(SchemaError(f"{prefix}.invariant_mask", "Must be a list"))
            else:
                for j, item in enumerate(mask):
                    if not isinstance(item, str) or not item.strip():
                        errors.append(SchemaError(
                            f"{prefix}.invariant_mask[{j}]",
                            "Each invariant must be a non-empty string"
                        ))
        return errors

    def _check_signal(self, i: int, sig: Any) -> List[SchemaError]:
        errors = []
        prefix = f"signals[{i}]"
        if not isinstance(sig, dict):
            return [SchemaError(prefix, "Must be a dict")]
        for k in REQUIRED_SIG_KEYS:
            if k not in sig:
                errors.append(SchemaError(f"{prefix}.{k}", f"Required key '{k}' missing"))
        for k in sig:
            if k not in ALLOWED_SIG_KEYS:
                errors.append(SchemaError(f"{prefix}.{k}", f"Unknown key '{k}'"))
        if "severity" in sig and sig["severity"] not in VALID_SEVERITIES:
            errors.append(SchemaError(
                f"{prefix}.severity",
                f"Invalid severity '{sig['severity']}'. Valid: {sorted(VALID_SEVERITIES)}"
            ))
        if "confidence" in sig:
            c = sig["confidence"]
            if not isinstance(c, (int, float)):
                errors.append(SchemaError(f"{prefix}.confidence", "Must be a number"))
            elif not (0.0 <= c <= 1.0):
                errors.append(SchemaError(f"{prefix}.confidence", f"Must be in [0.0, 1.0], got {c}"))
        if "logical_time" in sig and not isinstance(sig["logical_time"], int):
            errors.append(SchemaError(f"{prefix}.logical_time", "Must be an integer"))
        return errors


# ─── CANONICAL EXAMPLES ───────────────────────────────────────────────────────

EXAMPLE_VALID_MINIMAL = {
    "nodes": [
        {"id": "n0", "node_type": "STATE", "logical_time": 0},
        {"id": "n1", "node_type": "STATE", "logical_time": 1},
    ],
    "edges": [
        {"id": "e0", "from_id": "n0", "to_id": "n1", "event_type": "STEP"},
    ],
}

EXAMPLE_VALID_FULL = {
    "nodes": [
        {"id": "proposal_main", "node_type": "STATE", "logical_time": 0,
         "metadata": {"action": "inference_step"}},
        {"id": "proposal_next", "node_type": "STATE", "logical_time": 1},
    ],
    "edges": [
        {"id": "step_0", "from_id": "proposal_main", "to_id": "proposal_next",
         "event_type": "INFERENCE_STEP", "invariant_mask": ["I1", "I3", "I7"],
         "signal_binding": "council_sig_0"},
    ],
    "signals": [
        {"id": "council_sig_0", "logical_time": 0, "severity": "INFO",
         "confidence": 0.91, "category": "NOMINAL", "source": "COUNCIL",
         "emitted_by": "COUNCIL"},
    ],
    "root": "proposal_main",
    "tip":  "proposal_next",
}

EXAMPLE_INVALID_MISSING_NODE_TYPE = {
    "nodes": [{"id": "n0", "logical_time": 0}],  # missing node_type
    "edges": [],
}

EXAMPLE_INVALID_BAD_SEVERITY = {
    "nodes": [
        {"id": "n0", "node_type": "STATE", "logical_time": 0},
        {"id": "n1", "node_type": "STATE", "logical_time": 1},
    ],
    "edges": [
        {"id": "e0", "from_id": "n0", "to_id": "n1", "event_type": "STEP"},
    ],
    "signals": [
        {"id": "s0", "logical_time": 0, "severity": "ULTRA_CRITICAL",
         "confidence": 0.9},  # invalid severity
    ],
}

EXAMPLE_INVALID_UNKNOWN_KEY = {
    "nodes": [
        {"id": "n0", "node_type": "STATE", "logical_time": 0},
        {"id": "n1", "node_type": "STATE", "logical_time": 1},
    ],
    "edges": [
        {"id": "e0", "from_id": "n0", "to_id": "n1", "event_type": "STEP"},
    ],
    "inject_payload": "malicious",  # unknown top-level key
}


# ─── SCHEMA HASH ──────────────────────────────────────────────────────────────

def schema_hash() -> str:
    """
    Stable SHA-256 of the schema definition.
    Changes if any VALID_* set or REQUIRED_*/ALLOWED_* set changes.
    Use this to detect schema version drift in replay.
    """
    schema_def = json.dumps({
        "valid_node_types": sorted(VALID_NODE_TYPES),
        "valid_severities": sorted(VALID_SEVERITIES),
        "required_top": sorted(REQUIRED_TOP_KEYS),
        "allowed_top": sorted(ALLOWED_TOP_KEYS),
        "required_node": sorted(REQUIRED_NODE_KEYS),
        "allowed_node": sorted(ALLOWED_NODE_KEYS),
        "required_edge": sorted(REQUIRED_EDGE_KEYS),
        "allowed_edge": sorted(ALLOWED_EDGE_KEYS),
        "required_sig": sorted(REQUIRED_SIG_KEYS),
        "allowed_sig": sorted(ALLOWED_SIG_KEYS),
    }, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(schema_def.encode()).hexdigest()


# ─── CONVENIENCE ──────────────────────────────────────────────────────────────

def validate(proposal: Any) -> SchemaResult:
    return CGIRSchema().validate(proposal)


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_valid_minimal_passes() -> bool:
    r = validate(EXAMPLE_VALID_MINIMAL)
    assert r.valid, [e.to_dict() for e in r.errors]
    return True

def _test_valid_full_passes() -> bool:
    r = validate(EXAMPLE_VALID_FULL)
    assert r.valid, [e.to_dict() for e in r.errors]
    return True

def _test_non_dict_fails() -> bool:
    r = validate("not a dict")
    assert not r.valid
    assert r.errors[0].field == "root"
    return True

def _test_missing_nodes_fails() -> bool:
    r = validate({"edges": []})
    assert not r.valid
    fields = [e.field for e in r.errors]
    assert "nodes" in fields
    return True

def _test_missing_edges_fails() -> bool:
    r = validate({"nodes": []})
    assert not r.valid
    fields = [e.field for e in r.errors]
    assert "edges" in fields
    return True

def _test_unknown_top_key_fails() -> bool:
    r = validate(EXAMPLE_INVALID_UNKNOWN_KEY)
    assert not r.valid
    fields = [e.field for e in r.errors]
    assert "inject_payload" in fields
    return True

def _test_missing_node_type_fails() -> bool:
    r = validate(EXAMPLE_INVALID_MISSING_NODE_TYPE)
    assert not r.valid
    fields = [e.field for e in r.errors]
    assert any("node_type" in f for f in fields)
    return True

def _test_invalid_node_type_fails() -> bool:
    r = validate({"nodes": [
        {"id": "n0", "node_type": "GHOST", "logical_time": 0}
    ], "edges": []})
    assert not r.valid
    assert any("node_type" in e.field for e in r.errors)
    return True

def _test_invalid_severity_fails() -> bool:
    r = validate(EXAMPLE_INVALID_BAD_SEVERITY)
    assert not r.valid
    assert any("severity" in e.field for e in r.errors)
    return True

def _test_confidence_out_of_range_fails() -> bool:
    r = validate({"nodes": [
        {"id": "n0", "node_type": "STATE", "logical_time": 0},
        {"id": "n1", "node_type": "STATE", "logical_time": 1},
    ], "edges": [
        {"id": "e0", "from_id": "n0", "to_id": "n1", "event_type": "STEP"}
    ], "signals": [
        {"id": "s0", "logical_time": 0, "severity": "INFO", "confidence": 1.5}
    ]})
    assert not r.valid
    assert any("confidence" in e.field for e in r.errors)
    return True

def _test_negative_logical_time_fails() -> bool:
    r = validate({"nodes": [
        {"id": "n0", "node_type": "STATE", "logical_time": -1}
    ], "edges": []})
    assert not r.valid
    assert any("logical_time" in e.field for e in r.errors)
    return True

def _test_empty_invariant_mask_entry_fails() -> bool:
    r = validate({"nodes": [
        {"id": "n0", "node_type": "STATE", "logical_time": 0},
        {"id": "n1", "node_type": "STATE", "logical_time": 1},
    ], "edges": [
        {"id": "e0", "from_id": "n0", "to_id": "n1",
         "event_type": "STEP", "invariant_mask": ["I1", ""]}
    ]})
    assert not r.valid
    assert any("invariant_mask" in e.field for e in r.errors)
    return True

def _test_schema_hash_stable() -> bool:
    h1 = schema_hash()
    h2 = schema_hash()
    assert h1 == h2
    assert len(h1) == 64
    return True

def _test_to_dict_structure() -> bool:
    r = validate(EXAMPLE_VALID_MINIMAL)
    d = r.to_dict()
    assert "valid" in d
    assert "errors" in d
    assert d["valid"] is True
    return True

def _test_multiple_errors_all_reported() -> bool:
    r = validate({
        "nodes": [{"id": "n0", "node_type": "BAD_TYPE", "logical_time": -5}],
        "edges": [],
        "unknown_field": "x",
    })
    assert not r.valid
    assert len(r.errors) >= 3
    return True

def _test_valid_confidence_boundaries() -> bool:
    for conf in [0.0, 1.0]:
        r = validate({"nodes": [
            {"id": "n0", "node_type": "STATE", "logical_time": 0},
            {"id": "n1", "node_type": "STATE", "logical_time": 1},
        ], "edges": [
            {"id": "e0", "from_id": "n0", "to_id": "n1", "event_type": "STEP"}
        ], "signals": [
            {"id": "s0", "logical_time": 0, "severity": "INFO", "confidence": conf}
        ]})
        assert r.valid, f"conf={conf} should be valid: {r.errors}"
    return True


def run_tests() -> tuple:
    tests = sorted(
        [(name, obj) for name, obj in globals().items()
         if name.startswith("_test_") and callable(obj)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    import hashlib as _hl
    print("=" * 70)
    print("CGIR SCHEMA — Labyrinth-OS")
    print("=" * 70)
    print(f"\n  Schema hash: {schema_hash()[:24]}…")
    print("\n── TEST SUITE ──\n")
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err: line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed > 0:
        raise SystemExit(1)
    with open(__file__, "rb") as f:
        fh = _hl.sha256(f.read()).hexdigest()
    print(f"\n── RECEIPT ──\n  SHA-256: {fh}\n  Tests: {passed}/{passed+failed}")
    print(f"\n{'='*70}\n  CGIR SCHEMA — COMPLETE\n{'='*70}")
