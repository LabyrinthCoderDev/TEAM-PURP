# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ◈  (Evidence/Verification)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          Pretty-print Z3 proof (returns string for console and markdown).
# ----------------------------------------------------------------------------

import z3
from typing import Optional, List, Dict, Any
import datetime
import json


def print_z3_proof(proof: Optional[z3.Z3PPObject], 
                   max_depth: int = 6, 
                   indent: int = 0) -> str:
    """Pretty-print Z3 proof (returns string for console and markdown)."""
    if proof is None:
        return "  " * indent + "None"

    kind = proof.decl().name() if hasattr(proof.decl(), 'name') else str(proof.decl())
    lines = [f"{'  ' * indent}• {kind}"]

    if indent < max_depth and hasattr(proof, 'children'):
        children = proof.children()
        if children:
            lines.append(f"{'  ' * indent}  └─ children:")
            for i, child in enumerate(children):
                child_str = print_z3_proof(child, max_depth, indent + 2)
                lines.append(f"{'  ' * indent}    [{i}] {child_str}")

    return "\n".join(lines)


def extract_proof_steps(proof: Optional[z3.Z3PPObject]) -> List[Dict[str, Any]]:
    """
    Reconstruct proof as structured list of steps.
    Returns list of dicts with step type, children, and metadata.
    """
    steps = []

    def recurse(p, depth=0):
        if p is None:
            return None
        step = {
            "type": p.decl().name() if hasattr(p.decl(), 'name') else str(p.decl()),
            "depth": depth,
            "children": []
        }
        if hasattr(p, 'children'):
            for child in p.children():
                child_step = recurse(child, depth + 1)
                if child_step:
                    step["children"].append(child_step)
        steps.append(step)
        return step

    recurse(proof)
    return steps


def save_proof_reconstruction(proof: Optional[z3.Z3PPObject], 
                              filename: str = None) -> str:
    """Save reconstructed proof steps as JSON for audit/documentation."""
    if filename is None:
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"z3_proof_reconstruction_{timestamp}.json"

    steps = extract_proof_steps(proof)
    data = {
        "generated_at": datetime.datetime.now().isoformat(),
        "step_count": len(steps),
        "steps": steps
    }

    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

    print(f"✅ Proof reconstruction saved to: {filename}")
    return filename


def verify_proof(solver: z3.Solver, proof: Optional[z3.Z3PPObject]) -> bool:
    """
    Basic proof verification helper.
    Returns True if proof leads to unsat (lightweight check).
    """
    if proof is None:
        return False
    # Z3 already guarantees the proof is valid if we reached unsat
    # This helper confirms the proof object is non-empty and consistent
    try:
        # Simple sanity: proof should contain at least one resolution step
        if hasattr(proof, 'children') and len(proof.children()) > 0:
            return True
        # Fallback: re-run check on a copy
        s_copy = z3.Solver()
        for a in solver.assertions():
            s_copy.add(a)
        return s_copy.check() == z3.unsat
    except Exception:
        return False


def inspect_proof(solver: z3.Solver, 
                  title: str = "Z3 Proof Inspection", 
                  export_md: Optional[str] = None) -> None:
    """
    Full inspection with statistics, proof trace, and optional markdown export.
    """
    print(f"\n{'='*90}")
    print(f"{title}")
    print(f"{'='*90}")

    result = solver.check()
    print(f"Result: {result}")

    # Statistics
    stats = solver.statistics()
    print("\nSolver Statistics:")
    print(f"  • Conflicts:          {stats.get('conflicts', 'N/A')}")
    print(f"  • Learned clauses:    {stats.get('learned', 'N/A')}")
    print(f"  • Deleted clauses:    {stats.get('deleted', 'N/A')}")
    print(f"  • Restarts:           {stats.get('restarts', 'N/A')}")
    print(f"  • Decisions:          {stats.get('decisions', 'N/A')}")
    print(f"  • Propagations:       {stats.get('propagations', 'N/A')}")
    print(f"  • Memory (MB):        {stats.get('memory', 'N/A')}")

    learned = stats.get('learned', 0)
    if learned > 1000:
        print("  → High learning activity (complex proof)")
    elif learned > 100:
        print("  → Moderate learning (typical for threshold proofs)")
    else:
        print("  → Light learning (simple constraints)")

    # Proof trace
    proof_text = ""
    if result == z3.unsat:
        print("\nProof Trace (resolution steps from conflict analysis):")
        proof = solver.proof()
        proof_text = print_z3_proof(proof, max_depth=7)
        print(proof_text)

        # Reconstruction & verification
        print("\nProof Reconstruction & Verification:")
        steps = extract_proof_steps(proof)
        print(f"  • Reconstructed steps: {len(steps)}")
        save_proof_reconstruction(proof)
        verified = verify_proof(solver, proof)
        print(f"  • Basic verification: {'PASS' if verified else 'FAIL'}")
    elif result == z3.sat:
        print("\nSAT — Model available:")
        print(solver.model())
    else:
        print("\nUnknown result.")

    print(f"{'='*90}\n")

    # Markdown export
    if export_md:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        md_content = f"""# {title}
**Generated:** {timestamp}
**Result:** {result}

## Solver Statistics
- **Conflicts**: {stats.get('conflicts', 'N/A')}
- **Learned clauses**: {stats.get('learned', 'N/A')}
- **Deleted clauses**: {stats.get('deleted', 'N/A')}
- **Restarts**: {stats.get('restarts', 'N/A')}
- **Decisions**: {stats.get('decisions', 'N/A')}
- **Propagations**: {stats.get('propagations', 'N/A')}
- **Memory (MB)**: {stats.get('memory', 'N/A')}

## Proof Trace (if unsat)
```text
{proof_text}
```
"""
        # Write markdown file
        md_path = f"{title.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        with open(md_path, 'w') as f:
            f.write(md_content)
        print(f"  → Markdown exported to: {md_path}")

    return {
        "result": result,
        "stats": stats,
        "proof_steps": steps,
        "assertions": [str(a) for a in solver.assertions()],
        "session_id": hashlib.sha256(
            str(datetime.datetime.now()).encode()
        ).hexdigest()[:12]
    }
