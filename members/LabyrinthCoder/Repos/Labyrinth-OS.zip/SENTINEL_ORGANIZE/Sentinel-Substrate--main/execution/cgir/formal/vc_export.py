# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ◈  (Evidence/Verification)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          vc_export.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
vc_export.py — Labyrinth-OS
===========================
Verifiable Credentials (VC) export for typed receipts.

Implements a simple, standards-compliant VC wrapper for:
- PromotionReceipt
- GateCrossing
- FailedProposal

Uses the W3C Verifiable Credentials Data Model 2.0.
Outputs a signed or unsigned VC (signing is optional via external key).

This is the first concrete standards-alignment deliverable.
"""

import json
import hashlib
import datetime
from dataclasses import asdict
from typing import Any, Dict, Optional

# Minimal VC context (can be extended)
VC_CONTEXT = "https://www.w3.org/ns/credentials/v2"

def _now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def create_vc(receipt: Any, 
              issuer: str = "https://labyrinth-os.org/issuer/core",
              credential_type: str = "LabyrinthOSReceiptCredential",
              sign: bool = False) -> Dict[str, Any]:
    """
    Convert a Labyrinth-OS typed receipt into a W3C Verifiable Credential.
    
    receipt: PromotionReceipt, GateCrossing, or FailedProposal instance
    sign:    Future hook for cryptographic signing (currently returns unsigned)
    """
    if hasattr(receipt, 'to_dict'):
        credential_subject = receipt.to_dict()
    else:
        credential_subject = asdict(receipt) if hasattr(receipt, '__dataclass_fields__') else receipt.__dict__

    # Add Labyrinth-OS specific metadata
    credential_subject["@context"] = VC_CONTEXT
    credential_subject["labyrinthVersion"] = "Labyrinth-OS"
    credential_subject["proofType"] = "LabyrinthOSReceipt"

    vc = {
        "@context": [
            VC_CONTEXT,
            "https://www.w3.org/ns/credentials/v2"
        ],
        "id": f"urn:labyrinth:receipt:{hashlib.sha256(json.dumps(credential_subject, sort_keys=True).encode()).hexdigest()[:16]}",
        "type": ["VerifiableCredential", credential_type],
        "issuer": issuer,
        "validFrom": _now_iso(),
        "credentialSubject": credential_subject
    }

    if sign:
        # Future: add proof with external key (e.g., did:jwk or hardware-rot)
        vc["proof"] = {
            "type": "DataIntegrityProof",
            "cryptosuite": "eddsa-jcs-2022",
            "created": _now_iso(),
            "proofPurpose": "assertionMethod",
            "verificationMethod": f"{issuer}#key-1"
            # signature would be added here
        }

    return vc


def export_vc_to_json(vc: Dict[str, Any], filename: str = None) -> str:
    """Export VC to JSON file."""
    if filename is None:
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"labyrinth_vc_{timestamp}.json"
    
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(vc, f, indent=2)
    
    print(f"✅ VC exported to: {filename}")
    return filename


# Convenience helpers for common receipts
def promotion_receipt_to_vc(receipt, issuer: str = "https://labyrinth-os.org/issuer/core"):
    return create_vc(receipt, issuer, "LabyrinthOSPromotionReceiptCredential")

def gate_crossing_to_vc(crossing, issuer: str = "https://labyrinth-os.org/issuer/core"):
    return create_vc(crossing, issuer, "LabyrinthOSGateCrossingCredential")

def failed_proposal_to_vc(failed, issuer: str = "https://labyrinth-os.org/issuer/core"):
    return create_vc(failed, issuer, "LabyrinthOSFailedProposalCredential")


# Example usage (uncomment to test)
if __name__ == "__main__":
    print("VC Export Utility — Labyrinth-OS")
    print("Ready to convert typed receipts to Verifiable Credentials.\n")
    # Example: from promotion_protocol import PromotionReceipt
    # receipt = PromotionReceipt(...)
    # vc = promotion_receipt_to_vc(receipt)
    # export_vc_to_json(vc)