# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          retention_policy.py — Labyrinth-OS / Ledger
# ----------------------------------------------------------------------------

"""
retention_policy.py — Labyrinth-OS / Ledger
=============================================
Retention Policy for Ledger Entries and Archive Records.

Pattern adapted from Annunimas Machine Soterion retention system
(crates/annunimas-core/src/soterion.rs — SoterionMachineSigil).

The gap this closes:
    Every Labyrinth-OS ledger entry is permanently retained by default.
    Not everything should be. Working data from hypothesis tests,
    cue miner ephemeral state, and deferred node re-entries have
    different retention requirements than sovereignty receipts and
    promotion decisions.

    Retention levels:
    - EPHEMERAL  — this operation only (not written to persistent ledger)
    - SESSION    — survives this ignition session
    - DURABLE    — survives across sessions (default for most entries)
    - PERMANENT  — never purged (Z3 proofs, sovereignty receipts)

    Usage:
    Every ledger entry and archive entry carries a RetentionPolicy.
    chronicle_query.py can filter by retention level.
    Future pruning tools use EPHEMERAL/SESSION to identify purgeable entries.

References:
    Annunimas: crates/annunimas-core/src/soterion.rs
    Labyrinth-OS: execution/ledger/chronicle_query.py
    Labyrinth-OS: execution/ledger/cgir_ledger.py
    Labyrinth-OS: INVARIANTS.md — I6 (Ledger Immutability)
"""

from __future__ import annotations

from enum import Enum, unique
from typing import Dict


# ─── RETENTION POLICY ────────────────────────────────────────────────────────

@unique
class RetentionPolicy(str, Enum):
    """
    How long a ledger entry or archive record should be retained.

    EPHEMERAL  — This operation only. Not written to persistent ledger.
                 Example: hypothesis test working data, temp probe results.

    SESSION    — Survives this ignition session only.
                 Example: intermediate cue pattern candidates before mining.

    DURABLE    — Survives across sessions. Default for most entries.
                 Example: gate decisions, promotion records, trial results.

    PERMANENT  — Never purged. Reserved for the most critical records.
                 Example: Z3 sovereignty proofs, first LIVE_INFERENCE event,
                          sovereignty receipts, ACP-1 VERIFIED closures.
    """
    EPHEMERAL = "ephemeral"
    SESSION   = "session"
    DURABLE   = "durable"
    PERMANENT = "permanent"


# ─── SEVERITY LEVELS ─────────────────────────────────────────────────────────

@unique
class SigilSeverity(str, Enum):
    """
    Semantic severity of a ledger entry or archive record.
    
    Adapted from Annunimas SoterionMachineSigil.sigil_severity.
    Used for filtering and alerting in chronicle_query.py.
    """
    INFO     = "INFO"
    WARNING  = "WARNING"
    ERROR    = "ERROR"
    CRITICAL = "CRITICAL"


# ─── POLICY DEFAULTS BY EVENT TYPE ───────────────────────────────────────────

# Default retention policy for known event types.
# Entries not in this table default to DURABLE.
RETENTION_DEFAULTS: Dict[str, RetentionPolicy] = {
    # Permanent — never purge these
    "LIVE_INFERENCE":        RetentionPolicy.PERMANENT,
    "Z3_PROOF_RECEIPT":      RetentionPolicy.PERMANENT,
    "SOVEREIGNTY_RECEIPT":   RetentionPolicy.PERMANENT,
    "ASSUMPTION_VERIFIED":   RetentionPolicy.PERMANENT,
    "PROMOTION_APPROVED":    RetentionPolicy.PERMANENT,
    "A010_CLOSED":           RetentionPolicy.PERMANENT,
    "A021_VERIFIED":         RetentionPolicy.PERMANENT,

    # Durable — default for most gate and trial records
    "GATE_ALLOW":            RetentionPolicy.DURABLE,
    "GATE_BLOCK":            RetentionPolicy.DURABLE,
    "GATE_KILL":             RetentionPolicy.DURABLE,
    "TRIAL_REFLECTION":      RetentionPolicy.DURABLE,
    "CUE_PATTERN":           RetentionPolicy.DURABLE,
    "ANOMALY":               RetentionPolicy.DURABLE,
    "FEEDBACK":              RetentionPolicy.DURABLE,
    "ARCHIVE_ENTRY":         RetentionPolicy.DURABLE,

    # Session — kept for session duration, not persisted long-term
    "PIPELINE_TRACE":        RetentionPolicy.SESSION,
    "INTERMEDIATE_LABEL":    RetentionPolicy.SESSION,
    "DEFERRED_REENTRY":      RetentionPolicy.SESSION,

    # Ephemeral — working data, not written to persistent ledger
    "HYPOTHESIS_TEST_RUN":   RetentionPolicy.EPHEMERAL,
    "MOCK_DRY_RUN":          RetentionPolicy.EPHEMERAL,
    "PROBE_RESULT":          RetentionPolicy.EPHEMERAL,
}


def default_retention(event_type: str) -> RetentionPolicy:
    """Return the default retention policy for an event type."""
    return RETENTION_DEFAULTS.get(event_type.upper(), RetentionPolicy.DURABLE)


def default_severity(verdict: str) -> SigilSeverity:
    """Return a sensible default severity level for a gate verdict."""
    v = verdict.upper()
    if v == "KILL":
        return SigilSeverity.CRITICAL
    elif v in ("BLOCK", "ERROR"):
        return SigilSeverity.ERROR
    elif v in ("WARN", "WARNING"):
        return SigilSeverity.WARNING
    else:
        return SigilSeverity.INFO


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_permanent_events() -> bool:
    assert default_retention("LIVE_INFERENCE")      == RetentionPolicy.PERMANENT
    assert default_retention("Z3_PROOF_RECEIPT")    == RetentionPolicy.PERMANENT
    assert default_retention("SOVEREIGNTY_RECEIPT") == RetentionPolicy.PERMANENT
    return True


def _test_durable_events() -> bool:
    assert default_retention("GATE_ALLOW")       == RetentionPolicy.DURABLE
    assert default_retention("GATE_BLOCK")       == RetentionPolicy.DURABLE
    assert default_retention("TRIAL_REFLECTION") == RetentionPolicy.DURABLE
    assert default_retention("CUE_PATTERN")      == RetentionPolicy.DURABLE
    return True


def _test_session_events() -> bool:
    assert default_retention("PIPELINE_TRACE")   == RetentionPolicy.SESSION
    assert default_retention("DEFERRED_REENTRY") == RetentionPolicy.SESSION
    return True


def _test_ephemeral_events() -> bool:
    assert default_retention("HYPOTHESIS_TEST_RUN") == RetentionPolicy.EPHEMERAL
    assert default_retention("MOCK_DRY_RUN")        == RetentionPolicy.EPHEMERAL
    return True


def _test_unknown_defaults_to_durable() -> bool:
    assert default_retention("UNKNOWN_EVENT_TYPE") == RetentionPolicy.DURABLE
    assert default_retention("ANYTHING_ELSE")      == RetentionPolicy.DURABLE
    return True


def _test_case_insensitive() -> bool:
    assert default_retention("live_inference") == RetentionPolicy.PERMANENT
    assert default_retention("Live_Inference") == RetentionPolicy.PERMANENT
    assert default_retention("LIVE_INFERENCE") == RetentionPolicy.PERMANENT
    return True


def _test_severity_kill_is_critical() -> bool:
    assert default_severity("KILL")    == SigilSeverity.CRITICAL
    assert default_severity("BLOCK")   == SigilSeverity.ERROR
    assert default_severity("EXECUTE") == SigilSeverity.INFO
    assert default_severity("ALLOW")   == SigilSeverity.INFO
    return True


def _test_retention_enum_values() -> bool:
    assert RetentionPolicy.PERMANENT.value == "permanent"
    assert RetentionPolicy.DURABLE.value   == "durable"
    assert RetentionPolicy.SESSION.value   == "session"
    assert RetentionPolicy.EPHEMERAL.value == "ephemeral"
    return True


def run_tests():
    tests = [
        (_test_permanent_events,       "permanent_events"),
        (_test_durable_events,         "durable_events"),
        (_test_session_events,         "session_events"),
        (_test_ephemeral_events,       "ephemeral_events"),
        (_test_unknown_defaults_to_durable, "unknown_defaults_durable"),
        (_test_case_insensitive,       "case_insensitive"),
        (_test_severity_kill_is_critical, "severity_kill_critical"),
        (_test_retention_enum_values,  "enum_values"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
