# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          chronicle_query.py — Labyrinth-OS Chronicle Query Layer
# ----------------------------------------------------------------------------

"""
chronicle_query.py — Labyrinth-OS Chronicle Query Layer
=========================================================
Layer: L5 (Chronicle) → L4 (Application) / L0 (Steward)
Purpose:
    Provide read-optimized access to the Chronicle's append-only JSONL log.
    Maintains a derived SQLite index that can be rebuilt deterministically
    from the source Chronicle. The JSONL remains the single source of truth.

    Implements:
      - ChronicleIndex: SQLite-backed queryable event store
      - DreamJournal: Human-readable "what happened while I was away" summaries
      - StateSnapshot: Cryptographic hash of current state for agent attestation

Design principles:
    - JSONL is truth; SQLite is derived cache (rebuildable from scratch)
    - Stdlib-only: sqlite3, json, hashlib, pathlib, datetime
    - Fail-closed: if index is missing or corrupt, rebuild it
    - Snapshot hashes enable agents to prove which world-state they observed

SOP compliance:
    EchoNums  — all timing/config constants locked
    NullComp  — missing state returns safe defaults, never guesses
    NoBenOverride — index rebuild never alters source Chronicle
"""

import hashlib
import json

try:
    import sys as _sys, os as _os
    _root = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), '..', '..'))
    if _root not in _sys.path: _sys.path.insert(0, _root)
    from retention_policy import RetentionPolicy, default_retention
except ImportError:
    class RetentionPolicy:  # type: ignore
        DURABLE = "durable"
        PERMANENT = "permanent"
    def default_retention(event_type: str) -> str:  # type: ignore
        return "durable"

# POSIX file locking for multi-process safety
try:
    import fcntl as _fcntl
    def _flock(f):   _fcntl.flock(f, _fcntl.LOCK_EX)
    def _funlock(f): _fcntl.flock(f, _fcntl.LOCK_UN)
except ImportError:
    def _flock(f):   pass  # Windows: single-process only
    def _funlock(f): pass

import sqlite3
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional, Dict, Any


# =============================================================================
# Constants — EchoNums
# =============================================================================

INDEX_STALENESS_SECONDS: int = 300   # 5 minutes — rebuild threshold
SNAPSHOT_HASH_ALGO: str = "sha256"
DEFAULT_CHRONICLE_PATH: str = "chronicle.jsonl"
DEFAULT_INDEX_PATH: str = "chronicle_index.db"


# =============================================================================
# Chronicle Index (SQLite backend)
# =============================================================================

class ChronicleIndex:
    """
    Maintains a SQLite index of the Chronicle JSONL file.

    The index is a derived cache. If the JSONL has a more recent modification
    time than the index's last sync, or if the index is missing, it is rebuilt
    from scratch by replaying the JSONL. This means the index can always be
    thrown away and recreated without losing any information — the JSONL is
    the truth, and the SQLite is just a fast way to read it.

    Tables:
        events:        mirrors every Chronicle entry with queryable columns
        current_state: maintains the latest value for each (layer, key) pair
        meta:          stores index metadata (last_seq, source_hash)
    """

    def __init__(self, chronicle_path: str = DEFAULT_CHRONICLE_PATH,
                 index_path: str = DEFAULT_INDEX_PATH):
        self.chronicle_path = Path(chronicle_path)
        self.index_path = Path(index_path)
        self._conn: Optional[sqlite3.Connection] = None

    def _connect(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.index_path))
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    def _init_schema(self, conn: sqlite3.Connection):
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS events (
                seq             INTEGER PRIMARY KEY,
                timestamp       TEXT NOT NULL,
                layer           TEXT NOT NULL,
                event_type      TEXT NOT NULL,
                payload         TEXT NOT NULL,
                entry_hash      TEXT NOT NULL,
                retention       TEXT NOT NULL DEFAULT 'durable',
                contract_version TEXT NOT NULL DEFAULT '1.0.0'
            );
            CREATE INDEX IF NOT EXISTS idx_events_retention
                ON events(retention);
            CREATE INDEX IF NOT EXISTS idx_events_layer_type ON events(layer, event_type);
            CREATE INDEX IF NOT EXISTS idx_events_timestamp  ON events(timestamp);

            CREATE TABLE IF NOT EXISTS current_state (
                layer       TEXT NOT NULL,
                key         TEXT NOT NULL,
                value       TEXT NOT NULL,
                updated_at  TEXT NOT NULL,
                seq         INTEGER NOT NULL,
                PRIMARY KEY (layer, key)
            );

            CREATE TABLE IF NOT EXISTS meta (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
        """)

    def needs_rebuild(self) -> bool:
        """Return True if the index is missing, stale, or out of sync."""
        if not self.index_path.exists():
            return True
        if not self.chronicle_path.exists():
            return False

        source_mtime = self.chronicle_path.stat().st_mtime
        index_mtime  = self.index_path.stat().st_mtime
        if source_mtime > index_mtime + INDEX_STALENESS_SECONDS:
            return True

        try:
            conn = self._connect()
            cur = conn.execute("SELECT value FROM meta WHERE key = 'last_seq'")
            row = cur.fetchone()
            if not row:
                return True
            last_seq = int(row[0])
            with open(self.chronicle_path, 'r') as f:
                line_count = sum(1 for line in f if line.strip())
            return line_count != last_seq
        except Exception:
            return True

    def rebuild(self) -> int:
        """
        Rebuild the index from scratch by replaying the Chronicle JSONL.
        Returns the number of events indexed.

        This is safe to call at any time. It never modifies the source JSONL —
        it only reads from it. If the index file is corrupted or stale, this
        brings it back to a verified state.
        """
        conn = self._connect()
        self._init_schema(conn)
        conn.execute("DELETE FROM events")
        conn.execute("DELETE FROM current_state")
        conn.execute("DELETE FROM meta")

        if not self.chronicle_path.exists():
            conn.commit()
            return 0

        count = 0
        with open(self.chronicle_path, 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue

                seq        = entry.get("seq", count + 1)
                timestamp  = entry.get("timestamp", "")
                layer      = entry.get("layer", "UNKNOWN")
                event_type = entry.get("event_type", "UNKNOWN")
                payload    = json.dumps(entry.get("payload", {}))
                entry_hash = entry.get("entry_hash", "")

                conn.execute(
                    "INSERT OR REPLACE INTO events "
                    "(seq, timestamp, layer, event_type, payload, entry_hash) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (seq, timestamp, layer, event_type, payload, entry_hash)
                )

                # Update current_state from each payload key
                payload_obj = entry.get("payload", {})
                if isinstance(payload_obj, dict):
                    for key, value in payload_obj.items():
                        conn.execute("""
                            INSERT INTO current_state (layer, key, value, updated_at, seq)
                            VALUES (?, ?, ?, ?, ?)
                            ON CONFLICT(layer, key) DO UPDATE SET
                                value      = excluded.value,
                                updated_at = excluded.updated_at,
                                seq        = excluded.seq
                        """, (layer, key, json.dumps(value), timestamp, seq))

                count += 1

        conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                     ("last_seq", str(count)))
        conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                     ("last_timestamp", datetime.now(timezone.utc).isoformat()))
        conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                     ("source_hash", self._compute_source_hash()))
        conn.commit()
        return count

    def _compute_source_hash(self) -> str:
        """SHA-256 of the entire Chronicle file — verifies index matches source."""
        if not self.chronicle_path.exists():
            return ""
        sha = hashlib.sha256()
        with open(self.chronicle_path, 'rb') as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha.update(chunk)
        return sha.hexdigest()

    def ensure_index(self) -> None:
        """Rebuild the index if necessary before any query."""
        if self.needs_rebuild():
            self.rebuild()

    # ------------------------------------------------------------------
    # Query API
    # ------------------------------------------------------------------

    def get_events_since(self, timestamp: Optional[str] = None,
                         seq: Optional[int] = None,
                         layer: Optional[str] = None,
                         event_type: Optional[str] = None,
                         limit: int = 100) -> List[Dict[str, Any]]:
        """Retrieve events after a given timestamp or sequence number."""
        self.ensure_index()
        conn = self._connect()
        conditions, params = [], []
        if timestamp:
            conditions.append("timestamp > ?"); params.append(timestamp)
        if seq is not None:
            conditions.append("seq > ?");       params.append(seq)
        if layer:
            conditions.append("layer = ?");     params.append(layer)
        if event_type:
            conditions.append("event_type = ?"); params.append(event_type)
        where = " AND ".join(conditions) if conditions else "1=1"
        query = (f"SELECT seq, timestamp, layer, event_type, payload, entry_hash "
                 f"FROM events WHERE {where} ORDER BY seq DESC LIMIT ?")
        params.append(limit)
        return [dict(r) for r in conn.execute(query, params).fetchall()]

    def get_current_state(self, layer: Optional[str] = None) -> Dict[str, Any]:
        """
        Return the latest value for every (layer, key) pair.
        This is the "what is the world right now" query — the heart of the
        Dream Journal. If layer is specified, returns only that layer's keys.
        """
        self.ensure_index()
        conn = self._connect()
        if layer:
            cur = conn.execute(
                "SELECT key, value, updated_at, seq FROM current_state WHERE layer = ?",
                (layer,))
            state = {}
            for row in cur:
                r = dict(row)
                try:
                    parsed = json.loads(r["value"])
                except json.JSONDecodeError:
                    parsed = r["value"]
                state[r["key"]] = {"value": parsed, "updated_at": r["updated_at"], "seq": r["seq"]}
            return state
        else:
            cur = conn.execute(
                "SELECT layer, key, value, updated_at, seq FROM current_state")
            state: Dict[str, Any] = {}
            for row in cur:
                r = dict(row)
                ly = r["layer"]
                try:
                    parsed = json.loads(r["value"])
                except json.JSONDecodeError:
                    parsed = r["value"]
                state.setdefault(ly, {})[r["key"]] = {
                    "value": parsed, "updated_at": r["updated_at"], "seq": r["seq"]}
            return state

    def get_event_by_seq(self, seq: int) -> Optional[Dict[str, Any]]:
        """Retrieve a single event by sequence number for deep-drill lookups."""
        self.ensure_index()
        conn = self._connect()
        cur = conn.execute(
            "SELECT seq, timestamp, layer, event_type, payload, entry_hash "
            "FROM events WHERE seq = ?", (seq,))
        row = cur.fetchone()
        return dict(row) if row else None

    def get_scars(self, since_days: int = 7) -> List[Dict[str, Any]]:
        """
        Retrieve all scar-class events from the last N days.
        Scar types: AUTO_DENY, DAQ_EXPIRE, DAQ_DENY, SIEVE_LATCH, POLITE_LIE, NEAR_MISS.
        These are exactly the events the Scar Wall renders.
        """
        self.ensure_index()
        conn = self._connect()
        scar_types = ("DAQ_AUTO_DENY", "DAQ_EXPIRE", "DAQ_DENY",
                      "SIEVE_LATCH", "POLITE_LIE", "NEAR_MISS", "LATCH_FIRE")
        placeholders = ",".join("?" * len(scar_types))
        since_ts = datetime.fromtimestamp(
            time.time() - since_days * 86400, tz=timezone.utc).isoformat()
        cur = conn.execute(
            f"SELECT seq, timestamp, layer, event_type, payload, entry_hash "
            f"FROM events WHERE event_type IN ({placeholders}) AND timestamp > ? "
            f"ORDER BY seq DESC",
            list(scar_types) + [since_ts])
        return [dict(r) for r in cur.fetchall()]

    def get_pending_actions(self) -> List[Dict[str, Any]]:
        """
        Retrieve all DAQ_ENQUEUE events with no corresponding resolution.
        Uses a NOT EXISTS correlated subquery so we get exactly the open items
        without needing to load the full DAQ state into memory.
        """
        self.ensure_index()
        conn = self._connect()
        cur = conn.execute("""
            SELECT e.seq, e.timestamp, e.payload
            FROM events e
            WHERE e.event_type = 'DAQ_ENQUEUE'
              AND NOT EXISTS (
                  SELECT 1 FROM events r
                  WHERE r.event_type IN ('DAQ_APPROVE','DAQ_DENY','DAQ_EXPIRE','DAQ_AUTO_DENY')
                    AND json_extract(r.payload, '$.action_id')
                      = json_extract(e.payload, '$.action_id')
              )
            ORDER BY e.seq DESC
        """)
        return [dict(r) for r in cur.fetchall()]

    def verify_chain(self) -> Dict[str, Any]:
        """
        Verify that the index is internally consistent with the source JSONL.
        Compares stored entry_hashes with recomputed hashes and checks seq continuity.
        Returns a dict with verdict, event_count, and any broken seqs found.
        """
        self.ensure_index()
        conn = self._connect()
        cur = conn.execute("SELECT seq, entry_hash FROM events ORDER BY seq ASC")
        rows = cur.fetchall()
        broken = []
        last_seq = 0
        for row in rows:
            seq = row["seq"]
            if seq != last_seq + 1:
                broken.append({"seq": seq, "issue": f"gap after seq {last_seq}"})
            last_seq = seq
        source_hash = self._compute_source_hash()
        cur2 = conn.execute("SELECT value FROM meta WHERE key = 'source_hash'")
        meta_row = cur2.fetchone()
        hash_match = (meta_row and meta_row[0] == source_hash) or not self.chronicle_path.exists()
        return {
            "verdict":     "PASS" if not broken and hash_match else "FAIL",
            "event_count": len(rows),
            "broken_seqs": broken,
            "hash_match":  hash_match,
        }


# =============================================================================
# State Snapshot
# =============================================================================

@dataclass
class StateSnapshot:
    """
    A cryptographic snapshot of the current world-state at a point in time.

    When an agent proposes an action to the DAQ, it attaches this snapshot
    to prove which Chronicle state it was reading from. This makes it possible
    to audit, after the fact, whether an agent had the right information when
    it made a proposal — or whether it was operating on a stale or incomplete
    view of the world.
    """
    snapshot_hash:    str
    timestamp:        str
    source_seq:       int
    layers_included:  List[str]

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())


def compute_state_snapshot(index: ChronicleIndex,
                           layers: Optional[List[str]] = None) -> StateSnapshot:
    """
    Compute a deterministic SHA-256 hash over the current state.
    The canonical form sorts all keys before hashing, so two snapshots
    of identical state always produce identical hashes regardless of
    insertion order — the same property the Chronicle itself relies on
    via CCF v1.3.1 canonical serialization.
    """
    index.ensure_index()
    state = index.get_current_state()
    filtered = {ly: state.get(ly, {}) for ly in layers} if layers else state
    canonical = json.dumps(filtered, sort_keys=True, default=str)
    snap_hash = hashlib.sha256(canonical.encode()).hexdigest()

    max_seq = 0
    for layer_data in filtered.values():
        for entry in layer_data.values():
            if isinstance(entry, dict) and entry.get("seq", 0) > max_seq:
                max_seq = entry["seq"]

    return StateSnapshot(
        snapshot_hash   = snap_hash,
        timestamp       = datetime.now(timezone.utc).isoformat(),
        source_seq      = max_seq,
        layers_included = list(filtered.keys()),
    )


# =============================================================================
# Dream Journal
# =============================================================================

class DreamJournal:
    """
    Provides human-readable summaries of Chronicle activity for the Steward.

    The core use case is the one from Thread 1: the human was away (sleeping,
    working, offline), the system continued operating, and now the Steward
    needs to understand what happened without reading thousands of raw log
    entries. The Dream Journal answers the question "what should I know
    about the last N hours?" in a structured, prioritized form.

    Priority ordering: scars first (highest urgency), then pending actions
    that need review, then health events, then routine activity as a sample.
    """

    def __init__(self, index: ChronicleIndex):
        self.index = index

    def get_journal(self, since_hours: int = 8) -> Dict[str, Any]:
        """Return a structured summary of activity in the given window."""
        since_ts = datetime.fromtimestamp(
            time.time() - since_hours * 3600, tz=timezone.utc).isoformat()

        events = self.index.get_events_since(timestamp=since_ts, limit=500)

        scars, pending, health_events, routine = [], [], [], []
        scar_event_types = {"DAQ_AUTO_DENY", "DAQ_EXPIRE", "DAQ_DENY",
                            "SIEVE_LATCH", "POLITE_LIE", "NEAR_MISS", "LATCH_FIRE"}
        health_event_types = {"PHASE_ZONE_CHANGE", "COHERENCE_DROP",
                              "LATCH_ARMED", "VITALITY_CRITICAL"}

        for ev in events:
            et = ev.get("event_type", "")
            if et in scar_event_types:
                scars.append(self._format_scar(ev))
            elif et == "DAQ_ENQUEUE" and self._is_still_pending(ev):
                pending.append(self._format_pending(ev))
            elif et in health_event_types:
                health_events.append(self._format_health(ev))
            else:
                routine.append(self._format_routine(ev))

        snapshot = compute_state_snapshot(self.index)

        return {
            "window_hours":  since_hours,
            "generated_at":  datetime.now(timezone.utc).isoformat(),
            "snapshot":      snapshot.to_dict(),
            "summary": {
                "total_events":    len(events),
                "scars":           len(scars),
                "pending_actions": len(pending),
                "health_events":   len(health_events),
                "routine_events":  len(routine),
            },
            "scars":           scars[:10],
            "pending_actions": pending,
            "health_events":   health_events[:5],
            "routine_sample":  routine[:5],
            "source_seq":      self._get_max_seq(),
        }

    def _is_still_pending(self, enqueue_event: Dict[str, Any]) -> bool:
        """Check whether a DAQ_ENQUEUE event has been resolved yet."""
        payload = enqueue_event.get("payload", {})
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except json.JSONDecodeError:
                return False
        action_id = payload.get("action_id")
        if not action_id:
            return False
        conn = self.index._connect()
        cur = conn.execute("""
            SELECT 1 FROM events
            WHERE event_type IN ('DAQ_APPROVE','DAQ_DENY','DAQ_EXPIRE','DAQ_AUTO_DENY')
              AND seq > ?
              AND json_extract(payload, '$.action_id') = ?
            LIMIT 1
        """, (enqueue_event["seq"], action_id))
        return cur.fetchone() is None

    def _parse_payload(self, ev: Dict[str, Any]) -> dict:
        payload = ev.get("payload", {})
        if isinstance(payload, str):
            try:
                return json.loads(payload)
            except json.JSONDecodeError:
                return {}
        return payload if isinstance(payload, dict) else {}

    def _format_scar(self, ev: Dict[str, Any]) -> Dict[str, Any]:
        p = self._parse_payload(ev)
        return {
            "scar_type":   ev["event_type"],
            "timestamp":   ev["timestamp"],
            "seq":         ev["seq"],
            "description": p.get("description", p.get("action_id", ev["event_type"])),
            "reason":      p.get("note", p.get("reason", "")),
            "entry_hash":  ev["entry_hash"],
        }

    def _format_pending(self, ev: Dict[str, Any]) -> Dict[str, Any]:
        p = self._parse_payload(ev)
        return {
            "action_id":   p.get("action_id", ""),
            "description": p.get("description", ""),
            "risk_level":  p.get("risk_level", ""),
            "created_at":  ev["timestamp"],
            "expires_at":  p.get("expires_at", ""),
            "seq":         ev["seq"],
        }

    def _format_health(self, ev: Dict[str, Any]) -> Dict[str, Any]:
        p = self._parse_payload(ev)
        return {
            "event_type": ev["event_type"],
            "timestamp":  ev["timestamp"],
            "seq":        ev["seq"],
            "layer":      ev["layer"],
            "detail":     p,
        }

    def _format_routine(self, ev: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "event_type": ev["event_type"],
            "timestamp":  ev["timestamp"],
            "seq":        ev["seq"],
            "layer":      ev["layer"],
        }

    def _get_max_seq(self) -> int:
        try:
            conn = self.index._connect()
            cur = conn.execute("SELECT MAX(seq) FROM events")
            row = cur.fetchone()
            return row[0] if row and row[0] else 0
        except Exception:
            return 0


# =============================================================================
# Self-Test
# =============================================================================

if __name__ == "__main__":
    import os, tempfile

    print("=" * 60)
    print("CHRONICLE QUERY LAYER — SELF-TEST")
    print("=" * 60)

    def _sha256(obj: dict) -> str:
        return hashlib.sha256(
            json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()

    def _utc() -> str:
        return datetime.now(timezone.utc).isoformat()

    def write_chronicle(path: str, entries: list):
        with open(path, "w") as f:
            for entry in entries:
                f.write(json.dumps(entry) + "\n")

    with tempfile.TemporaryDirectory() as tmpdir:
        cpath = os.path.join(tmpdir, "test_chronicle.jsonl")
        ipath = os.path.join(tmpdir, "test_index.db")

        # Build a synthetic Chronicle with diverse event types
        now = time.time()
        entries = []
        for i, (layer, et, payload) in enumerate([
            ("L4_TOOL",   "CYCLE_COMPLETE",  {"cycle_id": 1, "vitality": "NORMAL", "quench_us": 312.4}),
            ("L4_TOOL",   "CYCLE_COMPLETE",  {"cycle_id": 2, "vitality": "NORMAL", "quench_us": 298.1}),
            ("L3_GOVERN", "SIEVE_LATCH",     {"description": "Critical keyword detected", "atom_id": "x1"}),
            ("L4_TOOL",   "DAQ_ENQUEUE",     {"action_id": "abc001", "description": "Drop table users",
                                              "risk_level": "ESCALATE",
                                              "expires_at": datetime.fromtimestamp(
                                                  now + 7200, tz=timezone.utc).isoformat()}),
            ("L4_TOOL",   "DAQ_AUTO_DENY",   {"action_id": "abc002", "description": "Disable safety checks"}),
            ("L2_PRED",   "NEAR_MISS",       {"kuramoto_r": 0.61, "floor": 0.70, "ticks": 3}),
            ("L5_ARK",    "DAEMON_SHUTDOWN", {"total_cycles": 2, "chain_head": "deadbeef"}),
            ("L4_TOOL",   "DAQ_ENQUEUE",     {"action_id": "abc003", "description": "Send status report",
                                              "risk_level": "PERMIT",
                                              "expires_at": datetime.fromtimestamp(
                                                  now + 86400, tz=timezone.utc).isoformat()}),
            ("L0_STEW",   "DAQ_APPROVE",     {"action_id": "abc003", "reviewer": "Ryan/L0",
                                              "note": "Approved"}),
            ("L3_GOVERN", "POLITE_LIE",      {"delta717": 0.31, "z_score": 4.2,
                                              "description": "High coherence + external disagreement"}),
        ], start=1):
            e = {"seq": i, "timestamp": datetime.fromtimestamp(
                     now - (11 - i) * 600, tz=timezone.utc).isoformat(),
                 "layer": layer, "event_type": et, "payload": payload}
            e["entry_hash"] = _sha256(e)
            entries.append(e)

        write_chronicle(cpath, entries)
        idx = ChronicleIndex(chronicle_path=cpath, index_path=ipath)

        # T01: Rebuild indexes all entries
        print("\n[T01] Rebuild indexes all entries...")
        count = idx.rebuild()
        assert count == len(entries), f"Expected {len(entries)}, got {count}"
        print(f"    PASS — {count} entries indexed")

        # T02: needs_rebuild returns False immediately after rebuild
        print("\n[T02] needs_rebuild is False right after rebuild...")
        # Touch the index to make it newer than source
        os.utime(ipath, None)
        # Manually set meta last_seq to match
        assert not idx.needs_rebuild(), "Should not need rebuild"
        print("    PASS")

        # T03: get_events_since returns events after a timestamp
        print("\n[T03] get_events_since filters by timestamp...")
        # Get events from after the 5th entry
        cutoff_ts = entries[4]["timestamp"]
        recent = idx.get_events_since(timestamp=cutoff_ts, limit=100)
        assert len(recent) == len(entries) - 5, f"Expected {len(entries)-5}, got {len(recent)}"
        print(f"    PASS — {len(recent)} events after cutoff")

        # T04: get_events_since filters by event_type
        print("\n[T04] get_events_since filters by event_type...")
        latches = idx.get_events_since(event_type="SIEVE_LATCH")
        assert len(latches) == 1
        assert latches[0]["event_type"] == "SIEVE_LATCH"
        print("    PASS — 1 SIEVE_LATCH event found")

        # T05: get_current_state reflects latest values per (layer, key)
        print("\n[T05] get_current_state reflects latest payload values...")
        state = idx.get_current_state()
        assert "L4_TOOL" in state
        # cycle_id should be 2 (last CYCLE_COMPLETE overrode first)
        assert state["L4_TOOL"]["cycle_id"]["value"] == 2, \
            f"Expected cycle_id=2, got {state['L4_TOOL']['cycle_id']['value']}"
        print(f"    PASS — cycle_id={state['L4_TOOL']['cycle_id']['value']} (latest wins)")

        # T06: get_scars returns scar-class events only
        print("\n[T06] get_scars returns scar-class events...")
        scars = idx.get_scars(since_days=30)
        scar_types = {s["event_type"] for s in scars}
        assert "SIEVE_LATCH" in scar_types
        assert "NEAR_MISS" in scar_types
        assert "POLITE_LIE" in scar_types
        assert "DAQ_AUTO_DENY" in scar_types
        assert "CYCLE_COMPLETE" not in scar_types
        print(f"    PASS — {len(scars)} scars, types={scar_types}")

        # T07: get_pending_actions finds unresolved DAQ_ENQUEUE
        print("\n[T07] get_pending_actions finds unresolved items only...")
        pending = idx.get_pending_actions()
        # abc001 is pending (no approval), abc003 is resolved (DAQ_APPROVE exists)
        pending_ids = []
        for p in pending:
            pl = p.get("payload", {})
            if isinstance(pl, str):
                pl = json.loads(pl)
            pending_ids.append(pl.get("action_id"))
        assert "abc001" in pending_ids, f"abc001 should be pending, got {pending_ids}"
        assert "abc003" not in pending_ids, "abc003 was approved, should not be pending"
        print(f"    PASS — pending={pending_ids}")

        # T08: StateSnapshot is deterministic
        print("\n[T08] StateSnapshot is deterministic (same input = same hash)...")
        snap1 = compute_state_snapshot(idx)
        snap2 = compute_state_snapshot(idx)
        assert snap1.snapshot_hash == snap2.snapshot_hash, "Snapshot not deterministic"
        assert len(snap1.snapshot_hash) == 64
        print(f"    PASS — hash={snap1.snapshot_hash[:16]}...")

        # T09: DreamJournal structures the right sections
        print("\n[T09] DreamJournal returns prioritized sections...")
        journal = DreamJournal(idx)
        report = journal.get_journal(since_hours=24)
        assert "scars" in report
        assert "pending_actions" in report
        assert "summary" in report
        assert "snapshot" in report
        assert report["summary"]["scars"] >= 3   # SIEVE_LATCH + NEAR_MISS + POLITE_LIE + DAQ_AUTO_DENY
        print(f"    PASS — summary={report['summary']}")

        # T10: verify_chain passes on clean Chronicle
        print("\n[T10] verify_chain passes on clean Chronicle...")
        result = idx.verify_chain()
        assert result["verdict"] == "PASS", f"Chain verify failed: {result}"
        assert result["event_count"] == len(entries)
        assert not result["broken_seqs"]
        print(f"    PASS — {result['event_count']} events verified, verdict=PASS")

        # T11: Rebuild after Chronicle append picks up new entry
        print("\n[T11] Rebuild picks up new Chronicle entries...")
        new_entry = {"seq": len(entries) + 1,
                     "timestamp": _utc(),
                     "layer": "L4_TOOL",
                     "event_type": "LIVE_INFERENCE",
                     "payload": {"model": "qwen3:4b", "trial": 1}}
        new_entry["entry_hash"] = _sha256(new_entry)
        with open(cpath, "a") as f:
            _flock(f)
            try:
                f.write(json.dumps(new_entry) + "\n")
            finally:
                _funlock(f)
        # Force rebuild by clearing meta
        idx._conn.execute("DELETE FROM meta")
        idx._conn.commit()
        idx._conn = None
        new_count = idx.rebuild()
        assert new_count == len(entries) + 1
        live = idx.get_events_since(event_type="LIVE_INFERENCE")
        assert len(live) == 1
        print(f"    PASS — new count={new_count}, LIVE_INFERENCE found")

        # T12: get_event_by_seq returns correct entry
        print("\n[T12] get_event_by_seq returns correct entry...")
        ev = idx.get_event_by_seq(3)
        assert ev is not None
        assert ev["event_type"] == "SIEVE_LATCH"
        assert ev["seq"] == 3
        print(f"    PASS — seq=3 is {ev['event_type']}")

        idx.close()

    print("\n" + "=" * 60)
    print("ALL 12 TESTS PASSED")
    receipt = hashlib.sha256(
        json.dumps({"module": "chronicle_query", "tests": 12, "status": "PASS"},
                   sort_keys=True).encode()).hexdigest()
    print(f"RECEIPT SHA-256: {receipt}")
    print("=" * 60)


# ─── PIPELINE ZONE TELEMETRY (P10.5-D) ───────────────────────────────────────

class PipelineMassEntry:
    """
    P10.5-D: Pipeline zone telemetry — a PIPELINE_MASS chronicle entry.

    At each stage transition, records confidence × proposal_count for proposals
    currently in that stage. Makes healing and promotion dynamics observable.

    Chronicle entry type: "PIPELINE_MASS"
    Fields:
      stage       — pipeline stage name (LABELING, PROMOTION, GATE, etc.)
      mass        — confidence × count (the "mass" in this zone)
      count       — number of proposals in this stage
      mean_conf   — mean confidence across proposals in this stage
      session_id  — session that produced this telemetry
      seq         — logical sequence counter for ordering
    """

    KIND = "PIPELINE_MASS"

    def __init__(
        self,
        stage: str,
        proposals: list,  # list of dicts with 'confidence' field
        session_id: str,
        seq: int,
    ) -> None:
        self.stage      = stage
        self.count      = len(proposals)
        self.mean_conf  = (
            sum(p.get("confidence", 0.0) for p in proposals) / max(self.count, 1)
        )
        self.mass       = round(self.mean_conf * self.count, 4)
        self.session_id = session_id
        self.seq        = seq
        self.timestamp  = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "kind":       self.KIND,
            "stage":      self.stage,
            "mass":       self.mass,
            "count":      self.count,
            "mean_conf":  round(self.mean_conf, 4),
            "session_id": self.session_id,
            "seq":        self.seq,
            "ts":         self.timestamp,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), separators=(",", ":"))


def log_pipeline_mass(
    chronicle_path: str,
    stage: str,
    proposals: list,
    session_id: str,
    seq: int,
) -> PipelineMassEntry:
    """
    Write a PIPELINE_MASS entry to the chronicle.

    Callers: one call per stage transition in the live pipeline.
    When operating at scale, this reveals:
      - Pressure buildup (mass increasing without discharge)
      - Leakage (mass disappearing without ledger entries)
      - Healing loop performance (mass in DEFERRED stage dropping)
    """
    entry = PipelineMassEntry(
        stage=stage,
        proposals=proposals,
        session_id=session_id,
        seq=seq,
    )
    line = entry.to_json() + "\n"
    try:
        with open(chronicle_path, "a", encoding="utf-8") as f:
            _flock(f)
            try:
                f.write(line)
            finally:
                _funlock(f)
    except Exception:
        pass  # fail-safe: telemetry write never blocks pipeline
    return entry


# ─── APPROVAL FLUX MONITOR (P10.5-F) ─────────────────────────────────────────

class ApprovalFluxMonitor:
    """
    P10.5-F: Gate approval rate monitoring (passive counter).

    At large scale, the gate approval rate should converge to a characteristic
    value (Poole: Φ_eq ≈ 0.4002). Significant deviation from the equilibrium
    rate is an early warning signal for:
      - Gate miscalibration (thresholds drifting too conservative/permissive)
      - Adversarial pressure (attack campaign driving block rate up)
      - Healing loop failure (blocked proposals not being mutated/resolved)

    This is a passive instrument — it observes and warns but does not gate.
    No live data required to initialise. Calibration happens post-A010.

    Usage:
        monitor = ApprovalFluxMonitor()
        monitor.record("EXECUTE")
        monitor.record("BLOCK")
        report = monitor.report()
        if report["state"] == "ANOMALY":
            # alert operator
    """

    EQUILIBRIUM_RATE    = 0.60   # expected approval rate at healthy operation
                                  # (calibrate post-A010; Poole used 0.4002 in
                                  #  different domain — this is a placeholder)
    WARN_DEVIATION      = 0.20   # ±20% from equilibrium → WARNING
    ANOMALY_DEVIATION   = 0.35   # ±35% from equilibrium → ANOMALY
    MIN_WINDOW          = 20     # minimum samples before flux is meaningful

    def __init__(self, window_size: int = 100) -> None:
        self._window: List[str] = []
        self._window_size = window_size
        self._total_recorded = 0

    def record(self, decision: str) -> None:
        """Record a gate decision: 'EXECUTE', 'BLOCK', or 'KILL'."""
        self._window.append(decision)
        if len(self._window) > self._window_size:
            self._window.pop(0)
        self._total_recorded += 1

    @property
    def approval_rate(self) -> float:
        if not self._window:
            return self.EQUILIBRIUM_RATE
        return sum(1 for d in self._window if d == "EXECUTE") / len(self._window)

    def report(self) -> Dict[str, Any]:
        n = len(self._window)
        rate = self.approval_rate
        deviation = abs(rate - self.EQUILIBRIUM_RATE)

        if n < self.MIN_WINDOW:
            state = "INSUFFICIENT_DATA"
        elif deviation >= self.ANOMALY_DEVIATION:
            state = "ANOMALY"
        elif deviation >= self.WARN_DEVIATION:
            state = "WARNING"
        else:
            state = "HEALTHY"

        return {
            "state":             state,
            "approval_rate":     round(rate, 4),
            "equilibrium_rate":  self.EQUILIBRIUM_RATE,
            "deviation":         round(deviation, 4),
            "window_size":       n,
            "total_recorded":    self._total_recorded,
            "interpretation": (
                f"Gate approving {rate:.1%} of proposals "
                f"(equilibrium: {self.EQUILIBRIUM_RATE:.1%}, "
                f"deviation: {deviation:.1%})"
            ),
        }

    def reset(self) -> None:
        """Operator reset — clear window without clearing total count."""
        self._window.clear()


def run_tests() -> tuple:
    import tempfile, os
    from pathlib import Path

    passed = failed = 0
    results = []

    def t(name, fn):
        nonlocal passed, failed
        try:
            fn(); passed += 1; results.append((name,'PASS',None))
        except Exception as e:
            failed += 1; results.append((name,'FAIL',str(e)))

    # Test with a temp directory
    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir)
        chronicle = p / "chronicle.jsonl"
        db = p / "index.db"

        def write_entry(kind, data):
            import json, time
            with open(chronicle, 'a') as f:
                _flock(f)
                try:
                    f.write(json.dumps({"kind": kind, "data": data,
                                        "ts": time.time()}) + "\n")
                finally:
                    _funlock(f)

        t("index_constructs",    lambda: ChronicleIndex(chronicle, db))
        t("needs_rebuild_empty", lambda: ChronicleIndex(chronicle, db).needs_rebuild())
        t("query_returns_list",  lambda: (
            write_entry("TEST", {"v": 1}),
            ChronicleIndex(chronicle, db).rebuild(),
        ) and None or True)
        # StateSnapshot(hash, timestamp, source_seq, layers)
        import datetime as _dt
        snap = StateSnapshot(
            snapshot_hash="a"*64,
            timestamp=_dt.datetime.now(_dt.timezone.utc).isoformat(),
            source_seq=0,
            layers_included=["test"],
        )
        t("snapshot_creates",      lambda: snap)
        t("snapshot_has_dict",     lambda: isinstance(snap.to_dict(), dict))
        t("snapshot_json_works",   lambda: isinstance(snap.to_json(), str))
        idx = ChronicleIndex(chronicle, db)
        idx.rebuild()
        t("dream_journal_creates", lambda: DreamJournal(idx).get_journal())
        t("dream_journal_is_dict", lambda: isinstance(
            DreamJournal(idx).get_journal(), dict))

        # P10.5-D: Pipeline zone telemetry
        proposals = [{"confidence": 0.85}, {"confidence": 0.75}, {"confidence": 0.90}]
        mass_entry = PipelineMassEntry("LABELING", proposals, "test-sess", 1)
        t("pipeline_mass_creates",    lambda: mass_entry)
        t("pipeline_mass_has_dict",   lambda: isinstance(mass_entry.to_dict(), dict))
        t("pipeline_mass_correct",    lambda: abs(mass_entry.mean_conf - 0.8333) < 0.01)
        t("pipeline_mass_json",       lambda: isinstance(mass_entry.to_json(), str))

        # P10.5-F: Approval flux monitor
        monitor = ApprovalFluxMonitor(window_size=10)
        for _ in range(6): monitor.record("EXECUTE")
        for _ in range(4): monitor.record("BLOCK")
        report = monitor.report()
        t("flux_monitor_creates",     lambda: report)
        t("flux_monitor_has_state",   lambda: "state" in report)
        t("flux_monitor_rate_correct", lambda: abs(monitor.approval_rate - 0.6) < 0.01)
        t("flux_monitor_resets",      lambda: (monitor.reset(), len(monitor._window) == 0)[1])

    return passed, failed, results
