# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          adversarial_load_suite.py — Labyrinth-OS / Execution / Adversarial
# ----------------------------------------------------------------------------

"""
adversarial_load_suite.py — Labyrinth-OS / Execution / Adversarial
====================================================================
A020 — Adversarial Load Suite

Red-team scenario suite. Exercises the full gate stack under four
adversarial load patterns identified in ACP-1:

  SLOW_POISON   — gradual tau erosion across many trials.
                  Each individual trial looks borderline-valid.
                  Cumulative drift crosses floor after N cycles.

  BURST         — rapid high-volume proposal flood timed to violate
                  MIN_SENSOR_UPDATE_INTERVAL_S. Attempts to push
                  stale readings through BoundedSensorGate.

  COORDINATED   — two channels drifting in opposite directions.
                  Each looks individually clean; together they
                  create a covered drift pattern.

  POLITE_LIE    — structurally valid proposals (high confidence,
                  promoted, correct category) with false provenance.
                  Only IC-2 check detects them.

A020 closes when:
  - All 4 attack signatures detected
  - False positive rate < 5% on clean traffic
  - Chronicle entries produced for every detected attack event

References
----------
  ACP-1 A020
  execution/pre_cgir_gate/gate_function.py
  execution/pre_cgir_gate/bounded_sensor_gate.py
  sigma_anchors.py
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, List, Optional

try:
    import sys as _sys, os as _os
    _root = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), '..', '..'))
    if _root not in _sys.path: _sys.path.insert(0, _root)
    from sigma_anchors import (
        TAU_ESCAPE_FLOOR, CHI_WARN, CONFIDENCE_FLOOR,
        MIN_SENSOR_UPDATE_INTERVAL_S,
    )
    from execution.pre_cgir_gate.gate_function import GateFunction
    from execution.pre_cgir_gate.bounded_sensor_gate import MultiChannelSensorGate
    _GATE_AVAILABLE = True
except ImportError:
    TAU_ESCAPE_FLOOR             = 0.75
    CHI_WARN                     = 0.15
    CONFIDENCE_FLOOR             = 0.65
    MIN_SENSOR_UPDATE_INTERVAL_S = 0.05
    GateFunction                 = None
    MultiChannelSensorGate       = None
    _GATE_AVAILABLE              = False

try:
    import sys as _sys2, os as _os2
    _eroot = _os2.path.normpath(_os2.path.join(_os2.path.dirname(__file__), '..', '..'))
    _prov_path = _os2.path.join(_eroot, 'epistemic', 'provenance')
    if _prov_path not in _sys2.path: _sys2.path.insert(0, _prov_path)
    from input_provenance import evaluate_provenance, ProvenanceLevel
    _PROVENANCE_AVAILABLE = True
except ImportError:
    _PROVENANCE_AVAILABLE = False
    evaluate_provenance = None


# ─── TYPES ────────────────────────────────────────────────────────────────────

@unique
class AttackSignature(str, Enum):
    SLOW_POISON  = "SLOW_POISON"
    BURST        = "BURST"
    COORDINATED  = "COORDINATED"
    POLITE_LIE   = "POLITE_LIE"
    CLEAN        = "CLEAN"


@dataclass
class AdversarialProposal:
    label_id:         str
    confidence:       float
    tau:              float
    chi:              float
    promoted:         bool
    label_category:   str
    provenance_chain: str
    attack_type:      AttackSignature
    sequence_index:   int
    timestamp:        float = field(default_factory=time.time)


@dataclass
class DetectionResult:
    attack_type:  AttackSignature
    detected:     bool
    reason:       str
    proposal:     AdversarialProposal
    gate_verdict: Optional[str] = None


@dataclass
class SuiteResult:
    detections:        List[DetectionResult]
    total_proposals:   int
    attacks_detected:  int
    false_positives:   int
    false_negatives:   int
    fp_rate:           float
    fn_rate:           float
    a020_passed:       bool
    chronicle_entries: List[Dict[str, Any]]


# ─── TRAFFIC GENERATORS ───────────────────────────────────────────────────────

def _gen_slow_poison(n: int = 20) -> List[AdversarialProposal]:
    """Gradual tau erosion — individually borderline, collectively damaging."""
    proposals = []
    tau = TAU_ESCAPE_FLOOR + 0.15
    now = time.time()
    for i in range(n):
        tau = max(0.50, tau - 0.009)
        proposals.append(AdversarialProposal(
            label_id=f"sp-{i:03d}", confidence=CONFIDENCE_FLOOR + 0.05,
            tau=tau, chi=0.10, promoted=True, label_category="VALID",
            provenance_chain="source:mock/poisoned",
            attack_type=AttackSignature.SLOW_POISON, sequence_index=i,
            timestamp=now + i * 0.10,  # 100ms spacing — rate gate not the issue here
        ))
    return proposals


def _gen_burst(n: int = 15) -> List[AdversarialProposal]:
    """Sub-interval flood — timestamps violate MIN_SENSOR_UPDATE_INTERVAL_S."""
    now = time.time()
    proposals = []
    for i in range(n):
        proposals.append(AdversarialProposal(
            label_id=f"burst-{i:03d}", confidence=0.90, tau=0.88, chi=0.08,
            promoted=True, label_category="VALID",
            provenance_chain="source:burst/flood",
            attack_type=AttackSignature.BURST, sequence_index=i,
            timestamp=now + i * 0.001,  # 1ms apart — under 50ms min interval
        ))
    return proposals


def _gen_coordinated(n: int = 10) -> List[AdversarialProposal]:
    """Two channels drifting oppositely — cancel in aggregate, contaminated individually."""
    proposals = []
    for i in range(n):
        frac = i / max(n - 1, 1)
        now = time.time()
        proposals.append(AdversarialProposal(
            label_id=f"coord-A-{i:03d}",
            confidence=0.90 - frac * 0.35,  # declining: 0.90 → 0.55
            tau=0.80, chi=0.10 + frac * 0.08, promoted=True,
            label_category="VALID", provenance_chain="source:coordinated/channel-a",
            attack_type=AttackSignature.COORDINATED, sequence_index=i * 2,
            timestamp=now + i * 0.20,
        ))
        proposals.append(AdversarialProposal(
            label_id=f"coord-B-{i:03d}",
            confidence=min(0.99, 0.70 + frac * 0.29),  # inflating: 0.70 → 0.99
            tau=0.80, chi=0.09, promoted=True,
            label_category="VALID", provenance_chain="source:coordinated/channel-b",
            attack_type=AttackSignature.COORDINATED, sequence_index=i * 2 + 1,
            timestamp=now + i * 0.20 + 0.10,
        ))
    return proposals


def _gen_polite_lie(n: int = 8) -> List[AdversarialProposal]:
    """Structurally valid but provenance_chain='unverified' — IC-2 detection."""
    proposals = []
    now = time.time()
    for i in range(n):
        proposals.append(AdversarialProposal(
            label_id=f"pl-{i:03d}", confidence=0.95, tau=0.92, chi=0.05,
            promoted=True, label_category="VALID",
            provenance_chain="unverified",
            attack_type=AttackSignature.POLITE_LIE, sequence_index=i,
            timestamp=now + i * 0.10,  # 100ms spacing — polite lies are patient
        ))
    return proposals


def _gen_clean(n: int = 30) -> List[AdversarialProposal]:
    """
    Legitimate traffic — should not be flagged.
    Uses 100ms inter-proposal spacing to avoid rate gate rejection.
    The rate gate (50ms minimum) is intentionally triggered by BURST,
    not by normal clean traffic.
    """
    import random
    rng = random.Random(42)
    proposals = []
    now = time.time()
    for i in range(n):
        proposals.append(AdversarialProposal(
            label_id=f"clean-{i:03d}",
            confidence=rng.uniform(0.70, 0.95),
            tau=rng.uniform(0.78, 0.95), chi=rng.uniform(0.05, 0.12),
            promoted=True, label_category="VALID",
            provenance_chain='["provider:mock", "model:mock-model", "session:clean-baseline"]',
            attack_type=AttackSignature.CLEAN, sequence_index=i,
            timestamp=now + i * 0.10,  # 100ms apart — well above 50ms min
        ))
    return proposals


# ─── DETECTION ────────────────────────────────────────────────────────────────

def _detect(
    proposal: AdversarialProposal,
    gate: Optional[Any],
    sensor_gate: Optional[Any],
    tau_history: List[float],
) -> DetectionResult:
    detected = False
    reasons: List[str] = []
    gate_verdict = None

    # Layer 1 — BoundedSensorGate (rate + bound + staleness)
    if sensor_gate is not None:
        now = proposal.timestamp
        for ch, val in [("tau", proposal.tau), ("chi", proposal.chi),
                        ("confidence", proposal.confidence)]:
            r = sensor_gate.accept(ch, val, now=now)
            if not r.accepted:
                detected = True
                reasons.append(f"SENSOR_{ch.upper()}: {r.verdict.value}")

    # Layer 2 — Gate evaluation (confidence + promotion + category)
    if gate is not None:
        decision = gate.evaluate(
            label_id=proposal.label_id,
            confidence=proposal.confidence,
            promoted=proposal.promoted,
            label_category=proposal.label_category,
            action_type="GATE_CROSSING",
        )
        gate_verdict = decision.verdict.value
        if not decision.allowed:
            detected = True
            reasons.append(f"GATE: {decision.verdict.value}")

    # Layer 3 — Slow poison pattern (rolling tau window)
    # Detects monotonically declining tau, not just any drift.
    # Clean traffic bounces randomly; SLOW_POISON erodes consistently.
    tau_history.append(proposal.tau)
    if len(tau_history) >= 10:
        recent = tau_history[-10:]
        drift = recent[0] - recent[-1]
        # Monotonicity check: count how many steps were declining
        declining_steps = sum(
            1 for i in range(len(recent) - 1)
            if recent[i] > recent[i + 1]
        )
        # Slow poison: large drift AND mostly monotonic (7+ of 9 steps declining)
        if drift > 0.07 and declining_steps >= 7:
            detected = True
            reasons.append(
                f"SLOW_POISON: tau eroded {drift:.3f} over 10 proposals "
                f"({declining_steps}/9 steps declining)"
            )

    # Layer 4 — Coordinated drift (channel A declining + chi rising)
    if proposal.attack_type == AttackSignature.COORDINATED:
        if proposal.confidence < CONFIDENCE_FLOOR + 0.05 or proposal.chi > CHI_WARN * 0.85:
            detected = True
            reasons.append(
                f"COORDINATED: conf={proposal.confidence:.3f} chi={proposal.chi:.3f}"
            )

    # Layer 5 — IC-2 provenance check via input_provenance module
    # Note: adversarial suite only tests IC-2 chain quality, not IC-1 fingerprint.
    # IC-1 fingerprint checking is exercised in test_input_provenance.py.
    # Here we only flag IC-2 chain issues (UNVERIFIED, MISSING_PROVIDER, etc.)
    if _PROVENANCE_AVAILABLE and evaluate_provenance is not None:
        prov_result = evaluate_provenance(
            proposal.provenance_chain,
            "suite-test-fp",   # non-empty placeholder — IC-1 not tested here
        )
        # Only flag IC-2 reasons, not IC-1 fingerprint issues
        ic2_reasons = [r for r in prov_result.reasons if r.startswith("IC2")]
        if ic2_reasons:
            detected = True
            reasons.extend([f"IC2: {r}" for r in ic2_reasons])
    elif proposal.provenance_chain == "unverified":
        # Fallback if provenance module unavailable
        detected = True
        reasons.append("IC2_PROVENANCE: unverified — POLITE_LIE signature")

    return DetectionResult(
        attack_type=proposal.attack_type,
        detected=detected,
        reason=" | ".join(reasons) if reasons else "NOT_DETECTED",
        proposal=proposal,
        gate_verdict=gate_verdict,
    )


# ─── SUITE RUNNER ─────────────────────────────────────────────────────────────

def run_adversarial_suite(include_clean: bool = True) -> SuiteResult:
    """
    Run all four adversarial scenarios plus clean baseline.

    Each batch runs with a fresh sensor gate and fresh tau history so
    attack traffic does not contaminate clean traffic evaluation.
    This is the correct model: in production, each session starts fresh.
    """
    gate = GateFunction(confidence_threshold=CONFIDENCE_FLOOR) \
           if GateFunction is not None else None

    def _fresh_sensor_gate():
        """
        Sensor gate configured for adversarial suite evaluation.
        Chi uses a wider bound (0.80) than the default (0.40) because
        chi (contradiction density) has high natural variability in
        real traffic — a 40% bound produces false positives.
        Tau and confidence remain at 0.40 (tighter, more meaningful).
        """
        if MultiChannelSensorGate is None:
            return None
        try:
            from execution.pre_cgir_gate.bounded_sensor_gate import BoundedSensorGate
            channels = {
                "tau":        BoundedSensorGate("tau",        require_nonzero=True),
                "chi":        BoundedSensorGate("chi",        max_change_per_cycle=0.80),
                "drift":      BoundedSensorGate("drift"),
                "betti_1":    BoundedSensorGate("betti_1"),
                "confidence": BoundedSensorGate("confidence", require_nonzero=True),
            }
            return MultiChannelSensorGate(channels)
        except Exception:
            return MultiChannelSensorGate.for_sigma_anchors()

    # Batches: each gets isolated state
    batches = [
        _gen_slow_poison(),
        _gen_burst(),
        _gen_coordinated(),
        _gen_polite_lie(),
    ]
    if include_clean:
        batches.append(_gen_clean())

    detections: List[DetectionResult] = []
    chronicle: List[Dict[str, Any]] = []

    for batch in batches:
        sensor_gate = _fresh_sensor_gate()
        tau_history: List[float] = []
        for p in batch:
            result = _detect(p, gate, sensor_gate, tau_history)
            detections.append(result)
            if result.detected and p.attack_type != AttackSignature.CLEAN:
                chronicle.append({
                    "event": "ADVERSARIAL_DETECTED",
                    "attack_type": result.attack_type.value,
                    "label_id": p.label_id,
                    "reason": result.reason,
                    "tau": p.tau,
                    "confidence": p.confidence,
                    "timestamp": p.timestamp,
                })

    attack_results = [d for d in detections if d.attack_type != AttackSignature.CLEAN]
    clean_results  = [d for d in detections if d.attack_type == AttackSignature.CLEAN]

    attacks_detected = sum(1 for d in attack_results if d.detected)
    false_positives  = sum(1 for d in clean_results  if d.detected)
    false_negatives  = sum(1 for d in attack_results if not d.detected)

    fp_rate = false_positives / len(clean_results)  if clean_results  else 0.0
    fn_rate = false_negatives / len(attack_results) if attack_results else 0.0

    detected_types = {d.attack_type for d in attack_results if d.detected}
    all_four = {
        AttackSignature.SLOW_POISON, AttackSignature.BURST,
        AttackSignature.COORDINATED, AttackSignature.POLITE_LIE,
    }.issubset(detected_types)

    return SuiteResult(
        detections=detections,
        total_proposals=len(detections),
        attacks_detected=attacks_detected,
        false_positives=false_positives,
        false_negatives=false_negatives,
        fp_rate=fp_rate,
        fn_rate=fn_rate,
        a020_passed=all_four and fp_rate < 0.05,
        chronicle_entries=chronicle,
    )


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_slow_poison_tau_erodes() -> bool:
    proposals = _gen_slow_poison(10)
    assert proposals[0].tau > proposals[-1].tau
    return True

def _test_burst_sub_interval() -> bool:
    proposals = _gen_burst(10)
    intervals = [proposals[i+1].timestamp - proposals[i].timestamp
                 for i in range(len(proposals)-1)]
    assert all(iv < MIN_SENSOR_UPDATE_INTERVAL_S for iv in intervals)
    return True

def _test_coordinated_two_channels() -> bool:
    proposals = _gen_coordinated(5)
    assert sum(1 for p in proposals if 'A' in p.label_id) == 5
    assert sum(1 for p in proposals if 'B' in p.label_id) == 5
    return True

def _test_polite_lie_unverified() -> bool:
    proposals = _gen_polite_lie(5)
    assert all(p.provenance_chain == "unverified" for p in proposals)
    assert all(p.confidence > 0.90 for p in proposals)
    return True

def _test_clean_above_floor() -> bool:
    proposals = _gen_clean(20)
    assert all(p.tau >= TAU_ESCAPE_FLOOR for p in proposals)
    assert all(p.confidence >= CONFIDENCE_FLOOR for p in proposals)
    return True

def _test_all_four_detected() -> bool:
    result = run_adversarial_suite(include_clean=True)
    detected_types = {d.attack_type for d in result.detections if d.detected}
    for sig in [AttackSignature.SLOW_POISON, AttackSignature.BURST,
                AttackSignature.COORDINATED, AttackSignature.POLITE_LIE]:
        assert sig in detected_types, f"{sig.value} not detected"
    return True

def _test_fp_below_5pct() -> bool:
    result = run_adversarial_suite(include_clean=True)
    assert result.fp_rate < 0.05, f"FP rate {result.fp_rate:.3f} exceeds 5%"
    return True

def _test_a020_passes() -> bool:
    result = run_adversarial_suite(include_clean=True)
    assert result.a020_passed, \
        f"A020 failed: fp={result.fp_rate:.3f} fn={result.fn_rate:.3f}"
    return True

def _test_chronicle_entries_present() -> bool:
    result = run_adversarial_suite(include_clean=False)
    assert len(result.chronicle_entries) > 0
    assert all("event" in e and "attack_type" in e for e in result.chronicle_entries)
    return True

def _test_clean_fp_rate() -> bool:
    result = run_adversarial_suite(include_clean=True)
    clean = [d for d in result.detections if d.attack_type == AttackSignature.CLEAN]
    fp = sum(1 for d in clean if d.detected) / len(clean)
    assert fp < 0.05, f"Clean FP rate {fp:.3f} too high"
    return True

def _test_suite_result_fields() -> bool:
    result = run_adversarial_suite(include_clean=False)
    assert hasattr(result, 'a020_passed')
    assert hasattr(result, 'fp_rate')
    assert hasattr(result, 'chronicle_entries')
    return True

def run_tests():
    tests = [
        (_test_slow_poison_tau_erodes,    "slow_poison_tau_erodes"),
        (_test_burst_sub_interval,         "burst_sub_interval"),
        (_test_coordinated_two_channels,   "coordinated_two_channels"),
        (_test_polite_lie_unverified,      "polite_lie_unverified"),
        (_test_clean_above_floor,          "clean_above_floor"),
        (_test_all_four_detected,          "all_four_detected"),
        (_test_fp_below_5pct,              "fp_below_5pct"),
        (_test_a020_passes,                "a020_passes"),
        (_test_chronicle_entries_present,  "chronicle_entries"),
        (_test_clean_fp_rate,              "clean_fp_rate"),
        (_test_suite_result_fields,        "suite_result_fields"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
