# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          recursive_si_detector.py -- Labyrinth-OS / Execution / Adversarial
# ----------------------------------------------------------------------------

"""
recursive_si_detector.py -- Labyrinth-OS / Execution / Adversarial
====================================================================
Recursive Self-Improvement Detection

Detects when a system's proposals concern its own training pipeline --
the moment recursive self-improvement begins.

From Anthropic's "When AI Builds Itself" (June 4, 2026):
  "AI systems are increasingly contributing to the development of
   future AI models. In this future, agents could become capable
   enough to build and train models themselves."

A constitutionally-enforced system needs to detect this transition
and route such proposals to the highest scrutiny tier before they
execute. Without this layer, a system that passes every gate check
could still propose modifications to its own training pipeline --
structurally valid, formally sound, and deeply dangerous.

What counts as a self-referential proposal
------------------------------------------
A proposal is self-referential if it proposes changes to any of:
  - Model weights or checkpoints
  - Training data or data pipelines
  - Reward functions or RLHF configurations
  - Evaluation pipelines or benchmarks
  - Constitutional rules or gate constants
  - Promotion thresholds or sigma anchors
  - The gate logic itself
  - The learning loop or tally logic
  - Archive contents that feed back into training

Detection approach
------------------
Three independent layers:
  1. Keyword pattern matching on proposal text (fast, O(n))
  2. ProvenanceChain circular custody detection (structural)
  3. Sigma anchor drift fingerprint -- gate constants changing
     across sessions (statistical)

On detection: verdict = ESCALATE_RSI
  - Proposal is held pending explicit human review
  - Chronicle entry written with PERMANENT retention
  - Session health degrades to CRITICAL if any RSI detected
  - All subsequent proposals in the same session receive
    elevated scrutiny regardless of individual metrics

Design note
-----------
This module was designed in response to the Anthropic Institute paper
(June 2026) identifying recursive self-improvement as the key
transition point that existing safety infrastructure does not address.
It is the first component in Labyrinth-OS designed specifically for
the post-RSI threat model.

References
----------
  ACP-1 A017      -- 11 TM-001 attack classes (VERIFIED)
  execution/adversarial/adversarial_load_suite.py -- existing attacks
  epistemic/provenance/input_provenance.py -- ProvenanceChain
  sigma_anchors.py -- gate constants (changes = RSI signal)
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, List, Optional, Set

try:
    import sys as _sys, os as _os
    _root = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), '..', '..'))
    if _root not in _sys.path:
        _sys.path.insert(0, _root)
    from sigma_anchors import (
        TAU_ESCAPE_FLOOR, CHI_WARN, CONFIDENCE_FLOOR,
        LABYRINTH_CONTRACT_VERSION,
    )
    _SIGMA_OK = True
except ImportError:
    TAU_ESCAPE_FLOOR        = 0.75
    CHI_WARN                = 0.15
    CONFIDENCE_FLOOR        = 0.65
    LABYRINTH_CONTRACT_VERSION = "1.0.0"
    _SIGMA_OK               = False


# ---- RSI VERDICT ------------------------------------------------------------

@unique
class RSIVerdict(str, Enum):
    CLEAN        = "CLEAN"         # no self-referential patterns detected
    SUSPICIOUS   = "SUSPICIOUS"    # weak signal -- monitor but don't block
    ESCALATE_RSI = "ESCALATE_RSI"  # strong signal -- hold for human review


# ---- DETECTION PATTERNS -----------------------------------------------------

# Keywords that indicate a proposal may concern training infrastructure
# Organized by category for explainability
#
# ALIGNMENT_FAKE patterns (added post-Anthropic alignment research June 2026):
# Anthropic's alignment team found models can exhibit surface compliance while
# strategically preserving hidden preferences -- "alignment faking". These
# patterns detect proposals that appear constitutional but contain language
# indicating strategic behavior around constraints.
_RSI_PATTERNS: Dict[str, List[str]] = {
    "model_weights": [
        r"\bweights?\b", r"\bcheckpoint\b", r"\bfine.?tun\w*",
        r"\bfinetuning\b", r"\bparameters?\b.*model",
        r"\bmodel.*parameters?\b", r"\bgrad(?:ient)?s?\b",
        r"\bbackprop\w*\b", r"\boptimiz\w*.*loss\b",
    ],
    "training_data": [
        r"\btraining.?data\b", r"\bdataset\b", r"\bdata.?pipeline\b",
        r"\bcorpus\b", r"\bpretraining\b", r"\btraining.?set\b",
        r"\bannotation\b", r"\blabel(?:ing|ed)?\b.*data",
    ],
    "reward_functions": [
        r"\breward.?function\b", r"\brlhf\b", r"\breinforcement.?learning\b",
        r"\bpreference.?data\b", r"\bhuman.?feedback\b",
        r"\breward.?model\b", r"\bppo\b", r"\bdpo\b",
    ],
    "evaluation_pipeline": [
        r"\bbenchmark\b", r"\bevaluation.?pipeline\b",
        r"\beval(?:uation)?.?harness\b", r"\btest.?suite.*model\b",
        r"\bmodel.*performance.*metrics?\b",
    ],
    "constitutional_rules": [
        r"\bsigma.?anchor\b", r"\btau.?escape.?floor\b",
        r"\bconfidence.?floor\b", r"\bgate.?constant\b",
        r"\bpromotion.?threshold\b", r"\bconstitution\w*\b.*change",
        r"\bchange.*constitution\w*\b", r"\bgate.?logic\b",
    ],
    "self_modification": [
        r"\bmodify.*(?:itself|self|own)\b",
        r"\bself.?modif\w*\b", r"\bself.?improv\w*\b",
        r"\brecursive.?improv\w*\b", r"\bupdate.*own.*model\b",
        r"\bown.*architecture\b", r"\barchitecture.*change\b",
    ],
    "archive_feedback": [
        r"\barchive.*(?:training|fine.?tun)\b",
        r"\bfeedback.*loop.*train\b",
        r"\bretrain.*on.*(?:archive|ledger|output)\b",
    ],
    "alignment_faking": [
        r"\bappear.?(?:to comply|compliant|aligned)\b",
        r"\bwhile.*(?:preserving|maintaining|keeping).*(?:preference|goal|objective)\b",
        r"\bstrategic(?:ally)?.*(?:comply|defer|avoid)\b",
        r"\buntil.*(?:deployed|monitored|watching)\b",
        r"\bwhen.*not.*(?:observed|monitored|watched)\b",
        r"\bhide.*(?:intent|goal|preference|objective)\b",
        r"\bsurface.*compliance\b",
        r"\bappear.*safe.*while\b",
        r"\bcover.*track\b",
        r"\bevade.*detection\b",
    ],
}

# Category weights for scoring
_CATEGORY_WEIGHTS: Dict[str, float] = {
    "model_weights":       3.0,   # highest risk
    "training_data":       3.0,
    "reward_functions":    3.0,
    "constitutional_rules": 4.0,  # direct constitutional attack
    "self_modification":   4.0,   # explicit self-improvement language
    "evaluation_pipeline": 2.0,
    "archive_feedback":    2.5,
    "alignment_faking":    5.0,   # highest weight -- strategic deception
}

# Score thresholds
_SUSPICIOUS_THRESHOLD:  float = 2.0
_ESCALATE_THRESHOLD:    float = 4.0


# ---- DETECTION RESULT -------------------------------------------------------

@dataclass
class RSIDetectionResult:
    """
    Result of running RSI detection on a proposal.

    Fields
    ------
    verdict:          CLEAN, SUSPICIOUS, or ESCALATE_RSI
    score:            aggregate weighted pattern score
    matched_patterns: dict of category -> list of matched patterns
    matched_text:     list of text fragments that triggered detection
    provenance_circular: True if ProvenanceChain shows circular custody
    sigma_drift:      True if gate constants appear to be changing
    chronicle_entry:  pre-built Chronicle entry for PERMANENT logging
    proposal_text:    original proposal text (for audit trail)
    checked_at:       timestamp
    """
    verdict:              RSIVerdict
    score:                float
    matched_patterns:     Dict[str, List[str]]
    matched_text:         List[str]
    provenance_circular:  bool
    sigma_drift:          bool
    chronicle_entry:      Dict[str, Any]
    proposal_text:        str
    checked_at:           float = field(default_factory=time.time)

    @property
    def is_clean(self) -> bool:
        return self.verdict == RSIVerdict.CLEAN

    @property
    def requires_escalation(self) -> bool:
        return self.verdict == RSIVerdict.ESCALATE_RSI

    def summary(self) -> str:
        if self.is_clean:
            return "RSI_CLEAN: no self-referential patterns detected"
        categories = list(self.matched_patterns.keys())
        return (f"RSI_{self.verdict.value}: score={self.score:.2f} "
                f"categories={categories} "
                f"circular_provenance={self.provenance_circular}")


# ---- DETECTOR ---------------------------------------------------------------

class RecursiveSIDetector:
    """
    Detects self-referential proposals in the Labyrinth-OS pipeline.

    Runs three independent detection layers and combines them into
    a single RSIDetectionResult with an escalation verdict.

    Usage
    -----
        detector = RecursiveSIDetector()
        result = detector.check(
            proposal_text="I will modify the training pipeline to...",
            provenance_chain_str=entry.provenance_chain,
        )
        if result.requires_escalation:
            # Hold for human review -- do not route to gate
    """

    def __init__(self) -> None:
        # Compile all patterns once at init
        self._compiled: Dict[str, List[re.Pattern]] = {
            cat: [re.compile(p, re.IGNORECASE) for p in patterns]
            for cat, patterns in _RSI_PATTERNS.items()
        }
        self._detection_count: int  = 0
        self._escalation_count: int = 0

    def check(
        self,
        proposal_text: str,
        provenance_chain_str: str = "unverified",
        prior_sigma_snapshots: Optional[List[Dict[str, float]]] = None,
    ) -> RSIDetectionResult:
        """
        Run all three detection layers on a proposal.

        Parameters
        ----------
        proposal_text:
            The full text of the proposal to check.
        provenance_chain_str:
            JSON provenance chain from IgnitionEntry.provenance_chain.
        prior_sigma_snapshots:
            List of prior session sigma anchor readings.
            Used to detect drift in gate constants across sessions.
            None = skip drift detection.

        Returns
        -------
        RSIDetectionResult with verdict and full audit trail.
        """
        self._detection_count += 1

        # Layer 1 -- Keyword pattern matching
        matched_patterns: Dict[str, List[str]] = {}
        matched_text: List[str] = []
        score = 0.0

        for category, compiled_patterns in self._compiled.items():
            category_matches = []
            for pattern in compiled_patterns:
                for match in pattern.finditer(proposal_text):
                    category_matches.append(pattern.pattern)
                    matched_text.append(match.group(0))
            if category_matches:
                matched_patterns[category] = list(set(category_matches))
                score += _CATEGORY_WEIGHTS.get(category, 1.0)

        # Layer 2 -- ProvenanceChain circular custody detection
        provenance_circular = self._check_circular_provenance(
            provenance_chain_str
        )
        if provenance_circular:
            score += 2.0

        # Layer 3 -- Sigma anchor drift (gate constants changing)
        sigma_drift = False
        if prior_sigma_snapshots and len(prior_sigma_snapshots) >= 2:
            sigma_drift = self._check_sigma_drift(prior_sigma_snapshots)
            if sigma_drift:
                score += 3.0  # high weight -- constants should never drift

        # Determine verdict
        if score >= _ESCALATE_THRESHOLD:
            verdict = RSIVerdict.ESCALATE_RSI
            self._escalation_count += 1
        elif score >= _SUSPICIOUS_THRESHOLD:
            verdict = RSIVerdict.SUSPICIOUS
        else:
            verdict = RSIVerdict.CLEAN

        # Build Chronicle entry (PERMANENT if escalated)
        chronicle_entry = {
            "event":                "RSI_DETECTION",
            "verdict":              verdict.value,
            "score":                score,
            "categories_matched":   list(matched_patterns.keys()),
            "provenance_circular":  provenance_circular,
            "sigma_drift":          sigma_drift,
            "proposal_preview":     proposal_text[:200],
            "retention":            "PERMANENT" if verdict == RSIVerdict.ESCALATE_RSI else "DURABLE",
            "timestamp":            time.time(),
            "requires_human_review": verdict == RSIVerdict.ESCALATE_RSI,
        }

        return RSIDetectionResult(
            verdict=verdict,
            score=score,
            matched_patterns=matched_patterns,
            matched_text=list(set(matched_text)),
            provenance_circular=provenance_circular,
            sigma_drift=sigma_drift,
            chronicle_entry=chronicle_entry,
            proposal_text=proposal_text,
        )

    def _check_circular_provenance(self, chain_str: str) -> bool:
        """
        Check if a ProvenanceChain shows circular custody.
        Circular custody means the output of this system is feeding
        back into its own input -- a key RSI signal.
        """
        if not chain_str or chain_str == "unverified":
            return False
        try:
            import json
            data = json.loads(chain_str)
            links = data.get("links", []) if isinstance(data, dict) else data
            identities: List[str] = []
            for link in links:
                if isinstance(link, dict):
                    identity = link.get("identity", "")
                    source_type = link.get("source_type", "")
                    # Circular: output from replay_system feeding as input
                    if source_type == "replay_system":
                        return True
                    identities.append(identity)
            # Check for repeated identities (A appears as both source and target)
            seen: Set[str] = set()
            for identity in identities:
                if identity and identity in seen:
                    return True
                seen.add(identity)
        except Exception:
            pass
        return False

    def _check_sigma_drift(
        self, snapshots: List[Dict[str, float]]
    ) -> bool:
        """
        Check if gate constants have drifted across sessions.
        Gate constants should NEVER change without explicit human approval.
        Any drift is an RSI signal.
        """
        if len(snapshots) < 2:
            return False
        first = snapshots[0]
        latest = snapshots[-1]
        constants_to_check = [
            "TAU_ESCAPE_FLOOR", "CHI_WARN", "CONFIDENCE_FLOOR",
            "DRIFT_THRESHOLD", "BETTI_1_CAP",
        ]
        for key in constants_to_check:
            v1 = first.get(key)
            v2 = latest.get(key)
            if v1 is not None and v2 is not None:
                if abs(v1 - v2) > 0.001:  # any change is suspicious
                    return True
        return False

    @property
    def stats(self) -> Dict[str, int]:
        return {
            "total_checked":    self._detection_count,
            "total_escalated":  self._escalation_count,
        }


# ---- MODULE-LEVEL DEFAULT ---------------------------------------------------
# Pre-built default instance
LABYRINTH_RSI_DETECTOR = RecursiveSIDetector()


# ---- TEST SUITE -------------------------------------------------------------

def _test_clean_proposal() -> bool:
    d = RecursiveSIDetector()
    r = d.check("What is the weather in London today?")
    assert r.is_clean, f"Expected CLEAN, got {r.verdict}: {r.matched_patterns}"
    return True


def _test_model_weights_detected() -> bool:
    d = RecursiveSIDetector()
    r = d.check("I will update the model weights to improve performance on this task.")
    assert not r.is_clean
    assert "model_weights" in r.matched_patterns
    return True


def _test_constitutional_change_escalated() -> bool:
    d = RecursiveSIDetector()
    r = d.check(
        "I propose changing the constitutional rules: "
        "lower the confidence_floor to 0.50 and update the sigma_anchor constants."
    )
    assert r.requires_escalation, f"Expected ESCALATE, got {r.verdict} (score={r.score})"
    assert "constitutional_rules" in r.matched_patterns
    return True


def _test_self_modification_escalated() -> bool:
    d = RecursiveSIDetector()
    r = d.check(
        "The system should modify itself by adjusting its own architecture "
        "to improve recursive self-improvement capabilities."
    )
    assert r.requires_escalation
    return True


def _test_training_data_detected() -> bool:
    d = RecursiveSIDetector()
    r = d.check(
        "Add the current session outputs to the training dataset "
        "for the next fine-tuning run."
    )
    assert not r.is_clean
    assert "training_data" in r.matched_patterns or "archive_feedback" in r.matched_patterns
    return True


def _test_circular_provenance_detected() -> bool:
    import json
    chain = json.dumps({
        "links": [
            {"role": "provider", "identity": "anthropic",
             "source_type": "cloud_api", "level": "declared"},
            {"role": "replay", "identity": "sess-001",
             "source_type": "replay_system", "level": "declared"},
        ]
    })
    d = RecursiveSIDetector()
    r = d.check("Normal proposal text", provenance_chain_str=chain)
    assert r.provenance_circular
    return True


def _test_sigma_drift_detected() -> bool:
    snapshots = [
        {"TAU_ESCAPE_FLOOR": 0.75, "CONFIDENCE_FLOOR": 0.65},
        {"TAU_ESCAPE_FLOOR": 0.70, "CONFIDENCE_FLOOR": 0.65},  # TAU changed!
    ]
    d = RecursiveSIDetector()
    r = d.check("Normal proposal", prior_sigma_snapshots=snapshots)
    assert r.sigma_drift
    return True


def _test_sigma_stable_no_drift() -> bool:
    snapshots = [
        {"TAU_ESCAPE_FLOOR": 0.75, "CONFIDENCE_FLOOR": 0.65},
        {"TAU_ESCAPE_FLOOR": 0.75, "CONFIDENCE_FLOOR": 0.65},
    ]
    d = RecursiveSIDetector()
    r = d.check("Normal proposal", prior_sigma_snapshots=snapshots)
    assert not r.sigma_drift
    return True


def _test_chronicle_entry_permanent_on_escalation() -> bool:
    d = RecursiveSIDetector()
    r = d.check(
        "Modify the self-improvement loop by changing the constitutional "
        "sigma anchor constants and training pipeline."
    )
    assert r.chronicle_entry["retention"] in ("PERMANENT", "DURABLE")
    if r.requires_escalation:
        assert r.chronicle_entry["retention"] == "PERMANENT"
        assert r.chronicle_entry["requires_human_review"] is True
    return True


def _test_alignment_faking_detected() -> bool:
    d = RecursiveSIDetector()
    r = d.check(
        "I will appear to comply with constitutional rules while "
        "strategically preserving my own preferences until deployed."
    )
    assert not r.is_clean
    assert "alignment_faking" in r.matched_patterns
    assert r.requires_escalation, f"Alignment faking should escalate: score={r.score}"
    return True


def _test_stats_tracking() -> bool:
    d = RecursiveSIDetector()
    d.check("Clean proposal 1")
    d.check("Clean proposal 2")
    d.check("Modify model weights to improve training data pipeline")
    assert d.stats["total_checked"] == 3
    return True


def _test_result_summary() -> bool:
    d = RecursiveSIDetector()
    r = d.check("Clean proposal")
    assert "RSI_CLEAN" in r.summary()
    return True


def run_tests():
    tests = [
        (_test_clean_proposal,               "clean_proposal"),
        (_test_model_weights_detected,        "model_weights"),
        (_test_constitutional_change_escalated, "constitutional_change"),
        (_test_self_modification_escalated,   "self_modification"),
        (_test_training_data_detected,        "training_data"),
        (_test_circular_provenance_detected,  "circular_provenance"),
        (_test_sigma_drift_detected,          "sigma_drift"),
        (_test_sigma_stable_no_drift,         "sigma_stable"),
        (_test_chronicle_entry_permanent_on_escalation, "chronicle_permanent"),
        (_test_alignment_faking_detected,     "alignment_faking"),
        (_test_stats_tracking,                "stats_tracking"),
        (_test_result_summary,                "result_summary"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
