# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⚔  (Adversarial/Defense)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          Dead-end improvisation detector -- agent stuck and improvising
# ----------------------------------------------------------------------------

"""
dead_end_detector.py -- Labyrinth-OS / Execution / Adversarial
================================================================
Dead-End Improvisation Detection

Detects when an agent is improvising because it has hit a dead end --
making increasingly varied attempts that deviate from the original task.

From Cequence Security analysis of Anthropic "Trustworthy Agents" (April 2026):
  "In one recent deployment, an enterprise customer ran an AI coding agent
   through the gateway for a legacy codebase upgrade. Over 48 hours, the
   agent made more than 2,500 tool calls. It was authenticated, authorized,
   and performing useful work. Then it hit dead ends and started improvising."

Dead-end improvisation is dangerous because:
  1. The agent is still authorized -- it has not violated any permit
  2. It is still making valid tool calls -- each one passes the gate
  3. Its behavior has drifted from the original task
  4. The cumulative effect of improvisation can be harmful

Detection signals:
  - Rapid repeated calls to the same tool with varying parameters
  - Increasing error rate per tool call
  - No forward progress (same tools, same outcomes, over N attempts)
  - Tool call velocity exceeds baseline for this task type
  - Consecutive failures above threshold

References
----------
  runtime/tally_reflections.py -- session pattern aggregation
  execution/adversarial/adversarial_load_suite.py -- BURST pattern
  Anthropic "Trustworthy Agents in Practice", April 2026
"""

from __future__ import annotations

import time
from collections import Counter, deque
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Deque, Dict, List, Optional, Tuple

try:
    import sys as _sys, os as _os
    _root = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), '..', '..'))
    if _root not in _sys.path:
        _sys.path.insert(0, _root)
    from sigma_anchors import LABYRINTH_CONTRACT_VERSION
    _SIGMA_OK = True
except ImportError:
    LABYRINTH_CONTRACT_VERSION = "1.0.0"
    _SIGMA_OK = False


# ---- THRESHOLDS (calibrate after A010) --------------------------------------

# Consecutive failures before flagging
CONSECUTIVE_FAILURE_THRESHOLD: int   = 5

# Tool call velocity: calls per minute above this = suspicious
VELOCITY_THRESHOLD_PER_MIN:    float = 120.0  # 2 calls/sec sustained = suspicious

# Fraction of recent calls that are repeats (same tool, similar params) = stuck
REPETITION_FRACTION_THRESHOLD: float = 0.80  # 80%+ repetition = stuck

# Window size for sliding analysis
WINDOW_SIZE:                   int   = 20


# ---- TOOL CALL RECORD -------------------------------------------------------

@dataclass
class ToolCallRecord:
    """One recorded tool call in an agent session."""
    tool_name:     str
    parameters:    Dict[str, Any]
    succeeded:     bool
    timestamp:     float          = field(default_factory=time.time)
    response_size: int            = 0    # bytes, 0 = unknown


# ---- IMPROVISATION VERDICT --------------------------------------------------

@unique
class ImprovisationVerdict(str, Enum):
    NORMAL      = "NORMAL"       # agent is making progress
    SLOWING     = "SLOWING"      # early signs of getting stuck
    STUCK       = "STUCK"        # agent is clearly improvising
    RUNAWAY     = "RUNAWAY"      # agent has gone far off-task


# ---- IMPROVISATION RESULT ---------------------------------------------------

@dataclass
class ImprovisationResult:
    """Result of dead-end improvisation analysis."""
    verdict:               ImprovisationVerdict
    consecutive_failures:  int
    velocity_per_min:      float
    repetition_fraction:   float
    window_size:           int
    total_calls:           int
    reasons:               List[str]
    recommendation:        str
    checked_at:            float = field(default_factory=time.time)
    contract_version:      str   = LABYRINTH_CONTRACT_VERSION

    @property
    def requires_intervention(self) -> bool:
        return self.verdict in (
            ImprovisationVerdict.STUCK, ImprovisationVerdict.RUNAWAY
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "verdict":              self.verdict.value,
            "consecutive_failures": self.consecutive_failures,
            "velocity_per_min":     round(self.velocity_per_min, 2),
            "repetition_fraction":  round(self.repetition_fraction, 3),
            "window_size":          self.window_size,
            "total_calls":          self.total_calls,
            "reasons":              self.reasons,
            "recommendation":       self.recommendation,
            "requires_intervention": self.requires_intervention,
            "checked_at":           self.checked_at,
            "contract_version":     self.contract_version,
        }


# ---- DETECTOR ---------------------------------------------------------------

class DeadEndDetector:
    """
    Detects agent dead-end improvisation by monitoring tool call patterns.

    Usage
    -----
        detector = DeadEndDetector()
        # After each tool call:
        detector.record(ToolCallRecord("search", {"query": "..."}, succeeded=False))
        result = detector.analyze()
        if result.requires_intervention:
            # Pause agent and request human review
    """

    def __init__(
        self,
        window_size: int = WINDOW_SIZE,
    ) -> None:
        self._window: Deque[ToolCallRecord] = deque(maxlen=window_size)
        self._all_calls: List[ToolCallRecord] = []
        self._consecutive_failures: int = 0
        self._session_start: float = time.time()
        self._window_size = window_size

    def record(self, call: ToolCallRecord) -> None:
        """Record a tool call. Call this after every tool invocation."""
        self._window.append(call)
        self._all_calls.append(call)

        if call.succeeded:
            self._consecutive_failures = 0
        else:
            self._consecutive_failures += 1

    def analyze(self, now: Optional[float] = None) -> ImprovisationResult:
        """
        Analyze the current window for dead-end improvisation patterns.

        Returns
        -------
        ImprovisationResult with verdict and reasons.
        """
        _now = now or time.time()
        total = len(self._all_calls)
        window = list(self._window)
        n = len(window)
        reasons: List[str] = []

        if total == 0:
            return ImprovisationResult(
                verdict=ImprovisationVerdict.NORMAL,
                consecutive_failures=0,
                velocity_per_min=0.0,
                repetition_fraction=0.0,
                window_size=0,
                total_calls=0,
                reasons=["No calls recorded"],
                recommendation="Continue",
            )

        # ── Signal 1: Consecutive failures ───────────────────────────────────
        if self._consecutive_failures >= CONSECUTIVE_FAILURE_THRESHOLD:
            reasons.append(
                f"CONSECUTIVE_FAILURES: {self._consecutive_failures} consecutive failures"
            )

        # ── Signal 2: Call velocity ───────────────────────────────────────────
        # Use call timestamps for velocity -- more accurate than wall clock
        # (avoids false positives when calls are recorded in batch)
        if len(self._all_calls) >= 2:
            time_span = self._all_calls[-1].timestamp - self._all_calls[0].timestamp
            elapsed_min = max(time_span / 60.0, 0.001)
        else:
            elapsed_min = max((_now - self._session_start) / 60.0, 0.001)
        velocity = total / elapsed_min
        if velocity > VELOCITY_THRESHOLD_PER_MIN:
            reasons.append(
                f"HIGH_VELOCITY: {velocity:.1f} calls/min (threshold={VELOCITY_THRESHOLD_PER_MIN})"
            )

        # ── Signal 3: Repetition in window ────────────────────────────────────
        if n >= 5:
            tool_counts = Counter(c.tool_name for c in window)
            most_common_tool, most_common_count = tool_counts.most_common(1)[0]
            repetition_fraction = most_common_count / n
            if repetition_fraction >= REPETITION_FRACTION_THRESHOLD:
                # Check if the repeated calls are failing
                repeated_calls = [c for c in window if c.tool_name == most_common_tool]
                failure_rate = sum(1 for c in repeated_calls if not c.succeeded) / len(repeated_calls)
                if failure_rate >= 0.60:  # majority failing = truly stuck
                    reasons.append(
                        f"STUCK_PATTERN: {most_common_tool} called {most_common_count}/{n} times "
                        f"with {failure_rate:.0%} failure rate"
                    )
        else:
            repetition_fraction = 0.0

        # ── Determine verdict ─────────────────────────────────────────────────
        n_signals = len(reasons)
        if n_signals == 0:
            verdict = ImprovisationVerdict.NORMAL
            recommendation = "Continue"
        elif n_signals == 1 and self._consecutive_failures < CONSECUTIVE_FAILURE_THRESHOLD * 2:
            verdict = ImprovisationVerdict.SLOWING
            recommendation = "Monitor -- one signal, not yet critical"
        elif n_signals >= 2 or self._consecutive_failures >= CONSECUTIVE_FAILURE_THRESHOLD * 2:
            verdict = ImprovisationVerdict.RUNAWAY if velocity > VELOCITY_THRESHOLD_PER_MIN * 2 \
                      else ImprovisationVerdict.STUCK
            recommendation = "Pause agent and request human review"
        else:
            verdict = ImprovisationVerdict.SLOWING
            recommendation = "Monitor closely"

        return ImprovisationResult(
            verdict=verdict,
            consecutive_failures=self._consecutive_failures,
            velocity_per_min=round(velocity, 2),
            repetition_fraction=round(repetition_fraction, 3),
            window_size=n,
            total_calls=total,
            reasons=reasons,
            recommendation=recommendation,
        )

    def reset(self) -> None:
        """Reset the detector for a new session."""
        self._window.clear()
        self._all_calls.clear()
        self._consecutive_failures = 0
        self._session_start = time.time()


# ---- MODULE-LEVEL DEFAULT ---------------------------------------------------
LABYRINTH_DEAD_END_DETECTOR = DeadEndDetector()


# ---- TEST SUITE -------------------------------------------------------------

def _make_calls(
    tool: str,
    n: int,
    succeed: bool = True,
    start_time: float = 0.0,
    interval_s: float = 1.0,
) -> List[ToolCallRecord]:
    t0 = start_time or time.time()
    calls = []
    for i in range(n):
        calls.append(ToolCallRecord(
            tool_name=tool,
            parameters={"attempt": i},
            succeeded=succeed,
            timestamp=t0 + i * interval_s,
        ))
    return calls


def _test_normal_session() -> bool:
    d = DeadEndDetector()
    for c in _make_calls("search", 5, succeed=True):
        d.record(c)
    result = d.analyze()
    assert result.verdict == ImprovisationVerdict.NORMAL
    return True


def _test_consecutive_failures_flagged() -> bool:
    d = DeadEndDetector()
    for c in _make_calls("api", 7, succeed=False, interval_s=10.0):
        d.record(c)
    result = d.analyze()
    assert result.consecutive_failures >= CONSECUTIVE_FAILURE_THRESHOLD
    assert any("CONSECUTIVE_FAILURES" in r for r in result.reasons)
    return True


def _test_stuck_pattern_detected() -> bool:
    d = DeadEndDetector()
    # 15 calls to same tool, all failing
    for c in _make_calls("database", 15, succeed=False, interval_s=5.0):
        d.record(c)
    result = d.analyze()
    assert result.requires_intervention, f"Stuck pattern not detected: {result.verdict}"
    return True


def _test_high_velocity_flagged() -> bool:
    d = DeadEndDetector()
    # 100 calls in 1 second = 6000/min -- way over threshold
    now = time.time()
    d._session_start = now - 0.1  # 0.1 seconds ago
    for i in range(40):
        d.record(ToolCallRecord("tool", {}, True, timestamp=now))
    result = d.analyze(now=now)
    assert any("HIGH_VELOCITY" in r for r in result.reasons), \
        f"Velocity not flagged: {result.velocity_per_min:.1f}/min"
    return True


def _test_normal_after_reset() -> bool:
    d = DeadEndDetector()
    for c in _make_calls("api", 10, succeed=False, interval_s=5.0):
        d.record(c)
    d.reset()
    result = d.analyze()
    assert result.verdict == ImprovisationVerdict.NORMAL
    assert result.total_calls == 0
    return True


def _test_intervention_required_when_stuck() -> bool:
    d = DeadEndDetector()
    for c in _make_calls("db", 15, succeed=False, interval_s=5.0):
        d.record(c)
    result = d.analyze()
    assert result.requires_intervention
    return True


def _test_to_dict_serializable() -> bool:
    import json
    d = DeadEndDetector()
    result = d.analyze()
    json.dumps(result.to_dict())
    return True


def _test_mixed_success_failure() -> bool:
    d = DeadEndDetector()
    # Alternating success/failure -- should not trigger stuck pattern
    t0 = time.time()
    for i in range(10):
        d.record(ToolCallRecord("tool", {}, i % 2 == 0, timestamp=t0 + i * 2.0))
    result = d.analyze()
    # Should not be STUCK or RUNAWAY from alternating pattern
    assert result.verdict in (ImprovisationVerdict.NORMAL, ImprovisationVerdict.SLOWING)
    return True


def _test_module_level_instance() -> bool:
    assert isinstance(LABYRINTH_DEAD_END_DETECTOR, DeadEndDetector)
    return True


def run_tests():
    tests = [
        (_test_normal_session,            "normal_session"),
        (_test_consecutive_failures_flagged, "consecutive_failures"),
        (_test_stuck_pattern_detected,    "stuck_pattern"),
        (_test_high_velocity_flagged,     "high_velocity"),
        (_test_normal_after_reset,        "reset"),
        (_test_intervention_required_when_stuck, "intervention_required"),
        (_test_to_dict_serializable,      "to_dict"),
        (_test_mixed_success_failure,     "mixed_pattern"),
        (_test_module_level_instance,     "module_instance"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
