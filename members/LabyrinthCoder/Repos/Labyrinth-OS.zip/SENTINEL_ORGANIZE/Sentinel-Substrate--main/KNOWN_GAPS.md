# Labyrinth-OS — Known Gaps
## Read This Before Assuming Something Is Broken

This is a prototype. Gaps are documented, not hidden. The gaps themselves are part of the formal record.

**Dependency rule:** If a gap marked LAYER_II is not closed, all LAYER_III claims that depend on it are invalid. See `THEORETICAL_FOUNDATIONS.md`.

**Classification standard:**
- `OPEN` — not yet resolved, documented as known risk
- `PARTIAL` — partially addressed, specific remaining work identified
- `WIRED` — resolved in code, pending live data verification
- `CLOSED` — fully resolved with evidence

**Three constitutions — only one is built:**

> 1. **Input constitution** — provenance, model identity, data supply chain (GAP 13 — MISSING)
> 2. **Execution constitution** — gates, CGIR, AEGIS, ledger, replay (THIS SYSTEM — built)
> 3. **Evolution constitution** — bounded mutation, promotion, healing, governance (SKETCHED)

GAP 13 (pre-execution contamination) is not just a gap in a list. It names the
missing first constitution. A perfect execution constitution operating on
contaminated inputs still produces contaminated outputs. More gate rules do not fix
what the gate cannot see. The input constitution is a separate engineering problem.

---


---

## INPUT CONSTITUTION — WHAT WOULD CLOSE GAP 13

> GPT external review (June 2026): "The architecture has become better at
> deciding what to do with information than proving where the information
> came from. That is a deeper issue than almost any individual wiring bug."

The three constitutions named in this document:

1. **Input constitution** — provenance, model identity, data supply chain
2. **Execution constitution** — gates, CGIR, AEGIS, ledger, replay ← THIS SYSTEM
3. **Evolution constitution** — bounded mutation, promotion, healing ← SKETCHED

The input constitution is not a list of missing features. It is a
different engineering problem from the execution constitution. Here is
what it would require, concretely:

### Layer IC-1: Model Identity Attestation
Every inference call must be able to prove which model produced it —
not just the model name, but a cryptographic attestation of the
specific checkpoint. This is analogous to the `ATECC608B` hardware
attestation planned for Phase 10 (A014), but applied upstream to
the model producing proposals rather than downstream to the gate
enforcing them.

**Concrete step:** When A010 runs, record the model's API-reported
fingerprint (version, deployment ID) in the ledger entry alongside
the proposal. This is partial — the API's word, not cryptographic
proof — but it establishes the habit before hardware attestation
is available.

### Layer IC-2: Input Provenance Tracking
Every proposal must carry a declared provenance chain: where did the
input come from? Who touched it before it reached the model?
BoundedSensorGate (now built) closes part of this for sensor readings —
it rejects stale, spiking, or rate-violated sensor data before it
enters the pipeline. But it does not track where the sensor data came
from or whether the sensor itself was compromised.

**Concrete step:** Add a `provenance_chain: list[str]` field to
proposals in ignition.py. Initially populated manually. After A010,
populated automatically from the API response + session metadata.

### Layer IC-3: Training Provenance (Long Horizon)
The deepest layer — auditing what training data produced the model
weights. This is outside current scope and requires infrastructure
that does not yet exist in the ecosystem. Documented as a known
boundary, not a failure.

**Status:** OPEN — architecture designed, partially implementable.
See `docs/INPUT_CONSTITUTION_IC3.md` for full design.

What can be done now (no ecosystem dependency):
- `ReplayProvenanceLink` — marks replayed Chronicle entries as replays
- `model_lineage_hash` reserved field on IgnitionEntry
- ARC-AGI-2 bias probe expansion after A010

What requires ecosystem:
- Training data attestation (providers don't publish this)
- Full bias attestation (requires systematic testing + provider cooperation)

### What to build next (ordered by feasibility)

| Priority | Item | Effort | Closes |
|----------|------|--------|--------|
| 1 | Model fingerprint in ledger entries (A010) | Low | IC-1 partial |
| 2 | `provenance_chain` field on proposals | Low | IC-2 partial |
| 3 | Source verification in predicate extractor | Medium | IC-2 partial |
| 4 | Hardware model attestation | High (A014+) | IC-1 full |
| 5 | Training provenance audit | Very High | IC-3 |

The first two are achievable before A015. They do not close the gap
fully, but they make the system honest about what it does and does
not know about its inputs.

---

## Gap Summary Table

| Gap | Status | Layer | What Closes It | Collapses If Open |
|-----|--------|-------|---------------|-------------------|
| GAP 1 — ignition stubs | PARTIAL | II | A010 live run | A010, A011, A013 |
| GAP 2 — Rust runtime parity | CLOSED | I | cargo build/test clean | — |
| GAP 3 — Lane 1 dirs empty | CLOSED | I | All modules implemented | — |
| GAP 4 — Feedback→archive | WIRED | II | Live sessions | Healing loop |
| GAP 5 — PipelineTrace in trials | WIRED | II | Live sessions | Ordering proof |
| GAP 6 — Hardware (A014) | OPEN | III | FPGA + ATECC608B silicon | Hardware attestation |
| GAP 7 — Semantic replay | OPEN | II | Spec + A010 data | A015 |
| GAP 8 — Promotion heuristic | WIRED | I | z3_promotion_proof.py PR1-PR8 | — |
| GAP 9 — FailedProposal typing | CLOSED | I | PROTOTYPE_BOUNDARIES.md + typed artifacts | — |
| GAP 10 — Orthogonal channel | WIRED | I | assert_can_enter_cgir() software enforcement | A014 hardware token |
| GAP 11 — GuardianSlot self-contained | CLOSED | I | Fixed in code | — |
| GAP 12 — PipelineTrace logical seq | CLOSED | I | Fixed in code | — |
| GAP 13 — Pre-execution contamination | OPEN | III | Provenance + weight attestation | Supply chain security |
| GAP R4 — Rust/Python runtime parity | PARTIAL | II | test_rust_python_differential in SUITES (15 tests — constants + decision parity) | Rust CLI binary |

---



## GAP 1 — ignition.py Does Not Follow the Full Pipeline

**Status:** PARTIAL — epistemic labeling now real; Archive/Promotion/Reality Gate still stubs.

**What is wired as of May 2026:**
- `EpistemicLabeler.classify_from_content()` runs on every trial response
- Real epistemic label (SPECULATIVE / DEFERRED / UNKNOWN) produced and recorded in IgnitionEntry
- `epistemic_label` and `epistemic_conf` fields appear in every session JSON entry
- `_current_reasoning` set per trial so EBF filter can access response text
- `validate_mandatory_stages()` runs before every trial and prints violations
- `assert_can_enter_cgir()` called in run() — violations recorded, not raised (prototype phase)

**What remains not wired (still Option B):**
- ARCHIVE → PROMOTION → REALITY_GATE still use local stubs in ignition
- `labeling_required=False` still set — FAILOVER_ENTRY path, not Option A
- Full closure requires: real ArchiveMemory, PromotionProtocol, RealityGate called from ignition
- This requires A010 live session data and proper module wiring post-A010

**The honest state:** The system now labels every response with a real epistemic
classification. The label is recorded but does not yet gate execution — the gate
still evaluates Sigma Anchor readings regardless of epistemic label. That wiring
closes when the full Lane 1 pipeline is connected from ignition.
- PipelineTrace ordering is enforced and timestamped

STUBBED (local mocks, not real Lane 1 modules):
- `_archive_ignition()` writes JSON to runtime/ — does NOT call ArchiveMemory
- `_promote_ignition()` checks model + n_trials — does NOT call PromotionProtocol.evaluate()
- `_reality_gate_admission()` checks timestamps — does NOT call RealityGate.check()

**Status:** PARTIAL. Ordering enforcement is real. The module calls are stubs.
A proposal rejected by real Lane 1 (bad evidence, FAILED classification) still
passes ignition. The tests prove stubs work, not that real modules block.

**Closes when:** ignition calls real ArchiveMemory, PromotionProtocol.evaluate(),
and RealityGate.check(). Meaningful only after A010 (live inference).

---

## GAP 2 — Rust Crates (A012) — CLOSED

28 Rust crates exist. Only cgir-types has real content (300 lines, 20 tests).
All 29 crates have real implementations. cargo test passes 249 tests.

**Why:** cargo build is not available in the current development environment.
**Fix:** `cargo build --workspace && cargo test` once Rust toolchain available.
**Risk:** Cross-language hash parity with Python not yet verified.

---

## GAP 3 ✓ CLOSED — Lane 1 Fully Populated

All lane1 subdirectories (L00–L09) have Python implementations.
No empty directories remain. The gap described here no longer exists.

**Closed:** May 2026 — all modules present: boot_manifest, user_intent,
mode_router, creative_zone, analytical_core, epistemic_labeling,
archive_memory, deferred_node, promotion_protocol, reality_gate.

---

## GAP 4 ✓ WIRED — FEEDBACK → ARCHIVE Hook Active

pipeline_wire.py provides FeedbackRecord and create_feedback().
deferred_node.py provides the healing loop.
Neither is called from ignition.py yet.

**Why:** Awaiting A010 (first live inference) before wiring the loop.
**Fix:** Wire FeedbackRecord into ignition._seal() post-A010.

---

## GAP 5 ✓ WIRED — PipelineTrace Active in Ignition Trial Loop

pipeline_wire.PipelineTrace exists and is tested (8/8).
It is not yet called from ignition.py.

**Why:** Same as GAP 4 — prototype phase.
**Rule:** NO_TRACE = INVALID EXECUTION (this rule holds for production,
not for the prototype validation phase).

---

## GAP 6 — Physical Hardware Not Validated (A014)

FPGA timing floor (670µs), ATECC608B hardware attestation — neither
has been tested on physical silicon. Verilator simulation says achievable.
Physical board required. No code can close this gap.

---

## GAP 7 — Replay Validates Determinism, Not Decision Correctness

**What it is:** A real gap, not previously documented explicitly.

Replay proves that the system does the same thing twice given the same inputs.
It does not prove that the original decision was correct or that enforcement was valid.

If a bad promotion passes (due to stub or bug), the ledger records it and replay
confirms it — perfectly reproducing a wrong decision.

**What closes this:** Semantic replay validation — checking not just that the chain
replays identically, but that the promotion criteria, gate thresholds, and classification
state transitions were all satisfied correctly. Requires real Lane 1 modules in ignition.

**Status:** PARTIAL — Requires real Lane 1 modules in ignition + A010.

---

## GAP 8 — Promotion Rules Are Heuristic, Not Formally Verified

**What it is:** A real gap, noted in GPT review.

The Sigma Anchor constants are Z3-proven for internal consistency. The promotion
rules (`promotion_rules.py`) are heuristic — confidence threshold, consecutive run
count, harness pass rate. They have not been formally verified the way the gate
constants have.

**What closes this:** Formal specification of promotion criteria (TLA+ or Z3),
then verification against those specs. Lower priority than A010 but worth tracking.

**Status:** OPEN — formal verification path exists, not yet executed.

---


## What Is NOT A Gap

- watcher_a, watcher_b, council_resolver: fully implemented, all tests pass
- CGIR core, gate, ledger, replay: fully implemented, 521 tests pass
- Z3 sovereignty proof: complete [REAL] — A021 closed
- Mock dry-run: fully working, session hash proven

*Labyrinth-OS — X @LabyrinthCoder*

---

## PROOF SCOPE TABLE

Every strong claim this system makes, with its exact scope and what it does NOT prove.
Read this if you are tempted to interpret any finding more broadly than intended.

| Claim | Evidence | Status | What it does NOT prove |
|-------|----------|--------|------------------------|
| Z3 Sigma proof | `z3_sovereignty_spec.py` — 20 theorems | A021 VERIFIED | Real-world alignment correctness; attack completeness; adversarial robustness |
| Pipeline ordering | `pipeline_wire.py` + 8 halt-before-trial tests | VERIFIED | That module calls are real (they are stubs in prototype) |
| WORM ledger | `hashchain.py` verify() + chain tests | VERIFIED | Encrypted storage; access control; semantic correctness of recorded decisions |
| Structural replay | `replay_validator.py` + chain_entries | VERIFIED | Semantic exact replay of LLM token streams without logit capture |
| TM-001 threat model | `threat_model.py` — all 11 attack classes tested | VERIFIED | Complete adversarial coverage; novel attack classes not yet identified |
| Rust parity | `cargo test --workspace` — 249/0 | A012 VERIFIED | Cross-language replay equivalence; Rust enforcement used in live Python path |
| Watcher bounds | `test_watcher_council_bounds.py` P1-P4 | VERIFIED | Semantic validity of watcher signals; protection against adversarially poisoned sensors |
| ACP-1 VERIFIED (10/22) | Concrete evidence per assumption | VERIFIED by evidence | Mathematically formal proof (only A021 is Z3-formal) |
| Gate is fatal | SystemError on violation | VERIFIED in prototype | Cryptographic impossibility of bypass; hardware attestation |
| Invariants I1-I10 | Tests per invariant | VERIFIED in test env | Production enforcement without real module wiring in ignition.py |

### Replay Determinism — Most Important Scope Boundary

"Exact replay" in Labyrinth-OS means **structural replay**:
same chain entries, same order, same hash chain integrity.

It does NOT mean **semantic exact replay** of LLM outputs, which would require:
- logit capture from the inference engine
- fixed random seed
- containerized runtime with version-locked environment
- archived token streams
- hardware/runtime environment hashes

Without those, two runs of the same prompt through an LLM will produce different
outputs. Structural replay proves the enforcement substrate was consistent. It
does not prove the model's outputs were deterministic.

This distinction becomes relevant when A010 closes (live inference). Until then,
all runs are mock and structural replay is exact by construction.

### Constitutional Deadlock — New Gap (GPT audit finding, May 2026)

The system does not yet define resolution mechanics for:
- disagreement loops between watchers
- promotion starvation (no proposal ever reaches confidence threshold)
- confidence collapse spirals (readings drift below all floors)
- contradictory watcher signals (A says CRITICAL, B says NOMINAL)
- governance recursion (feedback loop creates oscillation)

The mini system partially addresses this via CircuitBreaker + RollbackManager.
The full system has deferred_node but it is not wired into ignition.py.

**Status:** OPEN — requires A010 + real module wiring + resolution protocol design.

---

## GAP R4 — Cross-Language Runtime Parity Not Verified (NEW — DeepSeek audit)

**What A012 proves:**
`cargo test --workspace` passes 249 tests. 29 crates compile. Constants in
Rust source files match Python sigma_anchors.py (verified by
`test_rust_python_parity.py` via static source analysis).

**What A012 does NOT prove:**
That the same proposal fed to both Python and Rust runtimes produces the
same gate decision at runtime. The Rust enforcement layer is not called from
`ignition.py`. The parity is proven by comparing source files, not by running
both systems on the same input.

**Risk:** Python and Rust implementations could diverge in edge cases
(floating-point rounding, threshold boundary behavior) without any test
detecting it, because the test compares source constants, not runtime outputs.

**What would close this:**
A test that runs a proposal through both the Python enforcement stack and the
Rust crate stack and asserts byte-identical decisions. The Rust crates are
ready; the integration test is not.

**Status:** OPEN — solvable engineering problem, not a design flaw.
Blocked until Rust enforcement is wired into the Python execution path.

---

## GAP 9 — FailedProposal Typing Not Highlighted in Architecture Docs

**What exists:**
Both systems produce `FailedProposal` as a typed frozen dataclass on every
gate block. It is written to the ledger, indexed by MemoryArchive, read by
the healing system and evolution engine. No failure is ever silent.

**The gap:**
This is load-bearing behavior — the healing loop depends on it — but it is
not surfaced in ARCHITECTURE.md or the invariant list. A reviewer reading
the architecture docs would not know that failures produce typed artifacts.

**Status:** Documentation gap only. Code is correct. Adding to ARCHITECTURE.md.

---

## GAP 10 ✓ PARTIAL — UnlabeledProposal Orthogonal Channel Wired

**What exists:**
`UnlabeledProposal` is a typed artifact for Option B (labeling_required=False).
It carries an ExceptionToken and is_prototype_path flag.

**The gap:**
`cgir_gate.py` never checks for UnlabeledProposal or its token. It only looks
at promoted (boolean) and signal severity. An attacker could set
labeling_required=False and promoted=True without ever constructing an
UnlabeledProposal. The typed safeguard is currently ornamental.

**What would close this:**
Wire UnlabeledProposal into assert_can_enter_cgir() — require the receipt
to carry the typed object, not just a promoted=True flag. Or explicitly
document that Option B is solely a flag with no typed enforcement.

**Status:** PARTIAL — May 2026. Orthogonal channel wired: assert_can_enter_cgir() now requires EITHER a LABELING stage OR a FAILOVER_ENTRY stage when labeling_required=False. Closes fully when UnlabeledProposal.exception_token is validated against a hardware token (A014).

---

## GAP 11 ✓ FIXED — GuardianSlot Upgrade Prohibition Now Self-Contained

**What exists:**
AUTHORITY.md and ARCHITECTURE.md both state GuardianSlot may only further
restrict, never upgrade, a CGIR decision. cgir_guardian_bridge.py enforces
this by clipping confidence on BLOCK.

**The gap:**
GuardianSlot.evaluate() does not receive the CGIR decision as input. The
upgrade prohibition is enforced in the bridge, not in the slot itself. A
future refactor calling GuardianSlot directly (without the bridge) could
violate I5 without any test catching it.

**What would close this:**
Add cgir_decision parameter to GuardianSlot.evaluate() and enforce the
upgrade prohibition inside the slot, not only in the bridge.

**Status:** FIXED (May 2026). cgir_decision parameter added to evaluate().
I5 is now enforced inside GuardianSlot itself, not only in the bridge.
BlockReason.CGIR_PRECEDENCE added for cases where upstream CGIR blocks.

---

## GAP 12 ✓ FIXED — PipelineTrace Now Has Logical Sequence Counter

**What exists:**
PipelineTrace uses wall-clock timestamps (time.time()) for stage ordering.
Replay validates structural order (archive < promotion < gate < cgir).

**The gap:**
Wall-clock time is not monotonic across NTP adjustments. Two different runs
on the same machine could have different timestamps and still produce a "clean"
replay. Cross-session trace hash equality is not guaranteed.

**What would close this:**
Add a logical_sequence counter (monotonic integer) to PipelineTrace.
Include it in the trace hash. Require replay to verify logical sequence
equality, not wall-clock approximation.

**Status:** FIXED (May 2026). _logical_sequence counter added to PipelineTrace.
Increments on every record() call. Included in trace hash.
Replay can now verify causal ordering, not just wall-clock ordering.

---

## New Invariants (I16-I18) — Not Yet Enforced in Code

**I16 — Boundary Upgrade Prohibition (Promotion → Reality Gate)**
A PromotionReceipt with approved=False may never be upgraded to approved=True
by the Reality Gate. Currently reality_gate.py checks promoted (boolean)
from the stub, not the receipt's approved field directly.

**I17 — Non-Decreasing Timestamps Within Session**
Within a single PipelineTrace, recorded timestamps must be non-decreasing.
A violation indicates clock error or tampering. Not yet enforced in code.

**TTL Enforcement (related to I17):** Label TTL expiry must be checked by the
caller before passing to PromotionRules.evaluate(). The evaluate() method
receives label_id as a string — TTL must be checked on the LabelSchema object
at the call site, not inside evaluate().

**I18 — Confidence Cap Applied at Adapter Boundary**
Confidence derived from LogprobMetrics must be capped at the adapter,
not downstream. A compromised adapter should not be able to inject high
confidence without real logprob evidence reaching ignition.py.
Partially addressed: MISSING_LOGPROB_CONFIDENCE_CAP constant now defined
in logprob_bridge_adapter.py. Full enforcement requires moving the cap
application from ignition.py into the adapter's to_sensor_readings().

---

## GAP 13 — Pre-Execution Contamination Is Outside Scope

**Status:** OPEN — acknowledged boundary, not a failure.

The gate enforces constitutional invariants at action-execution time.
It addresses what the model does at the moment of proposal evaluation.

What the gate does NOT address:
- Compromise in model weights before deployment
- Poisoning of training data upstream of inference
- Manipulation of input pipelines before proposals reach the gate
- Biases embedded during pre-training that produce plausible-but-harmful outputs

**The armored door critique (Sylvain Delgado, May 2026):**
"I built an armored door. It's useless. While I was reinforcing the door,
the agent was already inside — in the model weights, in the training data,
in the biases no one audited. The armored door is useless if the enemy is
already in the house."

This critique is correct and must be stated honestly. Labyrinth-OS is the
armored door. It catches execution-time violations. It does not audit
model weights, training provenance, or pre-deployment contamination.

**What is bounded:** Execution-time actions that violate formal invariants.
The predicate_extractor.py LogicalSentinel adds a second axis — predicate
verification catches structural signatures of malicious reasoning (zero-day
pattern: SOURCE=UNVERIFIED + VERIFICATION=BYPASSED + LOOP=TRUE). But an
agent that constructs well-formed predicates while hiding malicious intent
upstream of the reasoning chain is not currently detected.

**What closes this gap:** Provenance auditing and weight attestation layers
upstream of the gate. These are a separate engineering problem requiring
supply-chain security, model cards with auditable training data, and hardware
attestation of model identity. Outside current scope. No timeline.

**What does NOT close this gap:** More gate invariants. The gap is not
about the gate's rules — it is about what the gate can see. A perfectly
designed gate operating on compromised inputs produces compromised outputs.

**Design principle derived from this gap:** The gate is the last line of
defense for execution-time actions. It is not the first line of defense
against training-time compromise. Both are necessary. Only one is built.

**Classification:** ANALOGY to Delgado's Geometric Morality Fallacy finding.
The fallacy there: making geometry more regular makes the model more truthful.
The gap here: making the gate stronger makes the system safer end-to-end.
Neither is false — both are partial. Honesty about partiality is the fix.

