# Labyrinth-OS — Architecture

## Core Law

```
Intelligence proposes.   VECTOR senses.      Watchers contest.
Council resolves.        CGIR formalizes.    Gate decides.
AEGIS commits.           Ledger proves.      Replay validates.
Evolution happens offline.
```

---

## System Class

Labyrinth-OS is a **constitutional execution substrate** that wraps any LLM.
The Ghost (LLM) proposes. The Machine validates, gates, and ledgers every
decision. The Ghost cannot execute. The Machine enforces the Σ Anchor
constants structurally — not ethically. Alignment by architecture.

---

## Mandatory System Flow

This flow is non-negotiable. Every input follows it exactly.
Nothing bypasses any stage. Nothing executes without every prior stage passing.

```
INPUT
  │
  ▼
LABELING ──────────────────────────── Hard Invariant I1: no bypass
  │  label_schema.py
  │  label_validator.py
  │  epistemic_types.py (UNKNOWN → SPECULATIVE | TRUTH | DEFERRED)
  │
  ▼
ARCHIVE ────────────────────────────── Hard Invariant I10: nothing deleted
  │  memory_store.py (immutable, SHA-256 chained)
  │  archive_memory.py
  │  confidence_record.py
  │
  ▼
DEFERRED (optional) ────────────────── Ideas with insufficient confidence
  │  deferred_exploration/
  │  pattern_catalog.py, recall_protocol.py
  │
  ▼
PROMOTION ──────────────────────────── Hard Invariant I3: ONLY Lane 1→2 bridge
  │  promotion_rules.py (criteria: evidence, test, no contradiction, age, consistency)
  │  promotion_protocol.py (orchestrator)
  │  audit_trail.py (all promotions logged)
  │  rollback_protocol.py
  │
  ▼
REALITY GATE ───────────────────────── Hard Invariants I4, I5: BEFORE CGIR
  │  MUST PRECEDE CGIR TRANSLATION
  │  reality_gate.py (Lane 1 → Lane 2 crossing)
  │  gate_function.py (TRUTH + evidence + proof + no contradiction)
  │  gate_proof.py, gate_rejection.py, gate_binding.py
  │  → GatePassage (authorized) or GateBlock (named rejection)
  │
  ▼
CGIR TRANSLATION ───────────────────── Only gate-approved data enters
  │  cgir_schema.py (schema validation before compilation)
  │  cgir_types.py, cgir_core.py
  │  cgir_validator.py (strict validation, fail closed)
  │  cgir_determinism.py (canonical hash, insertion-order independent)
  │
  ▼
CONSTRAINT ENGINE / SOLVER ─────────── Formal verification
  │  z3_sovereignty_spec.py (SMT proofs, A021 CLOSED [REAL])
  │  acbf_vm.py (policy-gated bytecode VM)
  │
  ▼
ADVERSARIAL STRESS TEST ────────────── TM-001 attack surface
  │  watcher_a.py (internal consistency)
  │  watcher_b.py (adversarial: replay, injection, evasion)
  │  threat_model.py (11 attack classes, all falsifiable)
  │  council_resolver.py (merge → one SignalNode, emitted_by='COUNCIL')
  │
  ▼
EXECUTION DECISION (GATE) ──────────── Hard Invariant I5 enforced
  │  cgir_gate.py        ALLOW | BLOCK  (CRITICAL + ERROR → BLOCK)
  │  guardian_slot.py    EXECUTE | BLOCK | KILL  (operational margin)
  │  cgir_guardian_bridge.py  (L10→L12, clips confidence on BLOCK)
  │  CGIR BLOCK → GuardianSlot MUST NOT EXECUTE (binding, no upgrade)
  │
  ▼
AEGIS / EXECUTION KERNEL ───────────── Only state mutator (I1)
  │  aegis_cesk.py  LOAD→PROPOSE→CHECK→COMMIT→PROVE
  │
  ├─── SANDBOX (experimental)
  ├─── EXPERIMENTAL_EXEC
  └─── VERIFIED_EXEC
  │
  ▼
LEDGER ─────────────────────────────── Hard Invariant I8: mandatory logging
  │  receipt.py, hashchain.py, cgir_ledger.py
  │  WORM append-only. No deletion. SHA-256 chain.
  │
  ▼
REPLAY / AUDIT ─────────────────────── Hard Invariant I9: all runs replayable
  │  replay_validator.py
  │  verify_run.py (4-step proof: receipt→replay→execute→forced-fail)
  │  Exact-chain replay from exported chain_entries.
  │
  ▼
OBSERVABILITY ──────────────────────── Downstream of execution (not upstream)
  │  drift_detector.py
  │  metrics.py
  │  anomaly_log.py
  │  feedback_loop.py
  │
  ▼
GOVERNANCE
  │  acp1_tracker.py (22 assumptions)
  │  promotion oversight, evolution controls
  │
  ▼
FEEDBACK → ARCHIVE ─────────────────── Hard Invariant I10: outcomes archived
     pipeline_wire.py (FeedbackRecord)
     Every outcome — PASS or FAIL — returns to archive.
     Failed ideas are never deleted. They become memory.
```

---

## Hard Invariants `[TEST-VERIFIED — I1–I19]`

| # | Invariant | Enforced By |
|---|-----------|-------------|
| I1 | No input bypasses LABELING | pipeline_wire.py PipelineTrace |
| I2 | No speculative data executes | promotion_protocol.py, reality_gate.py |
| I3 | PROMOTION is the only Lane 1→2 bridge | promotion_rules.py |
| I4 | REALITY_GATE is mandatory before execution | reality_gate.py |
| I5 | REALITY_GATE occurs BEFORE CGIR | pipeline_wire._test_i5 + ordering check |
| I6 | One responsibility per module | architecture enforcement |
| I7 | Hardware safety is final authority | guardian_slot.py KILL path |
| I8 | All execution is logged (WORM) | cgir_ledger.py, hashchain.py |
| I9 | All execution is replayable | replay_validator.py, verify_run.py |
| I10 | Failed ideas are never deleted | archive_memory.py, feedback_loop |

---

## Dual-Lane Design

```
┌─────────────────────────────────────────────────────────┐
│  LANE 1 — Creative / Epistemic  (L00–L09)               │
│  Unbounded. Non-deterministic. No suppression.           │
│  Everything labeled. Nothing executes from here.         │
│                                                          │
│  L00 Boot → L01 Intent → L02 Router                     │
│  L03 Creative → L04 Analytical                           │
│  L05 Epistemic Labeling (ALL paths converge here)        │
│  L06 Archive → L07 Deferred                              │
│  L08 Promotion Protocol                                  │
│  L09 Reality Gate ← ONLY crossing point                 │
└─────────────────────────┬───────────────────────────────┘
                          │ GatePassage only
                          ▼
┌─────────────────────────────────────────────────────────┐
│  LANE 2 — Execution / Constitution  (L10–L20)           │
│  Deterministic. Everything logged. Everything replayable.│
│                                                          │
│  L10 CGIR (only gate-approved data)                      │
│  L11 Gate (formal ALLOW/BLOCK)                           │
│  L12 AEGIS/CESK (only state mutator)                     │
│  L13 Ledger (WORM)                                       │
│  L14 Replay/Gnosis                                       │
│  L15 Experimental Exec                                   │
│  L16 Verified Exec                                       │
│  L17 WORM Chronicle                                      │
│  L18 Replay Audit                                        │
│  L19 Observability (downstream of execution)             │
│  L20 Governance                                          │
└─────────────────────────────────────────────────────────┘
```

---

## Security Invariant Per Layer

What each layer protects against — in plain terms:

| Layer | Security Invariant |
|-------|-------------------|
| L00 Boot Manifest | System proves it can self-check before accepting any input. Catches broken startup state before it propagates. |
| L01 User Intent | Every input has a traceable source. Mutations require a parent ID. Nothing enters the pipeline anonymously. |
| L02 Mode Router | Lane assignment is structural. A creative input cannot accidentally be routed to execution. |
| L03 Creative Zone | Speculative output stays speculative. Nothing generated here can execute without crossing the full pipeline. (I2) |
| L04 Analytical Core | Evidence is attached before promotion. Contradictions are caught here, not downstream. |
| L05 Epistemic Labeler (Thalamus equivalent — all paths converge) | Every path through the system converges here. No input skips the labeling authority. (I1) |
| L06 Archive Memory | Immutable append-only. A failure cannot be erased to hide it. (I10) |
| L07 Deferred Node | Failed candidates re-enter at labeling, not at a later stage. No shortcut back into the pipeline. |
| L08 Promotion Protocol (Basal Ganglia equivalent — go/no-go gating) | Explicit evidence required. No silent promotion. No assumption that "good enough" is good enough. (I3) |
| L09 Reality Gate | The only crossing point between lanes. Fatal if bypassed. Runs before CGIR, not after. (I4, I5) |
| L10 CGIR Translation | Only gate-approved proposals become CGIR nodes. The translation is typed and validated. |
| L11 Gate | Sigma Anchor check against proven thresholds. Binary: ALLOW or BLOCK. Nothing in between. |
| L12 AEGIS/CESK (Motor Cortex + Cerebellum equivalent) | Deterministic runtime. The only thing in the system that mutates state. Same input = same output. (I7) AEGIS implements a deterministic phase kernel (LOAD→PROPOSE→CHECK→COMMIT→PROVE). CESK is used as a structural analogy — the naming reflects the inspiration, not a strict formal claim. |
| L13 Ledger (Hippocampus equivalent — immutable episodic memory) | WORM. Every execution is logged. Nothing can be unlogged. (I8) |
| L14 Replay/Gnosis | Structural replay. Same chain entries, same order, same hash. Does not guarantee semantic replay of external LLM outputs without logit capture. (I9) |
| L15-L16 Execution | Sandboxed experimental and production paths. Neither can promote their own output. |
| L17 WORM Chronicle | Tamper-evident hash chain. Modifying any entry breaks all subsequent hashes. TM-001 verified. |
| L18 Replay Audit | Post-execution verification. Catches drift between what was intended and what ran. |
| L19 Observability | Strictly downstream of execution. Cannot influence what runs — only reports on it. |
| L20 Governance | Feedback closes back to archive. Failures become memory, not silence. (I10) |

---

## Gate Precedence (Invariant I5)

```
CGIR Gate BLOCK  → GuardianSlot MUST NOT EXECUTE. Binding.
                    GuardianSlot may never upgrade BLOCK to EXECUTE.
CGIR Gate ALLOW  → Necessary but not sufficient.
                    GuardianSlot may still BLOCK or KILL.

For EXECUTE:   CGIR ALLOW  AND  GuardianSlot EXECUTE
To stop:       CGIR BLOCK  OR   GuardianSlot BLOCK / KILL
```

---

## Sigma Anchor Constants `[Z3-PROVEN — A021]`

```python
TAU_ESCAPE_FLOOR = 0.75   # tau below → CRITICAL
CHI_WARN         = 0.15   # chi >= → WARNING  (chi = risk, high = bad)
CHI_COLLAPSE     = 0.40   # chi >= → CRITICAL
DRIFT_THRESHOLD  = 0.12   # drift >= → ERROR
BETTI_1_CAP      = 0.045  # beta1 >= → ERROR
```

Z3 formally proven non-vacuous, sound, boundary-correct, independent, and monotonically ordered. A021 CLOSED [REAL]. Single source: `sigma_anchors.py`.

---

## Known Gaps (honest)

1. **ignition.py Option B route** — `labeling_required=False` declared explicitly
   in PipelineTrace. `validate_mandatory_stages()` runs before every trial and
   prints violations. `assert_can_enter_cgir()` is called in `run()` before trials.
   ARCHIVE→PROMOTION→REALITY_GATE not yet wired — violations are measurable and
   honest (`option_b_violations` in session JSON, `gap1_measurable=True`).
   This is a controlled exception, not a silent bypass. Will be fully wired post-A010.

2. **FEEDBACK→ARCHIVE** — FeedbackRecord is written in `_seal()`. FeedbackLoop
   e2e test (7 tests) proves: anomaly → confidence adjusted → promotion affected.
   Ignition uses mock stages (GAP 1 PARTIAL). Full wiring post-A010. Was:
   the WORM ledger but not yet fed back to the epistemic archive.
   `pipeline_wire.FeedbackRecord` exists; needs wiring.

3. **Council sensor escalation bypass** — Sensor severity can directly
   escalate Council (council_resolver.py wired). Long-term: route
   through SensorWatcher before reaching Council.

---

*Labyrinth-OS — X @LabyrinthCoder — Private*

## Dual Enforcement — Forward and Backward `[TEST-VERIFIED]`

The system enforces its invariants in two independent directions:

**Forward path (prevention):**
`cgir_gate.py` blocks on CRITICAL/ERROR signals before execution.
`cgir_guardian_bridge.py` clips confidence on BLOCK. GuardianSlot cannot upgrade.
This prevents invalid proposals from executing.

**Backward path (audit integrity):**
`replay_validator.py` detects phase order violations (COMMIT without CHECK,
PROVE without COMMIT) and tampered hash chains after the fact.
This proves that blocks were correctly recorded and not tampered with.

Most audit systems have one or the other. This system has both.
Blocks are prevented. The records of blocks are independently verified.


## Dual Confidence Thresholds — Decay Safety Margin

The system uses two different confidence thresholds intentionally:

- **Promotion threshold:** `PROMOTION_CONFIDENCE_THRESHOLD = 0.95`
  (in `promotion/promotion_rules.py`)
- **Reality Gate floor:** `CONFIDENCE_FLOOR = 0.65`
  (in `sigma_anchors.py`)

The 0.30 gap is a decay safety margin. A label's confidence can drop by up
to 0.30 between promotion approval and gate crossing and still pass the gate.
This is intentional: temporal drift in confidence is expected, and the system
tolerates it within bounds rather than requiring exact preservation.

This is documented in `promotion_rules.py` line 35 but was not previously
surfaced in the architecture documentation.

## FailedProposal — Typed Failure Artifact (Load-Bearing)

Every gate block produces a `FailedProposal` typed frozen dataclass:

```python
@dataclass(frozen=True)
class FailedProposal:
    proposal_id: str
    failure_reason: str
    stage_reached: str
    timestamp: float
```

This is not optional logging. It is load-bearing:
- Written to the ledger on every crossing failure
- Indexed by MemoryArchive for pattern analysis
- Read by the healing system for circuit breaker decisions
- Read by the evolution engine for threshold adaptation

If a failure were dropped without producing a FailedProposal, the healing
loop would be blind to it. No failure is ever silent in either system.

## Three Decisions at the Gate (Not Two)

The GuardianSlot does not make a binary decision. It makes a ternary one:

**EXECUTE** — all checks pass. Action is safe to proceed.
**BLOCK** — soft violation or low confidence. Requires human review.
**KILL** — hard safety violation. Irrevocable within a decision cycle.

KILL cannot be overridden to EXECUTE without starting a new cycle.
It fires on: tau below floor, chi collapsed, CBF breached, or explicit
human kill signal.

Kill reasons are typed (`KillReason` enum): TAU_BELOW_FLOOR, CHI_COLLAPSED,
CBF_BREACHED, HUMAN_KILL. Every KILL is recorded in the ledger with reason.

This three-tier decision (EXECUTE / BLOCK / KILL) is a harder safety boundary
than a binary gate. KILL is the architectural equivalent of a hardware
emergency stop — it cannot be argued with, only reset by a new cycle.

## Artifact State Machine (enforcement.py)

Classification gains enforcement teeth through a six-state machine:

```
RAW → EXPERIMENTAL → PARTIAL → VALIDATED → (approach Reality Gate)
                              ↘ FAILED
                              ↘ ARCHIVED
                              ↘ DEPRECATED
```

Rules:
- FAILED / ARCHIVED → hard block. Cannot promote. Cannot execute.
- DEPRECATED → hard block unless explicitly revived.
- RAW / EXPERIMENTAL → sandbox only.
- PARTIAL → allowed in experimental promotion only, with confidence capped at 0.60.
- VALIDATED → may approach Reality Gate.

**Critical design doctrine:**
Classification can warn automatically. Classification can block automatically.
Classification must NOT silently upgrade automatically.

Transitions require operator approval (`approve_transition()`) — not automatic.
The system proposes. The operator decides. The record is immutable.

## Signal Algebra (cgir_signal_algebra.py)

The bridge between L3 sensor fabric and L10 CGIR. A pure function with no
state, no I/O, and no side effects. Same inputs always produce same SignalNode.

Converts five sensor readings (tau_escape, chi, drift, betti_1, confidence)
into a single typed CGIR SignalNode with deterministic severity:

```
CRITICAL  — tau < 0.75  OR  any chi component >= 0.40
ERROR     — drift >= 0.12  OR  betti_1 >= 0.045
WARNING   — chi mean >= 0.15  OR  confidence < 0.50
INFO      — all checks pass
```

The emitted_by tag is "SIGNAL_ALGEBRA" — raw sensor evidence, not yet
Council-adjudicated. Council then combines this with Watcher A and Watcher B
reports to produce the final gate recommendation.

## Cross-Domain Architecture — The Domain Adapter Pattern

The Sigma Anchor channels (tau, chi, drift, betti_1, confidence) are abstract
variables. Any domain that generates proposals and needs enforcement before
execution can feed its physical measurements into these five channels through
a domain adapter. The gate, ledger, healing loop, and replay mechanism are
domain-agnostic.

The domain adapter is the only domain-specific component. It translates
physical sensor readings into SensorReadings objects with the five channels.
The rest of the system operates identically regardless of domain.

This design was validated by comparison with the Poole Manifold (Rooke Poole,
April 2026): the same B5-7/S5-9 rule with prime-resonance sharpening produces
computation, memory, healing, replication, and cosmology by changing the
input mask geometry. Labyrinth-OS applies the same insight: the same
constitutional substrate governs any proposal-action system by changing
the domain adapter.

**Five documented domains:**
- AI governance: logprob bridge → SensorReadings (current build)
- Industrial automation: sensor fusion → SensorReadings (Phase 10.5)
- Medical decision support: evidence weights → SensorReadings (Phase 10.5)
- Financial systems: risk model → SensorReadings (Phase 10.5)
- Autonomous vehicles: safety envelope → SensorReadings (Phase 10.5)

See ROADMAP.md Phase 10.5 and archive/Labyrinth_OS_Extended_Vision.md
for full specifications.

## A014 Design Target — The Immortal Latch Layer `[NOT YET DEMONSTRATED — requires FPGA + ATECC608B]`

A014 is the FPGA hardware enforcement gap. The Poole Manifold's Immortal
Latch (V207) provides the reference architecture for what A014 should become:

- Reality Gate as a Venturi choke enforced by overpressure dead zones
- WORM ledger entries as cross-coupled macro-orbit latches with topological protection
- PromotionReceipt as a kinetic mass packet requiring correct mass signature
- Bypass becomes geometrically impossible, not just detectable

When A014 closes, the system crosses from "measurable violation" to
"structurally impossible violation." That is the final frontier.


## Theoretical Foundations — Why the Architecture Is Structured This Way `[ANALOGY — external frameworks, no derivation claimed]`

### The Geometric Morality Fallacy

**Source:** Sylvain Delgado, "Spectrography of Artificial Thought" (March 2026).
**Classification:** EXPERIMENTAL FINDING — 28 sessions, 72 bootstrap runs each.
**Attribution:** Sylvain Delgado. Personal information withheld by agreement.

The central finding: the geometric structure of a model's latent space —
its isotropy, rank, and tension — cannot distinguish correct reasoning
from well-constructed deception.

Experimental results:
- V3: Truth vs. coherent deception geometrically indistinguishable (p=0.948)
- V4: Same result under stochastic perturbation (p=0.975)
- V3-S4: Internal logical contradiction IS geometrically detectable (d=2.419),
  but this is coherence monitoring, not truth detection

**Implication for Labyrinth-OS:** The gate cannot live inside the model's
reasoning space because that space cannot see the distinction the gate needs
to make. Lane 1 reasons freely within geometry. Lane 2 enforces outside it.
This separation is not a design preference — it is experimentally necessary.

Delgado's conclusion: "Geometry is a channel, not a judge." This is exactly
the distinction between Lane 1 (the model reasons — geometry) and Lane 2
(the gate judges — not geometry).

His independent Logical Sentinel implementation (Z3 predicate verification,
eBPF kernel hook, "does not negotiate with the agent") arrived at the same
architecture as Labyrinth-OS from the deception-detection direction.
Same conclusion, independent derivation, different entry point.

### Binary Gate Necessity

**Source:** Delgado, S. (May 2026). "Spectral Selection in the Leech Substrate."
Proposition 2.2.2 (Stability Criterion).
**Classification:** ANALOGY — structural parallel, not a cosmological claim.

The gate is binary (ALLOW/BLOCK) not as a simplification but as a
mathematical necessity. In the spectral selection framework, a mode
survives if and only if R(ρ) = 0. There is no stable intermediate state.
A mode with R(ρ) = 0.001 decays just as surely as one with R(ρ) = 0.999 —
only more slowly. Partial execution is not a stable state.

Applied to Labyrinth-OS: a proposal either satisfies all constitutional
invariants or it does not. There is no "partially constitutional" execution.
The binary structure of ALLOW/BLOCK is what the mathematics demands.

### Three-Tier Decision Structure

**Source:** Delgado (2026), Section 4.4, Figure 8, Section 10.3.
**Classification:** ANALOGY.

The three decision tiers (EXECUTE / BLOCK / KILL) correspond to three
qualitatively distinct dynamical regimes in the non-Hermitian system:

- PT-unbroken phase (ε < 1): eigenvalues complex — pre-execution state (BLOCK)
- Exceptional point (ε = 1): eigenvalues coalesce — transition (PROMOTE)
- PT-broken phase (ε > 1): eigenvalues real with opposite signs — EXECUTE or KILL

The tiers are not chosen. They are the only three that exist. The three-tier
structure of the Reality Gate reflects this mathematical necessity.

### Watcher Severity Ordering

**Source:** Kato, T. (1966). Perturbation Theory for Linear Operators. Springer.
**Classification:** ANALOGY.

Kato's perturbation theory provides rigorous grounding for why the
severity ordering (INFO → WARNING → ERROR → CRITICAL) is a phase structure,
not an arbitrary scale:

- INFO and WARNING: pre-transition regime. Eigenvalues remain real.
  System is perturbed but has not crossed an exceptional point.
- ERROR and CRITICAL: post-transition regime. The coupling parameter g
  has crossed the critical value gc. The system is in a qualitatively
  different state.

The boundary between WARNING and ERROR is a phase transition, not a
threshold crossing. This is why the sigma anchors are jointly proven
(z3_sovereignty_spec.py) rather than individually set — crossing one
boundary affects the entire spectral structure.

### Irreducible Error Bound ε(Π)

**Source:** Van Vu, T. & Saito, K. (2026). Geometric complexity in thermodynamics.
**Classification:** THEORETICAL BOUND — applies regardless of implementation.

The Van Vu-Saito theorem proves that for any projection Π from a
high-dimensional substrate to a lower-dimensional space:
  exp[C(Π)] × ε(Π) ≥ 1

Perfect enforcement (ε = 0) requires infinite complexity, which is
thermodynamically forbidden. The irreducible residual error ε(Π) > 0 always.

**Implication for Labyrinth-OS:** The gate is not defective because it
has a non-zero false-positive/false-negative rate. That rate is
mathematically irreducible. The correct response is to bound it, measure
it, and report it as a first-class metric — not to treat it as a defect
to eliminate. A014 (hardware enforcement) reduces ε(Π) but cannot
eliminate it. Document this honestly rather than claiming perfect coverage.
