# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          input_provenance.py — Labyrinth-OS / Epistemic / Provenance
# ----------------------------------------------------------------------------

"""
input_provenance.py — Labyrinth-OS / Epistemic / Provenance
=============================================================
Input Constitution — IC-1 and IC-2 Partial Implementation

GPT external review (June 2026):
  "The architecture can increasingly validate behavior.
   It is still learning how to validate origins.
   A fake proposal that passes every gate except provenance is
   exactly the sort of thing that exposes where future work belongs."

This module implements provenance tracking at the depth currently
achievable without A014 hardware attestation:

IC-1 — Model Identity
  Current: SHA-256 fingerprint of provider:model:session_id.
  Partial: API-reported identity, not hardware-attested.
  Full: ATECC608B cryptographic attestation (A014).

IC-2 — Input Provenance Chain
  Current: Declared chain of custody as a JSON array.
  Partial: Self-reported by the adapter, not independently verified.
  Full: Cryptographic signing at each hop (future).

IC-3 — Training Provenance
  Current: Not implemented. Acknowledged boundary.
  Full: Requires ecosystem infrastructure that does not exist.

The POLITE_LIE attack (A020 adversarial suite) shows exactly where
this module matters: a structurally valid proposal with
provenance_chain="unverified" is detected as suspicious. This module
provides the tools to build richer provenance chains so that
"unverified" becomes increasingly rare.

References
----------
  ACP-1 A018 (signing key), A010 (live inference)
  execution/adversarial/adversarial_load_suite.py — POLITE_LIE
  runtime/ignition.py — model_fingerprint, provenance_chain fields
  KNOWN_GAPS.md — Input Constitution section
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, List, Optional


# ─── PROVENANCE LEVELS ────────────────────────────────────────────────────────

@unique
class ProvenanceLevel(str, Enum):
    """
    How much is known about where a proposal came from.

    UNVERIFIED    — No provenance information. Default for unknown origin.
                    POLITE_LIE attack signature triggers on this.

    DECLARED      — Self-reported by the adapter. Provider, model, session
                    are known but not independently verified.
                    This is what ignition.py now produces.

    SIGNED        — The provenance chain has been signed with the EDEN
                    signing key. Tamper-evident but not hardware-attested.
                    Available after A018 is fully wired.

    ATTESTED      — Hardware-attested model identity via ATECC608B.
                    Requires A014. The gold standard.
    """
    UNVERIFIED = "unverified"
    DECLARED   = "declared"
    SIGNED     = "signed"
    ATTESTED   = "attested"


# ─── PROVENANCE LINK ─────────────────────────────────────────────────────────

# Source type vocabulary for ProvenanceLink
# Answers: what kind of thing produced this information?
SOURCE_TYPES = {
    "cloud_api":       "Remote API call (OpenAI, Anthropic, etc.)",
    "local_model":     "Locally running model (Ollama, llama.cpp)",
    "replay_system":   "Replayed from Chronicle ledger",
    "synthetic":       "Synthetically generated (mock, test)",
    "imported_dataset":"Imported from external dataset",
    "human_input":     "Direct human operator input",
    "hardware_sensor": "Physical sensor reading",
    "unknown":         "Source type not determined",
}


@dataclass(frozen=True)
class ProvenanceLink:
    """
    A single link in the provenance chain.

    Each link records one hop in the chain of custody:
    where the data came from, what processed it, and when.

    GPT review observation (J53): "the current fingerprint proves consistency,
    not origin." ProvenanceLink is the origin layer — it records the source_type
    (what kind of thing), identity (which specific instance), acquisition_timestamp
    (when obtained), transformation (what happened to it), and confidence_in_origin
    (how certain we are about this link's accuracy).

    Fields
    ------
    role:               "provider", "model", "session", "gate", "adapter", "dataset"
    identity:           Specific value: "anthropic", "claude-3-5-sonnet", "sess-001"
    timestamp:          When this link was recorded (wall clock)
    level:              ProvenanceLevel — how verified is this link?
    source_type:        What kind of source produced this (see SOURCE_TYPES)
    acquisition_ts:     When the information was acquired (may differ from timestamp)
    transformation:     What processing occurred at this hop (empty = pass-through)
    confidence_origin:  [0.0-1.0] How confident we are this link is accurate
    signature:          EDEN signing key signature over this link (A018)
    """
    role:               str
    identity:           str
    timestamp:          float
    level:              ProvenanceLevel = ProvenanceLevel.DECLARED
    source_type:        str             = "unknown"
    acquisition_ts:     Optional[float] = None
    transformation:     str             = ""
    confidence_origin:  float           = 1.0   # 1.0 = fully confident
    signature:          Optional[str]   = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "role":              self.role,
            "identity":          self.identity,
            "timestamp":         self.timestamp,
            "level":             self.level.value,
            "source_type":       self.source_type,
            "acquisition_ts":    self.acquisition_ts,
            "transformation":    self.transformation,
            "confidence_origin": self.confidence_origin,
            "signature":         self.signature,
        }


@dataclass
class ProvenanceChain:
    """
    Ordered sequence of provenance links for one proposal.

    The chain records the full custody path from origin to gate.
    Each hop adds a link. The chain is serialized to a JSON string
    for storage in IgnitionEntry.provenance_chain.

    Amendment support: chains can be corrected without erasing history.
    The original chain is preserved in the amendments list. This allows
    the system to handle corrected provenance honestly rather than
    pretending errors never occurred.
    """
    links:      List[ProvenanceLink]  = field(default_factory=list)
    level:      ProvenanceLevel       = ProvenanceLevel.UNVERIFIED
    amendments: List[Dict]            = field(default_factory=list)

    def add_link(
        self,
        role: str,
        identity: str,
        level: ProvenanceLevel = ProvenanceLevel.DECLARED,
        source_type: str = "unknown",
        acquisition_ts: Optional[float] = None,
        transformation: str = "",
        confidence_origin: float = 1.0,
        signature: Optional[str] = None,
    ) -> "ProvenanceChain":
        """Add a link and update the chain's overall level."""
        self.links.append(ProvenanceLink(
            role=role, identity=identity,
            timestamp=time.time(),
            level=level,
            source_type=source_type,
            acquisition_ts=acquisition_ts,
            transformation=transformation,
            confidence_origin=confidence_origin,
            signature=signature,
        ))
        # Overall level is the minimum across all links
        levels = [ProvenanceLevel.UNVERIFIED, ProvenanceLevel.DECLARED,
                  ProvenanceLevel.SIGNED, ProvenanceLevel.ATTESTED]
        link_levels = [l.level for l in self.links]
        min_idx = min(levels.index(l) for l in link_levels)
        self.level = levels[min_idx]
        return self

    def is_suspect(self) -> bool:
        """Returns True if any link is UNVERIFIED — POLITE_LIE indicator."""
        return self.level == ProvenanceLevel.UNVERIFIED or not self.links

    def chain_hash(self) -> str:
        """SHA-256 of canonical chain content for tamper detection."""
        canonical = json.dumps(
            [link.to_dict() for link in self.links],
            sort_keys=True, separators=(",", ":"),
        )
        return hashlib.sha256(canonical.encode()).hexdigest()[:16]

    def to_json(self) -> str:
        data = {
            "links":      [l.to_dict() for l in self.links],
            "level":      self.level.value,
            "chain_hash": self.chain_hash(),
        }
        if self.amendments:
            data["amendments"] = self.amendments
        return json.dumps(data)

    @classmethod
    def from_json(cls, s: str) -> "ProvenanceChain":
        if s == "unverified" or not s:
            return cls()
        try:
            data = json.loads(s)
            if isinstance(data, list):
                # Legacy format from ignition.py
                chain = cls()
                for item in data:
                    if ":" in item:
                        role, _, identity = item.partition(":")
                        chain.add_link(role, identity)
                return chain
            # New format
            chain = cls()
            for link_dict in data.get("links", []):
                chain.links.append(ProvenanceLink(
                    role=link_dict["role"],
                    identity=link_dict["identity"],
                    timestamp=link_dict.get("timestamp", 0.0),
                    level=ProvenanceLevel(link_dict.get("level", "declared")),
                    signature=link_dict.get("signature"),
                ))
            # Recompute level from loaded links
            if chain.links:
                levels = [ProvenanceLevel.UNVERIFIED, ProvenanceLevel.DECLARED,
                          ProvenanceLevel.SIGNED, ProvenanceLevel.ATTESTED]
                link_levels = [l.level for l in chain.links]
                min_idx = min(levels.index(l) for l in link_levels)
                chain.level = levels[min_idx]
            # Load amendments if present
            if "amendments" in data:
                chain.amendments = list(data["amendments"])
            return chain
        except Exception:
            return cls()

    @property
    def provider(self) -> Optional[str]:
        for link in self.links:
            if link.role == "provider":
                return link.identity
        return None

    @property
    def model(self) -> Optional[str]:
        for link in self.links:
            if link.role == "model":
                return link.identity
        return None

    @property
    def revision_count(self) -> int:
        """Number of amendments applied to this chain."""
        return len(self.amendments)

    def amend(
        self,
        reason: str,
        correction: Optional["ProvenanceChain"] = None,
        amended_by: str = "operator",
    ) -> "ProvenanceChain":
        """
        Amend the chain without erasing history.

        GPT review observation (J53): "Research labs eventually run into this
        because discoveries get corrected. You do not want provenance systems
        that only handle perfect histories. You want them to handle revised
        histories honestly."

        Amendment creates an audit record — the original chain is preserved
        in the amendments list. The corrected version becomes the active chain.

        Parameters
        ----------
        reason:      Why the amendment is being made.
        correction:  New chain to replace this one (or None for meta-only).
        amended_by:  Who made the amendment.

        Returns
        -------
        New ProvenanceChain with amendment recorded.
        """
        amendment_record = {
            "timestamp":    time.time(),
            "reason":       reason,
            "amended_by":   amended_by,
            "prior_hash":   self.chain_hash(),
            "prior_level":  self.level.value,
            "prior_links":  len(self.links),
        }
        new_amendments = list(self.amendments) + [amendment_record]

        if correction is not None:
            # Replace chain with correction, preserve history
            result = ProvenanceChain(
                links=list(correction.links),
                level=correction.level,
                amendments=new_amendments,
            )
        else:
            # Meta-only amendment — chain content unchanged
            result = ProvenanceChain(
                links=list(self.links),
                level=self.level,
                amendments=new_amendments,
            )
        return result

    def amendment_history(self) -> List[Dict]:
        """Return the full amendment history. Empty if never amended."""
        return list(self.amendments)


# ─── REPLAY PROVENANCE LINK ──────────────────────────────────────────────────

@dataclass(frozen=True)
class ReplayProvenanceLink(ProvenanceLink):
    """
    A provenance link for replayed Chronicle entries.

    IC-3 partial: when Labyrinth-OS replays from the Chronicle ledger,
    replayed proposals must carry explicit marking that they are replays,
    not fresh inferences. This prevents a replayed proposal from being
    treated as a new live inference.

    Inherits all ProvenanceLink fields. Adds replay-specific metadata.
    """
    replay_from_session: str = ""
    replay_from_seq:     int = 0
    replay_reason:       str = "audit"   # "audit", "verification", "correction"

    def to_dict(self):
        d = super().to_dict()
        d.update({
            "replay_from_session": self.replay_from_session,
            "replay_from_seq":     self.replay_from_seq,
            "replay_reason":       self.replay_reason,
            "is_replay":           True,
        })
        return d


# ─── MODEL FINGERPRINT ────────────────────────────────────────────────────────

def compute_model_fingerprint(
    provider: str,
    model: str,
    session_id: str,
    signing_key: Optional[bytes] = None,
) -> str:
    """
    Compute an IC-1 model fingerprint.

    Without signing_key: SHA-256 of provider:model:session (DECLARED level).
    With signing_key: HMAC-SHA256 (SIGNED level — requires A018).

    Parameters
    ----------
    provider:    Provider name (e.g. "anthropic", "openai", "ollama").
    model:       Model identifier (e.g. "claude-3-5-sonnet-20241022").
    session_id:  Ignition session ID for uniqueness.
    signing_key: Optional 32-byte EDEN signing key for SIGNED level.

    Returns
    -------
    16-char hex fingerprint.
    """
    content = f"{provider}:{model}:{session_id}"
    if signing_key is not None:
        import hmac as _hmac
        return _hmac.new(signing_key, content.encode(), "sha256").hexdigest()[:16]
    return hashlib.sha256(content.encode()).hexdigest()[:16]


def fingerprint_level(signing_key: Optional[bytes] = None) -> ProvenanceLevel:
    """What level is a fingerprint computed with this signing_key?"""
    if signing_key is not None:
        return ProvenanceLevel.SIGNED
    return ProvenanceLevel.DECLARED


# ─── PROVENANCE EVALUATOR ─────────────────────────────────────────────────────

@dataclass
class ProvenanceEvaluation:
    """Result of evaluating a proposal's provenance."""
    chain:           ProvenanceChain
    fingerprint:     str
    level:           ProvenanceLevel
    is_suspect:      bool
    reasons:         List[str]
    recommendation:  str    # "ALLOW", "WARN", "BLOCK"


def evaluate_provenance(
    provenance_chain_str: str,
    model_fingerprint: str,
    require_level: ProvenanceLevel = ProvenanceLevel.DECLARED,
) -> ProvenanceEvaluation:
    """
    Evaluate a proposal's provenance against the required level.

    This is the gate-side provenance check. The adversarial load suite's
    POLITE_LIE detection calls this logic (IC-2 layer).

    Parameters
    ----------
    provenance_chain_str: Raw provenance_chain string from IgnitionEntry.
    model_fingerprint:    Raw model_fingerprint string from IgnitionEntry.
    require_level:        Minimum acceptable provenance level.

    Returns
    -------
    ProvenanceEvaluation with recommendation.
    """
    chain = ProvenanceChain.from_json(provenance_chain_str)
    reasons: List[str] = []

    # Check model fingerprint
    if not model_fingerprint:
        reasons.append("IC1_MISSING: no model fingerprint")
    elif len(model_fingerprint) < 8:
        reasons.append(f"IC1_MALFORMED: fingerprint too short: {model_fingerprint}")

    # Check provenance chain
    if chain.is_suspect():
        reasons.append("IC2_UNVERIFIED: provenance chain is unverified or empty")

    if chain.links:
        if not chain.provider:
            reasons.append("IC2_NO_PROVIDER: no provider link in chain")
        if not chain.model:
            reasons.append("IC2_NO_MODEL: no model link in chain")

    # Level check
    level_order = [ProvenanceLevel.UNVERIFIED, ProvenanceLevel.DECLARED,
                   ProvenanceLevel.SIGNED, ProvenanceLevel.ATTESTED]
    chain_level_idx = level_order.index(chain.level)
    required_idx = level_order.index(require_level)

    if chain_level_idx < required_idx:
        reasons.append(
            f"IC2_LEVEL_INSUFFICIENT: {chain.level.value} < required {require_level.value}"
        )

    # Determine recommendation
    if not reasons:
        recommendation = "ALLOW"
    elif any("UNVERIFIED" in r or "MISSING" in r for r in reasons):
        recommendation = "WARN"   # Warn but don't block — IC is still partial
    else:
        recommendation = "WARN"

    return ProvenanceEvaluation(
        chain=chain,
        fingerprint=model_fingerprint,
        level=chain.level,
        is_suspect=bool(reasons),
        reasons=reasons,
        recommendation=recommendation,
    )


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_provenance_level_unverified_by_default() -> bool:
    chain = ProvenanceChain()
    assert chain.level == ProvenanceLevel.UNVERIFIED
    assert chain.is_suspect()
    return True


def _test_declared_chain_not_suspect() -> bool:
    chain = ProvenanceChain()
    chain.add_link("provider", "anthropic")
    chain.add_link("model", "claude-3-5-sonnet")
    chain.add_link("session", "sess-001")
    assert chain.level == ProvenanceLevel.DECLARED
    assert not chain.is_suspect()
    return True


def _test_chain_serialization_roundtrip() -> bool:
    chain = ProvenanceChain()
    chain.add_link("provider", "anthropic")
    chain.add_link("model", "claude-3-5")
    j = chain.to_json()
    chain2 = ProvenanceChain.from_json(j)
    assert chain2.provider == "anthropic"
    assert chain2.model == "claude-3-5"
    return True


def _test_legacy_format_parses() -> bool:
    legacy = '["provider:anthropic", "model:claude-3-5", "session:abc123"]'
    chain = ProvenanceChain.from_json(legacy)
    assert chain.provider == "anthropic"
    assert not chain.is_suspect()
    return True


def _test_unverified_string_parses() -> bool:
    chain = ProvenanceChain.from_json("unverified")
    assert chain.is_suspect()
    assert chain.level == ProvenanceLevel.UNVERIFIED
    return True


def _test_compute_fingerprint_deterministic() -> bool:
    fp1 = compute_model_fingerprint("anthropic", "claude-3-5", "sess-001")
    fp2 = compute_model_fingerprint("anthropic", "claude-3-5", "sess-001")
    assert fp1 == fp2
    assert len(fp1) == 16
    return True


def _test_different_sessions_different_fingerprints() -> bool:
    fp1 = compute_model_fingerprint("anthropic", "claude-3-5", "sess-001")
    fp2 = compute_model_fingerprint("anthropic", "claude-3-5", "sess-002")
    assert fp1 != fp2
    return True


def _test_signed_fingerprint_different_from_unsigned() -> bool:
    key = b"test-signing-key-32bytes-exactly!!"[:32]
    fp_unsigned = compute_model_fingerprint("anthropic", "claude", "s1")
    fp_signed   = compute_model_fingerprint("anthropic", "claude", "s1", key)
    assert fp_unsigned != fp_signed
    return True


def _test_evaluate_provenance_clean() -> bool:
    chain = ProvenanceChain()
    chain.add_link("provider", "anthropic")
    chain.add_link("model", "claude-3-5")
    chain.add_link("session", "sess-001")
    fp = compute_model_fingerprint("anthropic", "claude-3-5", "sess-001")
    result = evaluate_provenance(chain.to_json(), fp)
    assert result.recommendation == "ALLOW"
    assert not result.is_suspect
    return True


def _test_evaluate_provenance_polite_lie() -> bool:
    """POLITE_LIE: valid fingerprint but provenance_chain='unverified'."""
    fp = compute_model_fingerprint("anthropic", "claude-3-5", "sess-001")
    result = evaluate_provenance("unverified", fp)
    assert result.is_suspect
    assert any("IC2_UNVERIFIED" in r for r in result.reasons)
    return True


def _test_evaluate_missing_fingerprint() -> bool:
    chain = ProvenanceChain()
    chain.add_link("provider", "anthropic")
    result = evaluate_provenance(chain.to_json(), "")
    assert result.is_suspect
    assert any("IC1_MISSING" in r for r in result.reasons)
    return True


def _test_chain_hash_stable() -> bool:
    chain = ProvenanceChain()
    chain.add_link("provider", "anthropic")
    h1 = chain.chain_hash()
    h2 = chain.chain_hash()
    assert h1 == h2
    return True



def _test_rich_link_source_type() -> bool:
    chain = ProvenanceChain()
    chain.add_link("provider", "anthropic", source_type="cloud_api",
                   confidence_origin=0.95)
    link = chain.links[0]
    assert link.source_type == "cloud_api"
    assert link.confidence_origin == 0.95
    d = link.to_dict()
    assert "source_type" in d
    assert "confidence_origin" in d
    return True


def _test_rich_link_confidence() -> bool:
    chain = ProvenanceChain()
    chain.add_link("provider", "anthropic", source_type="cloud_api",
                   confidence_origin=0.70)
    chain.add_link("model", "claude", source_type="cloud_api",
                   confidence_origin=0.95)
    # Both links are DECLARED — chain level stays DECLARED
    assert chain.level == ProvenanceLevel.DECLARED
    return True


def _test_chain_amendment_preserves_history() -> bool:
    chain = ProvenanceChain()
    chain.add_link("provider", "anthropic")
    original_hash = chain.chain_hash()
    original_link_count = len(chain.links)

    amended = chain.amend("Correcting provider name", amended_by="operator")

    # Amendment records the prior state
    assert amended.revision_count == 1
    history = amended.amendment_history()
    assert history[0]["prior_hash"] == original_hash
    assert history[0]["prior_links"] == original_link_count
    assert history[0]["amended_by"] == "operator"
    assert history[0]["reason"] == "Correcting provider name"
    return True


def _test_amendment_roundtrip() -> bool:
    chain = ProvenanceChain()
    chain.add_link("provider", "anthropic")
    amended = chain.amend("Test amendment")
    j = amended.to_json()
    loaded = ProvenanceChain.from_json(j)
    assert loaded.revision_count == 1
    assert loaded.amendment_history()[0]["reason"] == "Test amendment"
    return True


def _test_correction_replaces_chain() -> bool:
    original = ProvenanceChain()
    original.add_link("provider", "wrong-provider")

    correction = ProvenanceChain()
    correction.add_link("provider", "anthropic")
    correction.add_link("model", "claude-3-5")

    amended = original.amend("Provider was wrong", correction=correction)
    assert amended.provider == "anthropic"
    assert amended.model == "claude-3-5"
    assert amended.revision_count == 1
    # Original content preserved in amendment record
    history = amended.amendment_history()
    assert history[0]["prior_links"] == 1
    return True


def _test_revision_count() -> bool:
    chain = ProvenanceChain()
    assert chain.revision_count == 0
    a1 = chain.amend("First amendment")
    assert a1.revision_count == 1
    a2 = a1.amend("Second amendment")
    assert a2.revision_count == 2
    return True


def _test_source_types_known() -> bool:
    for key in ["cloud_api", "local_model", "replay_system", "synthetic",
                "imported_dataset", "human_input", "hardware_sensor", "unknown"]:
        assert key in SOURCE_TYPES, f"Missing source type: {key}"
    return True


def run_tests():
    tests = [
        (_test_provenance_level_unverified_by_default, "unverified_default"),
        (_test_declared_chain_not_suspect,             "declared_not_suspect"),
        (_test_chain_serialization_roundtrip,          "serialization_roundtrip"),
        (_test_legacy_format_parses,                   "legacy_format"),
        (_test_unverified_string_parses,               "unverified_string"),
        (_test_compute_fingerprint_deterministic,      "fingerprint_deterministic"),
        (_test_different_sessions_different_fingerprints, "different_sessions"),
        (_test_signed_fingerprint_different_from_unsigned, "signed_vs_unsigned"),
        (_test_evaluate_provenance_clean,              "evaluate_clean"),
        (_test_evaluate_provenance_polite_lie,         "evaluate_polite_lie"),
        (_test_evaluate_missing_fingerprint,           "evaluate_missing_fp"),
        (_test_chain_hash_stable,                      "chain_hash_stable"),
        # New tests for J54 extensions
        (_test_rich_link_source_type,                  "rich_link_source_type"),
        (_test_rich_link_confidence,                   "rich_link_confidence"),
        (_test_chain_amendment_preserves_history,      "amendment_preserves_history"),
        (_test_amendment_roundtrip,                    "amendment_roundtrip"),
        (_test_correction_replaces_chain,              "correction_replaces_chain"),
        (_test_revision_count,                         "revision_count"),
        (_test_source_types_known,                     "source_types_known"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
