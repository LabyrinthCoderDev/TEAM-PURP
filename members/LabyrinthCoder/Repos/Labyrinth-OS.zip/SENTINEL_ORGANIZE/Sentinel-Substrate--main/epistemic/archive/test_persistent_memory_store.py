# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          test_persistent_memory_store.py — Labyrinth-OS
# ----------------------------------------------------------------------------

"""
test_persistent_memory_store.py — Labyrinth-OS
Tests for PersistentMemoryStore: SQLite persistence, similarity search,
risk estimation, feature weight learning.
"""
from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'epistemic', 'archive'))

from memory_store import (
    PersistentMemoryStore, MemoryStore, SimilarityResult,
    _FeatureWeightLearner, EntryType, _FEATURE_NAMES
)


def _test_persistent_store_constructs() -> None:
    store = PersistentMemoryStore()
    assert isinstance(store, MemoryStore)


def _test_persistent_store_append_indexes() -> None:
    store = PersistentMemoryStore()
    store.append(EntryType.LABEL, "lbl-001",
                 {"confidence": 0.92, "tau_escape": 0.88, "outcome": "EXECUTED"})
    assert len(store._feature_index) == 1


def _test_persistent_store_find_similar_empty() -> None:
    store = PersistentMemoryStore()
    results = store.find_similar(confidence=0.85)
    assert results == []


def _test_persistent_store_find_similar_returns_results() -> None:
    store = PersistentMemoryStore()
    for i in range(5):
        store.append(EntryType.LABEL, f"lbl-{i:03d}",
                     {"confidence": 0.80 + i*0.02, "tau_escape": 0.80,
                      "chi": 0.10, "drift": 0.05, "betti_1": 0.02,
                      "outcome": "EXECUTED"})
    results = store.find_similar(confidence=0.85, tau_escape=0.80, top_k=3)
    assert len(results) == 3
    assert results[0].similarity >= results[-1].similarity


def _test_persistent_store_results_sorted_descending() -> None:
    store = PersistentMemoryStore()
    for i in range(8):
        store.append(EntryType.LABEL, f"lbl-{i:03d}",
                     {"confidence": 0.70 + i*0.03, "tau_escape": 0.75,
                      "outcome": "EXECUTED" if i % 2 == 0 else "BLOCKED"})
    results = store.find_similar(confidence=0.85, top_k=5)
    for j in range(len(results)-1):
        assert results[j].similarity >= results[j+1].similarity


def _test_persistent_store_risk_no_history() -> None:
    store = PersistentMemoryStore()
    risk = store.risk_estimate(confidence=0.85)
    assert risk["recommendation"] == "no_history"
    assert risk["sample_count"] == 0
    assert risk["estimated_success_rate"] is None


def _test_persistent_store_risk_with_history() -> None:
    store = PersistentMemoryStore()
    for i in range(10):
        out = "EXECUTED" if i < 8 else "BLOCKED"
        store.append(EntryType.LABEL, f"lbl-{i:03d}",
                     {"confidence": 0.85, "tau_escape": 0.80, "outcome": out})
    risk = store.risk_estimate(confidence=0.85)
    assert risk["estimated_success_rate"] is not None
    assert risk["recommendation"] in ("proceed", "caution", "likely_block")


def _test_persistent_store_sqlite_survives_restart() -> None:
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        db_path = os.path.join(td, "test_index.db")
        store1 = PersistentMemoryStore(index_path=db_path)
        store1.append(EntryType.LABEL, "lbl-persist",
                      {"confidence": 0.90, "tau_escape": 0.82, "outcome": "EXECUTED"})
        n_before = len(store1._feature_index)
        store2 = PersistentMemoryStore(index_path=db_path)
        n_after = len(store2._feature_index)
        assert n_before == n_after == 1


def _test_similarity_result_is_frozen() -> None:
    r = SimilarityResult(
        entry_id=1, label_id="lbl-001", entry_type="LABEL",
        similarity=0.95, outcome="EXECUTED", confidence=0.90
    )
    try:
        r.similarity = 0.5  # type: ignore[misc]
        assert False, "Should raise on frozen dataclass assignment"
    except Exception:
        pass  # expected — frozen dataclass raises FrozenInstanceError or AttributeError


def _test_feature_weight_learner_uniform_initially() -> None:
    learner = _FeatureWeightLearner()
    weights = learner.weights()
    n = len(_FEATURE_NAMES)
    assert len(weights) == n
    for w in weights:
        assert abs(w - 1.0/n) < 1e-9


def _test_feature_weight_learner_updates_with_history() -> None:
    learner = _FeatureWeightLearner()
    # Add enough samples to trigger recompute
    for _ in range(20):
        learner.update([0.9, 0.85, 0.05, 0.03, 0.01], succeeded=True)
        learner.update([0.4, 0.40, 0.35, 0.15, 0.04], succeeded=False)
    weights = learner.weights()
    assert abs(sum(weights) - 1.0) < 1e-6  # weights sum to 1


def run_tests() -> tuple[int, int, list]:
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0]
    )
    passed = failed = 0
    results = []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results
