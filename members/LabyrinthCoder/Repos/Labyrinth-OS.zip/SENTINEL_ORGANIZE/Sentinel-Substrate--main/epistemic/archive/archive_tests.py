# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          archive_tests.py — Labyrinth-OS / Epistemic Archive Layer (L5.5)
# ----------------------------------------------------------------------------

"""
archive_tests.py — Labyrinth-OS / Epistemic Archive Layer (L5.5)
================================================================
Unit tests for the archive memory layer.

Run with:
    python -m pytest epistemic/archive/archive_tests.py -v
"""

from __future__ import annotations

import time
import unittest

from memory_store import MemoryStore, ArchiveEntry, EntryType
from pattern_catalog import PatternCatalog, PatternIndex
from confidence_record import ConfidenceRecord, LabelOutcome
from recall_protocol import RecallProtocol, RecallResult


# ─── MEMORY STORE TESTS ───────────────────────────────────────────────────────

class TestMemoryStore(unittest.TestCase):

    def setUp(self):
        self.store = MemoryStore()

    def test_append_returns_entry(self):
        entry = self.store.append(
            entry_type=EntryType.LABEL,
            label_id="lbl-001",
            payload={"category": "VALID"},
        )
        self.assertIsInstance(entry, ArchiveEntry)
        self.assertEqual(entry.entry_id, 1)
        self.assertEqual(entry.entry_type, EntryType.LABEL)

    def test_sequential_entry_ids(self):
        for i in range(5):
            e = self.store.append(EntryType.LABEL, f"lbl-{i}", {})
        self.assertEqual(e.entry_id, 5)

    def test_chain_is_valid_after_appends(self):
        for i in range(10):
            self.store.append(EntryType.ANOMALY, None, {"i": i})
        self.assertTrue(self.store.verify())

    def test_verify_empty_store(self):
        self.assertTrue(self.store.verify())

    def test_count_matches_appends(self):
        for _ in range(7):
            self.store.append(EntryType.OUTCOME, "lbl-x", {})
        self.assertEqual(self.store.count(), 7)

    def test_tip_hash_changes_with_appends(self):
        h1 = self.store.tip_hash()
        self.store.append(EntryType.LABEL, "lbl-001", {})
        h2 = self.store.tip_hash()
        self.assertNotEqual(h1, h2)

    def test_query_by_entry_type(self):
        self.store.append(EntryType.LABEL, "lbl-001", {})
        self.store.append(EntryType.ANOMALY, None, {})
        self.store.append(EntryType.LABEL, "lbl-002", {})
        labels = self.store.query(entry_type=EntryType.LABEL)
        self.assertEqual(len(labels), 2)

    def test_query_by_label_id(self):
        self.store.append(EntryType.LABEL, "lbl-A", {})
        self.store.append(EntryType.LABEL, "lbl-B", {})
        self.store.append(EntryType.OUTCOME, "lbl-A", {})
        results = self.store.query(label_id="lbl-A")
        self.assertEqual(len(results), 2)

    def test_query_since(self):
        self.store.append(EntryType.LABEL, "lbl-001", {}, timestamp=100.0)
        self.store.append(EntryType.LABEL, "lbl-002", {}, timestamp=200.0)
        self.store.append(EntryType.LABEL, "lbl-003", {}, timestamp=300.0)
        results = self.store.query(since=150.0)
        self.assertEqual(len(results), 2)

    def test_query_limit(self):
        for i in range(10):
            self.store.append(EntryType.LABEL, f"lbl-{i}", {})
        results = self.store.query(limit=3)
        self.assertEqual(len(results), 3)

    def test_append_only_no_delete(self):
        """MemoryStore has no delete/modify methods."""
        self.assertFalse(hasattr(self.store, "delete"))
        self.assertFalse(hasattr(self.store, "remove"))
        self.assertFalse(hasattr(self.store, "modify"))

    def test_genesis_hash_for_empty_store(self):
        self.assertEqual(self.store.tip_hash(), MemoryStore.GENESIS_HASH)


# ─── PATTERN CATALOG TESTS ────────────────────────────────────────────────────

class TestPatternCatalog(unittest.TestCase):

    def setUp(self):
        self.catalog = PatternCatalog()

    def test_record_occurrence_creates_index(self):
        idx = self.catalog.record_occurrence("VALID", "council", "hash-abc", 0.90)
        self.assertEqual(idx.occurrences, 1)
        self.assertEqual(idx.category, "VALID")

    def test_record_multiple_occurrences(self):
        for _ in range(5):
            idx = self.catalog.record_occurrence("VALID", "council", "hash-abc", 0.90)
        self.assertEqual(idx.occurrences, 5)

    def test_success_rate_without_outcomes(self):
        idx = self.catalog.record_occurrence("VALID", "council", "hash-abc", 0.90)
        self.assertAlmostEqual(idx.success_rate, 0.5)

    def test_record_outcome_success(self):
        self.catalog.record_occurrence("VALID", "council", "hash-abc", 0.90)
        idx = self.catalog.record_outcome("VALID", "council", "hash-abc", success=True)
        self.assertEqual(idx.successes, 1)
        self.assertAlmostEqual(idx.success_rate, 1.0)

    def test_record_outcome_failure(self):
        self.catalog.record_occurrence("VALID", "council", "hash-abc", 0.90)
        idx = self.catalog.record_outcome("VALID", "council", "hash-abc", success=False)
        self.assertEqual(idx.failures, 1)
        self.assertAlmostEqual(idx.success_rate, 0.0)

    def test_query_by_category(self):
        self.catalog.record_occurrence("VALID", "council", "hash-1", 0.90)
        self.catalog.record_occurrence("REJECTED", "watcher_a", "hash-2", 0.30)
        results = self.catalog.query(category="VALID")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].category, "VALID")

    def test_query_min_occurrences(self):
        self.catalog.record_occurrence("VALID", "council", "hash-1", 0.90)
        for _ in range(3):
            self.catalog.record_occurrence("VALID", "council", "hash-2", 0.85)
        results = self.catalog.query(min_occurrences=2)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].content_prefix, "hash-2")

    def test_lookup_returns_none_for_unknown(self):
        result = self.catalog.lookup("VALID", "council", "nonexistent")
        self.assertIsNone(result)

    def test_size(self):
        self.catalog.record_occurrence("VALID", "A", "x", 0.9)
        self.catalog.record_occurrence("VALID", "B", "y", 0.8)
        self.assertEqual(self.catalog.size(), 2)


# ─── CONFIDENCE RECORD TESTS ─────────────────────────────────────────────────

class TestConfidenceRecord(unittest.TestCase):

    def setUp(self):
        self.record = ConfidenceRecord()

    def test_accuracy_neutral_when_empty(self):
        self.assertAlmostEqual(self.record.accuracy(), 0.5)

    def test_record_prediction_and_outcome(self):
        self.record.record_prediction("lbl-001", 0.92)
        obs = self.record.record_outcome("lbl-001", LabelOutcome.SUCCESS)
        self.assertIsNotNone(obs)
        self.assertTrue(obs.confidence_was_right)

    def test_high_confidence_correct_on_success(self):
        self.record.record_prediction("lbl-002", 0.95)
        obs = self.record.record_outcome("lbl-002", LabelOutcome.SUCCESS)
        self.assertTrue(obs.confidence_was_right)

    def test_high_confidence_wrong_on_failure(self):
        self.record.record_prediction("lbl-003", 0.95)
        obs = self.record.record_outcome("lbl-003", LabelOutcome.FAILURE)
        self.assertFalse(obs.confidence_was_right)

    def test_low_confidence_correct_on_failure(self):
        self.record.record_prediction("lbl-004", 0.30)
        obs = self.record.record_outcome("lbl-004", LabelOutcome.FAILURE)
        self.assertTrue(obs.confidence_was_right)

    def test_accuracy_improves_with_correct_predictions(self):
        for i in range(10):
            lid = f"lbl-a{i}"
            self.record.record_prediction(lid, 0.95)
            self.record.record_outcome(lid, LabelOutcome.SUCCESS)
        self.assertGreater(self.record.accuracy(), 0.9)

    def test_trend_stable_by_default(self):
        self.assertEqual(self.record.trend("unknown-label"), "STABLE")

    def test_trend_improving(self):
        # old half: failures, new half: successes
        for i in range(5):
            lid = f"lbl-t{i}"
            self.record.record_prediction(lid, 0.95)
            self.record.record_outcome(lid, LabelOutcome.FAILURE)
        for i in range(5, 10):
            lid = f"lbl-t{i}"
            self.record.record_prediction(lid, 0.95)
            self.record.record_outcome(lid, LabelOutcome.SUCCESS)
        # All under the same label for trend analysis
        cr2 = ConfidenceRecord()
        for i in range(5):
            cr2.record_prediction("lbl-trend", 0.95)
            cr2.record_outcome("lbl-trend", LabelOutcome.FAILURE)
        for i in range(5):
            cr2.record_prediction("lbl-trend", 0.95)
            cr2.record_outcome("lbl-trend", LabelOutcome.SUCCESS)
        self.assertIn(cr2.trend("lbl-trend"), ("IMPROVING", "STABLE"))

    def test_outcome_returns_none_without_prediction(self):
        obs = self.record.record_outcome("lbl-nopred", LabelOutcome.SUCCESS)
        self.assertIsNone(obs)


# ─── RECALL PROTOCOL TESTS ───────────────────────────────────────────────────

class TestRecallProtocol(unittest.TestCase):

    def setUp(self):
        self.store = MemoryStore()
        self.catalog = PatternCatalog()
        self.recall = RecallProtocol(self.store, self.catalog)

    def test_empty_catalog_returns_neutral(self):
        result = self.recall.similar_patterns("VALID")
        self.assertAlmostEqual(result.historical_success, 0.5)
        self.assertEqual(result.recommendation, "CAUTION")

    def test_high_success_rate_recommends_promote(self):
        for _ in range(5):
            self.catalog.record_occurrence("VALID", "council", "hash-abc", 0.90)
            self.catalog.record_outcome("VALID", "council", "hash-abc", success=True)
        result = self.recall.similar_patterns("VALID", min_occurrences=2)
        self.assertEqual(result.recommendation, "PROMOTE")

    def test_low_success_rate_recommends_block(self):
        for _ in range(5):
            self.catalog.record_occurrence("VALID", "council", "hash-abc", 0.90)
            self.catalog.record_outcome("VALID", "council", "hash-abc", success=False)
        result = self.recall.similar_patterns("VALID", min_occurrences=2)
        self.assertEqual(result.recommendation, "BLOCK")

    def test_recent_anomalies(self):
        self.store.append(EntryType.ANOMALY, None, {"metric": "drift"})
        anomalies = self.recall.recent_anomalies()
        self.assertEqual(len(anomalies), 1)

    def test_promotions_for_label(self):
        self.store.append(EntryType.PROMOTION, "lbl-001", {"approved_by": "steward"})
        promos = self.recall.promotions_for_label("lbl-001")
        self.assertEqual(len(promos), 1)

    def test_no_contradiction_for_new_pattern(self):
        result = self.recall.has_contradicting_rejection("VALID", "council", "new-content")
        self.assertFalse(result)

    def test_contradiction_for_repeatedly_failed_pattern(self):
        for _ in range(3):
            self.catalog.record_occurrence("VALID", "council", "bad-hash", 0.90)
            self.catalog.record_outcome("VALID", "council", "bad-hash", success=False)
        self.assertTrue(
            self.recall.has_contradicting_rejection("VALID", "council", "bad-hash")
        )



def run_tests() -> tuple:
    """Labyrinth-OS standard runner — wraps unittest for run_all.py compatibility."""
    import unittest, io
    loader = unittest.TestLoader()
    suite  = loader.loadTestsFromModule(__import__(__name__))
    buf    = io.StringIO()
    runner = unittest.TextTestRunner(stream=buf, verbosity=0)
    result = runner.run(suite)
    passed = result.testsRun - len(result.failures) - len(result.errors)
    failed = len(result.failures) + len(result.errors)
    results = []
    for test, tb in result.failures + result.errors:
        results.append((str(test), "FAIL", tb.split("\n")[-2]))
    for i in range(passed):
        results.append((f"test_{i:03}", "PASS", None))
    return passed, failed, results


if __name__ == "__main__":
    import unittest
    unittest.main()
