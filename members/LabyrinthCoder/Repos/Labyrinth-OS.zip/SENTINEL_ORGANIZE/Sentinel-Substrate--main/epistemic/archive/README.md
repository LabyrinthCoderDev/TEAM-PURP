# Archive Memory — Labyrinth-OS / Epistemic L5.5

## Purpose

The archive is the **epistemic memory** of Labyrinth-OS.  It records every
sealed label, promotion decision, anomaly, and real-world outcome in an
append-only, SHA-256-chained store — analogous to the Ledger (L13) but for
epistemics.

## Position in the Architecture

```
Labeling (L3.5) → Archive (L5.5) → Promotion (L6.5) → Reality Gate
                      ↑
              Observability (L5.75)
```

## Invariants

- **I12** — Archive Integrity: append-only, SHA-256-chained, no modification.
- **I6**  — Ledger Immutability applies symmetrically here.
- **I10** — Fail Closed: any chain verification failure → TAMPERED verdict.

## Modules

| File | Role |
|------|------|
| `memory_store.py` | Append-only SHA-256-chained store |
| `pattern_catalog.py` | Indexed pattern library (success rates, trends) |
| `confidence_record.py` | Historical label accuracy tracking |
| `recall_protocol.py` | Unified query interface |
| `archive_tests.py` | Unit tests |

## Entry Types

| Type | Meaning |
|------|---------|
| `LABEL` | Sealed LabelRecord |
| `PROMOTION` | Promotion decision |
| `REJECTION` | Reality Gate rejection |
| `ANOMALY` | Observability anomaly |
| `OUTCOME` | Real-world outcome of a promoted label |

## Non-Negotiable Rules

1. No entry may be deleted or modified.
2. Chain verification (`store.verify()`) must pass at all times.
3. Every label promotion must be written to the archive before Reality Gate entry.
4. Outcome records must be written when an outcome is observed.
