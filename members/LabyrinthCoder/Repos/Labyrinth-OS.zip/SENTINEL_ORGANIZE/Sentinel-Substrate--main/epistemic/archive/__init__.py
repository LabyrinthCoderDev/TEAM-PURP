# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          epistemic/archive — Labyrinth-OS / Epistemic Layer L5.5
# ----------------------------------------------------------------------------

"""
epistemic/archive — Labyrinth-OS / Epistemic Layer L5.5
========================================================
Archive memory: append-only epistemic record, pattern catalog,
historical confidence tracking, and recall protocol.

Exports:
    MemoryStore        — append-only SHA-256-chained record
    PatternCatalog     — indexed pattern library
    ConfidenceRecord   — historical label accuracy tracking
    RecallProtocol     — query interface for past patterns
"""

from memory_store import MemoryStore, ArchiveEntry
from pattern_catalog import PatternCatalog, PatternIndex
from confidence_record import ConfidenceRecord, LabelOutcome
from recall_protocol import RecallProtocol, RecallResult

__all__ = [
    "MemoryStore",
    "ArchiveEntry",
    "PatternCatalog",
    "PatternIndex",
    "ConfidenceRecord",
    "LabelOutcome",
    "RecallProtocol",
    "RecallResult",
]
