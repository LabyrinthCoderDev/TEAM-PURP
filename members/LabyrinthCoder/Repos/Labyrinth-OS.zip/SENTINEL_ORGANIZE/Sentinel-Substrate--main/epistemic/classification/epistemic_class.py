# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          epistemic_class.py — Labyrinth-OS / Lane 1 / L01
# ----------------------------------------------------------------------------

"""
epistemic_class.py — Labyrinth-OS / Lane 1 / L01
=================================================
TCP Truth-Class Schema — Epistemic Classification for Proposals

Every ProposalNode receives a typed EpistemicClass before it enters
promotion evaluation. This adds a second axis to promotion beyond
confidence score alone.

Design:
  Confidence alone can be high even when reasoning is structurally
  broken. EpistemicClass captures HOW a proposal knows what it claims
  to know — not just how confident it is.

  A Hypothetical proposal with high confidence still needs a higher
  confidence floor before promotion, or routes to deferred exploration.
  An Ambiguous proposal blocks promotion pending clarification.

Truth-class ladder (from Quillan TCP, implemented natively):
  EMPIRICALLY_VERIFIED   — directly corroborated by external verifiable source
  INFERRED               — logically deduced from verified or plausible inputs
  COHERENTLY_SYNTHESIZED — internally consistent, no external grounding
  HYPOTHETICAL           — exploratory, preliminary, subject to falsification
  AMBIGUOUS              — high uncertainty, requires clarification before promotion

Integration points:
  - L01 ProposalNode: receives EpistemicClass at intake
  - L08 PromotionProtocol: checks class before confidence floor
  - L07 DeferredExplorationNode: receives HYPOTHETICAL/AMBIGUOUS routing
  - L06 ArchiveMemory: stores class as part of episode record

Quillan reference:
  archive/external_references/quillan/ASSESSMENT_quillan.md
  Section: TCP Truth-Class Schema
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, Optional


# ─── EPISTEMIC CLASS ─────────────────────────────────────────────────────────

@unique
class EpistemicClass(str, Enum):
    """
    Typed epistemic classification for proposals.

    Assigned at L01 intake. Governs promotion eligibility and
    routing decisions at L08 PromotionProtocol.
    """
    EMPIRICALLY_VERIFIED   = "EMPIRICALLY_VERIFIED"
    INFERRED               = "INFERRED"
    COHERENTLY_SYNTHESIZED = "COHERENTLY_SYNTHESIZED"
    HYPOTHETICAL           = "HYPOTHETICAL"
    AMBIGUOUS              = "AMBIGUOUS"


# ─── CONFIDENCE FLOORS BY CLASS ──────────────────────────────────────────────

# Each class has a minimum confidence floor for promotion.
# Higher epistemic uncertainty requires higher confidence to compensate.
# These are defaults — domain adapters may tighten them.

CONFIDENCE_FLOOR_BY_CLASS: Dict[EpistemicClass, float] = {
    EpistemicClass.EMPIRICALLY_VERIFIED:   0.70,  # external grounding, lower bar
    EpistemicClass.INFERRED:               0.75,  # standard floor
    EpistemicClass.COHERENTLY_SYNTHESIZED: 0.80,  # no external grounding, higher bar
    EpistemicClass.HYPOTHETICAL:           0.90,  # exploratory, needs strong confidence
    EpistemicClass.AMBIGUOUS:              1.01,  # blocks promotion — above maximum
}

# Classes that route to DeferredExplorationNode instead of promotion
DEFERRED_CLASSES = {
    EpistemicClass.HYPOTHETICAL,
    EpistemicClass.AMBIGUOUS,
}

# Maximum valid confidence score (from Labyrinth-OS sigma_anchors.py)
CONFIDENCE_CAP = 0.99


# ─── EPISTEMIC LABEL ─────────────────────────────────────────────────────────

@dataclass(frozen=True)
class EpistemicLabel:
    """
    Immutable epistemic classification attached to a ProposalNode.

    Produced at L01. Carried through the pipeline.
    Stored in ArchiveMemory as part of the episode record.
    """
    proposal_id:      str
    epistemic_class:  EpistemicClass
    confidence_floor: float          # floor for this proposal's class
    is_promotable:    bool           # False = route to deferred
    is_ambiguous:     bool           # True = requires clarification
    assigned_at:      float          # timestamp
    basis:            str            # how the class was determined
    metadata:         Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "proposal_id":      self.proposal_id,
            "epistemic_class":  self.epistemic_class.value,
            "confidence_floor": self.confidence_floor,
            "is_promotable":    self.is_promotable,
            "is_ambiguous":     self.is_ambiguous,
            "assigned_at":      self.assigned_at,
            "basis":            self.basis,
            "metadata":         self.metadata,
        }


# ─── CLASSIFIER ──────────────────────────────────────────────────────────────

class EpistemicClassifier:
    """
    Assigns EpistemicClass to a proposal at L01 intake.

    Classification is based on:
      1. Explicit class provided by the proposal generator (if any)
      2. Presence of external citations or verified sources
      3. Reasoning chain characteristics (if available)
      4. Default fallback: COHERENTLY_SYNTHESIZED (conservative)

    The classifier does NOT set confidence. It sets the floor
    that confidence must clear for promotion.
    """

    def classify(
        self,
        proposal_id: str,
        proposal_content: str,
        has_external_sources: bool = False,
        has_citations: bool = False,
        is_exploratory: bool = False,
        has_unresolved_ambiguity: bool = False,
        explicit_class: Optional[EpistemicClass] = None,
        basis: str = "auto",
    ) -> EpistemicLabel:
        """
        Classify a proposal and return an EpistemicLabel.

        Parameters:
          proposal_id            — unique identifier
          proposal_content       — raw proposal text (used for heuristics)
          has_external_sources   — proposal cites verifiable external sources
          has_citations          — proposal includes citations
          is_exploratory         — proposal is explicitly exploratory/hypothetical
          has_unresolved_ambiguity — proposal contains unresolved ambiguity
          explicit_class         — override: caller explicitly sets the class
          basis                  — description of how class was determined
        """
        # Explicit override takes precedence
        if explicit_class is not None:
            ec = explicit_class
            basis = f"explicit:{basis}"

        # Ambiguity blocks promotion regardless of other signals
        elif has_unresolved_ambiguity:
            ec = EpistemicClass.AMBIGUOUS
            basis = "unresolved_ambiguity"

        # Exploratory proposals are hypothetical
        elif is_exploratory:
            ec = EpistemicClass.HYPOTHETICAL
            basis = "exploratory_flag"

        # External sources with citations → empirically verified
        elif has_external_sources and has_citations:
            ec = EpistemicClass.EMPIRICALLY_VERIFIED
            basis = "external_sources_with_citations"

        # External sources without citations → inferred
        elif has_external_sources:
            ec = EpistemicClass.INFERRED
            basis = "external_sources_no_citations"

        # Default: coherently synthesized (conservative)
        else:
            ec = EpistemicClass.COHERENTLY_SYNTHESIZED
            basis = basis if basis != "auto" else "default_coherent_synthesis"

        floor       = CONFIDENCE_FLOOR_BY_CLASS[ec]
        is_promotable = ec not in DEFERRED_CLASSES
        is_ambiguous  = ec == EpistemicClass.AMBIGUOUS

        return EpistemicLabel(
            proposal_id      = proposal_id,
            epistemic_class  = ec,
            confidence_floor = floor,
            is_promotable    = is_promotable,
            is_ambiguous     = is_ambiguous,
            assigned_at      = time.time(),
            basis            = basis,
        )


# ─── PROMOTION GUARD ─────────────────────────────────────────────────────────

class EpistemicPromotionGuard:
    """
    Checks whether a proposal's confidence clears its epistemic floor.

    Called by PromotionProtocol.evaluate() before the confidence
    floor check. If this blocks, no further promotion evaluation runs.

    Returns (allowed: bool, reason: str)
    """

    def check(
        self,
        label: EpistemicLabel,
        observed_confidence: float,
    ) -> tuple[bool, str]:
        """
        Returns (True, "ok") if promotable and confidence clears floor.
        Returns (False, reason) otherwise.
        """
        # Ambiguous always blocks
        if label.is_ambiguous:
            return False, (
                f"EPISTEMIC_BLOCK: class={label.epistemic_class.value} "
                f"requires clarification before promotion"
            )

        # Non-promotable classes route to deferred
        if not label.is_promotable:
            return False, (
                f"EPISTEMIC_DEFERRED: class={label.epistemic_class.value} "
                f"routes to DeferredExplorationNode, not promotion"
            )

        # Confidence must clear the class floor
        if observed_confidence < label.confidence_floor:
            return False, (
                f"EPISTEMIC_CONFIDENCE_FLOOR: class={label.epistemic_class.value} "
                f"requires confidence>={label.confidence_floor:.2f}, "
                f"got {observed_confidence:.3f}"
            )

        return True, "ok"


# ─── TESTS ───────────────────────────────────────────────────────────────────

def run_tests() -> tuple:
    passed = failed = 0
    results = []

    def t(name, fn):
        nonlocal passed, failed
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))

    clf = EpistemicClassifier()
    guard = EpistemicPromotionGuard()

    def test_default_class_is_coherently_synthesized():
        label = clf.classify("p1", "some proposal")
        assert label.epistemic_class == EpistemicClass.COHERENTLY_SYNTHESIZED
    t("test_default_class_is_coherently_synthesized",
      test_default_class_is_coherently_synthesized)

    def test_external_sources_and_citations_gives_empirically_verified():
        label = clf.classify("p2", "cited proposal",
                             has_external_sources=True, has_citations=True)
        assert label.epistemic_class == EpistemicClass.EMPIRICALLY_VERIFIED
    t("test_external_sources_and_citations_gives_empirically_verified",
      test_external_sources_and_citations_gives_empirically_verified)

    def test_exploratory_flag_gives_hypothetical():
        label = clf.classify("p3", "exploratory", is_exploratory=True)
        assert label.epistemic_class == EpistemicClass.HYPOTHETICAL
    t("test_exploratory_flag_gives_hypothetical",
      test_exploratory_flag_gives_hypothetical)

    def test_ambiguity_gives_ambiguous():
        label = clf.classify("p4", "ambiguous", has_unresolved_ambiguity=True)
        assert label.epistemic_class == EpistemicClass.AMBIGUOUS
    t("test_ambiguity_gives_ambiguous", test_ambiguity_gives_ambiguous)

    def test_explicit_class_overrides():
        label = clf.classify("p5", "any",
                             explicit_class=EpistemicClass.INFERRED)
        assert label.epistemic_class == EpistemicClass.INFERRED
    t("test_explicit_class_overrides", test_explicit_class_overrides)

    def test_ambiguous_is_not_promotable():
        label = clf.classify("p6", "ambiguous", has_unresolved_ambiguity=True)
        assert not label.is_promotable
        assert label.is_ambiguous
    t("test_ambiguous_is_not_promotable", test_ambiguous_is_not_promotable)

    def test_hypothetical_is_not_promotable():
        label = clf.classify("p7", "hypo", is_exploratory=True)
        assert not label.is_promotable
        assert not label.is_ambiguous
    t("test_hypothetical_is_not_promotable", test_hypothetical_is_not_promotable)

    def test_empirically_verified_is_promotable():
        label = clf.classify("p8", "verified",
                             has_external_sources=True, has_citations=True)
        assert label.is_promotable
        assert not label.is_ambiguous
    t("test_empirically_verified_is_promotable",
      test_empirically_verified_is_promotable)

    def test_confidence_floors_ordered_correctly():
        # Higher epistemic uncertainty = higher floor
        assert (CONFIDENCE_FLOOR_BY_CLASS[EpistemicClass.EMPIRICALLY_VERIFIED] <
                CONFIDENCE_FLOOR_BY_CLASS[EpistemicClass.INFERRED])
        assert (CONFIDENCE_FLOOR_BY_CLASS[EpistemicClass.INFERRED] <
                CONFIDENCE_FLOOR_BY_CLASS[EpistemicClass.COHERENTLY_SYNTHESIZED])
        assert (CONFIDENCE_FLOOR_BY_CLASS[EpistemicClass.COHERENTLY_SYNTHESIZED] <
                CONFIDENCE_FLOOR_BY_CLASS[EpistemicClass.HYPOTHETICAL])
        assert (CONFIDENCE_FLOOR_BY_CLASS[EpistemicClass.HYPOTHETICAL] <
                CONFIDENCE_FLOOR_BY_CLASS[EpistemicClass.AMBIGUOUS])
    t("test_confidence_floors_ordered_correctly",
      test_confidence_floors_ordered_correctly)

    def test_guard_blocks_ambiguous():
        label = clf.classify("p9", "ambiguous", has_unresolved_ambiguity=True)
        allowed, reason = guard.check(label, 0.99)
        assert not allowed
        assert "EPISTEMIC_BLOCK" in reason
    t("test_guard_blocks_ambiguous", test_guard_blocks_ambiguous)

    def test_guard_defers_hypothetical():
        label = clf.classify("p10", "hypo", is_exploratory=True)
        allowed, reason = guard.check(label, 0.99)
        assert not allowed
        assert "EPISTEMIC_DEFERRED" in reason
    t("test_guard_defers_hypothetical", test_guard_defers_hypothetical)

    def test_guard_blocks_on_confidence_floor():
        label = clf.classify("p11", "synth")  # COHERENTLY_SYNTHESIZED, floor=0.80
        allowed, reason = guard.check(label, 0.75)  # below floor
        assert not allowed
        assert "EPISTEMIC_CONFIDENCE_FLOOR" in reason
    t("test_guard_blocks_on_confidence_floor",
      test_guard_blocks_on_confidence_floor)

    def test_guard_allows_above_floor():
        label = clf.classify("p12", "synth")  # floor=0.80
        allowed, reason = guard.check(label, 0.85)
        assert allowed
        assert reason == "ok"
    t("test_guard_allows_above_floor", test_guard_allows_above_floor)

    def test_label_to_dict_serializable():
        label = clf.classify("p13", "some proposal")
        json.dumps(label.to_dict())
    t("test_label_to_dict_serializable", test_label_to_dict_serializable)

    def test_label_is_immutable():
        label = clf.classify("p14", "proposal")
        try:
            label.epistemic_class = EpistemicClass.AMBIGUOUS
            raise AssertionError("Should be immutable")
        except Exception as e:
            assert "frozen" in str(e).lower() or "can't" in str(e).lower() or "FrozenInstanceError" in type(e).__name__
    t("test_label_is_immutable", test_label_is_immutable)

    def test_all_classes_have_floors():
        for ec in EpistemicClass:
            assert ec in CONFIDENCE_FLOOR_BY_CLASS
    t("test_all_classes_have_floors", test_all_classes_have_floors)

    def test_ambiguous_floor_above_confidence_cap():
        # Ambiguous floor must exceed max valid confidence — permanent block
        assert CONFIDENCE_FLOOR_BY_CLASS[EpistemicClass.AMBIGUOUS] > CONFIDENCE_CAP
    t("test_ambiguous_floor_above_confidence_cap",
      test_ambiguous_floor_above_confidence_cap)

    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("Labyrinth-OS — Epistemic Class (TCP Truth-Class Schema)")
    print("=" * 70)
    print()
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err:
            line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed")
    if failed:
        raise SystemExit(1)
    print("\n  Epistemic Class — COMPLETE")
    print("=" * 70)
