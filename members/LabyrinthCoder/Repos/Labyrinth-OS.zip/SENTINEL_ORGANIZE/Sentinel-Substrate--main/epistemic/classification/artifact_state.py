# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          artifact_state.py — Labyrinth-OS / Epistemic / Classification
# ----------------------------------------------------------------------------

"""
artifact_state.py — Labyrinth-OS / Epistemic / Classification
==============================================================
Artifact State Definitions

Every artifact in the system has a state. States are formal.
Transitions between states are controlled (see transition_rules.py).

States:
  RAW         — unprocessed idea or code, not yet evaluated
  EXPERIMENTAL — partially working, unstable, under active development
  PARTIAL     — works in limited scope, known gaps documented
  VALIDATED   — passes tests, repeatable, can be promoted
  DEPRECATED  — replaced by something better, kept for history
  ARCHIVED    — preserved for memory only, not active
  FAILED      — known to break, informative for learning

Each artifact carries an ArtifactMetadata record.
This is the classification contract — every file/module must be taggable.

References:
  transition_rules.py — what transitions are allowed
  classifier.py       — how to assign states
  archive/KNOWLEDGE_SEEDS.md — the human-readable version of this
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, List, Optional


# ─── ARTIFACT STATE ───────────────────────────────────────────────────────────

@unique
class ArtifactState(str, Enum):
    """
    Formal lifecycle state of any artifact in the system.

    Total ordering by maturity: RAW < EXPERIMENTAL < PARTIAL < VALIDATED
    DEPRECATED, ARCHIVED, FAILED are terminal branches (not in main progression).
    """
    RAW          = "RAW"
    EXPERIMENTAL = "EXPERIMENTAL"
    PARTIAL      = "PARTIAL"
    VALIDATED    = "VALIDATED"
    DEPRECATED   = "DEPRECATED"
    ARCHIVED     = "ARCHIVED"
    FAILED       = "FAILED"

    @property
    def is_terminal(self) -> bool:
        """Terminal states do not progress further in the main lifecycle."""
        return self in (
            ArtifactState.DEPRECATED,
            ArtifactState.ARCHIVED,
            ArtifactState.FAILED,
        )

    @property
    def can_enter_execution(self) -> bool:
        """Only VALIDATED artifacts can cross the Reality Gate."""
        return self == ArtifactState.VALIDATED

    @property
    def maturity_score(self) -> int:
        """Numeric maturity. Used for comparison and reporting."""
        scores = {
            ArtifactState.RAW:          0,
            ArtifactState.EXPERIMENTAL: 1,
            ArtifactState.PARTIAL:      2,
            ArtifactState.VALIDATED:    3,
            ArtifactState.DEPRECATED:   2,  # was validated, now superseded
            ArtifactState.ARCHIVED:     1,  # preserved only
            ArtifactState.FAILED:       0,  # did not reach maturity
        }
        return scores[self]


# ─── ARTIFACT SOURCE ──────────────────────────────────────────────────────────

@unique
class ArtifactSource(str, Enum):
    """Where this artifact came from."""
    VECTOR   = "vector"    # VECTOR prototype system
    SENTINEL = "sentinel"  # Labyrinth-OS / Sentinel (our work)
    COPILOT  = "copilot"   # GitHub Copilot generated
    MANUAL   = "manual"    # Hand-written by operator
    EXTERNAL = "external"  # External reference / third-party


# ─── ARTIFACT METADATA ────────────────────────────────────────────────────────

@dataclass
class ArtifactMetadata:
    """
    Classification record for one artifact.

    Every file/module in the system can carry one of these.
    This is the formal classification contract.

    artifact_id   — stable identifier (usually relative file path)
    state         — current lifecycle state
    confidence    — how confident we are in the state assessment (0.0–1.0)
    source        — where this artifact came from
    notes         — why it exists and what it tries to solve
    last_tested   — timestamp of last successful test run (None if never)
    test_count    — number of tests passing (None if untested)
    replaced_by   — if DEPRECATED, what replaced it
    failure_reason — if FAILED, why it failed
    tags          — freeform tags for search/filter
    """
    artifact_id:    str
    state:          ArtifactState
    confidence:     float
    source:         ArtifactSource
    notes:          str
    last_tested:    Optional[float] = None
    test_count:     Optional[str]   = None   # e.g. "12/12" or "0/5"
    replaced_by:    Optional[str]   = None
    failure_reason: Optional[str]   = None
    tags:           List[str]       = field(default_factory=list)
    created_at:     float           = field(default_factory=time.time)

    def __post_init__(self) -> None:
        if not self.artifact_id:
            raise ValueError("artifact_id must be non-empty")
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError(f"confidence must be in [0,1], got {self.confidence}")
        if self.state == ArtifactState.DEPRECATED and not self.replaced_by:
            raise ValueError("DEPRECATED artifacts must specify replaced_by")
        if self.state == ArtifactState.FAILED and not self.failure_reason:
            raise ValueError("FAILED artifacts must specify failure_reason")

    @property
    def metadata_hash(self) -> str:
        """Stable hash of this metadata record."""
        payload = json.dumps({
            "artifact_id": self.artifact_id,
            "state":       self.state.value,
            "confidence":  round(self.confidence, 6),
            "source":      self.source.value,
        }, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(payload.encode()).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "artifact_id":    self.artifact_id,
            "state":          self.state.value,
            "confidence":     round(self.confidence, 4),
            "source":         self.source.value,
            "notes":          self.notes,
            "last_tested":    self.last_tested,
            "test_count":     self.test_count,
            "replaced_by":    self.replaced_by,
            "failure_reason": self.failure_reason,
            "tags":           self.tags,
            "can_execute":    self.state.can_enter_execution,
            "is_terminal":    self.state.is_terminal,
            "maturity_score": self.state.maturity_score,
            "metadata_hash":  self.metadata_hash,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ArtifactMetadata":
        return cls(
            artifact_id    = d["artifact_id"],
            state          = ArtifactState(d["state"]),
            confidence     = d["confidence"],
            source         = ArtifactSource(d["source"]),
            notes          = d["notes"],
            last_tested    = d.get("last_tested"),
            test_count     = d.get("test_count"),
            replaced_by    = d.get("replaced_by"),
            failure_reason = d.get("failure_reason"),
            tags           = d.get("tags", []),
        )


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _make_meta(state=ArtifactState.EXPERIMENTAL, source=ArtifactSource.SENTINEL,
               **kwargs) -> ArtifactMetadata:
    defaults = dict(
        artifact_id="test/module.py",
        state=state,
        confidence=0.7,
        source=source,
        notes="test artifact",
    )
    defaults.update(kwargs)
    if state == ArtifactState.DEPRECATED and "replaced_by" not in defaults:
        defaults["replaced_by"] = "test/new_module.py"
    if state == ArtifactState.FAILED and "failure_reason" not in defaults:
        defaults["failure_reason"] = "test failure"
    return ArtifactMetadata(**defaults)


def _test_valid_metadata_constructs() -> bool:
    m = _make_meta()
    assert m.artifact_id == "test/module.py"
    assert m.state == ArtifactState.EXPERIMENTAL
    assert len(m.metadata_hash) == 64
    return True

def _test_only_validated_can_execute() -> bool:
    for state in ArtifactState:
        m = _make_meta(state=state,
                       replaced_by="x" if state == ArtifactState.DEPRECATED else None,
                       failure_reason="x" if state == ArtifactState.FAILED else None)
        if state == ArtifactState.VALIDATED:
            assert m.state.can_enter_execution
        else:
            assert not m.state.can_enter_execution
    return True

def _test_terminal_states() -> bool:
    assert ArtifactState.DEPRECATED.is_terminal
    assert ArtifactState.ARCHIVED.is_terminal
    assert ArtifactState.FAILED.is_terminal
    assert not ArtifactState.VALIDATED.is_terminal
    assert not ArtifactState.EXPERIMENTAL.is_terminal
    return True

def _test_deprecated_requires_replaced_by() -> bool:
    try:
        ArtifactMetadata(
            artifact_id="x", state=ArtifactState.DEPRECATED,
            confidence=0.5, source=ArtifactSource.SENTINEL,
            notes="test", replaced_by=None,
        )
        raise AssertionError("Should require replaced_by")
    except ValueError:
        pass
    return True

def _test_failed_requires_failure_reason() -> bool:
    try:
        ArtifactMetadata(
            artifact_id="x", state=ArtifactState.FAILED,
            confidence=0.5, source=ArtifactSource.SENTINEL,
            notes="test", failure_reason=None,
        )
        raise AssertionError("Should require failure_reason")
    except ValueError:
        pass
    return True

def _test_confidence_clamped() -> bool:
    try:
        _make_meta(confidence=1.5)
        raise AssertionError("Should reject confidence > 1")
    except ValueError:
        pass
    return True

def _test_maturity_ordering() -> bool:
    assert ArtifactState.RAW.maturity_score < ArtifactState.EXPERIMENTAL.maturity_score
    assert ArtifactState.EXPERIMENTAL.maturity_score < ArtifactState.PARTIAL.maturity_score
    assert ArtifactState.PARTIAL.maturity_score < ArtifactState.VALIDATED.maturity_score
    return True

def _test_to_dict_round_trip() -> bool:
    import json
    m = _make_meta()
    d = m.to_dict()
    json.dumps(d)  # must be serializable
    assert d["state"] == "EXPERIMENTAL"
    assert d["can_execute"] is False
    return True

def _test_from_dict_round_trip() -> bool:
    m = _make_meta()
    d = m.to_dict()
    # Remove computed fields before from_dict
    for k in ["can_execute", "is_terminal", "maturity_score", "metadata_hash"]:
        d.pop(k, None)
    m2 = ArtifactMetadata.from_dict(d)
    assert m2.artifact_id == m.artifact_id
    assert m2.state == m.state
    return True

def _test_metadata_hash_stable() -> bool:
    m = _make_meta()
    assert m.metadata_hash == m.metadata_hash
    return True


def run_tests() -> tuple:
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("ARTIFACT STATE — Labyrinth-OS / Epistemic Classification")
    print("=" * 70)
    print("\n── TEST SUITE ──\n")
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err: line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed")
    if failed: raise SystemExit(1)
    import hashlib as _hl
    with open(__file__, "rb") as f:
        fh = _hl.sha256(f.read()).hexdigest()
    print(f"\n── RECEIPT ──\n  SHA-256: {fh}")
    print(f"\n{'='*70}\n  ARTIFACT STATE — COMPLETE\n{'='*70}")
