# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          transition_rules.py — Labyrinth-OS / Epistemic / Classification
# ----------------------------------------------------------------------------

"""
transition_rules.py — Labyrinth-OS / Epistemic / Classification
===============================================================
Artifact State Transition Rules

Controls which state transitions are valid.
Invalid transitions are rejected — never silently accepted.

Valid transition map:
  RAW          → EXPERIMENTAL, ARCHIVED, FAILED
  EXPERIMENTAL → PARTIAL, DEPRECATED, FAILED, ARCHIVED
  PARTIAL      → VALIDATED, DEPRECATED, FAILED, ARCHIVED
  VALIDATED    → DEPRECATED, ARCHIVED
  DEPRECATED   → ARCHIVED          (terminal branch, only archival allowed)
  ARCHIVED     → (none)            (fully terminal)
  FAILED       → EXPERIMENTAL      (allowed: lessons learned, retry with new approach)
               → ARCHIVED          (allowed: preserve and close)

Key rules:
  - Nothing jumps from RAW to VALIDATED (must earn each step)
  - ARCHIVED is fully terminal (no resurrection)
  - FAILED can retry as EXPERIMENTAL (learning, not deletion)
  - VALIDATED → DEPRECATED requires a replacement artifact specified
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Set

from artifact_state import ArtifactState, ArtifactMetadata


# ─── TRANSITION MAP ───────────────────────────────────────────────────────────

VALID_TRANSITIONS: Dict[ArtifactState, Set[ArtifactState]] = {
    ArtifactState.RAW: {
        ArtifactState.EXPERIMENTAL,
        ArtifactState.ARCHIVED,
        ArtifactState.FAILED,
    },
    ArtifactState.EXPERIMENTAL: {
        ArtifactState.PARTIAL,
        ArtifactState.DEPRECATED,
        ArtifactState.FAILED,
        ArtifactState.ARCHIVED,
    },
    ArtifactState.PARTIAL: {
        ArtifactState.VALIDATED,
        ArtifactState.DEPRECATED,
        ArtifactState.FAILED,
        ArtifactState.ARCHIVED,
    },
    ArtifactState.VALIDATED: {
        ArtifactState.DEPRECATED,
        ArtifactState.ARCHIVED,
    },
    ArtifactState.DEPRECATED: {
        ArtifactState.ARCHIVED,
    },
    ArtifactState.ARCHIVED: set(),  # fully terminal
    ArtifactState.FAILED: {
        ArtifactState.EXPERIMENTAL,   # retry with lessons learned
        ArtifactState.ARCHIVED,       # preserve and close
    },
}

# Transitions that skip maturity levels (never allowed)
FORBIDDEN_SKIPS = [
    (ArtifactState.RAW,          ArtifactState.VALIDATED),
    (ArtifactState.RAW,          ArtifactState.PARTIAL),
    (ArtifactState.EXPERIMENTAL, ArtifactState.VALIDATED),
    (ArtifactState.FAILED,       ArtifactState.VALIDATED),
    (ArtifactState.FAILED,       ArtifactState.PARTIAL),
    (ArtifactState.ARCHIVED,     ArtifactState.EXPERIMENTAL),
    (ArtifactState.ARCHIVED,     ArtifactState.VALIDATED),
]


# ─── TRANSITION RESULT ────────────────────────────────────────────────────────

@dataclass(frozen=True)
class TransitionResult:
    """Result of a transition check. Always explicit — never silent."""
    allowed:      bool
    from_state:   ArtifactState
    to_state:     ArtifactState
    reason:       str

    @property
    def is_forbidden_skip(self) -> bool:
        return (self.from_state, self.to_state) in FORBIDDEN_SKIPS


# ─── TRANSITION RULES ─────────────────────────────────────────────────────────

class TransitionRules:
    """
    Validates and applies artifact state transitions.

    check(from, to) → TransitionResult
    apply(metadata, to_state, ...) → updated ArtifactMetadata

    Never mutates in place. Returns new metadata objects.
    """

    def check(
        self,
        from_state: ArtifactState,
        to_state: ArtifactState,
    ) -> TransitionResult:
        """Check if a transition is valid. Returns TransitionResult."""
        # Forbidden skip check first
        if (from_state, to_state) in FORBIDDEN_SKIPS:
            return TransitionResult(
                allowed=False,
                from_state=from_state,
                to_state=to_state,
                reason=(
                    f"Forbidden skip: {from_state.value} → {to_state.value}. "
                    f"Artifacts must earn each maturity level. "
                    f"Cannot jump from {from_state.value} to {to_state.value}."
                ),
            )

        # Same state
        if from_state == to_state:
            return TransitionResult(
                allowed=False,
                from_state=from_state,
                to_state=to_state,
                reason=f"No-op transition: already in {from_state.value}",
            )

        # Check valid transition map
        allowed_targets = VALID_TRANSITIONS.get(from_state, set())
        if to_state not in allowed_targets:
            return TransitionResult(
                allowed=False,
                from_state=from_state,
                to_state=to_state,
                reason=(
                    f"Invalid transition: {from_state.value} → {to_state.value}. "
                    f"From {from_state.value}, allowed: "
                    f"{sorted(s.value for s in allowed_targets) or 'none (terminal)'}"
                ),
            )

        return TransitionResult(
            allowed=True,
            from_state=from_state,
            to_state=to_state,
            reason=f"Valid transition: {from_state.value} → {to_state.value}",
        )

    def apply(
        self,
        metadata: ArtifactMetadata,
        to_state: ArtifactState,
        reason: str = "",
        replaced_by: Optional[str] = None,
        failure_reason: Optional[str] = None,
        new_confidence: Optional[float] = None,
        new_test_count: Optional[str] = None,
    ) -> ArtifactMetadata:
        """
        Apply a transition. Returns new ArtifactMetadata.
        Raises ValueError if transition is invalid.
        Never modifies the original.
        """
        result = self.check(metadata.state, to_state)
        if not result.allowed:
            raise ValueError(
                f"Rejected transition for '{metadata.artifact_id}': {result.reason}"
            )

        # Validate required fields for terminal states
        if to_state == ArtifactState.DEPRECATED:
            effective_replaced_by = replaced_by or metadata.replaced_by
            if not effective_replaced_by:
                raise ValueError(
                    f"Transition to DEPRECATED requires replaced_by to be set"
                )
        else:
            effective_replaced_by = replaced_by or metadata.replaced_by

        if to_state == ArtifactState.FAILED:
            effective_failure_reason = failure_reason or metadata.failure_reason
            if not effective_failure_reason:
                raise ValueError(
                    f"Transition to FAILED requires failure_reason to be set"
                )
        else:
            effective_failure_reason = failure_reason or metadata.failure_reason

        from dataclasses import replace
        import time
        return replace(
            metadata,
            state          = to_state,
            confidence     = new_confidence if new_confidence is not None else metadata.confidence,
            test_count     = new_test_count or metadata.test_count,
            replaced_by    = effective_replaced_by,
            failure_reason = effective_failure_reason,
            last_tested    = time.time() if new_test_count else metadata.last_tested,
        )

    def valid_next_states(self, state: ArtifactState) -> Set[ArtifactState]:
        """Return the set of valid next states from a given state."""
        return VALID_TRANSITIONS.get(state, set())


# ─── CONVENIENCE ──────────────────────────────────────────────────────────────

_rules = TransitionRules()

def check_transition(from_state: ArtifactState,
                     to_state: ArtifactState) -> TransitionResult:
    return _rules.check(from_state, to_state)

def apply_transition(metadata: ArtifactMetadata,
                     to_state: ArtifactState, **kwargs) -> ArtifactMetadata:
    return _rules.apply(metadata, to_state, **kwargs)


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _make_meta(state=ArtifactState.EXPERIMENTAL):
    from artifact_state import ArtifactSource
    kwargs = dict(
        artifact_id="test/mod.py", state=state,
        confidence=0.6, source=ArtifactSource.SENTINEL, notes="test",
    )
    if state == ArtifactState.DEPRECATED:
        kwargs["replaced_by"] = "test/new.py"
    if state == ArtifactState.FAILED:
        kwargs["failure_reason"] = "test fail"
    return ArtifactMetadata(**kwargs)


def _test_valid_transitions_allowed() -> bool:
    rules = TransitionRules()
    valid = [
        (ArtifactState.RAW,          ArtifactState.EXPERIMENTAL),
        (ArtifactState.EXPERIMENTAL, ArtifactState.PARTIAL),
        (ArtifactState.PARTIAL,      ArtifactState.VALIDATED),
        (ArtifactState.VALIDATED,    ArtifactState.DEPRECATED),
        (ArtifactState.FAILED,       ArtifactState.EXPERIMENTAL),
        (ArtifactState.FAILED,       ArtifactState.ARCHIVED),
    ]
    for from_s, to_s in valid:
        r = rules.check(from_s, to_s)
        assert r.allowed, f"Should allow {from_s.value} → {to_s.value}: {r.reason}"
    return True

def _test_forbidden_skips_rejected() -> bool:
    rules = TransitionRules()
    for from_s, to_s in FORBIDDEN_SKIPS:
        r = rules.check(from_s, to_s)
        assert not r.allowed, f"Should reject skip {from_s.value} → {to_s.value}"
    return True

def _test_archived_is_fully_terminal() -> bool:
    rules = TransitionRules()
    for to_s in ArtifactState:
        if to_s == ArtifactState.ARCHIVED:
            continue
        r = rules.check(ArtifactState.ARCHIVED, to_s)
        assert not r.allowed, f"ARCHIVED should not transition to {to_s.value}"
    return True

def _test_raw_cannot_skip_to_validated() -> bool:
    r = check_transition(ArtifactState.RAW, ArtifactState.VALIDATED)
    assert not r.allowed
    assert r.is_forbidden_skip
    return True

def _test_failed_can_retry_as_experimental() -> bool:
    r = check_transition(ArtifactState.FAILED, ArtifactState.EXPERIMENTAL)
    assert r.allowed, "FAILED → EXPERIMENTAL should be allowed (learning retry)"
    return True

def _test_apply_valid_transition() -> bool:
    m = _make_meta(ArtifactState.EXPERIMENTAL)
    rules = TransitionRules()
    m2 = rules.apply(m, ArtifactState.PARTIAL, new_confidence=0.75)
    assert m2.state == ArtifactState.PARTIAL
    assert m2.confidence == 0.75
    assert m.state == ArtifactState.EXPERIMENTAL  # original unchanged
    return True

def _test_apply_invalid_transition_raises() -> bool:
    m = _make_meta(ArtifactState.ARCHIVED)
    try:
        apply_transition(m, ArtifactState.VALIDATED)
        raise AssertionError("Should raise ValueError")
    except ValueError as e:
        assert "Rejected" in str(e)
    return True

def _test_deprecated_requires_replaced_by() -> bool:
    m = _make_meta(ArtifactState.EXPERIMENTAL)
    rules = TransitionRules()
    try:
        rules.apply(m, ArtifactState.DEPRECATED)  # no replaced_by
        raise AssertionError("Should require replaced_by")
    except ValueError:
        pass
    return True

def _test_failed_requires_failure_reason() -> bool:
    m = _make_meta(ArtifactState.EXPERIMENTAL)
    rules = TransitionRules()
    try:
        rules.apply(m, ArtifactState.FAILED)  # no failure_reason
        raise AssertionError("Should require failure_reason")
    except ValueError:
        pass
    return True

def _test_same_state_rejected() -> bool:
    r = check_transition(ArtifactState.EXPERIMENTAL, ArtifactState.EXPERIMENTAL)
    assert not r.allowed
    return True

def _test_valid_next_states_archived_empty() -> bool:
    rules = TransitionRules()
    assert len(rules.valid_next_states(ArtifactState.ARCHIVED)) == 0
    return True


def run_tests() -> tuple:
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("TRANSITION RULES — Labyrinth-OS / Epistemic Classification")
    print("=" * 70)
    print("\n── TEST SUITE ──\n")
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err: line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed")
    if failed: raise SystemExit(1)
    import hashlib as _hl
    with open(__file__, "rb") as f:
        fh = _hl.sha256(f.read()).hexdigest()
    print(f"\n── RECEIPT ──\n  SHA-256: {fh}")
    print(f"\n{'='*70}\n  TRANSITION RULES — COMPLETE\n{'='*70}")
