# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          classifier.py — Labyrinth-OS / Epistemic / Classification
# ----------------------------------------------------------------------------

"""
classifier.py — Labyrinth-OS / Epistemic / Classification
==========================================================
Artifact Classifier

Assigns ArtifactState to every module in the system.
Maintains the canonical classification register.
Produces the machine-readable artifact list for SYSTEM_REPORT.json.

The classifier knows the current state of every artifact.
When code changes, the classifier is updated here.
The register is the source of truth for what state each module is in.

Rules:
  - Every artifact in the register has exactly one state
  - State must be consistent with evidence (test counts, known gaps)
  - classifier.py is updated when state changes — not silently
  - New artifacts start as RAW until evaluated
"""

from __future__ import annotations

import json
import time
from typing import Dict, List, Optional

from artifact_state import ArtifactMetadata, ArtifactSource, ArtifactState
from transition_rules import TransitionRules


# ─── CANONICAL CLASSIFICATION REGISTER ───────────────────────────────────────
# Every artifact in the system. Updated when state changes.
# Format: artifact_id → ArtifactMetadata

def _build_register() -> Dict[str, ArtifactMetadata]:
    """Build the canonical classification register."""
    now = time.time()
    S = ArtifactSource

    def m(aid, state, conf, source, notes,
          test_count=None, replaced_by=None,
          failure_reason=None, tags=None, last_tested=None):
        kwargs = dict(
            artifact_id=aid, state=state, confidence=conf,
            source=source, notes=notes, last_tested=last_tested or now,
            test_count=test_count, replaced_by=replaced_by,
            failure_reason=failure_reason, tags=tags or [],
        )
        return ArtifactMetadata(**kwargs)

    register = {}

    # ── LANE 2 EXECUTION SPINE — VALIDATED ───────────────────────────────────
    for aid, notes, tests in [
        ("execution/cgir/cgir_types.py",
         "CGIR type definitions. Compile-time enforcement in Rust mirror.",
         "21/21"),
        ("execution/cgir/cgir_core.py",
         "CGIR graph container. Nodes, edges, signals.",
         "24/24"),
        ("execution/cgir/cgir_validator.py",
         "Strict graph validation. Fail closed on any error.",
         "25/25"),
        ("execution/cgir/cgir_determinism.py",
         "Canonical hash. Insertion-order independent. Proves I2.",
         "18/18"),
        ("execution/cgir/acbf_vm.py",
         "Policy-gated bytecode VM.",
         "5/5"),
        ("execution/cgir/schema/cgir_schema.py",
         "Proposal schema gate. Rejects malformed proposals before AEGIS.",
         "16/16"),
        ("execution/gate/cgir_gate.py",
         "Pure gate function. Blocks CRITICAL+ERROR. I5 enforced.",
         "21/21"),
        ("execution/gate/guardian_slot.py",
         "Operational gate. EXECUTE/BLOCK/KILL. Sigma Anchor enforcement.",
         "29/29"),
        ("execution/ledger/receipt.py",     "WORM receipt.", "25/25"),
        ("execution/ledger/hashchain.py",   "SHA-256 append-only chain.", "29/29"),
        ("execution/ledger/cgir_ledger.py", "CGIR WORM ledger.", "24/24"),
        ("execution/aegis/aegis_cesk.py",
         "CESK execution kernel. LOAD→PROPOSE→CHECK→COMMIT→PROVE.",
         "20/20"),
        ("execution/aegis/cgir_guardian_bridge.py",
         "L10→L12 bridge. Clips confidence on BLOCK. I5 enforced.",
         "12/12"),
        ("execution/replay/replay_validator.py",
         "Exact-chain replay. Detects TAMPERED/INCONSISTENT/INCOMPLETE.",
         "10/10"),
        ("execution/cgir/formal/z3_sovereignty_spec.py",
         "Z3 formal proofs. A021 CLOSED [REAL]. 20 theorems proven.",
         "22/22"),
    ]:
        register[aid] = m(aid, ArtifactState.VALIDATED, 0.98,
                          S.SENTINEL, notes, test_count=tests,
                          tags=["lane2", "execution-spine"])

    # ── EPISTEMIC LAYER — VALIDATED ───────────────────────────────────────────
    for aid, notes, tests in [
        ("epistemic/signal-aggregation/cgir_signal_algebra.py",
         "Sigma Anchor enforcement. χ=risk (high=bad). emitted_by=SIGNAL_ALGEBRA.",
         "29/29"),
        ("epistemic/watcher-a/watcher_a.py",
         "Internal consistency auditor. Temporal/signal/path checks.",
         "12/12"),
        ("epistemic/watcher-b/watcher_b.py",
         "Adversarial auditor. Replay/injection/evasion/strip detection.",
         "9/9"),
        ("epistemic/council/council_resolver.py",
         "v2. EscalationCode, determinism_hash, machine categories. I4 enforced.",
         "21/21"),
        ("epistemic/vector/tau_baseline_generator.py",
         "P0 #2 CLEARED. τ baseline generation.",
         "26/26"),
        ("epistemic/logprob-bridge/logprob_bridge_adapter.py",
         "LogprobMetrics→SensorReadings. Fail-closed. Never fakes D_KL.",
         "13/13"),
        ("epistemic/logprob-bridge/api_logprob_extractor.py",
         "Provider logprob parsing. MissingLogprobEvent on unavailable.",
         "15/15"),
    ]:
        register[aid] = m(aid, ArtifactState.VALIDATED, 0.95,
                          S.SENTINEL, notes, test_count=tests,
                          tags=["lane2", "epistemic"])

    # ── LANE 1 — VALIDATED ────────────────────────────────────────────────────
    for aid, notes, tests in [
        ("lane1/05_epistemic_labeling/epistemic_types.py",
         "EpistemicLabel, IdeaNode, PromotionCriteria. Label transition rules.",
         "12/12"),
        ("lane1/02_mode_router/mode_router.py",
         "Routes CREATIVE/ANALYTICAL/EXECUTION. Deterministic.",
         "10/10"),
        ("lane1/05_epistemic_labeling/epistemic_labeler.py",
         "Assigns labels. Confidence floors. Fail closed.",
         "11/11"),
        ("lane1/06_archive_memory/archive_memory.py",
         "Append-only versioned store. Nothing deleted.",
         "10/10"),
        ("lane1/08_promotion_protocol/promotion_protocol.py",
         "Falsifiable promotion. SPECULATIVE→TRUTH only via criteria.",
         "10/10"),
        ("lane1/09_reality_gate/reality_gate.py",
         "Only Lane 1→2 crossing. GatePassage or GateBlock.",
         "11/11"),
        ("lane1/07_deferred_exploration/deferred_node.py",
         "Agent D. Controlled healing loop. Bounded mutation. Oscillation detection.",
         "15/15"),
    ]:
        register[aid] = m(aid, ArtifactState.VALIDATED, 0.92,
                          S.SENTINEL, notes, test_count=tests,
                          tags=["lane1"])

    # ── RUNTIME — VALIDATED (with known gap) ──────────────────────────────────
    register["runtime/api_adapter.py"] = m(
        "runtime/api_adapter.py", ArtifactState.VALIDATED, 0.90,
        S.SENTINEL, "Provider-agnostic. OpenAI|Anthropic|Grok|Ollama|Mock. Fail-closed.",
        test_count="19/19", tags=["runtime"])

    register["runtime/verify_run.py"] = m(
        "runtime/verify_run.py", ArtifactState.VALIDATED, 0.90,
        S.SENTINEL, "4-step proof: receipt→replay→execute→forced-fail. Exact-chain replay.",
        test_count="6/6", tags=["runtime"])

    register["pipeline_wire.py"] = m(
        "pipeline_wire.py", ArtifactState.VALIDATED, 0.88,
        S.SENTINEL, "PipelineTrace enforcement. Stage ordering. NO_TRACE=INVALID. FeedbackRecord.",
        test_count="8/8", tags=["runtime", "lane1"])

    # ── RUNTIME — PARTIAL (ignition — Option B route) ─────────────────────────
    register["runtime/ignition.py"] = m(
        "runtime/ignition.py", ArtifactState.PARTIAL, 0.75,
        S.SENTINEL,
        "Master unblock. Option B route — bypasses Lane 1 (prototype only, see KNOWN_GAPS.md). "
        "Full Lane 2 path intact. A010 not yet closed (no real API run).",
        test_count="9/9", tags=["runtime", "prototype", "option-b"])

    # ── TESTS — VALIDATED ─────────────────────────────────────────────────────
    for aid, notes, tests in [
        ("tests/adversarial/threat_model.py",
         "TM-001. 11 attack classes. All falsifiable. 11/11 end-to-end.",
         "11/11"),
        ("tests/integration/test_full_pipeline.py",
         "End-to-end L3→CGIR→Gate→Ledger.",
         "22/22"),
        ("tests/integration/test_forced_failure.py",
         "Proof item 4. BLOCK→replay CLEAN→chain tamper detected.",
         "12/12"),
        ("tests/determinism/test_determinism.py",
         "Proves I2 (Gate) + I8 (Council). 19 determinism proofs.",
         "19/19"),
        ("tests/watcher-council/test_watcher_council.py",
         "Adversarial watcher+council. I4, I7. All escalation paths.",
         "30/30"),
    ]:
        register[aid] = m(aid, ArtifactState.VALIDATED, 0.95,
                          S.SENTINEL, notes, test_count=tests,
                          tags=["tests"])

    # ── RUST — PARTIAL ────────────────────────────────────────────────────────
    register["crates/cgir-types/src/lib.rs"] = m(
        "crates/cgir-types/src/lib.rs", ArtifactState.VALIDATED, 0.85,
        S.SENTINEL,
        "Only real Rust crate. 300 lines. Compile-time invariant enforcement. "
        "Severity::blocks_gate(), Confidence clamps, TimeRange rejects inverted.",
        test_count="20/20", tags=["rust", "lane2"])

    for i in range(1, 28):
        aid = f"crates/stub_{i:02d}/src/lib.rs"
        register[f"crates/__stubs__({i})"] = m(
            "crates/**/src/lib.rs (27 stubs)",
            ArtifactState.PARTIAL, 0.20,
            S.SENTINEL,
            "27 Rust crate stubs. Placeholder lib.rs. cargo build not yet run. A012 open.",
            tags=["rust", "stub"])
        break  # one entry represents all 27

    # ── EXTERNAL REFERENCES — ARCHIVED ────────────────────────────────────────
    register["archive/external_references/quicksilver_v3/quicksilver_v3.py"] = m(
        "archive/external_references/quicksilver_v3/quicksilver_v3.py",
        ArtifactState.ARCHIVED, 0.30, S.EXTERNAL,
        "Quicksilver v3 JOX Tower. External work studied for RTZ floor pattern. "
        "RTZ floor already in Labyrinth-OS independently. Atomic cascade: ARCHIVE_ONLY.",
        tags=["external", "reference"])

    register["archive/external_references/quantum_tubulin/"] = m(
        "archive/external_references/quantum_tubulin/",
        ArtifactState.ARCHIVED, 0.25, S.EXTERNAL,
        "QuTiP quantum tubulin simulation. Physical interpretation of TAU_ESCAPE_FLOOR. "
        "Penrose-Hameroff hypothesis — contested science. Enriches documentation only.",
        tags=["external", "reference"])

    # ── MISPLACED — DEPRECATED ────────────────────────────────────────────────
    register["crates/council-resolver/src/council_resolver.py"] = m(
        "crates/council-resolver/src/council_resolver.py",
        ArtifactState.DEPRECATED, 0.10, S.COPILOT,
        "Python file placed in Rust crate dir by Copilot error. Kept per I10.",
        replaced_by="epistemic/council/council_resolver.py",
        tags=["misplaced", "copilot-error"])

    return register


# ─── CLASSIFIER ───────────────────────────────────────────────────────────────

class Classifier:
    """
    Maintains the artifact classification register.
    Provides lookup, filtering, and reporting.
    """

    def __init__(self) -> None:
        self._register = _build_register()
        self._rules = TransitionRules()

    def get(self, artifact_id: str) -> Optional[ArtifactMetadata]:
        return self._register.get(artifact_id)

    def by_state(self, state: ArtifactState) -> List[ArtifactMetadata]:
        return [m for m in self._register.values() if m.state == state]

    def can_execute(self) -> List[ArtifactMetadata]:
        """Artifacts that can cross the Reality Gate."""
        return [m for m in self._register.values() if m.state.can_enter_execution]

    def summary(self) -> Dict[str, int]:
        from collections import Counter
        counts = Counter(m.state.value for m in self._register.values())
        return dict(counts)

    def to_report(self) -> Dict:
        """Machine-readable report for SYSTEM_REPORT.json."""
        return {
            "generated_at":    time.time(),
            "total_artifacts": len(self._register),
            "summary":         self.summary(),
            "artifacts":       [m.to_dict() for m in sorted(
                                    self._register.values(),
                                    key=lambda x: (x.state.value, x.artifact_id))],
        }

    def transition(self, artifact_id: str, to_state: ArtifactState,
                   **kwargs) -> ArtifactMetadata:
        """Apply a state transition to a registered artifact."""
        meta = self._register.get(artifact_id)
        if meta is None:
            raise KeyError(f"Artifact not in register: {artifact_id}")
        updated = self._rules.apply(meta, to_state, **kwargs)
        self._register[artifact_id] = updated
        return updated


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_register_builds() -> bool:
    c = Classifier()
    assert len(c._register) > 0
    return True

def _test_validated_artifacts_can_execute() -> bool:
    c = Classifier()
    executables = c.can_execute()
    assert len(executables) > 0
    for m in executables:
        assert m.state == ArtifactState.VALIDATED
    return True

def _test_partial_artifacts_cannot_execute() -> bool:
    c = Classifier()
    partials = c.by_state(ArtifactState.PARTIAL)
    for m in partials:
        assert not m.state.can_enter_execution
    return True

def _test_ignition_is_partial() -> bool:
    c = Classifier()
    ignition = c.get("runtime/ignition.py")
    assert ignition is not None
    assert ignition.state == ArtifactState.PARTIAL
    assert "option-b" in ignition.tags
    return True

def _test_misplaced_file_is_deprecated() -> bool:
    c = Classifier()
    m = c.get("crates/council-resolver/src/council_resolver.py")
    assert m is not None
    assert m.state == ArtifactState.DEPRECATED
    return True

def _test_summary_has_all_states() -> bool:
    c = Classifier()
    summary = c.summary()
    assert "VALIDATED" in summary
    assert "PARTIAL" in summary
    assert "DEPRECATED" in summary
    assert "ARCHIVED" in summary
    return True

def _test_report_serializable() -> bool:
    c = Classifier()
    report = c.to_report()
    json.dumps(report)
    assert "artifacts" in report
    assert "summary" in report
    return True

def _test_external_refs_archived() -> bool:
    c = Classifier()
    archived = c.by_state(ArtifactState.ARCHIVED)
    ids = [m.artifact_id for m in archived]
    assert any("quicksilver" in i for i in ids)
    return True


def run_tests() -> tuple:
    tests = sorted(
        [(n, o) for n, o in globals().items()
         if n.startswith("_test_") and callable(o)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    print("=" * 70)
    print("CLASSIFIER — Labyrinth-OS / Epistemic Classification")
    print("=" * 70)

    c = Classifier()
    summary = c.summary()
    print("\n── ARTIFACT SUMMARY ──\n")
    for state, count in sorted(summary.items()):
        bar = "█" * count
        print(f"  {state:12} {count:3}  {bar}")

    print("\n── TEST SUITE ──\n")
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err: line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed")
    if failed: raise SystemExit(1)
    import hashlib as _hl
    with open(__file__, "rb") as f:
        fh = _hl.sha256(f.read()).hexdigest()
    print(f"\n── RECEIPT ──\n  SHA-256: {fh}")
    print(f"\n{'='*70}\n  CLASSIFIER — COMPLETE\n{'='*70}")
