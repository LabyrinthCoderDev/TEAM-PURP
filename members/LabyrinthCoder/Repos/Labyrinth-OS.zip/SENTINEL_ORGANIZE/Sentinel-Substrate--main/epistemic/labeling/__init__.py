# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          epistemic/labeling — Labyrinth-OS / Epistemic Layer L3.5
# ----------------------------------------------------------------------------

"""
epistemic/labeling — Labyrinth-OS / Epistemic Layer L3.5
=========================================================
Labeling layer: classify epistemic artifacts, measure confidence,
enforce label schema, and emit rejection reasons.

Exports:
    LabelCategory, ConfidenceTier, RejectionReason   (schema)
    LabelRecord, ValidationResult                     (data classes)
    LabelValidator                                    (validation engine)
    ConfidenceMeter                                   (scoring engine)
"""

from label_schema import (
    LabelCategory,
    ConfidenceTier,
    RejectionReason,
    LabelRecord,
)
from label_validator import LabelValidator, ValidationResult
from confidence_meter import ConfidenceMeter

__all__ = [
    "LabelCategory",
    "ConfidenceTier",
    "RejectionReason",
    "LabelRecord",
    "LabelValidator",
    "ValidationResult",
    "ConfidenceMeter",
]
