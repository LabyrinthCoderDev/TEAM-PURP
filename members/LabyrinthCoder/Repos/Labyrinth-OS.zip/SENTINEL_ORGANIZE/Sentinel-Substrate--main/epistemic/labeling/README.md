# Labeling Layer — Labyrinth-OS / Epistemic L3.5

## Purpose

The labeling layer classifies every epistemic artifact before it can reach the
**Reality Gate**.  It enforces **I11 (Labeling Closure)**: only `VALID` labels
with confidence ≥ threshold may advance toward execution.

## Position in the Architecture

```
Sensing (L3) → Labeling (L3.5) → Archive (L5.5) → Promotion (L6.5) → Reality Gate → CGIR
```

## Label Categories

| Category    | Meaning |
|-------------|---------|
| `VALID`     | Passed all validation checks — may advance to promotion |
| `UNCERTAIN` | Below confidence threshold — needs more signal |
| `REJECTED`  | Failed validation — must not proceed |
| `DEFERRED`  | Structurally sound but outside current scope |

## Confidence Tiers

| Tier            | Score Range |
|-----------------|-------------|
| `HIGH`          | ≥ 0.85      |
| `MEDIUM`        | ≥ 0.60      |
| `LOW`           | ≥ 0.35      |
| `UNINITIALIZED` | < 0.35 or None |

## Rejection Reasons

| Reason | Trigger |
|--------|---------|
| `SCHEMA_VIOLATION` | Required field missing or wrong type |
| `CONFIDENCE_BELOW_THRESHOLD` | Score below floor |
| `POLICY_VIOLATION` | Contradicts a hard policy rule |
| `STALE_LABEL` | Label older than TTL |
| `ARCHIVE_CONTRADICTION` | Contradicts archived pattern |
| `DUPLICATE_LABEL` | Identical label_id already registered |
| `MISSING_SOURCE` | No originating sensor chain |

## Modules

| File | Role |
|------|------|
| `label_schema.py` | Types, categories, LabelRecord dataclass |
| `label_validator.py` | Validation engine + promotion threshold check |
| `confidence_meter.py` | Weighted scoring, decay, trend detection |
| `labeling_tests.py` | Unit tests |

## Invariants

- **I11** — Labeling Closure: only VALID labels reach the Reality Gate.
- **I3** — Sensor Read-Only: labeling reads sensor output, never writes to it.
- **I10** — Fail Closed: any validation error → REJECTED, not VALID.

## Non-Negotiable Rules

1. Labels are immutable once sealed (seal_hash stored in archive).
2. `VALID` category requires `confidence ≥ VALID_CONFIDENCE_FLOOR (0.60)`.
3. Promotion requires `confidence ≥ PROMOTION_CONFIDENCE_THRESHOLD (0.85)`.
4. `REJECTED` labels must carry a `RejectionReason`.
5. Duplicate `label_id` is always rejected.
