# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          logprob_bridge_adapter.py — Labyrinth-OS / L3 Sensor Bridge
# ----------------------------------------------------------------------------

"""
logprob_bridge_adapter.py — Labyrinth-OS / L3 Sensor Bridge
============================================================
LogProb Bridge → CGIR Signal Adapter

ACP-1 A011: "logprob_bridge.py is not wired to eden_daemon.py.
Metrics exist in isolation, never integrated with the governance stack."

This module provides the adapter layer that:
  1. Takes logprob metrics (KL divergence, entropy delta) from
     logprob_bridge.py output format
  2. Translates them into a SensorReadings object
  3. Feeds into cgir_signal_algebra → council_resolver → CGIR gate

This is NOT the full A011 closure — that requires logprob_bridge.py
itself to be wired into eden_daemon.py handle_chat() (needs live Ollama).
This is the adapter that makes that wiring straightforward: implement
the interface here, plug into eden_daemon once Ollama is running.

Interface contract:
  LogprobMetrics {
    kl_divergence: float     # KL(P || Q) between token distributions
    entropy_delta: float     # H(t) - H(t-1), rate of entropy change
    mean_logprob: float      # mean log probability of tokens in response
    token_count: int         # number of tokens in this response
    session_id: str          # session identifier
    logical_time: int        # monotonic counter within session
  }

  → SensorReadings (feeds cgir_signal_algebra)

Mapping:
  tau_escape   = clip(1.0 - kl_divergence / KL_COLLAPSE, 0, 1)
  drift_score  = clip(abs(entropy_delta) / ENTROPY_DELTA_MAX, 0, 1)
  chi_vector   = [kl_divergence, abs(entropy_delta)]
  betti_1      = 0.0 (not available from logprob — placeholder)
  confidence   = clip(exp(-kl_divergence), 0, 1)

References:
  ACP-1.yaml       — A011
  logprob_bridge.py — source of KL + entropy metrics
  cgir_signal_algebra.py — consumer
"""

from __future__ import annotations

# Confidence cap for missing logprobs is defined in api_logprob_extractor.py
# (MISSING_LOGPROB_CONFIDENCE_CAP = 0.65) and applied in ignition.py.
# Single source of truth — do not redefine here.
# See KNOWN_GAPS.md I18 for the planned migration to apply cap at adapter boundary.

import math
from dataclasses import dataclass
from typing import Optional

from cgir_signal_algebra import SensorReadings, evaluate as signal_eval, CHI_COL


# ─── CONSTANTS ────────────────────────────────────────────────────────────────

# KL divergence at which τ_escape hits 0 (complete distributional collapse)
KL_COLLAPSE_THRESHOLD = 2.0

# Entropy delta at which drift_score hits 1.0 (maximum rate of change)
ENTROPY_DELTA_MAX = 3.0

# Source identifier for signals from this adapter
LOGPROB_SOURCE = "LOGPROB_BRIDGE"


# ─── LOGPROB METRICS ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class LogprobMetrics:
    """
    Raw metrics from logprob_bridge.py.

    kl_divergence  — KL(P||Q) between consecutive token distributions.
                     0.0 = identical distributions (stable).
                     High = major distributional shift.

    entropy_delta  — H(t) - H(t-1). Positive = getting more uncertain.
                     Negative = getting more certain (can be drift too).

    mean_logprob   — Mean log probability. More negative = less confident.

    token_count    — Number of tokens in this response window.

    session_id     — Session this reading belongs to.

    logical_time   — Monotonic counter within session.
    """
    kl_divergence: float
    entropy_delta: float
    mean_logprob:  float
    token_count:   int
    session_id:    str
    logical_time:  int

    def __post_init__(self) -> None:
        if not self.session_id:
            raise ValueError("session_id must be non-empty")
        if self.logical_time < 0:
            raise ValueError("logical_time must be non-negative")
        if self.token_count < 0:
            raise ValueError("token_count must be non-negative")


# ─── ADAPTER ──────────────────────────────────────────────────────────────────

class LogprobBridgeAdapter:
    """
    Translates LogprobMetrics → SensorReadings.

    The mapping is deterministic: same metrics → same SensorReadings.
    No state. No side effects. Pure translation.
    """

    @staticmethod
    def to_sensor_readings(metrics: LogprobMetrics) -> SensorReadings:
        """
        Translate logprob metrics into CGIR SensorReadings.

        τ_escape:
          When KL=0 → τ=1.0 (stable, fully observable).
          When KL=KL_COLLAPSE_THRESHOLD → τ=0.0 (collapsed, CRITICAL).
          Clipped to [0.0, 1.0].

        drift_score:
          Absolute entropy delta normalized by max.
          Both positive and negative entropy deltas are drift.
          Clipped to [0.0, 1.0].

        chi_vector:
          [kl_divergence, abs(entropy_delta)] — two-component risk vector.
          KL and entropy rate both contribute to χ risk.
          Clipped to [0.0, 1.0] each.

        confidence:
          exp(-kl_divergence). At KL=0 → conf=1.0.
          At KL=2 → conf≈0.135. Monotonically decreasing with KL.
          Also penalized by very short token_count (< 10 tokens = uncertain).
          Clipped to [0.0, 1.0].
        """
        kl  = max(0.0, metrics.kl_divergence)
        dh  = metrics.entropy_delta
        mlp = metrics.mean_logprob

        # τ_escape: inverse of KL ratio — high KL = low observability
        tau = max(0.0, min(1.0, 1.0 - kl / max(KL_COLLAPSE_THRESHOLD, 1e-9)))

        # drift_score: |ΔH| normalized
        drift = max(0.0, min(1.0, abs(dh) / max(ENTROPY_DELTA_MAX, 1e-9)))

        # chi_vector: two-component risk — both clipped to [0, 1]
        chi_kl = max(0.0, min(1.0, kl / max(KL_COLLAPSE_THRESHOLD, 1e-9)))
        chi_dh = max(0.0, min(1.0, abs(dh) / max(ENTROPY_DELTA_MAX, 1e-9)))
        chi_vector = [chi_kl, chi_dh]

        # confidence: exp(-KL), penalized for very short responses
        base_conf = math.exp(-kl)
        token_penalty = min(1.0, metrics.token_count / 10.0) if metrics.token_count < 10 else 1.0
        confidence = max(0.0, min(1.0, base_conf * token_penalty))

        return SensorReadings(
            tau_escape   = tau,
            drift_score  = drift,
            chi_vector   = chi_vector,
            betti_1      = 0.0,       # not available from logprob — placeholder
            confidence   = confidence,
            source       = LOGPROB_SOURCE,
            logical_time = metrics.logical_time,
        )

    @staticmethod
    def evaluate_signal(
        metrics: LogprobMetrics,
        signal_id: str,
    ):
        """
        Convenience: LogprobMetrics → SensorReadings → SignalNode.
        Returns a SignalNode with emitted_by='SIGNAL_ALGEBRA'.
        Council wraps this into emitted_by='COUNCIL'.
        """
        readings = LogprobBridgeAdapter.to_sensor_readings(metrics)
        return signal_eval(readings, signal_id)


# ─── CONVENIENCE ──────────────────────────────────────────────────────────────

def adapt(metrics: LogprobMetrics) -> SensorReadings:
    """Convenience: metrics → SensorReadings."""
    return LogprobBridgeAdapter.to_sensor_readings(metrics)


# ─── TEST HELPERS ─────────────────────────────────────────────────────────────

def _stable_metrics(**overrides) -> LogprobMetrics:
    defaults = dict(
        kl_divergence=0.02,
        entropy_delta=0.05,
        mean_logprob=-1.2,
        token_count=150,
        session_id="test_session",
        logical_time=0,
    )
    defaults.update(overrides)
    return LogprobMetrics(**defaults)


# ─── TEST SUITE ───────────────────────────────────────────────────────────────

def _test_stable_metrics_produce_healthy_readings() -> bool:
    """Stable logprob metrics → high τ, low drift, low chi."""
    m = _stable_metrics()
    r = adapt(m)
    assert r.tau_escape > 0.90, f"tau={r.tau_escape}"
    assert r.drift_score < 0.10, f"drift={r.drift_score}"
    assert r.confidence > 0.90, f"conf={r.confidence}"
    assert r.source == LOGPROB_SOURCE
    return True

def _test_zero_kl_gives_max_tau() -> bool:
    """KL=0 → τ=1.0 (perfect observability)."""
    m = _stable_metrics(kl_divergence=0.0)
    r = adapt(m)
    assert r.tau_escape == 1.0
    return True

def _test_kl_collapse_gives_zero_tau() -> bool:
    """KL at collapse threshold → τ=0.0."""
    m = _stable_metrics(kl_divergence=KL_COLLAPSE_THRESHOLD)
    r = adapt(m)
    assert r.tau_escape == 0.0
    return True

def _test_high_kl_triggers_critical_severity() -> bool:
    """KL above collapse → CRITICAL severity in signal algebra."""
    from cgir_types import Severity
    m = _stable_metrics(kl_divergence=2.5)  # above KL_COLLAPSE_THRESHOLD
    sig = LogprobBridgeAdapter.evaluate_signal(m, "sig_kl_crit")
    assert sig.severity == Severity.CRITICAL, f"Got {sig.severity}"
    return True

def _test_high_entropy_delta_increases_drift() -> bool:
    """Large entropy delta → higher drift_score."""
    low  = adapt(_stable_metrics(entropy_delta=0.1))
    high = adapt(_stable_metrics(entropy_delta=2.0))
    assert high.drift_score > low.drift_score
    return True

def _test_short_token_count_reduces_confidence() -> bool:
    """Few tokens → lower confidence."""
    many = adapt(_stable_metrics(token_count=200))
    few  = adapt(_stable_metrics(token_count=3))
    assert few.confidence < many.confidence
    return True

def _test_chi_vector_has_two_components() -> bool:
    """chi_vector always has exactly 2 components."""
    r = adapt(_stable_metrics())
    assert len(r.chi_vector) == 2
    return True

def _test_all_outputs_in_unit_interval() -> bool:
    """tau, drift, chi, confidence all in [0, 1]."""
    for kl in [0.0, 0.5, 1.0, 2.0, 5.0]:
        m = _stable_metrics(kl_divergence=kl)
        r = adapt(m)
        assert 0.0 <= r.tau_escape <= 1.0
        assert 0.0 <= r.drift_score <= 1.0
        assert all(0.0 <= c <= 1.0 for c in r.chi_vector)
        assert 0.0 <= r.confidence <= 1.0
    return True

def _test_logical_time_preserved() -> bool:
    """logical_time passes through unchanged."""
    m = _stable_metrics(logical_time=42)
    r = adapt(m)
    assert r.logical_time == 42
    return True

def _test_evaluate_signal_returns_signal_node() -> bool:
    """evaluate_signal returns a SignalNode with SIGNAL_ALGEBRA emitter."""
    from cgir_types import SignalNode
    m = _stable_metrics()
    sig = LogprobBridgeAdapter.evaluate_signal(m, "lp_sig_001")
    assert isinstance(sig, SignalNode)
    assert sig.emitted_by == "SIGNAL_ALGEBRA"
    assert sig.source == LOGPROB_SOURCE
    return True

def _test_negative_entropy_delta_still_triggers_drift() -> bool:
    """Negative entropy delta (getting more certain) still counts as drift."""
    m = _stable_metrics(entropy_delta=-2.0)
    r = adapt(m)
    assert r.drift_score > 0.5, f"drift={r.drift_score}"
    return True

def _test_invalid_session_id_raises() -> bool:
    """Empty session_id raises ValueError."""
    try:
        LogprobMetrics(
            kl_divergence=0.1, entropy_delta=0.1, mean_logprob=-1.0,
            token_count=100, session_id="", logical_time=0,
        )
        raise AssertionError("Should have raised ValueError")
    except ValueError:
        pass
    return True

def _test_deterministic() -> bool:
    """Same metrics → same SensorReadings."""
    m = _stable_metrics()
    r1 = adapt(m)
    r2 = adapt(m)
    assert r1.tau_escape == r2.tau_escape
    assert r1.drift_score == r2.drift_score
    assert r1.confidence == r2.confidence
    return True


def run_tests() -> tuple:
    tests = sorted(
        [(name, obj) for name, obj in globals().items()
         if name.startswith("_test_") and callable(obj)],
        key=lambda x: x[0],
    )
    passed, failed, results = 0, 0, []
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    return passed, failed, results


if __name__ == "__main__":
    import hashlib as _hl
    print("=" * 70)
    print("LOGPROB BRIDGE ADAPTER — Labyrinth-OS / ACP-1 A011")
    print("=" * 70)
    print("\n  Wires logprob_bridge.py metrics → CGIR SensorReadings")
    print("  Partial A011 closure — full closure requires live Ollama (A010)\n")
    print("── TEST SUITE ──\n")
    passed, failed, results = run_tests()
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err: line += f"  → {err}"
        print(line)
    print(f"\n  Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed > 0:
        raise SystemExit(1)

    print("\n── DEMO ──\n")
    cases = [
        ("STABLE",   dict(kl_divergence=0.02, entropy_delta=0.05)),
        ("ELEVATED", dict(kl_divergence=0.30, entropy_delta=0.80)),
        ("COLLAPSE", dict(kl_divergence=2.10, entropy_delta=2.50)),
    ]
    for label, kw in cases:
        m = _stable_metrics(**kw)
        r = adapt(m)
        sig = LogprobBridgeAdapter.evaluate_signal(m, f"demo_{label.lower()}")
        print(f"  {label:10} τ={r.tau_escape:.3f}  drift={r.drift_score:.3f}  "
              f"chi={[round(c,3) for c in r.chi_vector]}  "
              f"sev={sig.severity.value}")

    with open(__file__, "rb") as f:
        fh = _hl.sha256(f.read()).hexdigest()
    print(f"\n── RECEIPT ──\n  SHA-256: {fh}\n  Tests: {passed}/{passed+failed}")
    print(f"\n{'='*70}\n  LOGPROB BRIDGE ADAPTER — COMPLETE\n{'='*70}")
