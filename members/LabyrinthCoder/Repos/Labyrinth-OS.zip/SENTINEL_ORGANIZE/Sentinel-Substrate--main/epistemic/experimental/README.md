# epistemic/experimental/

Experimental and external reference material.

## Rule

Nothing in this directory influences execution.
Nothing here is promoted without passing:
  LABELING → ARCHIVE → PROMOTION → REALITY_GATE

This is Lane 1 creative/speculative territory only.

## Contents

- `resonant_memory_ref.md` — external resonant/frequency storage concept (condensed)
- `distributed_topology_ref.md` — distributed multi-node deployment reference
- `wasm_rust_ref.md` — WebAssembly + Rust integration reference

## Status

All files here are EXPERIMENTAL. Classification: RAW or EXPERIMENTAL.
None are VALIDATED. None influence execution.
