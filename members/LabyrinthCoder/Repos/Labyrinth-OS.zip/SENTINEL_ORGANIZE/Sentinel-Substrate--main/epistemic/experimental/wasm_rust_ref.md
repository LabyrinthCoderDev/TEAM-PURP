# WebAssembly + Rust Integration — Reference

**Classification:** EXPERIMENTAL  
**Status:** RAW — reference for future Rust crate deployment  
**Relevant to:** Labyrinth-OS Rust crates (Phase 2+)

---

## Why This Matters for Labyrinth-OS

The Rust crates already built (`cgir-types`, `gate`, `ledger-chronicle`, etc.)
can compile to WebAssembly targets. This enables:

- Running the enforcement layer client-side with no server round-trips
- Browser-based hashchain verification (public, reviewable)
- Edge deployment of the cryptographic core
- Near-native speed (5–20× faster than JS) for hashing, compression, token processing

**Current state:** Crates written. Not yet compiled to any target (A012 open).

---

## Compile Targets

| Target | Use |
|--------|-----|
| `wasm32-unknown-unknown` | Browser (no OS) |
| `wasm32-wasip2` | Server/edge with file I/O (Wasmtime, WasmEdge) |
| Native | Default — current test target |

---

## Core Toolchain

```bash
rustup target add wasm32-unknown-unknown
cargo install wasm-pack
wasm-pack build --target bundler   # produces npm-compatible package
```

**Tools:**
- `wasm-pack` — one-command build + packaging (v0.14.0 in 2026)
- `wasm-bindgen` — Rust ↔ JS interop, auto TypeScript definitions
- `wasm-opt` — shrinks .wasm binary 10–30%

---

## What Labyrinth-OS Crates Need in Cargo.toml

```toml
[lib]
crate-type = ["cdylib"]   # required for Wasm output

[dependencies]
wasm-bindgen = "0.2"
blake3 = "1"              # excellent Wasm SIMD support
# zstd compiles cleanly to Wasm
# web-sys for browser storage if needed
```

---

## Example — Hash + Compress Pipeline

```rust
use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub fn hash_and_compress(data: &[u8]) -> Vec<u8> {
    let hash = blake3::hash(data);
    // This is the ledger-chronicle pattern:
    // prefix 32-byte Blake3 hash, then compressed content
    let mut result = hash.as_bytes().to_vec();
    // append compressed data...
    result
}

#[wasm_bindgen]
pub fn verify_chain_entry(data: &[u8], expected_hash: &[u8]) -> bool {
    blake3::hash(data).as_bytes() == expected_hash
}
```

---

## ML Inference in Rust (Candle)

Candle is Hugging Face's pure-Rust ML inference framework.
Relevant for: running the Ghost (LLM) inference inside the Rust layer.

```toml
[dependencies]
candle-core = "0.6"
candle-nn = "0.6"
```

This would make `shadow-ghost` crate the inference layer, keeping
the full stack in Rust without Python dependency for inference.

**Not needed for A010** (Python ignition handles inference).
**Relevant for Phase 3** distributed deployment.

---

## Binary Size Optimization (Critical for Wasm)

```toml
[profile.release]
opt-level = "z"    # optimize for size
lto = true         # link-time optimization
panic = "abort"    # smaller than unwind
```

Then: `wasm-opt -Oz output.wasm -o output_opt.wasm`

---

## Storage in Wasm Context

Standard crates (`sled`, `rocksdb`) don't compile to Wasm.
Use instead:
- `web-sys` + IndexedDB/OPFS for browser persistence
- Pure-Rust `redb` (Wasm-compatible embedded DB)
- Our own `chunk_store.py` pattern ported to Rust for edge

---

## Threading Note

Rayon-style parallelism requires SharedArrayBuffer + Web Workers.
`crossbeam` channels work but need manual Worker setup.
For Labyrinth-OS: start single-threaded, add Workers later.

---

## Phase Order for Wasm Deployment

1. Get `cargo build --workspace` passing (A012 — needs toolchain)
2. Add `wasm-pack` to CI
3. Compile `ledger-chronicle` + `cgir-types` to Wasm first (smallest, most critical)
4. Build browser-based chain verifier (public X audit tool idea)
5. Full enforcement layer in Wasm for edge deployment

---

## Key Resources

- Rust and WebAssembly Book: https://rustwasm.github.io/book/
- wasm-bindgen Guide: https://rustwasm.github.io/docs/wasm-bindgen/
- Candle (Rust ML): https://github.com/huggingface/candle

*This file: `epistemic/experimental/wasm_rust_ref.md`*  
*Reference for future Rust crate deployment. Not active until A012 closes.*
