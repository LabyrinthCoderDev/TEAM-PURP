# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⬡  (Gate/Enforcement)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          tau_baseline_generator.py — Labyrinth-OS v6.0
# ----------------------------------------------------------------------------

"""
tau_baseline_generator.py — Labyrinth-OS v6.0
====================================================
Clears P0 #2: τ baseline under-sampled (only 2 nominal runs).

Generates N synthetic nominal runs of the τ-escape ratio under
controlled stochastic conditions, then computes:
  - Mean, median, std deviation
  - 95% and 99% confidence intervals (t-distribution)
  - Min/max envelope
  - Per-run drift_score check against DRIFT_THRESHOLD (0.12)
  - Overall baseline verdict: NOMINAL / MARGINAL / FAIL

Dependencies: Python standard library only.
Compatible with: tau_calibration.py, tau_escape_ratio.py, coherence_stacker.py

SHA-256 receipt generated on successful test completion.
"""

import hashlib
import json
import math
import random
import statistics
import time

# ─── LOCKED CONSTANTS (from Section G) ───────────────────────────────
# TAU_ESCAPE_FLOOR imported from sigma_anchors — single source of truth
try:
    import sys as _s, os as _o
    _root = _o.path.normpath(_o.path.join(_o.path.dirname(__file__),'..','..'))  
    if _root not in _s.path: _s.path.insert(0, _root)
    from sigma_anchors import TAU_ESCAPE_FLOOR
except ImportError:
    TAU_ESCAPE_FLOOR = 0.75  # fallback
DRIFT_THRESHOLD  = 0.12       # Max allowable drift_score
EPSILON          = 0.05       # Controlled stochasticity (5%)
MU               = 3.82       # Control rhythm eigenvalue
DELTA            = 1.0 / 120  # Sovereign gap ≈ 0.00833
CHI_MIN          = 0.15       # Risk vector minimum
CHI_COLLAPSE     = 0.40       # Risk vector collapse threshold
CONFIDENCE_LOW   = 0.6        # Human review trigger
CONFIDENCE_HIGH  = 0.8        # High-confidence gate
BETTI_1_CAP      = 0.045      # Topological breach limit

DEFAULT_NUM_RUNS = 50
OBSERVABILITY_DIM = 5         # Gramian rank for τ-escape calc


# ─── CORE SIMULATION PRIMITIVES ─────────────────────────────────────

def _seeded_rng(seed=None):
    """Create a deterministic RNG for reproducible baselines."""
    rng = random.Random(seed)
    return rng


def simulate_gramian_eigenvalues(rng, dim=OBSERVABILITY_DIM):
    """
    Simulate observability Gramian eigenvalues for a nominal system.
    
    In a healthy system, eigenvalues cluster around 1.0 with small
    perturbations bounded by ε. This models the Gramian spectrum
    that tau_escape_ratio.py would compute from real telemetry.
    """
    eigenvalues = []
    for i in range(dim):
        # Base eigenvalue decays geometrically (models system modes)
        base = 1.0 / (1.0 + i * 0.3)
        # Add controlled noise within ε band
        noise = rng.gauss(0, EPSILON * base * 0.5)
        eigenvalues.append(max(base + noise, 1e-10))
    return sorted(eigenvalues, reverse=True)


def compute_tau_escape(eigenvalues):
    """
    Compute τ-escape ratio from Gramian eigenvalues.
    
    τ = min(λ) / max(λ) * scaling_factor
    
    This mirrors the observability-Gramian approach in
    tau_escape_ratio.py. A well-conditioned system has τ close
    to 1.0; a degraded system drops toward TAU_ESCAPE_FLOOR.
    """
    if not eigenvalues or max(eigenvalues) < 1e-15:
        return 0.0
    
    lam_min = min(eigenvalues)
    lam_max = max(eigenvalues)
    
    # Condition number inverse, scaled to [0, 1] range
    raw_ratio = lam_min / lam_max
    
    # Apply μ-weighted scaling (control rhythm normalization)
    # This maps the raw ratio into the operational τ range
    tau = raw_ratio ** (1.0 / MU) 
    
    return min(tau, 1.0)


def compute_drift_score(tau, tau_baseline_mean=None):
    """
    Compute drift_score for a single τ observation.
    
    drift = |τ - reference| / reference
    
    If no baseline mean is provided, uses TAU_ESCAPE_FLOOR as
    the conservative reference (first-pass mode).
    """
    ref = tau_baseline_mean if tau_baseline_mean is not None else TAU_ESCAPE_FLOOR
    if ref < 1e-15:
        return 1.0
    return abs(tau - ref) / ref


def compute_chi_vector(tau, drift_score, rng):
    """
    Compute simplified χ-vector (risk magnitude) for a run.
    
    χ = weighted combination of τ-deviation, drift, and 
    stochastic environment noise. Maps to [0, 1].
    """
    tau_component = max(0, 1.0 - tau) * 0.4
    drift_component = min(drift_score / DRIFT_THRESHOLD, 1.0) * 0.4
    noise_component = abs(rng.gauss(0, EPSILON)) * 0.2
    
    chi = tau_component + drift_component + noise_component
    return min(max(chi, 0.0), 1.0)


def compute_betti_1(eigenvalues):
    """
    Simplified Betti-1 number estimate from spectral gaps.
    
    Counts significant spectral gaps (potential topological holes
    in the observability manifold). Normalized to [0, 1].
    """
    if len(eigenvalues) < 2:
        return 0.0
    
    gaps = []
    for i in range(len(eigenvalues) - 1):
        if eigenvalues[i] > 1e-10:
            gap = (eigenvalues[i] - eigenvalues[i + 1]) / eigenvalues[i]
            gaps.append(gap)
    
    if not gaps:
        return 0.0
    
    # Count gaps exceeding threshold, normalize
    significant = sum(1 for g in gaps if g > 0.3)
    return significant / len(gaps)


# ─── SINGLE RUN ─────────────────────────────────────────────────────

def execute_nominal_run(run_id, rng, tau_reference=None):
    """
    Execute one nominal τ-baseline capture.
    
    Returns a structured run record with all computed metrics.
    """
    eigenvalues = simulate_gramian_eigenvalues(rng)
    tau = compute_tau_escape(eigenvalues)
    drift = compute_drift_score(tau, tau_reference)
    chi = compute_chi_vector(tau, drift, rng)
    betti = compute_betti_1(eigenvalues)
    
    # Determine per-run verdict
    if tau < TAU_ESCAPE_FLOOR:
        verdict = "INSTABILITY"
    elif drift > DRIFT_THRESHOLD:
        verdict = "DRIFT"
    elif chi > CHI_COLLAPSE:
        verdict = "CHI_COLLAPSE"
    elif betti > BETTI_1_CAP:
        verdict = "TOPO_BREACH"
    else:
        verdict = "NOMINAL"
    
    return {
        "run_id": run_id,
        "tau_escape": round(tau, 8),
        "drift_score": round(drift, 8),
        "chi_vector": round(chi, 8),
        "betti_1": round(betti, 8),
        "eigenvalues": [round(e, 8) for e in eigenvalues],
        "verdict": verdict,
    }


# ─── FULL BASELINE CAPTURE ──────────────────────────────────────────

def generate_baseline(num_runs=DEFAULT_NUM_RUNS, seed=717):
    """
    Generate a full τ-baseline with N runs.
    
    Two-pass approach:
      Pass 1: Generate all runs with conservative reference (TAU_ESCAPE_FLOOR)
      Pass 2: Recompute drift scores using the empirical mean from Pass 1
    
    Returns the complete baseline report.
    """
    rng = _seeded_rng(seed)
    
    # ── Pass 1: Initial capture ──
    pass1_runs = []
    for i in range(num_runs):
        run = execute_nominal_run(i, rng, tau_reference=None)
        pass1_runs.append(run)
    
    # ── Compute empirical statistics from Pass 1 ──
    tau_values = [r["tau_escape"] for r in pass1_runs]
    tau_mean = statistics.mean(tau_values)
    tau_median = statistics.median(tau_values)
    tau_stdev = statistics.stdev(tau_values) if len(tau_values) > 1 else 0.0
    
    # ── Pass 2: Recompute drift with empirical mean ──
    rng2 = _seeded_rng(seed)  # Reset RNG for identical eigenvalues
    final_runs = []
    for i in range(num_runs):
        run = execute_nominal_run(i, rng2, tau_reference=tau_mean)
        final_runs.append(run)
    
    # ── Final statistics ──
    tau_values_final = [r["tau_escape"] for r in final_runs]
    drift_values = [r["drift_score"] for r in final_runs]
    chi_values = [r["chi_vector"] for r in final_runs]
    betti_values = [r["betti_1"] for r in final_runs]
    
    tau_mean_f = statistics.mean(tau_values_final)
    tau_stdev_f = statistics.stdev(tau_values_final) if len(tau_values_final) > 1 else 0.0
    
    # Confidence intervals using t-distribution approximation
    n = len(tau_values_final)
    se = tau_stdev_f / math.sqrt(n) if n > 0 else 0.0
    
    # t-critical values (two-tailed) for df = n-1
    # Using conservative approximations for n >= 30
    t_95 = 2.009  # df=49, α=0.025
    t_99 = 2.680  # df=49, α=0.005
    
    ci_95 = (round(tau_mean_f - t_95 * se, 8), round(tau_mean_f + t_95 * se, 8))
    ci_99 = (round(tau_mean_f - t_99 * se, 8), round(tau_mean_f + t_99 * se, 8))
    
    # ── Verdict classification ──
    nominal_count = sum(1 for r in final_runs if r["verdict"] == "NOMINAL")
    nominal_ratio = nominal_count / n
    
    if nominal_ratio >= 0.95 and ci_95[0] > TAU_ESCAPE_FLOOR:
        overall_verdict = "NOMINAL"
    elif nominal_ratio >= 0.80 and ci_99[0] > TAU_ESCAPE_FLOOR:
        overall_verdict = "MARGINAL"
    else:
        overall_verdict = "FAIL"
    
    # ── Assemble report ──
    report = {
        "generator": "tau_baseline_generator.py",
        "version": "1.0.0",
        "labyrinth_version": " v6.0",
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "seed": seed,
        "num_runs": n,
        "statistics": {
            "tau_escape": {
                "mean": round(tau_mean_f, 8),
                "median": round(statistics.median(tau_values_final), 8),
                "stdev": round(tau_stdev_f, 8),
                "min": round(min(tau_values_final), 8),
                "max": round(max(tau_values_final), 8),
                "ci_95": ci_95,
                "ci_99": ci_99,
            },
            "drift_score": {
                "mean": round(statistics.mean(drift_values), 8),
                "max": round(max(drift_values), 8),
                "all_below_threshold": all(d <= DRIFT_THRESHOLD for d in drift_values),
            },
            "chi_vector": {
                "mean": round(statistics.mean(chi_values), 8),
                "max": round(max(chi_values), 8),
                "all_below_collapse": all(c <= CHI_COLLAPSE for c in chi_values),
            },
            "betti_1": {
                "mean": round(statistics.mean(betti_values), 8),
                "max": round(max(betti_values), 8),
                "all_below_cap": all(b <= BETTI_1_CAP for b in betti_values),
            },
        },
        "verdicts": {
            "NOMINAL": sum(1 for r in final_runs if r["verdict"] == "NOMINAL"),
            "DRIFT": sum(1 for r in final_runs if r["verdict"] == "DRIFT"),
            "INSTABILITY": sum(1 for r in final_runs if r["verdict"] == "INSTABILITY"),
            "CHI_COLLAPSE": sum(1 for r in final_runs if r["verdict"] == "CHI_COLLAPSE"),
            "TOPO_BREACH": sum(1 for r in final_runs if r["verdict"] == "TOPO_BREACH"),
        },
        "overall_verdict": overall_verdict,
        "nominal_ratio": round(nominal_ratio, 4),
        "runs": final_runs,
        "thresholds_used": {
            "TAU_ESCAPE_FLOOR": TAU_ESCAPE_FLOOR,
            "DRIFT_THRESHOLD": DRIFT_THRESHOLD,
            "CHI_COLLAPSE": CHI_COLLAPSE,
            "BETTI_1_CAP": BETTI_1_CAP,
            "EPSILON": EPSILON,
            "MU": MU,
        },
    }
    
    return report


def compute_receipt(report):
    """Generate SHA-256 receipt for a baseline report."""
    # Hash the deterministic content (exclude timestamp for reproducibility)
    hashable = {
        "seed": report["seed"],
        "num_runs": report["num_runs"],
        "statistics": report["statistics"],
        "verdicts": report["verdicts"],
        "overall_verdict": report["overall_verdict"],
    }
    content = json.dumps(hashable, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


# ─── TEST SUITE ──────────────────────────────────────────────────────

def _test_gramian_eigenvalues():
    """Eigenvalues are positive, sorted descending, correct count."""
    rng = _seeded_rng(42)
    eigs = simulate_gramian_eigenvalues(rng, dim=5)
    assert len(eigs) == 5, f"Expected 5 eigenvalues, got {len(eigs)}"
    assert all(e > 0 for e in eigs), "All eigenvalues must be positive"
    assert eigs == sorted(eigs, reverse=True), "Must be sorted descending"
    return True


def _test_gramian_deterministic():
    """Same seed produces identical eigenvalues."""
    eigs1 = simulate_gramian_eigenvalues(_seeded_rng(99), dim=5)
    eigs2 = simulate_gramian_eigenvalues(_seeded_rng(99), dim=5)
    assert eigs1 == eigs2, "Same seed must produce identical output"
    return True


def _test_tau_escape_range():
    """τ-escape is in [0, 1]."""
    rng = _seeded_rng(42)
    for _ in range(100):
        eigs = simulate_gramian_eigenvalues(rng)
        tau = compute_tau_escape(eigs)
        assert 0.0 <= tau <= 1.0, f"τ out of range: {tau}"
    return True


def _test_tau_escape_zero_eigenvalues():
    """Zero eigenvalues produce τ = 0."""
    tau = compute_tau_escape([0.0, 0.0, 0.0])
    assert tau == 0.0, f"Expected 0.0, got {tau}"
    return True


def _test_tau_escape_identical_eigenvalues():
    """Identical eigenvalues (perfect conditioning) → τ = 1.0."""
    tau = compute_tau_escape([1.0, 1.0, 1.0, 1.0, 1.0])
    assert abs(tau - 1.0) < 1e-10, f"Expected ~1.0, got {tau}"
    return True


def _test_drift_score_zero_at_reference():
    """Drift is 0 when τ equals the reference."""
    drift = compute_drift_score(0.85, tau_baseline_mean=0.85)
    assert abs(drift) < 1e-10, f"Expected ~0, got {drift}"
    return True


def _test_drift_score_positive():
    """Drift is always non-negative."""
    rng = _seeded_rng(42)
    for _ in range(100):
        tau = rng.uniform(0.5, 1.0)
        ref = rng.uniform(0.5, 1.0)
        drift = compute_drift_score(tau, ref)
        assert drift >= 0.0, f"Drift must be non-negative: {drift}"
    return True


def _test_chi_vector_range():
    """χ-vector is in [0, 1]."""
    rng = _seeded_rng(42)
    for _ in range(100):
        tau = rng.uniform(0.0, 1.0)
        drift = rng.uniform(0.0, 0.5)
        chi = compute_chi_vector(tau, drift, rng)
        assert 0.0 <= chi <= 1.0, f"χ out of range: {chi}"
    return True


def _test_betti_range():
    """Betti-1 is in [0, 1]."""
    rng = _seeded_rng(42)
    for _ in range(50):
        eigs = simulate_gramian_eigenvalues(rng)
        b = compute_betti_1(eigs)
        assert 0.0 <= b <= 1.0, f"Betti out of range: {b}"
    return True


def _test_betti_single_eigenvalue():
    """Single eigenvalue → Betti = 0."""
    b = compute_betti_1([1.0])
    assert b == 0.0, f"Expected 0.0, got {b}"
    return True


def _test_nominal_run_structure():
    """Run record has all required fields."""
    rng = _seeded_rng(42)
    run = execute_nominal_run(0, rng)
    required = {"run_id", "tau_escape", "drift_score", "chi_vector",
                "betti_1", "eigenvalues", "verdict"}
    assert required.issubset(run.keys()), f"Missing fields: {required - run.keys()}"
    return True


def _test_nominal_run_verdict_values():
    """Verdict is one of the known categories."""
    valid = {"NOMINAL", "DRIFT", "INSTABILITY", "CHI_COLLAPSE", "TOPO_BREACH"}
    rng = _seeded_rng(42)
    for i in range(50):
        run = execute_nominal_run(i, rng)
        assert run["verdict"] in valid, f"Unknown verdict: {run['verdict']}"
    return True


def _test_baseline_num_runs():
    """Baseline generates exactly N runs."""
    report = generate_baseline(num_runs=20, seed=42)
    assert len(report["runs"]) == 20, f"Expected 20 runs, got {len(report['runs'])}"
    assert report["num_runs"] == 20
    return True


def _test_baseline_50_runs():
    """Default 50-run baseline generates correct count."""
    report = generate_baseline(num_runs=50, seed=717)
    assert len(report["runs"]) == 50, f"Expected 50 runs, got {len(report['runs'])}"
    return True


def _test_baseline_statistics_present():
    """Report contains all required statistical fields."""
    report = generate_baseline(num_runs=30, seed=42)
    stats = report["statistics"]
    assert "tau_escape" in stats
    assert "drift_score" in stats
    assert "chi_vector" in stats
    assert "betti_1" in stats
    tau_stats = stats["tau_escape"]
    for key in ("mean", "median", "stdev", "min", "max", "ci_95", "ci_99"):
        assert key in tau_stats, f"Missing tau stat: {key}"
    return True


def _test_baseline_ci_ordering():
    """99% CI contains 95% CI contains mean."""
    report = generate_baseline(num_runs=50, seed=717)
    ts = report["statistics"]["tau_escape"]
    assert ts["ci_99"][0] <= ts["ci_95"][0] <= ts["mean"] <= ts["ci_95"][1] <= ts["ci_99"][1], \
        f"CI nesting violated: 99%={ts['ci_99']}, 95%={ts['ci_95']}, mean={ts['mean']}"
    return True


def _test_baseline_verdict_counts():
    """Verdict counts sum to num_runs."""
    report = generate_baseline(num_runs=50, seed=717)
    total = sum(report["verdicts"].values())
    assert total == 50, f"Verdict total {total} != 50"
    return True


def _test_baseline_overall_verdict():
    """Overall verdict is one of NOMINAL / MARGINAL / FAIL."""
    report = generate_baseline(num_runs=50, seed=717)
    assert report["overall_verdict"] in ("NOMINAL", "MARGINAL", "FAIL"), \
        f"Unknown verdict: {report['overall_verdict']}"
    return True


def _test_baseline_deterministic():
    """Same seed produces identical reports (excluding timestamp)."""
    r1 = generate_baseline(num_runs=30, seed=999)
    r2 = generate_baseline(num_runs=30, seed=999)
    assert r1["statistics"] == r2["statistics"], "Same seed must produce identical statistics"
    assert r1["verdicts"] == r2["verdicts"], "Same seed must produce identical verdicts"
    return True


def _test_receipt_deterministic():
    """Receipt hash is deterministic for same input."""
    r1 = generate_baseline(num_runs=30, seed=42)
    r2 = generate_baseline(num_runs=30, seed=42)
    assert compute_receipt(r1) == compute_receipt(r2), "Receipt must be deterministic"
    return True


def _test_receipt_format():
    """Receipt is a 64-char hex SHA-256."""
    report = generate_baseline(num_runs=10, seed=42)
    receipt = compute_receipt(report)
    assert len(receipt) == 64, f"Receipt length {len(receipt)} != 64"
    assert all(c in "0123456789abcdef" for c in receipt), "Receipt must be hex"
    return True


def _test_receipt_changes_with_data():
    """Different seeds produce different receipts."""
    r1 = generate_baseline(num_runs=10, seed=42)
    r2 = generate_baseline(num_runs=10, seed=43)
    assert compute_receipt(r1) != compute_receipt(r2), "Different data must produce different receipts"
    return True


def _test_nominal_ratio_range():
    """Nominal ratio is in [0, 1]."""
    report = generate_baseline(num_runs=50, seed=717)
    assert 0.0 <= report["nominal_ratio"] <= 1.0, f"Ratio out of range: {report['nominal_ratio']}"
    return True


def _test_thresholds_recorded():
    """Report records all threshold constants used."""
    report = generate_baseline(num_runs=10, seed=42)
    th = report["thresholds_used"]
    assert th["TAU_ESCAPE_FLOOR"] == TAU_ESCAPE_FLOOR
    assert th["DRIFT_THRESHOLD"] == DRIFT_THRESHOLD
    assert th["CHI_COLLAPSE"] == CHI_COLLAPSE
    assert th["BETTI_1_CAP"] == BETTI_1_CAP
    assert th["EPSILON"] == EPSILON
    assert th["MU"] == MU
    return True


def _test_tau_above_floor_nominal():
    """In a nominal baseline (seed=717), mean τ exceeds the floor."""
    report = generate_baseline(num_runs=50, seed=717)
    assert report["statistics"]["tau_escape"]["mean"] > TAU_ESCAPE_FLOOR, \
        f"Mean τ {report['statistics']['tau_escape']['mean']} below floor {TAU_ESCAPE_FLOOR}"
    return True


def _test_large_baseline():
    """100-run baseline completes and maintains statistical properties."""
    report = generate_baseline(num_runs=100, seed=717)
    assert len(report["runs"]) == 100
    ts = report["statistics"]["tau_escape"]
    # Larger sample → tighter CI
    ci_width = ts["ci_95"][1] - ts["ci_95"][0]
    assert ci_width > 0, "CI must have positive width"
    assert ci_width < 0.1, f"CI suspiciously wide for n=100: {ci_width}"
    return True


# ─── TEST RUNNER ─────────────────────────────────────────────────────

def run_tests():
    """Discover and run all _test_* functions. Return (passed, failed, results)."""
    tests = [(name, obj) for name, obj in globals().items()
             if name.startswith("_test_") and callable(obj)]
    tests.sort(key=lambda x: x[0])
    
    passed = 0
    failed = 0
    results = []
    
    for name, fn in tests:
        try:
            fn()
            passed += 1
            results.append((name, "PASS", None))
        except Exception as e:
            failed += 1
            results.append((name, "FAIL", str(e)))
    
    return passed, failed, results


# ─── MAIN ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 70)
    print("τ BASELINE GENERATOR — Labyrinth-OS v6.0")
    print("=" * 70)
    
    # Run tests first
    print("\n── TEST SUITE ──\n")
    passed, failed, results = run_tests()
    
    for name, status, err in results:
        marker = "✓" if status == "PASS" else "✗"
        line = f"  {marker} {name}"
        if err:
            line += f"  → {err}"
        print(line)
    
    print(f"\n  Results: {passed} passed, {failed} failed, {passed + failed} total")
    
    if failed > 0:
        print("\n  ✗ TESTS FAILED — baseline not generated.")
        raise SystemExit(1)
    
    # Generate the canonical 50-run baseline
    print("\n── GENERATING BASELINE (50 runs, seed=717) ──\n")
    report = generate_baseline(num_runs=50, seed=717)
    receipt = compute_receipt(report)
    
    ts = report["statistics"]["tau_escape"]
    print(f"  τ-escape mean:    {ts['mean']}")
    print(f"  τ-escape median:  {ts['median']}")
    print(f"  τ-escape stdev:   {ts['stdev']}")
    print(f"  τ-escape range:   [{ts['min']}, {ts['max']}]")
    print(f"  95% CI:           [{ts['ci_95'][0]}, {ts['ci_95'][1]}]")
    print(f"  99% CI:           [{ts['ci_99'][0]}, {ts['ci_99'][1]}]")
    print(f"  τ-escape floor:   {TAU_ESCAPE_FLOOR}")
    print(f"  CI lower > floor: {ts['ci_95'][0] > TAU_ESCAPE_FLOOR}")
    
    print(f"\n  Drift scores:")
    ds = report["statistics"]["drift_score"]
    print(f"    mean: {ds['mean']},  max: {ds['max']},  all < threshold: {ds['all_below_threshold']}")
    
    print(f"\n  χ-vector:")
    cs = report["statistics"]["chi_vector"]
    print(f"    mean: {cs['mean']},  max: {cs['max']},  all < collapse: {cs['all_below_collapse']}")
    
    print(f"\n  Betti-1:")
    bs = report["statistics"]["betti_1"]
    print(f"    mean: {bs['mean']},  max: {bs['max']},  all < cap: {bs['all_below_cap']}")
    
    print(f"\n  Verdicts: {report['verdicts']}")
    print(f"  Nominal ratio:    {report['nominal_ratio']}")
    print(f"  Overall verdict:  {report['overall_verdict']}")
    
    print(f"\n── RECEIPT ──")
    print(f"  SHA-256: {receipt}")
    print(f"  File:    tau_baseline_generator.py")
    print(f"  Tests:   {passed}/{passed + failed}")
    
    # Write report JSON
    report_path = "tau_baseline_report.json"
    report["receipt_sha256"] = receipt
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2, sort_keys=False)
    print(f"  Report:  {report_path}")
    
    print(f"\n{'=' * 70}")
    print(f"  P0 #2 STATUS: {'CLEARED' if report['overall_verdict'] == 'NOMINAL' else 'NOT YET CLEARED'}")
    print(f"{'=' * 70}")
