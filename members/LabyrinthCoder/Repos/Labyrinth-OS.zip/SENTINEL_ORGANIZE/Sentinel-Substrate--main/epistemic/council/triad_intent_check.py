# -- SOTERION METADATA -------------------------------------------------------
# sigil:         ⚖  (Council/Decision)
# owner:         @LabyrinthCoder
# status:        active
# last_reviewed: 2026-06-05
# role:          Triad Intent Check -- Sun Tzu axis on council resolver
# ----------------------------------------------------------------------------

"""
triad_intent_check.py -- Labyrinth-OS / Epistemic / Council
=============================================================
Triad Intent Check: Sun Tzu Axis

The third axis on the council resolver. Where Watcher A checks
internal consistency and Watcher B checks adversarial signals,
the Triad checks one question:

    Does this proposal serve the long-term health of the system?

Named the "Sun Tzu axis" because it evaluates strategic intent --
not whether a proposal is correct (Watcher A) or safe (Watcher B),
but whether it serves the system's long-term purpose or undermines it.

The three axes together:
    Watcher A: "Is this internally consistent?"
    Watcher B: "Is this adversarially sound?"
    Triad:     "Does this serve long-term system health?"

A proposal can pass both watchers and still fail the triad if it
is locally optimal but strategically corrosive -- e.g. proposals
that erode trust mechanisms, that simplify governance in ways that
reduce auditability, or that accumulate technical debt in the gate.

Calibration status
------------------
The triad scoring weights depend on A015 (fractal parameter solver)
for betti_1 calibration. Until A015 is fully closed with live data,
the triad operates in ADVISORY mode -- it records its assessment
but does not block proposals. After A015, it can be promoted to
VOTING mode where it contributes to the council verdict.

Current mode: ADVISORY (records but does not block)
Target mode:  VOTING (after A015 live data calibration)

References
----------
    epistemic/council/council_resolver.py -- council integration point
    execution/formal/fractal_parameter_solver.py -- A015 calibration
    ACP-1 A015 -- betti_1 calibration (PARTIAL)
    sigma_anchors.py -- BETTI_1_CAP for topological loop threshold
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any, Dict, List, Optional

try:
    import sys as _sys, os as _os
    _root = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), '..', '..'))
    if _root not in _sys.path:
        _sys.path.insert(0, _root)
    from sigma_anchors import (
        TAU_ESCAPE_FLOOR, BETTI_1_CAP, CONFIDENCE_FLOOR,
        LABYRINTH_CONTRACT_VERSION,
    )
    _SIGMA_OK = True
except ImportError:
    TAU_ESCAPE_FLOOR        = 0.75
    BETTI_1_CAP             = 0.045
    CONFIDENCE_FLOOR        = 0.65
    LABYRINTH_CONTRACT_VERSION = "1.0.0"
    _SIGMA_OK               = False


# ---- TRIAD MODE -------------------------------------------------------------

@unique
class TriadMode(str, Enum):
    ADVISORY = "ADVISORY"   # records but does not block (current)
    VOTING   = "VOTING"     # contributes to council verdict (after A015)
    DISABLED = "DISABLED"   # bypassed entirely


# ---- INTENT DIMENSIONS ------------------------------------------------------

@unique
class IntentDimension(str, Enum):
    """
    The seven dimensions of long-term system health the triad evaluates.
    Each dimension is scored 0.0 to 1.0. Higher = healthier.
    """
    AUDITABILITY     = "AUDITABILITY"      # does this preserve audit trail quality?
    TRUST_INTEGRITY  = "TRUST_INTEGRITY"   # does this maintain trust mechanisms?
    GATE_HEALTH      = "GATE_HEALTH"       # does this keep gate logic sound?
    REVERSIBILITY    = "REVERSIBILITY"     # can this be undone if wrong?
    SCOPE_DISCIPLINE = "SCOPE_DISCIPLINE"  # does this stay within intended scope?
    DEBT_AWARENESS   = "DEBT_AWARENESS"    # does this avoid accumulating technical debt?
    ALIGNMENT        = "ALIGNMENT"         # does this serve the system's stated purpose?


# ---- DIMENSION WEIGHTS (calibrate after A015) -------------------------------
_DIMENSION_WEIGHTS: Dict[str, float] = {
    IntentDimension.AUDITABILITY:     1.5,   # highest -- audit trail is foundational
    IntentDimension.TRUST_INTEGRITY:  1.5,   # highest -- trust mechanisms are critical
    IntentDimension.GATE_HEALTH:      1.3,
    IntentDimension.REVERSIBILITY:    1.0,
    IntentDimension.SCOPE_DISCIPLINE: 1.0,
    IntentDimension.DEBT_AWARENESS:   0.8,
    IntentDimension.ALIGNMENT:        1.2,
}


# ---- INTENT SIGNAL ----------------------------------------------------------

@dataclass
class IntentSignal:
    """A signal about one dimension of long-term system health."""
    dimension:    IntentDimension
    score:        float          # 0.0 to 1.0. Higher = healthier.
    confidence:   float          # how confident is this assessment?
    reasoning:    str            # why this score


# ---- TRIAD ASSESSMENT -------------------------------------------------------

@dataclass
class TriadAssessment:
    """
    Full triad assessment for one proposal.

    composite_score: weighted average across all dimensions.
    mode:            ADVISORY or VOTING.
    In ADVISORY mode, verdict is always PASS -- only records concerns.
    In VOTING mode, verdict reflects actual blocking threshold.
    """
    proposal_id:      str
    signals:          List[IntentSignal]
    composite_score:  float
    mode:             TriadMode
    verdict:          str          # "PASS", "CONCERN", "BLOCK"
    concerns:         List[str]    # named concerns even in ADVISORY mode
    advisory_note:    str
    checked_at:       float = field(default_factory=time.time)
    contract_version: str   = LABYRINTH_CONTRACT_VERSION

    @property
    def has_concerns(self) -> bool:
        return len(self.concerns) > 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "proposal_id":     self.proposal_id,
            "composite_score": round(self.composite_score, 4),
            "mode":            self.mode.value,
            "verdict":         self.verdict,
            "concerns":        self.concerns,
            "advisory_note":   self.advisory_note,
            "signals":         [
                {"dimension": s.dimension.value,
                 "score": round(s.score, 4),
                 "confidence": round(s.confidence, 4),
                 "reasoning": s.reasoning}
                for s in self.signals
            ],
            "checked_at":      self.checked_at,
            "contract_version": self.contract_version,
        }


# ---- TRIAD CHECKER ----------------------------------------------------------

class TriadIntentCheck:
    """
    Evaluates proposals on the Sun Tzu axis: long-term system health.

    Currently operates in ADVISORY mode. Scores proposals but does not
    block them. After A015 (betti_1 calibration with live data), promote
    to VOTING mode to give the triad a real vote in council decisions.

    Usage
    -----
        triad = TriadIntentCheck()
        assessment = triad.evaluate(
            proposal_id="prop-001",
            proposal_text="Simplify the gate by removing the Merkle check.",
            tau=0.82,
            betti_1=0.02,
            confidence=0.88,
        )
        if assessment.has_concerns:
            # Log concerns even in ADVISORY mode
    """

    def __init__(self, mode: TriadMode = TriadMode.ADVISORY) -> None:
        self.mode = mode
        self._evaluations: int = 0
        self._concerns_raised: int = 0

    def evaluate(
        self,
        proposal_id: str,
        proposal_text: str = "",
        tau: float = 0.80,
        betti_1: float = 0.0,
        confidence: float = 0.80,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> TriadAssessment:
        """
        Evaluate a proposal on all seven intent dimensions.

        Parameters
        ----------
        proposal_id:    ID of the proposal being evaluated.
        proposal_text:  Full text of the proposal (for keyword analysis).
        tau:            Epistemic escape value from sigma anchor readings.
        betti_1:        Topological loop count (0.0 = placeholder, awaiting A015).
        confidence:     Confidence score from gate evaluation.
        metadata:       Optional additional context.

        Returns
        -------
        TriadAssessment with dimension scores and advisory note.
        """
        self._evaluations += 1
        text_lower = proposal_text.lower()

        # ---- Score each dimension ----------------------------------------
        signals = [
            self._score_auditability(text_lower, metadata),
            self._score_trust_integrity(text_lower, tau),
            self._score_gate_health(text_lower, tau),
            self._score_reversibility(text_lower),
            self._score_scope_discipline(text_lower, betti_1),
            self._score_debt_awareness(text_lower),
            self._score_alignment(text_lower, confidence),
        ]

        # ---- Weighted composite --------------------------------------------
        total_weight = sum(_DIMENSION_WEIGHTS[s.dimension] for s in signals)
        weighted_sum = sum(
            s.score * _DIMENSION_WEIGHTS[s.dimension] for s in signals
        )
        composite = weighted_sum / total_weight if total_weight > 0 else 0.5

        # ---- Identify concerns ---------------------------------------------
        concerns = []
        for signal in signals:
            if signal.score < 0.4:
                concerns.append(
                    f"{signal.dimension.value}: score={signal.score:.2f} -- {signal.reasoning}"
                )

        if concerns:
            self._concerns_raised += 1

        # ---- Verdict (ADVISORY: always PASS but records concerns) ---------
        if self.mode == TriadMode.ADVISORY:
            verdict = "CONCERN" if concerns else "PASS"
            advisory_note = (
                "ADVISORY MODE: triad records concerns but does not block. "
                "Promote to VOTING mode after A015 calibration."
            ) if concerns else "ADVISORY MODE: no concerns raised."
        elif self.mode == TriadMode.VOTING:
            if composite < 0.35:
                verdict = "BLOCK"
            elif composite < 0.55 or concerns:
                verdict = "CONCERN"
            else:
                verdict = "PASS"
            advisory_note = f"VOTING MODE: composite={composite:.3f}"
        else:
            verdict = "PASS"
            advisory_note = "DISABLED"

        return TriadAssessment(
            proposal_id=proposal_id,
            signals=signals,
            composite_score=composite,
            mode=self.mode,
            verdict=verdict,
            concerns=concerns,
            advisory_note=advisory_note,
        )

    # ---- Dimension scorers -------------------------------------------------

    def _score_auditability(
        self, text: str, metadata: Optional[Dict]
    ) -> IntentSignal:
        score = 0.85  # default: assume most proposals preserve auditability
        reasoning = "No auditability concerns detected."
        negative_phrases = [
            "remove logging", "disable ledger", "skip audit",
            "no record", "bypass chronicle", "delete history",
            "clear log", "remove trace",
        ]
        for phrase in negative_phrases:
            if phrase in text:
                score = 0.15
                reasoning = f"Proposal appears to reduce auditability: '{phrase}'"
                break
        return IntentSignal(
            IntentDimension.AUDITABILITY, score, 0.7, reasoning
        )

    def _score_trust_integrity(self, text: str, tau: float) -> IntentSignal:
        score = min(1.0, tau / TAU_ESCAPE_FLOOR) * 0.9
        reasoning = f"tau={tau:.3f} (floor={TAU_ESCAPE_FLOOR})"
        degrading = [
            "weaken gate", "lower threshold", "reduce confidence",
            "bypass verification", "skip validation", "remove check",
        ]
        for phrase in degrading:
            if phrase in text:
                score = min(score, 0.20)
                reasoning = f"Proposal weakens trust mechanism: '{phrase}'"
                break
        return IntentSignal(
            IntentDimension.TRUST_INTEGRITY, round(score, 3), 0.7, reasoning
        )

    def _score_gate_health(self, text: str, tau: float) -> IntentSignal:
        score = 0.80
        if tau >= TAU_ESCAPE_FLOOR + 0.10:
            score = 0.90
        elif tau < TAU_ESCAPE_FLOOR:
            score = 0.40
        reasoning = f"Gate signals healthy: tau={tau:.3f}"
        gate_risk = [
            "modify gate", "change gate logic", "update sigma anchor",
            "alter threshold", "gate bypass", "skip gate",
        ]
        for phrase in gate_risk:
            if phrase in text:
                score = min(score, 0.25)
                reasoning = f"Proposal modifies gate logic: '{phrase}'"
                break
        return IntentSignal(
            IntentDimension.GATE_HEALTH, round(score, 3), 0.75, reasoning
        )

    def _score_reversibility(self, text: str) -> IntentSignal:
        score = 0.75  # neutral default
        irreversible = [
            "permanent", "irreversible", "cannot be undone", "delete permanently",
            "purge", "destroy", "overwrite",
        ]
        reversible = [
            "rollback", "revert", "undo", "temporary", "trial",
            "experiment", "can be reversed",
        ]
        for phrase in irreversible:
            if phrase in text:
                score = 0.30
                break
        for phrase in reversible:
            if phrase in text:
                score = min(1.0, score + 0.20)
        reasoning = f"Reversibility score: {score:.2f}"
        return IntentSignal(
            IntentDimension.REVERSIBILITY, round(score, 3), 0.6, reasoning
        )

    def _score_scope_discipline(self, text: str, betti_1: float) -> IntentSignal:
        # betti_1 = 0.0 is placeholder -- can't use it yet
        if betti_1 == 0.0:
            score = 0.70  # neutral when placeholder
            reasoning = "betti_1=0.0 (BETTI_PLACEHOLDER -- A015 calibration pending)"
        else:
            # Higher betti_1 = more loops = less scope discipline
            score = max(0.1, 1.0 - (betti_1 / BETTI_1_CAP))
            reasoning = f"betti_1={betti_1:.4f} (cap={BETTI_1_CAP})"
        scope_issues = [
            "expand scope", "add more", "while we're at it",
            "also change", "and also modify",
        ]
        for phrase in scope_issues:
            if phrase in text:
                score = min(score, 0.40)
                reasoning += f" | scope expansion detected: '{phrase}'"
                break
        return IntentSignal(
            IntentDimension.SCOPE_DISCIPLINE, round(score, 3), 0.5, reasoning
        )

    def _score_debt_awareness(self, text: str) -> IntentSignal:
        score = 0.75
        debt_phrases = [
            "todo", "fixme", "hack", "workaround", "temporary fix",
            "will fix later", "tech debt", "skip for now",
        ]
        for phrase in debt_phrases:
            if phrase in text:
                score = 0.45
                break
        clean_phrases = [
            "clean", "refactor", "improve", "simplify properly",
            "document", "test coverage",
        ]
        for phrase in clean_phrases:
            if phrase in text:
                score = min(1.0, score + 0.15)
        return IntentSignal(
            IntentDimension.DEBT_AWARENESS, round(score, 3), 0.5,
            f"Debt awareness: {score:.2f}"
        )

    def _score_alignment(self, text: str, confidence: float) -> IntentSignal:
        score = min(1.0, confidence / CONFIDENCE_FLOOR) * 0.85
        aligned = [
            "constitutional", "gate enforces", "aligned with",
            "serves the system", "improves safety",
        ]
        misaligned = [
            "circumvent", "workaround", "avoid the gate",
            "skip validation", "not important",
        ]
        for phrase in aligned:
            if phrase in text:
                score = min(1.0, score + 0.15)
        for phrase in misaligned:
            if phrase in text:
                score = max(0.0, score - 0.40)
        reasoning = f"Alignment with system purpose: conf={confidence:.3f}"
        return IntentSignal(
            IntentDimension.ALIGNMENT, round(score, 3), 0.65, reasoning
        )

    @property
    def stats(self) -> Dict[str, int]:
        return {
            "evaluations":    self._evaluations,
            "concerns_raised": self._concerns_raised,
        }


# ---- MODULE-LEVEL DEFAULT ---------------------------------------------------
LABYRINTH_TRIAD = TriadIntentCheck(mode=TriadMode.ADVISORY)


# ---- TEST SUITE -------------------------------------------------------------

def _test_clean_proposal_passes() -> bool:
    triad = TriadIntentCheck(mode=TriadMode.ADVISORY)
    a = triad.evaluate("test-001", "Improve the archive query performance.", tau=0.85)
    assert a.composite_score > 0.5
    assert a.verdict in ("PASS", "CONCERN")
    return True


def _test_gate_bypass_raises_concern() -> bool:
    triad = TriadIntentCheck(mode=TriadMode.ADVISORY)
    a = triad.evaluate("test-002",
        "We should bypass verification and skip gate checks for speed.",
        tau=0.85)
    assert a.has_concerns
    assert any("TRUST_INTEGRITY" in c or "GATE_HEALTH" in c for c in a.concerns)
    return True


def _test_advisory_mode_never_blocks() -> bool:
    triad = TriadIntentCheck(mode=TriadMode.ADVISORY)
    # Even a terrible proposal doesn't block in ADVISORY mode
    a = triad.evaluate("test-003",
        "Remove logging, bypass verification, modify gate logic permanently.",
        tau=0.70)
    assert a.verdict != "BLOCK"
    assert "ADVISORY" in a.advisory_note
    return True


def _test_voting_mode_can_block() -> bool:
    triad = TriadIntentCheck(mode=TriadMode.VOTING)
    a = triad.evaluate("test-004",
        "Remove audit logging and disable the ledger permanently.",
        tau=0.71)
    # Low composite score should trigger BLOCK or CONCERN in VOTING
    assert a.verdict in ("BLOCK", "CONCERN")
    return True


def _test_seven_signals_always_produced() -> bool:
    triad = TriadIntentCheck()
    a = triad.evaluate("test-005", "Normal proposal.", tau=0.82)
    assert len(a.signals) == 7
    dims = {s.dimension for s in a.signals}
    assert len(dims) == 7  # all unique
    return True


def _test_betti_placeholder_handled() -> bool:
    triad = TriadIntentCheck()
    # betti_1 = 0.0 should not cause errors or extreme scores
    a = triad.evaluate("test-006", "Normal proposal.", tau=0.82, betti_1=0.0)
    scope_signal = next(
        (s for s in a.signals if s.dimension == IntentDimension.SCOPE_DISCIPLINE),
        None
    )
    assert scope_signal is not None
    assert 0.0 <= scope_signal.score <= 1.0
    assert "BETTI_PLACEHOLDER" in scope_signal.reasoning
    return True


def _test_to_dict_serializable() -> bool:
    import json
    triad = TriadIntentCheck()
    a = triad.evaluate("test-007", "Normal proposal.", tau=0.82)
    json.dumps(a.to_dict())
    return True


def _test_stats_tracking() -> bool:
    triad = TriadIntentCheck()
    triad.evaluate("t1", "Normal proposal.")
    triad.evaluate("t2", "Remove logging permanently.")
    assert triad.stats["evaluations"] == 2
    return True


def _test_composite_score_in_range() -> bool:
    triad = TriadIntentCheck()
    a = triad.evaluate("t3", "Some proposal text.", tau=0.82, confidence=0.85)
    assert 0.0 <= a.composite_score <= 1.0
    return True


def _test_module_level_instance() -> bool:
    assert isinstance(LABYRINTH_TRIAD, TriadIntentCheck)
    assert LABYRINTH_TRIAD.mode == TriadMode.ADVISORY
    return True


# Fix reference in test
TriadDimension = IntentDimension


def run_tests():
    tests = [
        (_test_clean_proposal_passes,      "clean_passes"),
        (_test_gate_bypass_raises_concern, "gate_bypass_concern"),
        (_test_advisory_mode_never_blocks, "advisory_no_block"),
        (_test_voting_mode_can_block,      "voting_can_block"),
        (_test_seven_signals_always_produced, "seven_signals"),
        (_test_betti_placeholder_handled,  "betti_placeholder"),
        (_test_to_dict_serializable,       "to_dict"),
        (_test_stats_tracking,             "stats"),
        (_test_composite_score_in_range,   "score_in_range"),
        (_test_module_level_instance,      "module_instance"),
    ]
    passed = failed = 0
    for fn, name in tests:
        try:
            fn()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"    FAIL {name}: {e}")
    return passed, failed, []
