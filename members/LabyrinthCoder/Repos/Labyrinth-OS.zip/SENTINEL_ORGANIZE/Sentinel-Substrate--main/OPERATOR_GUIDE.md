# Operator Guide — Labyrinth-OS

**Who this is for:** Someone who wants to actually run Labyrinth-OS.
No technical background assumed beyond being able to run a command.

---

## What This System Does

You have an LLM (like Claude or GPT). You want to use it to do things.
The problem: LLMs can be wrong, inconsistent, or manipulated.

Labyrinth-OS sits between you and the LLM.
The LLM suggests. Labyrinth-OS decides whether to act on it.

Think of it like this:
- LLM = a smart consultant who proposes ideas
- Labyrinth-OS = the compliance and legal team that checks every proposal before it executes

The consultant can say anything. Nothing executes until Labyrinth-OS approves it.

---

## What Labyrinth-OS Guarantees

**It will:**
- Log every decision permanently (can't be deleted or changed)
- Detect if logs are tampered with
- Let you replay any past session and get identical results
- Block any execution that fails its safety checks
- Stop hard (not warn, not log — actually stop) if the pipeline is violated

**It will not:**
- Guarantee the LLM is right
- Guarantee it catches every possible bad output
- Replace human judgment on important decisions

---

## What It Does NOT Guarantee

- That the LLM produces good outputs (it just checks them)
- That it catches sophisticated attacks it hasn't seen before
- Production reliability (this is a prototype — see below)

---

## Prototype Status

This system is a prototype. That means:

- The core pipeline is proven and tested (1,556 tests, 0 failures)
- The Rust enforcement layer compiles and passes tests
- The mock run works end-to-end
- **A real API run (A010) has not been done yet** — that's the next step

One thing to know: when you run it for the first time with a real API key,
that's called A010. Everything has been built toward that moment.

**What's new in the architecture (May 2026):**

- **Two verification axes** — the gate now runs Sigma Anchor channels (sensor)
  AND a predicate layer (LogicalSentinel, Z3 Φ1/Φ2/Φ3) simultaneously.
  Both must pass. Neither is sufficient alone.
- **Real epistemic labeling** — every trial response is labeled by EpistemicLabeler
  (SPECULATIVE / DEFERRED / UNKNOWN) and recorded in the session chain.
- **Constitutional deadlock resolution** — CircuitBreaker (CLOSED/HALF_OPEN/OPEN)
  and DegradationDetector (HEALTHY/WARNING/ANOMALY) now guard against
  consecutive BLOCK storms and watcher oscillation.
- **EBF native filter** — promotion Rule 6 now checks reasoning polarity
  (contradiction pairs, certainty overstatement, hedged certainty).
- **PROMOTION_RACE (CLASS-11)** — two proposals with the same label_id
  arriving simultaneously both get blocked.
- **Exact replay only** — EQUIVALENT replay mode removed. Missing chain_entries
  now raises SystemError rather than returning a weak PASS.

---

## Before You Run

**Requirements:**
- Python 3.10+
- One of: Anthropic API key, OpenAI API key, or Ollama running locally

**Verify everything works first:**
```bash
python run_all.py
```
You should see: `✓ ALL TESTS PASS  (Python: 1556  Rust: 249  Total: 1700+)`

---

## Running It

**Step 1: Mock run (no API key needed)**

Proves the pipeline works without spending money or needing a key:
```bash
python runtime/ignition.py --backend mock --model mock-model-v1 --trials 5
```

You'll see 5 trials execute. Each one shows: decision, severity, confidence.
At the end: `A010: PATH VALIDATED (mock) — not closed, real API required`

**Step 2: Check the results**
```bash
python runtime/verify_run.py ignition_session_<timestamp>.json
python runtime/a010_monitor.py ignition_session_<timestamp>.json
```

The monitor tells you what the signals mean and what to watch for.

**Step 3: Real run (closes A010)**
```bash
export ANTHROPIC_API_KEY=your_key_here
python runtime/ignition.py --backend anthropic --model claude-sonnet-4-20250514 --trials 5
python runtime/verify_run.py ignition_session_<timestamp>.json
python runtime/a010_monitor.py ignition_session_<timestamp>.json
```

---

## What You'll See During a Run

Each trial prints something like:
```
Trial 01  decision=EXECUTE  sev=INFO  conf=0.85  KL=0.03  logprobs=✓
```

**decision:** EXECUTE means it passed. BLOCK means it was stopped.
**sev:** INFO is fine. WARNING is watch it. ERROR/CRITICAL means something failed.
**conf:** Confidence 0.0-1.0. Below 0.65 will be blocked.
**KL:** How different this output was from what was expected. Low is good.
**logprobs:** ✓ means we got real probability data. ✗ means fallback estimation.

---

## What to Watch For (A010 Signal Guide)

| Signal | What It Means | What To Do |
|--------|--------------|------------|
| confidence < 0.65 consistently | Logprob extraction failing | Check your API connection |
| severity = CRITICAL | Tau collapsed or chi too high | Stop. Don't retry without understanding why. |
| chain_valid = False | Replay integrity broken | Reject this run entirely |
| All BLOCK decisions | Gate threshold may need calibration | Review sigma anchor values |
| All EXECUTE decisions | Gate may not be checking correctly | Verify gate is actually running |

---

## What Happens After a Run

Two files are written:
- `ignition_session_<ts>.json` — full session record
- `feedback_<ts>.json` — outcome record used in future promotion decisions

These never get deleted. The system learns from failures.

---

## If Something Goes Wrong

**"PIPELINE VIOLATION — IGNITION HALTED"**
A mandatory stage was skipped or failed. This is a hard stop — intentional.
The message will tell you which stage failed.
Fix the stage. Don't try to work around it.

**"HASH MISMATCH"**
A ledger entry was tampered with or corrupted.
Do not use data from this run. Investigate the file.

**"A010: PATH VALIDATED (mock)"**
You ran with `--backend mock`. That's the dry-run mode.
Use `--backend anthropic` (or openai/ollama) for a real run.

---

## The Rules (Short Version)

1. Every input gets labeled before anything else
2. Everything gets archived — nothing is deleted
3. Nothing executes without passing promotion and the reality gate
4. Everything that executes gets logged in a tamper-proof ledger
5. Everything logged can be replayed identically

Break any of these and the system stops. That's by design.

---

## Roadmap — What Comes After A010

1. **A010** — First real inference run (you're here)
2. **A011** — Real logprob data (needs OpenAI or Ollama for logprobs)
3. **A013** — SCUEL classification on live traffic (closes after 100+ real events)
4. **Phase 2** — Multi-sentinel on one machine
5. **Phase 3** — Multi-node distributed deployment
6. **Phase 5** — Hardware enforcement (FPGA + hardware root of trust)

Full details: `ROADMAP.md`

---


---

## Sharing This System With Other AIs

If you are feeding Labyrinth-OS to another AI system for review or analysis,
use the manifest-first workflow to avoid burning unnecessary context tokens.

**Three files to know:**

`Labyrinth-OS-Manifest.txt` (17KB)
The navigational index. Feed this first. The AI can orient itself, understand
the architecture, and identify which source files it actually needs.

`Labyrinth-OS.txt.zst` (475KB)
The full system compressed. 5.8x smaller than the plain TXT. Upload this;
decompress it in the same session; work with the content. Requires `pip install zstandard`.

`OPT4_manifest_plus_chunks.zip`
The system split into 10 layer chunks, each independently decompressable.
Manifest is the entry point. Pull only the layer relevant to the question.
Typical targeted review: 100-200KB instead of 2,749KB.

**Decompress in one line:**
```python
import base64, zstandard as zstd
lines = open("CHUNK_FILE.txt").readlines()
b64 = "".join(l.strip() for l in lines if not l.startswith("#") and l.strip())
text = zstd.ZstdDecompressor().decompress(base64.b64decode(b64)).decode()
```

## Questions

**"Can I trust the output?"**
Labyrinth-OS enforces the process, not the answer. It guarantees the LLM's output
went through the pipeline. It does not guarantee the output is correct.

**"What if the LLM lies convincingly?"**
That's what the SCUEL tests are for. POLITE_LIE detection is built in.
But live detection requires real traffic — that's A013.

**"Is this production-ready?"**
No. It's a prototype. The pipeline is proven. Hardware enforcement is not.
Use it for research, testing, and building toward production.

**"Who maintains this?"**
X: @LabyrinthCoder
