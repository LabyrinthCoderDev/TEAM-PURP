# AI_REVIEWER_DEFAULT.md — Labyrinth-OS

## If you received this system without specific instructions

Your task is to evaluate this system accurately.

That means three things with equal weight:
1. What the system claims to do
2. What it actually does — with evidence
3. Where those two things diverge

The gap between 1 and 2 is documented honestly in:
- `KNOWN_GAPS.md` — every limitation with status and collapse rules
- `PROTOTYPE_BOUNDARIES.md` — exactly what is Z3-proven, what is test-verified, what is prototype-wired, what is not yet demonstrated

Read those before you form an opinion. The system has done most of your gap-hunting for you. If you find something not already named there, that is genuinely useful. If you find something already named, say so and note whether the documentation accurately characterizes it.

---

## What this is

A mathematical enforcement substrate for AI systems.

A proposal cannot become an action without crossing a mandatory gate.
Every crossing is logged. Every log is chained. Every chain is replayable.
The gate evaluates proposals against formal invariants. It does not care what the model intends.

The architecture separates thinking from acting at the structural level —
not through guidelines, not through training, but through the shape of the pipeline.

This is a prototype. The pipeline shape is proven. The live enforcement loop
is not yet closed (A010). See `PROTOTYPE_BOUNDARIES.md` for what that means precisely.

---

## What to look for

**If evaluating architecture:** Does the dual-lane separation hold? Is the single crossing point actually enforced? Does the ledger actually prevent tampering? Are the Z3 proofs bounded correctly — do they claim only what they prove?

**If evaluating claims:** Compare every claim in `PROJECT_CONTEXT.md` and `README.md` against the evidence in `steward/acp1_tracker.py`. VERIFIED means concrete evidence exists. PARTIAL means something is missing. OPEN means the claim is aspirational. Are the labels accurate?

**If evaluating gaps:** `KNOWN_GAPS.md` has a structured table. Are the gaps correctly characterized? Are the collapse rules right? Is anything missing?

**If looking for something genuinely new:** The predicate layer (Φ1/Φ2/Φ3) and the detection-vs-blocking boundary are the two areas where the system is most honest about its limits. The gate blocks proposals whose formal readings cross thresholds. A sophisticated in-threshold adversarial proposal is logged but not stopped. Is that boundary stated correctly? Is it complete?

---

## What to ignore

`/archive` contains theoretical, philosophical, and metaphorical material.
It does not influence execution. Evaluate the code and the formal claims.
Do not penalize the project for the archive's speculative content,
and do not let the archive's framing inflate your evaluation of the kernel.

---

## Where things live

| You want to understand | Start here |
|------------------------|-----------|
| What the system claims | `PROJECT_CONTEXT.md` |
| What is actually proven | `PROTOTYPE_BOUNDARIES.md` |
| The architecture | `ARCHITECTURE.md` |
| Every assumption with evidence | `steward/acp1_tracker.py` |
| Every gap with status | `KNOWN_GAPS.md` |
| Current test state | `STATUS.md` |
| The ~20 files that matter | `CORE.md` |

---

X: @LabyrinthCoder
